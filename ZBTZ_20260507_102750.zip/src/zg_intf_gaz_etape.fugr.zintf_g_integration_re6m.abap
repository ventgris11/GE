FUNCTION zintf_g_integration_re6m .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  TYPES : BEGIN OF ty_etrg,
            abrvorg  TYPE abrvorg,
            adatsoll TYPE adatsoll,
          END OF ty_etrg.
  TYPES : BEGIN OF ty_eabl,
            ablbelnr TYPE ablbelnr,
            adattats TYPE adattats,
            adatsoll TYPE adatsoll,
          END OF ty_eabl.

  DATA: lc_field_num_pce      TYPE fieldname VALUE 'NUM_PCE',
        lc_field_date_releve  TYPE fieldname VALUE 'DATE_RELEVE',
        lc_field_motif_releve TYPE fieldname VALUE 'MOTIF_RELEVE',
        lc_field_statut       TYPE fieldname VALUE 'STATUT',
        lc_field_flux         TYPE fieldname VALUE 'FLUX',
        lv_field              TYPE string,
        lv_int_ui             TYPE int_ui,
        lv_anlage             TYPE anlage,
        ls_object             TYPE eedm_isu_objects,
        ls_canc_param         TYPE isu21_canc_param,
        lt_anlage             TYPE isu_t_eanlkey_h,
        lv_instdata           TYPE isu2a_instdata,
        lt_idispdata          TYPE isu_bi_inst_dispdata_tab,
        lv_idispdata          TYPE isu_bi_inst_dispdata,
        lt_ianl_bdoc          TYPE isu_bi_inst_billdoc_disp_tab,
        lv_ianl_bdoc          TYPE isu_bi_inst_billdoc_disp,
        ls_iabl               TYPE isu_bi_inst_eabl_disp,
        lt_insttab            TYPE isu17_meterdocu_insttab,
        ls_insttab            TYPE isu17_meterdocu_inst,
        ls_obj                TYPE isu17_meterread,
        ls_etrg               TYPE ty_etrg,
        lt_etrg               TYPE TABLE OF ty_etrg,
        lt_eabl               TYPE TABLE OF ty_eabl,
        ls_eabl               TYPE ty_eabl,
        ls_eabl_integration   TYPE eabl,
        lt_iabl               TYPE isu_bi_inst_eabl_disp_tab,
        lt_auto               TYPE  isu17_meterread_auto,
        lv_energie_entier     TYPE v_zwstand,
        lv_energie_decimal    TYPE n_zwstand,
        lt_mr_data            TYPE TABLE OF bapieabl,
        ls_mr_data            TYPE bapieabl,
        lt_mr_reason          TYPE TABLE OF bapieablg,
        lv_message            TYPE char255,
        lv_subobj             TYPE balsubobj,
        lv_date_dbt_or        TYPE dats,
        lv_date_fin_or        TYPE dats
        .

  CLEAR : ls_eabl_integration,
          lv_energie_entier,
          lv_energie_decimal.




  FIELD-SYMBOLS: <fs_num_pce>, <fs_date_releve>, <fs_motif_releve>, <fs_motif_statut>, <fs_flux>.
  FIELD-SYMBOLS: <fs_re6m> TYPE zintf_g_re6m.

  ASSIGN flux TO <fs_re6m>.

  lv_energie_entier = trunc( <fs_re6m>-index_brut_fin_periode ).
  lv_energie_decimal = frac( <fs_re6m>-index_brut_fin_periode ).

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_flux INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.
  IF <fs_flux> IS NOT ASSIGNED.
  ENDIF.


  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.
  IF <fs_num_pce> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_releve>.
  IF <fs_date_releve> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_motif_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_motif_releve>.
  IF <fs_motif_releve> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_statut INTO lv_field.
  ASSIGN (lv_field) TO <fs_motif_statut>.
  IF <fs_motif_statut> IS NOT ASSIGNED.
  ENDIF.

  IF <fs_flux> = 'RE6M'.
    lv_subobj = zcl_tool=>gc_log_subobject_re6m.
  ELSE.
    lv_subobj = zcl_tool=>gc_log_subobject_remm.
  ENDIF.

* Pour récupération de INT_UI
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).
  IF lv_int_ui IS INITIAL.
  ENDIF.

* Pour récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.
  IF ls_object-installation IS INITIAL.
  ENDIF.

  lv_anlage = ls_object-installation.

  INSERT lv_anlage INTO TABLE lt_anlage.

  IF <fs_re6m>-motif_releve = '01'.
    " On vérifie si on ne dispose pas déja d'un historique de releve sur le point
    REFRESH: lt_mr_data, lt_mr_reason.
    lv_date_dbt_or = <fs_date_releve> - 12 .
    lv_date_fin_or = <fs_date_releve> + 12.
    CALL FUNCTION 'BAPI_MTRREADDOC_GETLIST'
      EXPORTING
        installation      = ls_object-installation
        mrdocumenttype    = '1' "Ordre de calc de facturation
        targetmrdatefrom  = lv_date_dbt_or
        targetmrdateto    = lv_date_fin_or
      TABLES
        mrdocumentdata    = lt_mr_data
        mrdocumentreasons = lt_mr_reason.

    READ TABLE lt_mr_data INTO ls_mr_data INDEX 1.
** Ouverture de l'objet relève
    CALL FUNCTION 'ISU_O_METERREAD_OPEN'
      EXPORTING
        "x_anlage              = lv_anlage
        x_adatsoll            = <fs_date_releve>
        x_action              = '01'
        x_ablbelnr            = ls_mr_data-mridnumber
        "x_ablesgr             = '02'
        x_wmode               = '2'
        x_select2             = '1'
        x_no_dialog           = 'X'
        x_upd_online          = 'X'
        x_no_enqueue          = 'X'
        "x_ebene               = 'I'
        x_auto                = lt_auto
      IMPORTING
        y_obj                 = ls_obj
      EXCEPTIONS
        not_found             = 1
        foreign_lock          = 2
        internal_error        = 3
        input_error           = 4
        existing              = 5
        number_error          = 6
        general_fault         = 7
        system_error          = 8
        manual_abort          = 9
        gasdat_not_found      = 10
        no_mrrel_registers    = 11
        internal_warning      = 12
        not_authorized        = 13
        not_qualified         = 14
        anpstorno_not_allowed = 15
        already_billed        = 16
        OTHERS                = 17.
    IF NOT sy-subrc IS INITIAL.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
          INTO lv_message
          WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      zcl_tool=>log_add_msg( EXPORTING iv_log_object = zcl_tool=>gc_log_object_intf_gaz
                                       iv_log_subobject = lv_subobj
                                       iv_test_mode = iv_mode_test
                             CHANGING  cv_log_handle = cv_log_handle ).
      ev_etape = 2.
      RETURN.
    ENDIF.
    "" ENDIF.

  ELSEIF <fs_re6m>-motif_releve = '02'.
** Ouverture de l'objet relève
    CALL FUNCTION 'ISU_O_METERREAD_OPEN'
      EXPORTING
        x_anlage              = lv_anlage
        x_adatsoll            = <fs_date_releve>
        x_action              = '01'
        x_ablesgr             = '02'
        x_wmode               = '3'
        x_no_dialog           = 'X'
        x_upd_online          = 'X'
        x_no_enqueue          = 'X'
        x_ebene               = 'I'
        x_auto                = lt_auto
      IMPORTING
        y_obj                 = ls_obj
      EXCEPTIONS
        not_found             = 1
        foreign_lock          = 2
        internal_error        = 3
        input_error           = 4
        existing              = 5
        number_error          = 6
        general_fault         = 7
        system_error          = 8
        manual_abort          = 9
        gasdat_not_found      = 10
        no_mrrel_registers    = 11
        internal_warning      = 12
        not_authorized        = 13
        not_qualified         = 14
        anpstorno_not_allowed = 15
        already_billed        = 16
        OTHERS                = 17.
    IF NOT sy-subrc IS INITIAL.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                INTO lv_message
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      zcl_tool=>log_add_msg( EXPORTING iv_log_object = zcl_tool=>gc_log_object_intf_gaz
                                       iv_log_subobject = lv_subobj
                                       iv_test_mode = iv_mode_test
                             CHANGING  cv_log_handle = cv_log_handle ).
      ev_etape = 2.
      RETURN.
    ENDIF.

  ELSE.

    "MFO Cas si pas 01 ou pas 02 ==> erreur
    ev_etape = 2.
    RETURN.

  ENDIF.

  READ TABLE ls_obj-ieabl INTO ls_eabl_integration INDEX 1.
  IF sy-subrc <> 0.
    ev_etape = 2.
    RETURN.
  ENDIF.
  "MFO
  "ls_eabl_integration-adatsoll         = <fs_re6m>-date_releve.
  ls_eabl_integration-adattats         = <fs_re6m>-date_releve.
  ls_eabl_integration-adat             = <fs_re6m>-date_releve.
  "MFO
  ls_eabl_integration-zwnummer         = 1.
  ls_eabl_integration-v_zwstand        = lv_energie_entier.
  ls_eabl_integration-n_zwstand        = lv_energie_decimal.
  ls_eabl_integration-v_zwstndab       = lv_energie_entier.
  ls_eabl_integration-n_zwstndab       = lv_energie_decimal.

  ls_eabl_integration-zztype_rel              = <fs_re6m>-type_releve.
  ls_eabl_integration-zzraison_rel            = <fs_re6m>-raison_releve.
  ls_eabl_integration-zzdate_debut            = <fs_re6m>-debut_periode.
  ls_eabl_integration-zzindex_brut_debut      = <fs_re6m>-index_brut_debut_periode.
  ls_eabl_integration-zzqual_index_brut_debut = <fs_re6m>-qual_index_brut_debut_periode.
  ls_eabl_integration-zzdate_fin              = <fs_re6m>-fin_periode.
  ls_eabl_integration-zzqual_index_brut_fin   = <fs_re6m>-qual_index_brut_fin_periode.
  ls_eabl_integration-zzvolume_brut           = <fs_re6m>-vol_brut_conso.
  ls_eabl_integration-zzqual_volume_brut      = <fs_re6m>-qualif_vol_brut_conso.
  ls_eabl_integration-zzenergie               = <fs_re6m>-energie_conso.
  ls_eabl_integration-zzqualif_energie        = <fs_re6m>-qualif_energie_conso.
  ls_eabl_integration-zzmotif_corr            = <fs_re6m>-motif_correction.
  ls_eabl_integration-zzorig_corr             = <fs_re6m>-origine_correction.
  IF <fs_re6m>-qual_index_brut_fin_periode = 'E'.
    ls_eabl_integration-istablart               = 'Z4'.
    ls_eabl_integration-ablestyp                = '01'.
  ELSE.
    ls_eabl_integration-istablart               = '01'.
    ls_eabl_integration-ablestyp                = '01'.
  ENDIF.

  ls_eabl_integration-ablstat                 = '1'.
  ls_eabl_integration-zzidenreg               = <fs_re6m>-idenreg.

*Ajout du notice agent Z4
  IF ls_eabl_integration-zzvolume_brut < 0.
    ls_eabl_integration-ABLHINW = 'Z4'.
  ENDIF.

  MODIFY ls_obj-ieabl  FROM ls_eabl_integration  INDEX 1.



  CALL FUNCTION 'ISU_O_METERREAD_OPEN_SUBOBJ'
    EXPORTING
      x_action   = '01'
      x_auto     = lt_auto
      x_adatsoll = <fs_date_releve>
    CHANGING
      xy_obj     = ls_obj
*       EXCEPTIONS
*     NOT_FOUND  = 1
*     FOREIGN_LOCK               = 2
*     INTERNAL_ERROR             = 3
*     INPUT_ERROR = 4
*     EXISTING   = 5
*     NUMBER_ERROR               = 6
*     GENERAL_FAULT              = 7
*     SYSTEM_ERROR               = 8
*     MANUAL_ABORT               = 9
*     OTHERS     = 10
    .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  CALL FUNCTION 'ISU_O_METERREAD_INPUT'
    CHANGING
      xy_obj = ls_obj
    EXCEPTIONS
      OTHERS = 99.
  IF NOT sy-subrc IS INITIAL.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              INTO lv_message
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    zcl_tool=>log_add_msg( EXPORTING iv_log_object = zcl_tool=>gc_log_object_intf_gaz
                                     iv_log_subobject = lv_subobj
                                     iv_test_mode = iv_mode_test
                           CHANGING  cv_log_handle = cv_log_handle ).
    ev_etape = 2.
    RETURN.
  ENDIF.

* Préparation de la sauvegarde
  CALL FUNCTION 'ISU_O_METERREAD_ACTION'
    EXPORTING
      x_okcode             = 'PSAV'
    CHANGING
      xy_obj               = ls_obj
    EXCEPTIONS
      cancelled            = 1
      failed               = 2
      action_not_supported = 3
      system_error         = 4
      input_error          = 5
      not_customized       = 6
      OTHERS               = 7.
  IF NOT sy-subrc IS INITIAL.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              INTO lv_message
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    zcl_tool=>log_add_msg( EXPORTING iv_log_object = zcl_tool=>gc_log_object_intf_gaz
                                     iv_log_subobject = lv_subobj
                                     iv_test_mode = iv_mode_test
                           CHANGING  cv_log_handle = cv_log_handle ).
    ev_etape = 2.
    RETURN.
  ENDIF.
* sauvegarde
  CALL FUNCTION 'ISU_O_METERREAD_ACTION'
    EXPORTING
      x_okcode             = 'SAVE'
    CHANGING
      xy_obj               = ls_obj
    EXCEPTIONS
      cancelled            = 1
      failed               = 2
      action_not_supported = 3
      system_error         = 4
      input_error          = 5
      not_customized       = 6
      OTHERS               = 7.
  IF NOT sy-subrc IS INITIAL.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
          INTO lv_message
          WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    zcl_tool=>log_add_msg( EXPORTING iv_log_object = zcl_tool=>gc_log_object_intf_gaz
                                     iv_log_subobject = lv_subobj
                                     iv_test_mode = iv_mode_test
                           CHANGING  cv_log_handle = cv_log_handle ).
    ev_etape = 2.
    RETURN.
  ENDIF.

  CALL FUNCTION 'ISU_O_METERREAD_CLOSE'
    EXPORTING
      x_no_dialog = 'X'
*     X_DEQ_SYNC  = ' '
*     IMPORTING
*     Y_DB_UPDATE =
*     Y_EXIT_TYPE =
*     TABLES
*     YT_NEW_EABL =
*     YT_NEW_EABLG         =
*     YT_NEW_ETRG =
    CHANGING
      xy_obj      = ls_obj
*     EXCEPTIONS
*     NOT_CUSTOMIZED       = 1
*     FAILED      = 2
*     GENERAL_FAULT        = 3
*     OTHERS      = 4
    .
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              INTO lv_message
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    zcl_tool=>log_add_msg( EXPORTING iv_log_object = zcl_tool=>gc_log_object_intf_gaz
                                     iv_log_subobject = lv_subobj
                                     iv_test_mode = iv_mode_test
                           CHANGING  cv_log_handle = cv_log_handle ).
    ev_etape = 2.
    RETURN.
  ENDIF.


  "ENDIF.

  ev_etape = 1.

*  " Recherche des informations nécessaires aux différentes annulations
*  CALL FUNCTION 'ISU_INST_BIVIEW_SELECT'
*    EXPORTING
*      x_ab         = <fs_date_releve>
**     X_BIS        =
*      x_ianlkey    = lt_anlage
**     X_ONLY_MR    =
*    IMPORTING
*      y_instdata   = lv_instdata
*    CHANGING
*      xy_idispdata = lt_idispdata.
*
*  SELECT ablbelnr adattats adatsoll INTO TABLE lt_eabl
*    FROM eabl
*    FOR ALL ENTRIES IN lt_iabl
*    WHERE ablbelnr = lt_iabl-ablbelnr
*    AND   adatsoll GE <fs_date_releve>.
*  IF sy-subrc = 0.
*    ev_etape = 2.
*  ELSE.
** Suppression des ordres de calcul de facturation et ordre de relève MM 6M
** car se basant sur la table EABL des documents de relevé pour cadrans à index
*    LOOP AT lt_iabl INTO ls_iabl.
*      CLEAR ls_eabl.
*      READ TABLE lt_eabl INTO ls_eabl WITH KEY ablbelnr = ls_iabl-ablbelnr.
*      IF sy-subrc = 0.
*
*      ENDIF.
** Initialisation table interne
*      CLEAR lt_insttab[].
** Alimentation table interne pour appel module fonction
*      ls_insttab-anlage  = lv_anlage.
*      ls_insttab-ablesgr = ls_iabl-ablesgr.
*      APPEND ls_insttab TO lt_insttab.
** Ouverture de l'objet relève
*      CALL FUNCTION 'ISU_O_METERREAD_OPEN'
*        EXPORTING
*          x_anlage              = lv_anlage
*          x_equnr               = ls_iabl-equnr
*          x_adatsoll            = ls_eabl-adatsoll
*          x_ablesgr             = ls_iabl-ablesgr
*          x_select2             = '5'             "Ordres de relevé et Relevés
*          x_wmode               = '2'             "Modification
*          x_no_dialog           = 'X'
*          x_upd_online          = 'X'
*          x_no_enqueue          = 'X'
*        IMPORTING
*          y_obj                 = ls_obj
*        TABLES
*          xt_insttab            = lt_insttab
*        EXCEPTIONS
*          not_found             = 1
*          foreign_lock          = 2
*          internal_error        = 3
*          input_error           = 4
*          existing              = 5
*          number_error          = 6
*          general_fault         = 7
*          system_error          = 8
*          manual_abort          = 9
*          gasdat_not_found      = 10
*          no_mrrel_registers    = 11
*          internal_warning      = 12
*          not_authorized        = 13
*          not_qualified         = 14
*          anpstorno_not_allowed = 15
*          already_billed        = 16
*          OTHERS                = 17.
*      IF NOT sy-subrc IS INITIAL.
*        RETURN.
*      ENDIF.
*
*      CALL FUNCTION 'ISU_O_METERREAD_INPUT'
** EXPORTING
**   X_MAXERROR                 = 1
**   X_CORRECT                  = ' '
**   X_ONLY_FORMAL_CHECKS       = ' '
**   X_VALDEP_PARTLY            = ' '
** IMPORTING
**   Y_SUBSCR_CURSPOS           =
** TABLES
**   XYT_REABLD                 =
*        CHANGING
*          xy_obj             = ls_obj
*        EXCEPTIONS
*          input_error        = 1
*          not_valid          = 2
*          plausi_error       = 3
*          plausi_error_nocor = 4
*          system_error       = 5
*          not_complete       = 6
*          indep_implausible  = 7
*          not_authorized     = 8
*          OTHERS             = 9.
*      IF sy-subrc <> 0.
** Implement suitable error handling here
*      ENDIF.
*
** Préparation de l'annulation des ordres de relevés et des documents de relèves
*      CALL FUNCTION 'ISU_O_METERREAD_ACTION'
*        EXPORTING
*          x_okcode             = 'PSAV'
*        CHANGING
*          xy_obj               = ls_obj
*        EXCEPTIONS
*          cancelled            = 1
*          failed               = 2
*          action_not_supported = 3
*          system_error         = 4
*          input_error          = 5
*          not_customized       = 6
*          OTHERS               = 7.
*      IF NOT sy-subrc IS INITIAL.
*        RETURN.
*      ENDIF.
** Suppression des ordres de relevés, ordres de calcul de facturation
** et des résultats de relevés
*      CALL FUNCTION 'ISU_O_METERREAD_ACTION'
*        EXPORTING
*          x_okcode             = 'SAVE'
*        CHANGING
*          xy_obj               = ls_obj
*        EXCEPTIONS
*          cancelled            = 1
*          failed               = 2
*          action_not_supported = 3
*          system_error         = 4
*          input_error          = 5
*          not_customized       = 6
*          OTHERS               = 7.
*      IF NOT sy-subrc IS INITIAL.
*        RETURN.
*      ELSE.
*
*      ENDIF.
*    ENDLOOP.
*    ev_etape = 2.
*  ENDIF.

ENDFUNCTION.
