FUNCTION zintf_g_maj_pcs_pta .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
  DATA:


    lc_field_num_pce      TYPE fieldname VALUE 'NUM_PCE',
    lc_field_date_releve  TYPE fieldname VALUE 'DATE_RELEVE',
    lc_field_motif_releve TYPE fieldname VALUE 'MOTIF_RELEVE',
    lc_field_statut       TYPE fieldname VALUE 'STATUT',
    lc_field_date_deb     TYPE fieldname VALUE 'DEBUT_PERIODE',
    lc_field_emetteur     TYPE fieldname VALUE 'EMETTEUR',
    lc_field_flux         TYPE fieldname VALUE 'FLUX',
    lc_field_idenreg      TYPE fieldname VALUE 'IDENREG',
    lc_field_pcs          TYPE fieldname VALUE 'PCS',
    lc_field_pta          TYPE fieldname VALUE 'PTA',
    "MFO début
    lc_field_vol_brut     TYPE fieldname VALUE 'VOL_BRUT_CONSO',
    lc_field_vol_conv     TYPE fieldname VALUE 'VOLUME_CONV',
    lc_field_energie      TYPE fieldname VALUE 'ENERGIE_CONSO',
    "MFO Fin
    lc_pcs                TYPE e_operand VALUE 'GVFTPCS001',
    lc_pta                TYPE e_operand VALUE 'GVFTPTA001',
    lv_field              TYPE string,
    lv_int_ui             TYPE int_ui,
    lv_anlage             TYPE anlage,
    ls_object             TYPE eedm_isu_objects,
    obj                   TYPE  isu01_instln,
    lt_ettifn             TYPE TABLE OF ettifn,
    lt_ettifn_pcs         TYPE TABLE OF ettifn,
    ls_ettifn_pcs         TYPE  ettifn,
    ls_ettifn_pcs_new     TYPE  ettifn,
    lt_ettifn_pta         TYPE TABLE OF ettifn,
    ls_ettifn_pta         TYPE  ettifn,
    ls_ettifn_pta_new     TYPE  ettifn,
    lt_ettifn_delete      TYPE isu_iettifn,
    lt_ettifn_update      TYPE isu_iettifn,
    lv_wert1              TYPE e_wert1,
    lv_message            TYPE char255,
    lv_pcs                TYPE e_factor,
    lv_pta                TYPE e_factor,
    lv_energie            TYPE string,
    lv_vol_brut           TYPE string,
    lv_vol_conv           TYPE string,
    lv_post_mes           TYPE i,
    lv_post_pose           TYPE i,
    lt_eablg              TYPE TABLE OF eablg
    .

  FIELD-SYMBOLS: <fs_num_pce>, <fs_date_releve>, <fs_motif_releve>,
<fs_motif_statut>, <fs_date_deb>, <fs_pcs>, <fs_pta>, <fs_emetteur>, <fs_flux>, <fs_idenreg>,
<fs_vol_brut>, <fs_vol_conv>, <fs_energie>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_vol_brut INTO lv_field.
  ASSIGN (lv_field) TO <fs_vol_brut>.
  IF <fs_num_pce> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_vol_conv INTO lv_field.
  ASSIGN (lv_field) TO <fs_vol_conv>.
  IF <fs_num_pce> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_energie INTO lv_field.
  ASSIGN (lv_field) TO <fs_energie>.
  IF <fs_num_pce> IS NOT ASSIGNED.
  ENDIF.



  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.
  IF <fs_num_pce> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_releve>.
  IF <fs_date_releve> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_motif_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_motif_releve>.
  IF <fs_motif_releve> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_statut INTO lv_field.
  ASSIGN (lv_field) TO <fs_motif_statut>.
  IF <fs_motif_statut> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_deb INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_deb>.
  IF <fs_date_deb> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_pcs INTO lv_field.
  ASSIGN (lv_field) TO <fs_pcs>.
  IF <fs_pcs> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_pta INTO lv_field.
  ASSIGN (lv_field) TO <fs_pta>.
  IF <fs_pta> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_emetteur INTO lv_field.
  ASSIGN (lv_field) TO <fs_emetteur>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_flux INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_idenreg INTO lv_field.
  ASSIGN (lv_field) TO <fs_idenreg>.

* Pour récupération de INT_UI
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).
  IF lv_int_ui IS INITIAL.
  ENDIF.

* Pour récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.

  IF ls_object-installation IS INITIAL.
    MESSAGE e230(zintf_g_messages) INTO lv_message.
    ev_etape = 2.
    RETURN.
  ENDIF.

  SELECT *
  INTO TABLE lt_ettifn
  FROM ettifn
  WHERE anlage = ls_object-installation.

*GLI - 01/06/2016 - recherche de la relève post MES :
  lv_post_mes = 0.

  SELECT *
  INTO TABLE lt_eablg
  FROM eablg
  WHERE anlage = ls_object-installation
  and adatsoll = <fs_date_deb>
  and ablesgr = '06'.

  If sy-subrc NE 0.
    lv_post_mes = 0.
  else.
    lv_post_mes = 1.
  endif.

*GLI - 01/06/2016 - fin ajout

*GLI - 16/06/2016 - recherche de la relève pose :

  lv_post_pose = 0.


  SELECT *
  INTO TABLE lt_eablg
  FROM eablg
  WHERE anlage = ls_object-installation
  and adatsoll = <fs_date_deb>
  and ablesgr = '21'.

  If sy-subrc NE 0.
    lv_post_pose = 0.
  else.
    lv_post_pose = 1.
  endif.

*GLI - 16/06/2016 - fin ajout

** Mise à jour du PCS

    lt_ettifn_pcs[] = lt_ettifn[].
    DELETE lt_ettifn_pcs WHERE operand NE lc_pcs.
    IF lt_ettifn_pcs IS INITIAL.
MESSAGE e209(zintf_g_messages) WITH <fs_emetteur> <fs_flux> <fs_idenreg> 'PCS' INTO lv_message.
      ev_etape = 2.
      RETURN.
    ENDIF.
" Si date début ou PCS vide ne pas mettre à jour le PCS
  IF <fs_date_deb> IS INITIAL OR <fs_pcs> IS INITIAL.
    "Ne rien faire.
  ELSE.

    SORT lt_ettifn_pcs BY bis DESCENDING.

"on supprime les entrées qui ont une date de début supérieure ou égale à la date de début de la tranche à insérer
    LOOP AT lt_ettifn_pcs INTO ls_ettifn_pcs.
      IF ls_ettifn_pcs-ab GE <fs_date_deb>.
        APPEND ls_ettifn_pcs TO lt_ettifn_delete.
        DELETE TABLE lt_ettifn_pcs FROM ls_ettifn_pcs.
      ENDIF.
    ENDLOOP.

    IF lt_ettifn_delete IS NOT INITIAL.
      CALL FUNCTION 'ISU_DB_ETTIFN_UPDATE'
        EXPORTING
          x_upd_mode = 'D'
          x_iettifn  = lt_ettifn_delete.
    ENDIF.

    IF lt_ettifn_pcs IS NOT INITIAL.
      READ TABLE lt_ettifn_pcs INTO ls_ettifn_pcs INDEX 1.
    ENDIF.
    lv_energie = <fs_energie>.
    lv_vol_conv = <fs_vol_conv>.
    IF lv_vol_conv <> 0.
      lv_wert1 = lv_energie / lv_vol_conv.
    ELSE.
      lv_wert1 = <fs_pcs>.
    ENDIF.

    ls_ettifn_pcs_new = ls_ettifn_pcs.

*GLI - 01/06/2016 - Ajout + 1 :

    if lv_post_mes = 0.
      If lv_post_pose = 1.
        ls_ettifn_pcs_new-ab = <fs_date_deb>.
      ELSE.
        ls_ettifn_pcs_new-ab = <fs_date_deb> + 1.
      ENDIF.
    else.
      ls_ettifn_pcs_new-ab = <fs_date_deb>.
    endif.

*GLI - 01/06/2016 - fin

    ls_ettifn_pcs_new-wert1 = lv_wert1.
    ls_ettifn_pcs_new-bis = '99991231'.

*GLI - 01/06/2016 - modification pour prise en compte des MES en cours de vie d'une install (RES + MES) :
    if lv_post_mes = 0.
      If lv_post_pose = 1.
        ls_ettifn_pcs-bis = <fs_date_deb> - 1.
      ELSE.
        ls_ettifn_pcs-bis = <fs_date_deb>.
      ENDIF.
    else.
      ls_ettifn_pcs-bis = <fs_date_deb> - 1.
    endif.
*GLI - 01/06/2016 - fin

*  Ajout début BWF20151005
*  if ls_ettifn_pcs-bis lt  ls_ettifn_pcs_new-ab.
*    MESSAGE e219(zintf_g_messages) WITH <fs_emetteur> <fs_flux> <fs_idenreg> 'PCS' INTO lv_message.
*    ev_etape = 2.
*    RETURN.
*  endif.
*  Fin ajout BWF20151005

    "Si le PCS est le même on fusionne les 2 tranches de temps
    IF ls_ettifn_pcs_new-wert1 = ls_ettifn_pcs-wert1.
      ls_ettifn_pcs_new-ab = ls_ettifn_pcs-ab.
    ENDIF.

    CLEAR: lt_ettifn_update[].
    REFRESH: lt_ettifn_update.
    APPEND ls_ettifn_pcs TO lt_ettifn_update.
    IF lt_ettifn_pcs IS NOT INITIAL.
      IF ls_ettifn_pcs_new-wert1 = ls_ettifn_pcs-wert1.
        CALL FUNCTION 'ISU_DB_ETTIFN_UPDATE'
          EXPORTING
            x_upd_mode = 'D'
            x_iettifn  = lt_ettifn_update.
      ELSE.
        " mise à jour de la date de la dernière tranche
        CALL FUNCTION 'ISU_DB_ETTIFN_UPDATE'
          EXPORTING
            x_upd_mode = 'U'
            x_iettifn  = lt_ettifn_update.
      ENDIF.
    ENDIF.

    CLEAR: lt_ettifn_update[].
    REFRESH: lt_ettifn_update.
    APPEND ls_ettifn_pcs_new TO lt_ettifn_update.
    " insertion de la nouvelle tranche
    CALL FUNCTION 'ISU_DB_ETTIFN_UPDATE'
      EXPORTING
        x_upd_mode = 'I'
        x_iettifn  = lt_ettifn_update.

  ENDIF.


** Mise à jour du PTA


    lt_ettifn_pta[] = lt_ettifn[].
    DELETE lt_ettifn_pta WHERE operand NE lc_pta.
    IF lt_ettifn_pta IS INITIAL.
MESSAGE e209(zintf_g_messages) WITH <fs_emetteur> <fs_flux> <fs_idenreg> 'PTA' INTO lv_message.
      ev_etape = 2.
      RETURN.
    ENDIF.

  " Si date début ou PTA vide ne pas mettre à jour le PTA
  IF <fs_date_deb> IS INITIAL OR <fs_pta> IS INITIAL.
    "Ne rien faire.
  ELSE.
    SORT lt_ettifn_pta BY bis DESCENDING.
    REFRESH lt_ettifn_delete.

"on supprime les entrées qui ont une date de début supérieure ou égale à la date de début de la tranche à insérer
    LOOP AT lt_ettifn_pta INTO ls_ettifn_pta.
      IF ls_ettifn_pta-ab GE <fs_date_deb>.
        APPEND ls_ettifn_pta TO lt_ettifn_delete.
        DELETE TABLE lt_ettifn_pta FROM ls_ettifn_pta.
      ENDIF.
    ENDLOOP.

    IF lt_ettifn_delete IS NOT INITIAL.
      CALL FUNCTION 'ISU_DB_ETTIFN_UPDATE'
        EXPORTING
          x_upd_mode = 'D'
          x_iettifn  = lt_ettifn_delete.
    ENDIF.

    IF lt_ettifn_pta IS NOT INITIAL.
      READ TABLE lt_ettifn_pta INTO ls_ettifn_pta INDEX 1.
    ENDIF.
    lv_vol_brut = <fs_vol_brut>.
    IF lv_vol_brut <> 0.
      lv_wert1 =  lv_vol_conv / lv_vol_brut.
    ELSE.
      lv_wert1 = <fs_pta>.
    ENDIF.

    ls_ettifn_pta_new = ls_ettifn_pta.

*GLI - 01/06/2016 - Ajout + 1 :

    if lv_post_mes = 0.
      If lv_post_pose = 1.
        ls_ettifn_pta_new-ab = <fs_date_deb>.
      ELSE.
        ls_ettifn_pta_new-ab = <fs_date_deb> + 1.
      ENDIF.
    else.
      ls_ettifn_pta_new-ab = <fs_date_deb>.
    endif.

*GLI - 01/06/2016 - fin

    ls_ettifn_pta_new-wert1 = lv_wert1.
    ls_ettifn_pta_new-bis = '99991231'.

*GLI - 01/06/2016 - modification pour prise en compte des MES en cours de vie d'une install (RES + MES) :
    if lv_post_mes = 0.
      If lv_post_pose = 1.
        ls_ettifn_pta-bis = <fs_date_deb> - 1.
      ELSE.
        ls_ettifn_pta-bis = <fs_date_deb>.
      ENDIF.
    else.
      ls_ettifn_pta-bis = <fs_date_deb> - 1.
    endif.
*GLI - 01/06/2016 - fin


*  Ajout début BWF20151005
*  if ls_ettifn_pta-bis lt  ls_ettifn_pta_new-ab.
*    MESSAGE e219(zintf_g_messages) WITH <fs_emetteur> <fs_flux> <fs_idenreg> 'PTA' INTO lv_message.
*    ev_etape = 2.
*    RETURN.
*  endif.
*  Fin ajout BWF20151005

    "Si le PTA est le même on fusionne les 2 tranches de temps
    IF ls_ettifn_pta_new-wert1 = ls_ettifn_pta-wert1.
      ls_ettifn_pta_new-ab = ls_ettifn_pta-ab.
    ENDIF.

    CLEAR: lt_ettifn_update[].
    REFRESH: lt_ettifn_update.
    APPEND ls_ettifn_pta TO lt_ettifn_update.
    IF lt_ettifn_pta IS NOT INITIAL.
      IF ls_ettifn_pta_new-wert1 = ls_ettifn_pta-wert1.
        CALL FUNCTION 'ISU_DB_ETTIFN_UPDATE'
          EXPORTING
            x_upd_mode = 'D'
            x_iettifn  = lt_ettifn_update.
      ELSE.
        " mise à jour de la date de la dernière tranche
        CALL FUNCTION 'ISU_DB_ETTIFN_UPDATE'
          EXPORTING
            x_upd_mode = 'U'
            x_iettifn  = lt_ettifn_update.
      ENDIF.
    ENDIF.

    CLEAR: lt_ettifn_update[].
    REFRESH: lt_ettifn_update.
    APPEND ls_ettifn_pta_new TO lt_ettifn_update.
    " insertion de la nouvelle tranche
    CALL FUNCTION 'ISU_DB_ETTIFN_UPDATE'
      EXPORTING
        x_upd_mode = 'I'
        x_iettifn  = lt_ettifn_update.
  ENDIF.

  ev_etape = 1.
ENDFUNCTION.
