FUNCTION-POOL ZEVI1.                         "MESSAGE-ID ..

TYPE-POOLS: ISU21.

TYPES VAL_ITFKIVV LIKE TFKIVV OCCURS 5.

* --------------------------- Includes ---------------------------------
INCLUDE MEAWA000.
INCLUDE IECONE21.
INCLUDE IEKIVORG. "constants for internal main transactions
INCLUDE EMSG.
INCLUDE IEACOVKK.






