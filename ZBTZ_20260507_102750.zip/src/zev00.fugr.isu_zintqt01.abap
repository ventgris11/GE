FUNCTION ISU_ZINTQT01.
*"--------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(X_OP) TYPE  ISU2A_VARIANT_PARAMETERS
*"     REFERENCE(X_SS) TYPE  ISU2A_SS
*"     REFERENCE(X_RED) TYPE  ISU2A_REDUCED_BILLING_DATA
*"  CHANGING
*"     REFERENCE(XY_OBJ) TYPE  ISU2A_BILLING_DATA
*"     REFERENCE(XY_SOBJ) TYPE  ISU2A_DATA_COLLECTOR
*"  EXCEPTIONS
*"      GENERAL_FAULT
*"      REGULAR_ERROR
*"--------------------------------------------------------------------

  INCLUDE IEVARBASIC.

  MAC_CONTROL_CHECK 2.
  MAC_BELZART_CHECK 1.

  MAC_INIT_OUTPUT X_SS-VARCONT2 X_OP-O1.

  LOOP AT X_RED-IVB INTO WVB.
* preparing the output processing
    OUT_VB-AB  = WVB-AB.
    OUT_VB-BIS = WVB-BIS.
    OUT_VB-QNT_NEW = WVB-QNT_NEW.
    OUT_VB-QNT_OLD = WVB-QNT_OLD.
    append out_vb to out_ivb.

  ENDLOOP.                             "x_red-ivb

  clear out_vb.
  MAC_OUTPUT_IVB X_OP-O1.

  LOOP AT X_RED-IVB INTO WVB.
*   important: using the (eventually) rounded value from output
*   processing for the info invoice line
    read table out_ivb into out_vb index sy-tabix.
    WVB-QNT_NEW = OUT_VB-QNT_NEW.

    MAC_INVOICE_LINE_QNT X_SS-VARCONT1 CO_DLTYP01.

  ENDLOOP.                             "x_red-ivb


ENDFUNCTION.
