FUNCTION isu_val_zbbp_perc2.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(X_TE327) LIKE  TE327 STRUCTURE  TE327
*"  CHANGING
*"     REFERENCE(XY_OBJ) TYPE  ISU2A_BILLING_DATA
*"     REFERENCE(XY_OUTCNSO) LIKE  ERCHO-OUTCNSO
*"  EXCEPTIONS
*"      GENERAL_FAULT
*"----------------------------------------------------------------------

  DATA: werchz          LIKE erchz,
        nettobtr        LIKE erchz-nettobtr,
        nettobtr_bbp    LIKE erchz-nettobtr,
        deviation       LIKE ercho-deviation,
        diff_percentage LIKE te327-value1.

*DEB-IBEN-20181217-GE-2729
* Empêcher la création de plan de paiement au-dessus d'un montant

  DATA: ls_zw TYPE isu2a_zw,
        BEGIN OF ls_easte,
          logikzw  TYPE easte-logikzw,
          ab       TYPE easte-ab,
          bis      TYPE easte-bis,
          perverbr TYPE easte-perverbr,
        END OF ls_easte,
        lt_easte          LIKE TABLE OF ls_easte,
        ld_conso_annuelle TYPE erchz-i_abrmenge,
        ld_conso_bbp      TYPE erchz-i_abrmenge,
        lt_logno          TYPE TABLE OF dfkkop-logno,
        ld_logno          TYPE dfkkop-logno,
        ld_bbp_not_full   TYPE abap_bool.

*DEB-IBEN-20190208-GE-3952
  DATA: ld_nb_ech_controle TYPE tvarvc-low.
*FIN-IBEN-20190208-GE-3952

* Vérifier que le document de calcul contient des lignes du nouveau BBP
  CLEAR werchz.
  READ TABLE xy_obj-bill-ierchz TRANSPORTING NO FIELDS WITH KEY abslkz = 'X'.
  IF sy-subrc <> 0.
    RETURN.
  ENDIF.

* Déterminer si échéancier non complet
  SELECT logno INTO TABLE lt_logno
  FROM eabp JOIN dfkkop ON eabp~opbel = dfkkop~opbel
  WHERE eabp~vertrag = xy_obj-st-vertrag AND eabp~deaktiv = ''.

  SORT lt_logno DESCENDING.
  READ TABLE lt_logno INTO ld_logno INDEX 1.
*DEB-IBEN-20190208-GE-3952
*  IF ld_logno <> '11'.
  SELECT SINGLE low
           INTO ld_nb_ech_controle
           FROM tvarvc
          WHERE name EQ 'Z_NB_ECH_CONTROLE'.

  IF ld_logno < ld_nb_ech_controle.
*FIN-IBEN-20190208-GE-3952
    ld_bbp_not_full = abap_true.
  ENDIF.


  IF xy_obj-izw[] IS NOT INITIAL.
    SELECT logikzw
           ab
           bis
           perverbr
    INTO TABLE lt_easte
           FROM easte
           FOR ALL ENTRIES IN xy_obj-izw
           WHERE logikzw = xy_obj-izw-logikzw
           .

    SORT lt_easte BY logikzw ASCENDING ab DESCENDING.
  ENDIF.

* Conso annuelle
* Cas du premier échéancier
  IF ld_bbp_not_full = abap_true.
* Pour chaque LOGIKZW de la structure XY_OBJ-IZW
* Sélectionner de la table EASTE avec le champ LOGIKZW la ligne qui le AB le plus grand
* Récupérer AB, BIS, PERVERBR
    LOOP AT xy_obj-izw INTO ls_zw.
      READ TABLE lt_easte INTO ls_easte WITH KEY logikzw = ls_zw-logikzw
                                        BINARY SEARCH.
      IF sy-subrc = 0.
* Calculer la consommation annuelle comme suit 365 * PERVERBR / Nombre de jour [AB ; BIS]
* Cumuler la conso annuelle pour chaque LOGIKZW de la structure XY_OBJ-IZ
        ld_conso_annuelle = ld_conso_annuelle + 365 * ls_easte-perverbr / ( ( ls_easte-bis - ls_easte-ab ) + 1 ).
      ENDIF.
    ENDLOOP.
  ENDIF.
* Pour chaque ligne de la structure XY_OBJ-BILL-IERCHZ cumuler I_ABRMENGE pour
* la conso annuelle ou conso BBP
  LOOP AT xy_obj-bill-ierchz INTO werchz
          WHERE buchrel = 'X' AND
                ( belzart = 'ZCON' OR  belzart = 'ZCBS' OR belzart = 'ZCHP' OR belzart = 'ZCHC' ).

    IF werchz-abslkz = '' AND ld_bbp_not_full = abap_false.
      ld_conso_annuelle = ld_conso_annuelle + werchz-i_abrmenge.
    ENDIF.

    IF werchz-abslkz = 'X'.
      ld_conso_bbp = ld_conso_bbp + werchz-i_abrmenge.
    ENDIF.
  ENDLOOP.

  IF ld_conso_annuelle <> 0.
    diff_percentage  =  100 * (  ld_conso_bbp - ld_conso_annuelle ) / ld_conso_annuelle.
  ENDIF.


  IF ( diff_percentage >= 0 AND diff_percentage >= x_te327-value1 )
  OR ( diff_percentage < 0 AND diff_percentage <= x_te327-value2 ).
    deviation = diff_percentage.
    CALL FUNCTION 'ISU_OUTSORT_IERCHO_WRITE'
      EXPORTING
        x_validation = x_te327-validation
        x_deviation  = deviation
      CHANGING
        xy_iercho    = xy_obj-bill-iercho
        xy_outcnso   = xy_outcnso.
  ENDIF.
*FIN-IBEN-20181217-GE-2729
ENDFUNCTION.
