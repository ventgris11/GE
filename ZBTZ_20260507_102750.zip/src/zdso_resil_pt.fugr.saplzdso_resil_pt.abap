* regenerated at 05.04.2019 12:51:31
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDSO_RESIL_PTTOP.                 " Global Data
  INCLUDE LZDSO_RESIL_PTUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDSO_RESIL_PTF...                 " Subroutines
* INCLUDE LZDSO_RESIL_PTO...                 " PBO-Modules
* INCLUDE LZDSO_RESIL_PTI...                 " PAI-Modules
* INCLUDE LZDSO_RESIL_PTE...                 " Events
* INCLUDE LZDSO_RESIL_PTP...                 " Local class implement.
* INCLUDE LZDSO_RESIL_PTT99.                 " ABAP Unit tests
  INCLUDE LZDSO_RESIL_PTF00                       . " subprograms
  INCLUDE LZDSO_RESIL_PTI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
