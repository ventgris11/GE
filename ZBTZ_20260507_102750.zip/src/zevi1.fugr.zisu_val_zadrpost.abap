FUNCTION zisu_val_zadrpost.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(X_TE328) LIKE  TE328 STRUCTURE  TE328
*"  CHANGING
*"     REFERENCE(XY_OBJ) TYPE  ISU21_INVOICE_UNIT
*"     REFERENCE(XY_OUTCNSO) LIKE  ERDO-OUTCNSO
*"  EXCEPTIONS
*"      GENERAL_FAULT
*"----------------------------------------------------------------------
  DATA: deviation LIKE ercho-deviation,
        outsorted TYPE c,
        amount    LIKE erdk-total_amnt.

*DEB-IBEN-20210127-GE-10455
  DATA: ld_type_envoi TYPE zisu_type_envoi-type_envoi,
        ls_adrc       TYPE adrc.

  SELECT SINGLE type_envoi INTO ld_type_envoi
  FROM zisu_type_envoi
  WHERE sendcontrol_rh = xy_obj-print_doc-erdk-zzsendcontrol_rh
  AND coprc = xy_obj-print_doc-erdk-zzcoprc
  AND ctrl_zadrpost = 'X'.

  CHECK sy-subrc = 0.

  SELECT SINGLE adrc~* INTO @ls_adrc
  FROM but020
  JOIN adrc ON adrc~addrnumber = but020~addrnumber
  WHERE but020~partner = @xy_obj-print_doc-erdk-zzdest_fact.

  IF ls_adrc-street IS INITIAL
    OR ls_adrc-post_code1 IS INITIAL
    OR ls_adrc-city1 IS INITIAL
    OR ls_adrc-country IS INITIAL.
    outsorted = 'X'.
  ENDIF.
*FIN-IBEN-20210127-GE-10455

  IF NOT outsorted IS INITIAL.
    CALL FUNCTION 'ISU_OUTSORT_IERDO_WRITE'
      EXPORTING
        x_validat_in = x_te328-validat_in
        x_deviation  = deviation
      CHANGING
        xy_ierdo     = xy_obj-print_doc-t_erdo
        xy_outcnso   = xy_outcnso.
  ENDIF.
ENDFUNCTION.
