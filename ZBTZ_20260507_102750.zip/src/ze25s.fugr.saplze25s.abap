*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZE25STOP.                    " Global Data
  INCLUDE LZE25SUXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LE25SO...                          " PBO-Modules
* INCLUDE LE25SI...                          " PAI-Modules

*INCLUDE LZE25SF01.
*  INCLUDE le25sf01.     " Subprograms for ISU_S_BBP_AUTO_CHANGE
*INCLUDE LZE25SF02.
*  INCLUDE le25sf02.     " Subprograms for ISU_S_BBP_AUTO_CREATE
*INCLUDE LZE25SF03.
*  INCLUDE le25sf03.     " Subprograms for ISU_S_BBP_FO_READ_DATECONTR
*INCLUDE LZE25SF04.
*  INCLUDE le25sf04.     " Subprograms for ISU_S_BBP_PRINTDATA
*INCLUDE LZE25SF05.
*  INCLUDE le25sf05.     " Subprograms for ISU_S_BBP_STOP

*INCLUDE LZE25SF08.
*  INCLUDE le25sf08.     " Subprograms for ISU_S_BBP_AUTO_PPL_CREATE
*INCLUDE LZE25SF09.
*  INCLUDE le25sf09.     " Subprograms for ISU_S_BBP_STOP_REVERSE
*INCLUDE LZE25SF10.
*  INCLUDE le25sf10.     " Subprograms for ISU_S_BBP_DI
*INCLUDE LZE25SF11.
*  INCLUDE le25sf11.     " Subprograms for ISU_S_BBP_PRECUSTOMER_AMOUNT
*INCLUDE LZE25SF12.
*  INCLUDE le25sf12.     " Subprograms for ISU_S_BBP_STOP_REQUEST_CHECK
*INCLUDE LZE25SF13.
*  INCLUDE le25sf13.     " Subprograms for ISU_S_BBP_ADJUST
*INCLUDE LZE25SF14.
*  INCLUDE le25sf14.     " Subprograms for ISU_S_BBP_COLLBILL_DEACTIV

*INCLUDE LZE25SF16.
*  INCLUDE le25sf16.     " Subprograms for ISU_S_BBP_KZABSVER

*INCLUDE LZE25SF18.
*  INCLUDE le25sf18.
*INCLUDE LZE25SF19.
*  INCLUDE le25sf19.     " Subprograms for ISU_S_BBP_DEBCH_DEACTIV_REV
INCLUDE LZE25SF20.
*  INCLUDE le25sf20.
INCLUDE LZE25SF21.
*  INCLUDE le25sf21.

INCLUDE LZE25SF23.
*  INCLUDE le25sf23.

INCLUDE LZE25SF00.
*INCLUDE LE25SF00.
