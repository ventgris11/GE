*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZINTF_DSO_LOG
*   generation date: 11.06.2019 at 17:56:47
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZINTF_DSO_LOG      .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.
