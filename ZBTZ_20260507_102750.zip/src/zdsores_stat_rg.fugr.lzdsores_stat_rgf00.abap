*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 07.04.2019 at 13:04:36
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
