FUNCTION zfkk_sample_5063.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(I_FKKCOLL) LIKE  DFKKCOLL STRUCTURE  DFKKCOLL
*"  TABLES
*"      T_FKKOP STRUCTURE  FKKOP
*"      T_FKKMAZE STRUCTURE  FKKMAZE
*"  CHANGING
*"     VALUE(C_FKKCOLFILE) LIKE  FKKCOLFILE STRUCTURE  FKKCOLFILE
*"----------------------------------------------------------------------

  DATA : lv_ur         TYPE ableinheit,
         ls_fkkop      TYPE fkkop,
         ls_fkkvkp     TYPE fkkvkp,
         lv_contrat    TYPE vertrag.


  DEFINE m_format_date.
    IF &1 IS NOT INITIAL .
        &2 = &1+6(2) && '/' && &1+4(2) && '/' && &1(4) .
    ENDIF.
  END-OF-DEFINITION.

  READ TABLE t_fkkop INTO ls_fkkop INDEX 1 .

  SELECT SINGLE *
     FROM fkkvkp
     INTO ls_fkkvkp
     WHERE vkont = i_fkkcoll-vkont
       AND gpart = i_fkkcoll-gpart.


  CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
    EXPORTING
      input  = ls_fkkop-vtref
    IMPORTING
      output = lv_contrat.

  SELECT SINGLE eanlh~ableinh
    INTO lv_ur
    FROM eanlh INNER JOIN ever
      ON eanlh~anlage = ever~anlage
    WHERE ever~vertrag = lv_contrat .


  c_fkkcolfile-zdebut_dso_file = '|'.
  c_fkkcolfile-zposte          = i_fkkcoll-inkps.

  c_fkkcolfile-zpartner = i_fkkcoll-gpart.

  "Type Facture
  IF matches( val = lv_ur regex = '.+BM.+').
    c_fkkcolfile-ztype_facture = 'BIM' .
  ELSEIF matches( val = lv_ur regex = '.+AM.+').
    c_fkkcolfile-ztype_facture = 'MENS' .
  ENDIF.

  m_format_date : sy-datum  c_fkkcolfile-zdate_transmission .

  CLEAR c_fkkcolfile-zdate_naissance .


  c_fkkcolfile-zenergie     = ls_fkkop-spart .

  CLEAR c_fkkcolfile-zref_dso.


  CLEAR c_fkkcolfile-zmotif_rejet .

  c_fkkcolfile-zopbel           = c_fkkcolfile-opbel.
  m_format_date : ls_fkkop-faedn c_fkkcolfile-zdate_echeance .
  c_fkkcolfile-zmontant_init    = i_fkkcoll-betrw .

  CLEAR : c_fkkcolfile-zfrais         ,
          c_fkkcolfile-zinterets      ,
          c_fkkcolfile-zclause_penale .

  c_fkkcolfile-zvkont   = i_fkkcoll-vkont .
  c_fkkcolfile-zcontrat = lv_contrat .

  CLEAR : c_fkkcolfile-zmontant_encaiss_dso      ,
          c_fkkcolfile-zdate_encaiss_dso         ,
          c_fkkcolfile-zmontant_encaiss_gdp_btz  ,
          c_fkkcolfile-zdate_encaiss_dso_gdp_btz .

  c_fkkcolfile-zmontant_restant = i_fkkcoll-betrw - i_fkkcoll-betrz .

  CLEAR : c_fkkcolfile-zdate_cloture  ,
          c_fkkcolfile-zmotif_cloture .


ENDFUNCTION.
