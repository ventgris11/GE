* regenerated at 29.11.2021 15:56:24
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZANNUL_REL_FACTTOP.               " Global Data
  INCLUDE LZANNUL_REL_FACTUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZANNUL_REL_FACTF...               " Subroutines
* INCLUDE LZANNUL_REL_FACTO...               " PBO-Modules
* INCLUDE LZANNUL_REL_FACTI...               " PAI-Modules
* INCLUDE LZANNUL_REL_FACTE...               " Events
* INCLUDE LZANNUL_REL_FACTP...               " Local class implement.
* INCLUDE LZANNUL_REL_FACTT99.               " ABAP Unit tests
  INCLUDE LZANNUL_REL_FACTF00                     . " subprograms
  INCLUDE LZANNUL_REL_FACTI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
