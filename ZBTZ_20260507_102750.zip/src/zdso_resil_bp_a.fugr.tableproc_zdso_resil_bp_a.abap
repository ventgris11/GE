*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDSO_RESIL_BP_A
*   generation date: 21.04.2019 at 17:53:02
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDSO_RESIL_BP_A     .

  PERFORM TABLEPROC.

ENDFUNCTION.
