*----------------------------------------------------------------------*
*   INCLUDE LFKLOCKCOM                                                 *
*----------------------------------------------------------------------*

* constants for LOTYP (corresponds to TFK080B)
CONSTANTS: gc_lotyp_dokument        TYPE lotyp_kk VALUE '01',
           gc_lotyp_position        TYPE lotyp_kk VALUE '02',
           gc_lotyp_account         TYPE lotyp_kk VALUE '04',
           gc_lotyp_partner         TYPE lotyp_kk VALUE '05',
           gc_lotyp_partner_account TYPE lotyp_kk VALUE '06',
           gc_lotyp_incorr          TYPE lotyp_kk VALUE '07',
           gc_lotyp_master_agrmt    TYPE lotyp_kk VALUE '08',
           gc_lotyp_prov_contract   TYPE lotyp_kk VALUE '20',
           gc_lotyp_ins_contract    TYPE lotyp_kk VALUE '21',
           gc_lotyp_partner_insobj  TYPE lotyp_kk VALUE '22',
           gc_lotyp_util_contract   TYPE lotyp_kk VALUE '41',
           gc_lotyp_psob_bp_acc     TYPE lotyp_kk VALUE '51'.


* constants for PROID (corresponds to TFK080F)
CONSTANTS: gc_proid_dunning    TYPE proid_kk VALUE '01',
           gc_proid_inc_pay    TYPE proid_kk VALUE '02',
           gc_proid_out_pay    TYPE proid_kk VALUE '03',
           gc_proid_interest   TYPE proid_kk VALUE '04',
           gc_proid_invoice    TYPE proid_kk VALUE '05',
           gc_proid_corrdun    TYPE proid_kk VALUE '07',
           gc_proid_post       TYPE proid_kk VALUE '09',
           gc_proid_sched      TYPE proid_kk VALUE '06',
           gc_proid_in_out_pay TYPE proid_kk VALUE '10',
           gc_proid_broker     TYPE proid_kk VALUE '11',
           gc_proid_fica_inv   TYPE proid_kk VALUE '12'.

* constant for unlimited locks
CONSTANTS: gc_tdate TYPE tdate_kk VALUE '99991231',
           gc_fdate TYPE tdate_kk VALUE '00010101'.

* constants for wmode
CONSTANTS: gc_wmode_create  TYPE wmode_kk VALUE '01',
           gc_wmode_change  TYPE wmode_kk VALUE '02',
           gc_wmode_display TYPE wmode_kk VALUE '03',
           gc_wmode_delete  TYPE wmode_kk VALUE '04'.

* Icons
CONSTANTS: icon_green_arrow(4) VALUE '@1E@',
           icon_white_arrow(4) VALUE '@1F@',
           icon_activated(4)   VALUE '@3C@',
           icon_time_over(4)   VALUE '@1T@',
           icon_recycle_bin(4) VALUE '@11@'.

CONSTANTS: gc_multiple_locks(1) VALUE '~'.
