FUNCTION zintf_g_contrat_existe .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA: lc_field_num_pce     TYPE fieldname VALUE 'NUM_PCE',
        lc_field_type_releve TYPE fieldname VALUE 'TYPE_RELEVE',
        lc_field_raison      TYPE fieldname VALUE 'RAISON_RELEVE',
        lc_field_date_releve TYPE fieldname VALUE 'DATE_RELEVE',
        lc_field_date_fin    TYPE fieldname VALUE 'FIN_PERIODE', "++GE-2200
        lc_field_flux        TYPE fieldname VALUE 'FLUX',
        lc_field_emetteur    TYPE fieldname VALUE 'EMETTEUR',
        lv_date_rel          TYPE zdate_rel,
        lc_field_idenreg     TYPE fieldname VALUE 'IDENREG',
        lv_field             TYPE string,
        lv_int_ui            TYPE int_ui,
        ls_object            TYPE eedm_isu_objects,
        lv_message           TYPE char255,
        lv_subobj            TYPE balsubobj,
        ls_bpem              TYPE zbpem_flux_struct,
        lv_interface         TYPE zisu_flxid.


  FIELD-SYMBOLS: <fs_num_pce>, <fs_date_releve>, <fs_emetteur>, <fs_flux>, <fs_idenreg>, <fs_type>, <fs_raison>.
  "MFO début
  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_type_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_type>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_raison INTO lv_field.
  ASSIGN (lv_field) TO <fs_raison>.

  "MFO fin

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.



  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_emetteur INTO lv_field.
  ASSIGN (lv_field) TO <fs_emetteur>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_flux INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.

*++ STOU DEBUT GE-2200
*-- STOU DEBUT GE-2204
*  IF <fs_flux> = 'RE6M' AND <fs_raison> IS ASSIGNED AND <fs_type> IS ASSIGNED .
*    IF <fs_raison> = '87' AND <fs_type> = 'S'.
*      CLEAR: lv_field.
*      CONCATENATE 'FLUX-' lc_field_date_fin INTO lv_field.
*      ASSIGN (lv_field) TO <fs_date_releve>.
*    ELSE.
*      CLEAR: lv_field.
*      CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
*      ASSIGN (lv_field) TO <fs_date_releve>.
*    ENDIF.
*  ELSE.
*    CLEAR: lv_field.
*    CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
*    ASSIGN (lv_field) TO <fs_date_releve>.
*  ENDIF.
*-- STOU FIN   GE-2204

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_releve>.
*++ STOU FIN   GE-2200

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_idenreg INTO lv_field.
  ASSIGN (lv_field) TO <fs_idenreg>.

* FPE Début GE-83 - implémentation RE1M
  IF <fs_flux> = 'RE6M'.
    lv_subobj = zcl_tool=>gc_log_subobject_re6m.
  ELSEIF <fs_flux> = 'RE1M'.
    lv_subobj = zcl_tool=>gc_log_subobject_re1m.
  ELSE.
    lv_subobj = zcl_tool=>gc_log_subobject_remm.
  ENDIF.
* Fin GE-83

  IF <fs_type> IS ASSIGNED.
    IF <fs_type> = 'N'.
      IF <fs_date_releve> IS ASSIGNED.
        lv_date_rel = <fs_date_releve> - 5.
      ENDIF.
    ELSE.
      IF <fs_raison> > 46.
        lv_date_rel = <fs_date_releve> - 5.
      ELSE.
        lv_date_rel = <fs_date_releve>.
      ENDIF.
    ENDIF.
  ELSE.
    "Erreur technique
  ENDIF.

  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).
  IF lv_int_ui IS INITIAL.
  ENDIF.

  IF <fs_num_pce> IS ASSIGNED.
    IF <fs_date_releve> IS ASSIGNED.

      CLEAR ls_object.
      CALL METHOD zcl_tool=>pod_get_related_object
        EXPORTING
          iv_int_ui = lv_int_ui
          iv_date   = <fs_date_releve>
        IMPORTING
          es_detail = ls_object.

      IF ls_object-contract IS INITIAL.
        MESSAGE e210(zintf_g_messages) WITH <fs_emetteur> <fs_flux> <fs_idenreg> <fs_num_pce> INTO lv_message.


        CLEAR ls_bpem.
        ls_bpem-num_pce = <fs_num_pce>.
        CASE <fs_flux>.
          WHEN 'ADIF'.
            ls_bpem-date_effet_cont = <fs_date_releve>.
          WHEN 'RE6M' OR 'RE1M' OR 'REMM' OR 'REJJ' OR 'REJM'.
            ls_bpem-date_releve     = <fs_date_releve>.
          WHEN 'AFAC'.
            ls_bpem-date_fin_prest  = <fs_date_releve>.
        ENDCASE.

        lv_interface    = <fs_flux> .
        ls_bpem-idenreg = <fs_idenreg>.
        CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
          EXPORTING
            iv_interface_name = lv_interface
            iv_sparte         = 'ZG'
            is_structure      = ls_bpem.
        ev_etape = 2.
      ELSE.
*        "" MFO début
*        CLEAR ls_object.
*        CALL METHOD zcl_tool=>pod_get_related_object
*          EXPORTING
*            iv_int_ui = lv_int_ui
*            iv_date   = lv_date_rel
*          IMPORTING
*            es_detail = ls_object.
*        IF ls_object-contract IS INITIAL.
*          MESSAGE e227(zintf_g_messages) WITH <fs_emetteur> <fs_flux> <fs_idenreg> <fs_date_releve> INTO lv_message.
*          ev_etape = 2.
*        ELSE.
*          ev_etape = 1.
*        ENDIF.
      ENDIF.

    ELSE.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
      INTO lv_message
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      zcl_tool=>log_add_msg( EXPORTING iv_log_object = zcl_tool=>gc_log_object_intf_gaz
                                       iv_log_subobject = lv_subobj
                                       iv_test_mode = iv_mode_test
                             CHANGING  cv_log_handle = cv_log_handle ).
      ev_etape = 2.
      RETURN.
    ENDIF.
  ELSE.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
    INTO lv_message
    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    zcl_tool=>log_add_msg( EXPORTING iv_log_object = zcl_tool=>gc_log_object_intf_gaz
                                     iv_log_subobject = lv_subobj
                                     iv_test_mode = iv_mode_test
                           CHANGING  cv_log_handle = cv_log_handle ).
    ev_etape = 2.
    RETURN.
  ENDIF.

ENDFUNCTION.
