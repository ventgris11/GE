FUNCTION z_isu_sample_tfk116_exclfacvid.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(X_VERVAR) LIKE  TFK115-VERVAR
*"     VALUE(X_VERART) LIKE  TFK110-VERART OPTIONAL
*"     VALUE(X_BLDAT) LIKE  FKKKO-BLDAT OPTIONAL
*"     VALUE(X_IFNAM) LIKE  TFK116-IFNAM
*"     VALUE(X_XSORT) LIKE  BOOLE-BOOLE DEFAULT SPACE
*"  TABLES
*"      T_E516_FKKCL STRUCTURE  E516_FKKCL
*"      T_SELTAB STRUCTURE  ISELTAB OPTIONAL
*"----------------------------------------------------------------------
*  Event zur Ableitung der Merkmalwerte. Zum importierten Merkmal-
*  schlüssel x_ifnam können hier aus der zusätzlich zur Verfügung
*  stehender Posteninformation je Posten abgeleitet/gesetzt werden:
*
*  - ein Merkmalwert in T_e516_fkkcl-e_fwert_te516
*
*  - Kennzeichen für die gruppenübergreifende Verrechnung
*    T_e516_fkkcl-e_zreg_te516 = '1', d. h. die so markierten Posten
*    dürfen mit Posten kombiniert werden, die nur in der Ausprägung der
*    übergeordneten Merkmale der Gruppierleiste gleich sind.
*    Die Steuerung gilt nur innerhalb eines Verrechnungsschrittes, der
*    das aktuelle Merkmal im Aufbau der Gruppierleiste verwendet.
*
*  - Deaktivierungskennzeichen  T_e516_fkkcl-e_zreg_te516 = '2',
*    falls der Posten in der Zuordnung nicht berücksichtigt werden
*    soll. Die Deaktivierung gilt nur innerhalb eines
*    Verrechnungsschrittes, der das aktuelle Merkmal in der Definition
*    der Gruppierung verwendet.
*
*  - Deaktivierungskennzeichen  T_e516_fkkcl-e_zreg_te516 = '3',
*    falls der Posten in der Zuordnung nicht berücksichtigt werden
*    soll. Die Deaktivierung gilt innerhalb eines
*    Verrechnungsschrittes, der das aktuelle Merkmal in der Definition
*    der Gruppierung verwendet sowie für alle Folgeschritte (d. h.
*    es wird keine weitere Verrechnung des Postens durchgeführt).

  DATA: y_value LIKE e516_fkkcl-e_fwert_te516,
        y_zreg  LIKE e516_fkkcl-e_zreg_te516.
  DATA: refe   LIKE fkkop-betrw.
  RANGES: hvorgtab  FOR  teivv-hvorg.

  CASE x_ifnam.

    WHEN 'Z_EXCL_F_VIDE'. "'S_XBLNR'.
*  On exclut les postes qui n'ont pas en référence un numéro présent dans la table des sélections
      LOOP AT t_e516_fkkcl.
        IF t_e516_fkkcl-i_xnpos_te516 NE 'X'.
          READ TABLE t_seltab WITH KEY selfn = 'XBLNR' selcu = t_e516_fkkcl-xblnr.
          IF sy-subrc <> 0.
            t_e516_fkkcl-e_zreg_te516 = '2'.
            MODIFY t_e516_fkkcl.
          ENDIF.
        ENDIF.
      ENDLOOP.

  ENDCASE.

* Code exemple du MF ISU_SAMPLE_TFK116
*  LOOP AT t_e516_fkkcl.
*
*    CLEAR: y_value.
*    y_zreg = t_e516_fkkcl-e_zreg_te516.
*
*    CASE x_ifnam.
*
**----------------------------------------------------------------------
*
*      WHEN 'E_VORG'.
*        y_value = t_e516_fkkcl-hvorg.
*        y_value+4(4) = t_e516_fkkcl-tvorg.
*
**----------------------------------------------------------------------
*
*      WHEN 'E_VTREF'.
*        IF t_e516_fkkcl-vtref IS INITIAL.
*          y_zreg = '2'.
*        ENDIF.
*
**----------------------------------------------------------------------
*
*      WHEN 'E_PAYSCHEME'.
*        IF NOT t_e516_fkkcl-opbel IS INITIAL
*           AND t_e516_fkkcl-augrs NA '1R'.
*          y_zreg = '2'.
*        ENDIF.
*
**-----------------------------------------------------------------------
*
*      WHEN 'E_FAED'.                   "nur die fälligen Posten
*        IF t_e516_fkkcl-faedn > x_bldat.
*          y_zreg = '2'.
*        ENDIF.
*
**-----------------------------------------------------------------------
*
*      WHEN 'E_FAED_STUD'.
**  nur die fälligen Posten mit Beachtung des Stundungsdatums
*        IF t_e516_fkkcl-studt IS INITIAL.
*          IF t_e516_fkkcl-faedn > x_bldat.
*            y_zreg = '2'.
*          ENDIF.
*        ELSE.
*          IF t_e516_fkkcl-studt > x_bldat.
*            y_zreg = '2'.
*          ENDIF.
*        ENDIF.
*
**-----------------------------------------------------------------------
*
*      WHEN 'E_BETRS'.
*        IF t_e516_fkkcl-faeds LT x_bldat.
**          y_value = abs( t_e516_fkkcl-betrw ).
*          refe = t_e516_fkkcl-betrw.
*        ELSE.
** Skonto
*          refe = t_e516_fkkcl-betrw.
*          refe = refe - t_e516_fkkcl-betrw * t_e516_fkkcl-sktpz / 100.
**          y_value = abs( refe ).
*        ENDIF.
*        IF refe < 0.
*          y_value = refe * - 100.
*        ELSE.
*          y_value = refe *  100.
*        ENDIF.
*
**-----------------------------------------------------------------------
*
*      WHEN 'E_BETRW'.
**        y_value = abs( t_e516_fkkcl-betrw ).
*        IF t_e516_fkkcl-betrw < 0.
*          y_value = t_e516_fkkcl-betrw * - 100.
*        ELSE.
*          y_value = t_e516_fkkcl-betrw *  100.
*        ENDIF.
*
**-----------------------------------------------------------------------
*
**  Betrag mit Vorzeichen (für vorzeichengerechte Sortierung)
*      WHEN 'E_BETRW_V'.
*        y_value = t_e516_fkkcl-betrw *  100 + 999999999999999. "n821386
*
**-----------------------------------------------------------------------
*
*      WHEN 'E_SINGLE'.
*        y_value = t_e516_fkkcl-tabix.
*
**-----------------------------------------------------------------------
*
*      WHEN 'E_GRKEY'.
*        y_value = t_e516_fkkcl-grkey.
*        IF t_e516_fkkcl-grkey IS INITIAL.
**  ist GRKEY nicht gefüllt, werden die Posten als Einzelpositionen
**  betrachtet. Damit es beim Versorgen des Trennmerkmals nicht zur
**  Überschneidung mit GRKEY kommt, erhalten GRKEY und TABIX getrennte
**  Bereiche in y_value
*          y_value+3(10) =  t_e516_fkkcl-tabix.
*        ENDIF.
*
**-----------------------------------------------------------------------
*
*      WHEN 'E_CREDIT'.
**  Verrechnung Guthaben vor dem Zahlbetrag
*        y_value = '0'.
*        IF NOT t_e516_fkkcl-i_xnpos_te516 IS INITIAL.
*          y_value = '1'.
*        ENDIF.
*
**-----------------------------------------------------------------------
*
*      WHEN 'E_CREDIT_ZREG_1'.
**  Verrechnung Guthaben wie Zahlung (Gruppenübergr. Guthabenverrechnung)
*        IF t_e516_fkkcl-betrw < 0.
*          y_zreg = '1'.
*        ENDIF.
*
**-----------------------------------------------------------------------
*
*      WHEN 'E_STUDT'.
**  Fälligkeit mit Berücksichtigung des Stundungsdatums
*        IF NOT t_e516_fkkcl-studt IS INITIAL.
*          y_value =  t_e516_fkkcl-studt.
*        ELSE.
*          y_value =  t_e516_fkkcl-faedn.
*        ENDIF.
*
*    ENDCASE.
*
*    t_e516_fkkcl-e_zreg_te516 = y_zreg.
*    t_e516_fkkcl-e_fwert_te516 = y_value.
*    MODIFY t_e516_fkkcl.
*
*  ENDLOOP.
*-----------------------------------------------------------------------
*  CASE x_ifnam.
*
*    WHEN 'E_AUSZAHL'.
*      LOOP AT t_e516_fkkcl WHERE i_xnpos_te516 = 'X' AND
*                                 betrw > 0.
*        EXIT.
*      ENDLOOP.
*      IF sy-subrc <> 0.
*        CLEAR: y_value.
*        LOOP AT t_e516_fkkcl.
*
*          t_e516_fkkcl-e_zreg_te516 = '2'.
*          MODIFY t_e516_fkkcl.
*        ENDLOOP.
*      ENDIF.
*
*    WHEN 'S_OPBEL'.
**  das Merkmal 'Zahlung auf Beleg' kann dann interessant sein, wenn
**  man in diesem Falle eine abweichende Ausgleichslogik (etwa 'Teilaus-
**  gleich grundsätzlich zugelassen') festlegen will
*      READ TABLE t_seltab WITH KEY selfn = 'OPBEL'.
*      IF sy-subrc <> 0.
*        CLEAR: y_value.
*        LOOP AT t_e516_fkkcl.
*
*          t_e516_fkkcl-e_zreg_te516 = '2'.
*          MODIFY t_e516_fkkcl.
*        ENDLOOP.
*      ENDIF.
**----------------------------------------------------------------------
*
*    WHEN 'S_NRZAS'.
**  das merkmal 'Zahlung auf Zahlschein' kann dann interessant sein, wenn
**  man in diesem falle eine abweichende ausgleichslogik (etwa 'Teilaus-
**  gleich grundsätzlich zugelassen') festlegen will
*      READ TABLE t_seltab WITH KEY selfn = 'NRZAS'.
*      IF sy-subrc <> 0.
*        CLEAR: y_value.
*        LOOP AT t_e516_fkkcl.
*
*          t_e516_fkkcl-e_zreg_te516 = '2'.
*          MODIFY t_e516_fkkcl.
*        ENDLOOP.
*      ENDIF.
**-----------------------------------------------------------------------
*
*    WHEN 'E_JVL_ZAHL'.
** Zahlung auf JVL:
** Betrachte nur JVL + Abschlag. Falls kein JVL-vorhanden,
** den Schritt überspringen:
*
*      IF vorg_read IS INITIAL.
*
*        CLEAR: hvorgtab[], hvorgtab.
*        hvorgtab-option = 'EQ'.
*        hvorgtab-sign   = 'I'.
*        DO 3 TIMES.
*          CASE sy-index.
*            WHEN 1.
**       interner Hauptvorgang Jahresvorausleistung
*              h_ihvor = co_ihv_jvl.
*            WHEN 2.
**       interner Hauptvorgang Abschlag stat. Verfahren
*              h_ihvor = co_ihv_abs.
*            WHEN 3.
**       interner Hauptvorgang Abschlag Teilrechnung
*              h_ihvor = co_ihv_abs_dd.
*          ENDCASE.
*
**       Ermitteln des externen Hauptvorgangs
*          CALL FUNCTION 'ISU_DB_TEIVV_SELECT'
*            EXPORTING
*              i_ihvor = h_ihvor
*              i_applk = 'R'
*            IMPORTING
*              e_hvorg = h_hvorg
*            EXCEPTIONS
*              OTHERS  = 4.
*          IF sy-subrc EQ 0.
*            hvorgtab-low = h_hvorg.
*            APPEND hvorgtab.
*            IF h_ihvor = co_ihv_jvl.
*              h_vorg_jvl = h_hvorg.
*            ENDIF.
*          ENDIF.
*
*        ENDDO.
*
**       im globalen Gedaechtnis merken ob Vorgaenge gelesen
*        vorg_read = 'X'.
*      ENDIF.
*
*      IF h_vorg_jvl IS INITIAL.
*        t_e516_fkkcl-e_zreg_te516 = '2'.
*        MODIFY t_e516_fkkcl TRANSPORTING e_zreg_te516
*                             WHERE e_zreg_te516 <> '2'.
*      ELSE.
**  JVL vorhanden?
*        LOOP AT t_e516_fkkcl WHERE hvorg = h_vorg_jvl.
*          t_e516_fkkcl-e_zreg_te516 = '4'.
*          MODIFY t_e516_fkkcl.
*          EXIT.
*        ENDLOOP.
*        IF sy-subrc = 0.
**  JVL vorhanden: nur JVL + Abschläge betrachten
*          t_e516_fkkcl-e_zreg_te516 = '2'.
*          MODIFY t_e516_fkkcl TRANSPORTING e_zreg_te516
*                               WHERE NOT hvorg IN hvorgtab.
*        ELSE.
**  JVL nicht vorhanden: Verrechnungsschritt überspringen
*          t_e516_fkkcl-e_zreg_te516 = '2'.
*          MODIFY t_e516_fkkcl TRANSPORTING e_zreg_te516
*                               WHERE e_zreg_te516 <> '2'.
*        ENDIF.
*      ENDIF.
*
**-----------------------------------------------------------------------
*    WHEN 'E_GEMFAKT'.
**    für die JVL-Verrechnung werden Mussgruppen identifiziert
*
*      IF vorg_read IS INITIAL.
*
*        CLEAR: hvorgtab[], hvorgtab.
*        hvorgtab-option = 'EQ'.
*        hvorgtab-sign   = 'I'.
*        DO 3 TIMES.
*          CASE sy-index.
*            WHEN 1.
**       interner Hauptvorgang Jahresvorausleistung
*              h_ihvor = co_ihv_jvl.
*            WHEN 2.
**       interner Hauptvorgang Abschlag stat. Verfahren
*              h_ihvor = co_ihv_abs.
*            WHEN 3.
**       interner Hauptvorgang Abschlag Teilrechnung
*              h_ihvor = co_ihv_abs_dd.
*          ENDCASE.
*
**       Ermitteln des externen Hauptvorgangs
*          CALL FUNCTION 'ISU_DB_TEIVV_SELECT'
*            EXPORTING
*              i_ihvor = h_ihvor
*              i_applk = 'R'
*            IMPORTING
*              e_hvorg = h_hvorg
*            EXCEPTIONS
*              OTHERS  = 4.
*          IF sy-subrc EQ 0.
*            hvorgtab-low = h_hvorg.
*            APPEND hvorgtab.
*            IF h_ihvor = co_ihv_jvl.
*              h_vorg_jvl = h_hvorg.
*            ENDIF.
*          ENDIF.
*
*        ENDDO.
*
**       im globalen Gedaechtnis merken ob Vorgaenge gelesen
*        vorg_read = 'X'.
*      ENDIF.
*
**     Vorbereitung der Daten
*      SORT t_e516_fkkcl BY opbel.
*      CLEAR h_opbel.
*      h_count = 0.
*
**     Bildung der Gruppen
*      LOOP AT t_e516_fkkcl WHERE hvorg IN hvorgtab.
**       Bei Aenderung der Belegnummer evtl. Gruppierung aendern
*        IF h_opbel NE t_e516_fkkcl-opbel.
*          h_opbel = t_e516_fkkcl-opbel.
**         Wurde dieser Vertrag bereits bearbeitet?
*          LOOP AT t_e516_fkkcl INTO wa_fkkcl
*                  WHERE hvorg         IN hvorgtab
*                  AND   vtref         EQ t_e516_fkkcl-vtref
*                  AND   e_fwert_te516 NE space.
*            EXIT.
*          ENDLOOP.
*          IF sy-subrc = 0.
**           Gibt es einen Eintrag? Dann ueberimm Gruppierung
*            y_value = wa_fkkcl-e_fwert_te516.
*          ELSE.
**           Vergib neue Gruppierung, falls kein Eintrag vorhanden
*            ADD 1 TO h_count.
*            y_value = h_count.
*          ENDIF.
*        ENDIF.
*        t_e516_fkkcl-e_fwert_te516 = y_value.
*        MODIFY t_e516_fkkcl.
*      ENDLOOP.
**----------------------------------------------------------------------
*
*
*      " Payment Scheme includes contract account items
*    WHEN 'E_INCLCAITEMS'.
*
*      " check functionality status
*      DATA lv_active TYPE abap_bool VALUE abap_false.
*      PERFORM f18_inclcaitems_active(saplea61ps) CHANGING lv_active.
*      IF lv_active = abap_true.
*
*        DATA: lv_hvorg TYPE tfkivv-hvorg,
*              lv_tvorg TYPE tfkivv-tvorg.
*
*        " get external transaction
*        CALL FUNCTION 'ISU_DB_TEIVV_SELECT'
*          EXPORTING
*            i_ihvor = co_ihv_abs_ps                         "0053
*            i_itvor = co_itv_anzanfo                        "0010
*            i_applk = 'R'
*          IMPORTING
*            e_hvorg = lv_hvorg
*            e_tvorg = lv_tvorg.
*
*        IF lv_hvorg IS NOT INITIAL AND lv_tvorg IS NOT INITIAL.
*
*          " loop the items and group by contract
*          "  make sure, that items on contract account level included into a payscheme
*          "   are cleared only by payments of one specific contract. This contract can be found by
*          "    looking for the payscheme which is allowed to handle contract account items (field eabp-inclcaitems = true).
*          FIELD-SYMBOLS <ls_item> LIKE LINE OF t_e516_fkkcl.
*          LOOP AT t_e516_fkkcl ASSIGNING <ls_item>.
*
*            " is it an included open item on contract account level?
*            IF  <ls_item>-vtref IS INITIAL " contract account item? ...
*            AND <ls_item>-augrs = 'R'      " ... and included into payscheme? ...
*            AND <ls_item>-stakz <> 'A'.    " ... and not a stat. pos? ...
*
*              " get the contract whose payscheme includes ca items
*              DATA y_rollin_vtref TYPE vtref_kk.
*              PERFORM f18_get_vtref_item_rolled_in(saplea61ps) USING    <ls_item>-vkont
*                                                               CHANGING y_rollin_vtref.
*              " do payments exist for the contract?
*              READ TABLE t_e516_fkkcl WITH KEY hvorg = lv_hvorg "0053
*                                               tvorg = lv_tvorg "0010
*                                               vtref = y_rollin_vtref
*                                      TRANSPORTING NO FIELDS.
*              " payments exist --> take item into account
*              IF sy-subrc = 0.
*                <ls_item>-vtref = y_rollin_vtref.
*                <ls_item>-e_fwert_te516 = y_rollin_vtref.
*                " no payment exists --> do not take item into account
*              ELSE.
*                <ls_item>-e_zreg_te516 = '2'.
*              ENDIF.
*              " no contract account item...
*            ELSE.
*              <ls_item>-e_fwert_te516 = <ls_item>-vtref.
*            ENDIF.
*          ENDLOOP.
*
*        ENDIF.
*      ENDIF.
*  ENDCASE.

ENDFUNCTION.
