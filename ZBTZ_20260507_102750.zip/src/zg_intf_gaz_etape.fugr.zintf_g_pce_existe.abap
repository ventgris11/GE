FUNCTION zintf_g_pce_existe .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA: lc_field_num_pce  TYPE fieldname VALUE 'NUM_PCE',
        lv_field          TYPE string,
        lv_int_ui         TYPE int_ui,
        lv_message        TYPE char255,
        lc_field_emetteur TYPE fieldname VALUE 'EMETTEUR',
        lc_field_flux     TYPE fieldname VALUE 'FLUX',
        lc_field_idenreg  TYPE fieldname VALUE 'IDENREG',
        ls_bpem           TYPE zbpem_flux_struct,
        lv_interface      TYPE zisu_flxid.


  FIELD-SYMBOLS: <fs>, <fs_emetteur>, <fs_flux>, <fs_idenreg>, <fs_date_releve>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_emetteur INTO lv_field.
  ASSIGN (lv_field) TO <fs_emetteur>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_flux INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_idenreg INTO lv_field.
  ASSIGN (lv_field) TO <fs_idenreg>.

  CLEAR lv_field.
  MOVE 'FLUX-DATE_RELEVE'  TO lv_field.
  ASSIGN (lv_field)        TO <fs_date_releve>.

  IF <fs> IS ASSIGNED.
    lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs> ).
    IF lv_int_ui IS INITIAL.
      MESSAGE e084(zintf_g_messages) WITH <fs_emetteur> <fs_flux> <fs_idenreg> <fs> INTO lv_message.

      IF <fs_date_releve> IS ASSIGNED .
        CLEAR ls_bpem.
        ls_bpem-num_pce = <fs>.
        CASE <fs_flux>.
          WHEN 'ADIF'.
            ls_bpem-date_effet_cont = <fs_date_releve>.
          WHEN 'RE6M' OR 'RE1M' OR 'REMM' OR 'REJJ' OR 'REJM'.
            ls_bpem-date_releve     = <fs_date_releve>.
          WHEN 'AFAC'.
            ls_bpem-date_fin_prest  = <fs_date_releve>.
        ENDCASE.
      ENDIF.

      lv_interface    = <fs_flux> .
      ls_bpem-idenreg = <fs_idenreg>.
      CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
        EXPORTING
          iv_interface_name = lv_interface
          iv_sparte         = 'ZG'
          is_structure      = ls_bpem.
      ev_etape = 2.
    ELSE.
      ev_etape = 1.
    ENDIF.
  ELSE.
    "Erreur technique
  ENDIF.

ENDFUNCTION.
