FUNCTION zintf_g_integration_recn .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  FIELD-SYMBOLS:
    <fs_idenreg>,
    <fs_flux>,
    <fs_num_pce>,
    <fs_date_releve>,
    <fs_flux_re6m>   TYPE zintf_g_re6m,
* FPE GE-83 - implémentation RE1M
    <fs_flux_re1m>   TYPE zintf_g_re1m,
* FPE GE-8E Fin
    <fs_flux_remm>   TYPE zintf_g_remm.

  DATA:
    lv_field           TYPE string,
    lv_ablbelnr        TYPE ablbelnr,
    ls_obj             TYPE isu17_meterread,
    ls_ieabl           TYPE eabl,
    lt_auto            TYPE isu17_meterread_auto,
    lv_energie_entier  TYPE v_zwstand,
    lv_energie_decimal TYPE n_zwstand,
    lv_message         TYPE char255,
    lv_subobj          TYPE balsubobj,

    ls_bpem            TYPE zbpem_flux_struct,
    lv_interface       TYPE zisu_flxid,

    BEGIN OF ls_flux,
      idenreg	                      TYPE zintf_g_id_enreg,
      statut                        TYPE zintf_g_statut,
      num_pce                       TYPE ext_ui,
      emetteur                      TYPE zemetteur_id,
      flux                          TYPE zflux_id,
      date_releve                   TYPE zdate_rel,
      type_releve                   TYPE zzisu_type_releve,
      raison_releve                 TYPE zzisu_raison_releve,
      motif_releve                  TYPE zzmotif_rel,
      debut_periode                 TYPE zzisu_date_deb_per,
      index_brut_debut_periode      TYPE zzisu_index_brut_deb,
      qual_index_brut_debut_periode TYPE zzisu_qlf_index_brut_deb,
      index_conv_debut_periode      TYPE z_index_conv_deb_per,
      qual_index_conv_debut_periode TYPE zqual_index_conv_deb_per,
      fin_periode                   TYPE zdate_fin_per,
      index_brut_fin_periode        TYPE zidx_fin_per,
      qual_index_brut_fin_periode   TYPE zzisu_qlf_index_brut_fin,
      index_conv_fin_periode        TYPE zindex_conv_fin_per,
      qual_index_conv_fin_periode   TYPE zqual_index_conv_fin_per,
      volume_conv                   TYPE zvol_conv,
      qualif_volume_conv            TYPE zqual_vol_conv,
      qualif_pcs                    TYPE zqual_pcs,
      vol_brut_conso                TYPE zzisu_vol_brut,
      qualif_vol_brut_conso         TYPE zzisu_qlf_vol_brut,
      energie_conso                 TYPE zzisu_energie,
      qualif_energie_conso          TYPE zzisu_qlf_energie,
      motif_correction              TYPE zzisu_motif_corr,
      origine_correction            TYPE zzisu_orig_corr,
    END   OF ls_flux.

  DEFINE macro_add_message_to_log.
    MESSAGE ID sy-msgid
          TYPE sy-msgty
        NUMBER sy-msgno
          INTO lv_message
          WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    zcl_tool=>log_add_msg(
      EXPORTING iv_log_object    = zcl_tool=>gc_log_object_intf_gaz
                iv_log_subobject = lv_subobj
                iv_test_mode     = iv_mode_test
      CHANGING  cv_log_handle    = cv_log_handle ).
  END-OF-DEFINITION.

  ev_etape = 2.

  CLEAR: lv_field.
  MOVE 'FLUX-IDENREG'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_idenreg>.

  CLEAR: lv_field.
  MOVE 'FLUX-FLUX'         TO lv_field.
  ASSIGN (lv_field)        TO <fs_flux>.
  MOVE <fs_flux>           TO lv_subobj.

  CLEAR: lv_field.
  MOVE 'FLUX-NUM_PCE'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_num_pce>.

  CLEAR: lv_field.
  MOVE 'FLUX-DATE_RELEVE'  TO lv_field.
  ASSIGN (lv_field)        TO <fs_date_releve>.

  GET PARAMETER ID 'EAB' FIELD lv_ablbelnr.

  IF NOT sy-subrc IS INITIAL.
    MESSAGE e168(zintf_g_messages)
       WITH 'Impossible de poursuivre le traitement'
            'du processus ZINTF_G_INTEGRATION_RECN'
       INTO lv_message.
    RETURN.
  ENDIF.

** Ouverture de l'objet relève
  CALL FUNCTION 'ISU_O_METERREAD_OPEN'
    EXPORTING
      x_adatsoll   = <fs_date_releve>
      x_action     = '01'
      x_ablbelnr   = lv_ablbelnr
      x_wmode      = '2'
      x_select2    = '1'
      x_no_dialog  = 'X'
      x_upd_online = 'X'
      x_no_enqueue = 'X'
      x_auto       = lt_auto
    IMPORTING
      y_obj        = ls_obj
    EXCEPTIONS
      OTHERS       = 99.

  IF NOT sy-subrc IS INITIAL.
    macro_add_message_to_log.
    RETURN.
  ENDIF.

  CLEAR lv_ablbelnr.
  SET PARAMETER ID 'EAB' FIELD lv_ablbelnr.

  CLEAR ls_ieabl.
  READ TABLE ls_obj-ieabl INTO ls_ieabl INDEX 1.

  IF NOT sy-subrc IS INITIAL.
* Aucune relève pertinente pour le PCE &1 en date du &2
    MESSAGE e242(zintf_g_messages)
       WITH <fs_num_pce>
            <fs_date_releve>
       INTO lv_message.

    CLEAR ls_bpem.
    ls_bpem-num_pce =  <fs_num_pce>.
    IF <fs_date_releve> IS ASSIGNED .
      CASE <fs_flux>.
        WHEN 'ADIF'.
          ls_bpem-date_effet_cont = <fs_date_releve>.
        WHEN 'RE6M' OR 'RE1M' OR 'REMM' OR 'REJJ' OR 'REJM'.
          ls_bpem-date_releve     = <fs_date_releve>.
        WHEN 'AFAC'.
          ls_bpem-date_fin_prest  = <fs_date_releve>.
      ENDCASE.
    ENDIF.

    lv_interface    = <fs_flux>.
    ls_bpem-idenreg = <fs_num_pce>.

    CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
      EXPORTING
        iv_interface_name = lv_interface
        iv_sparte         = 'ZG'
        is_structure      = ls_bpem.

    RETURN.
  ENDIF.

*FPE GE-83 - implémentation RE1M
  IF <fs_flux> EQ 'RE6M'.
    ASSIGN flux TO <fs_flux_re6m>.
    MOVE-CORRESPONDING <fs_flux_re6m> TO ls_flux.
  ELSEIF <fs_flux> EQ 'RE1M'.
    ASSIGN flux TO <fs_flux_re1m>.
    MOVE-CORRESPONDING <fs_flux_re1m> TO ls_flux.
  ELSE.
    ASSIGN flux TO <fs_flux_remm>.
    MOVE-CORRESPONDING <fs_flux_remm> TO ls_flux.
  ENDIF.
*FPE GE-83 - Fin

  CLEAR : lv_energie_entier,
          lv_energie_decimal.

  lv_energie_entier  = trunc( ls_flux-index_brut_fin_periode ).
  lv_energie_decimal =  frac( ls_flux-index_brut_fin_periode ).

  ls_ieabl-zwnummer             = 1.
  ls_ieabl-adat                 = ls_flux-date_releve.
  ls_ieabl-v_zwstand            = lv_energie_entier.
  ls_ieabl-n_zwstand            = lv_energie_decimal.
  ls_ieabl-v_zwstndab           = lv_energie_entier.
  ls_ieabl-n_zwstndab           = lv_energie_decimal.
  ls_ieabl-adattats             = ls_flux-date_releve.
  ls_ieabl-ablstat              = '1'.

  IF ls_flux-vol_brut_conso < 0.
    ls_ieabl-ablhinw            = 'Z4'.
  ENDIF.

  IF ls_flux-qual_index_brut_fin_periode = 'E'.
    ls_ieabl-istablart          = 'Z4'.
  ELSE.
    ls_ieabl-istablart          = '01'.
  ENDIF.

  ls_ieabl-ablestyp             = '01'.

  ls_ieabl-zztype_rel           = ls_flux-type_releve.
  ls_ieabl-zzraison_rel         = ls_flux-raison_releve.
  ls_ieabl-zzdate_debut         = ls_flux-debut_periode.
  ls_ieabl-zzindex_brut_debut   = ls_flux-index_brut_debut_periode.
  ls_ieabl-zzqual_index_brut_debut
                                = ls_flux-qual_index_brut_debut_periode.

  IF ls_flux-flux EQ 'REMM'.
    ls_ieabl-zzindex_conv_debut = ls_flux-index_conv_debut_periode.
    ls_ieabl-zzqual_index_conv_debut
                                = ls_flux-qual_index_conv_debut_periode.
  ENDIF.

  ls_ieabl-zzdate_fin           = ls_flux-fin_periode.
  ls_ieabl-zzqual_index_brut_fin
                                = ls_flux-qual_index_brut_fin_periode.

  IF ls_flux-flux EQ 'REMM'.
    ls_ieabl-zzindex_conv_fin   = ls_flux-index_conv_fin_periode.
    ls_ieabl-zzqual_index_conv_fin
                                = ls_flux-qual_index_conv_fin_periode.
  ENDIF.

  ls_ieabl-zzvolume_brut        = ls_flux-vol_brut_conso.
  ls_ieabl-zzqual_volume_brut   = ls_flux-qualif_vol_brut_conso.

  IF ls_flux-flux EQ 'REMM'.
    ls_ieabl-zzvolume_brut_conv = ls_flux-volume_conv.
    ls_ieabl-zzqual_volume_conv = ls_flux-qualif_volume_conv.
    ls_ieabl-zzqual_coeff_pcs   = ls_flux-qualif_pcs.
  ENDIF.

  ls_ieabl-zzenergie            = ls_flux-energie_conso.
  ls_ieabl-zzqualif_energie     = ls_flux-qualif_energie_conso.

  IF ls_flux-flux EQ 'RE6M' OR ls_flux-flux EQ 'RE1M'.
    ls_ieabl-zzmotif_corr       = ls_flux-motif_correction.
    ls_ieabl-zzorig_corr        = ls_flux-origine_correction.
  ENDIF.

  ls_ieabl-zzidenreg            = ls_flux-idenreg.

  MODIFY ls_obj-ieabl FROM ls_ieabl INDEX 1.

  CALL FUNCTION 'ISU_O_METERREAD_OPEN_SUBOBJ'
    EXPORTING
      x_action   = '01'
      x_auto     = lt_auto
      x_adatsoll = <fs_date_releve>
    CHANGING
      xy_obj     = ls_obj
    EXCEPTIONS
      OTHERS     = 99.

  IF NOT sy-subrc IS INITIAL.
    macro_add_message_to_log.
    RETURN.
  ENDIF.

  CALL FUNCTION 'ISU_O_METERREAD_INPUT'
    CHANGING
      xy_obj = ls_obj
    EXCEPTIONS
      OTHERS = 99.

  IF NOT sy-subrc IS INITIAL.
    macro_add_message_to_log.
    RETURN.
  ENDIF.

* Préparation de la sauvegarde
  CALL FUNCTION 'ISU_O_METERREAD_ACTION'
    EXPORTING
      x_okcode = 'PSAV'
    CHANGING
      xy_obj   = ls_obj
    EXCEPTIONS
      OTHERS   = 99.

  IF NOT sy-subrc IS INITIAL.
    macro_add_message_to_log.
    RETURN.
  ENDIF.

* sauvegarde
  CALL FUNCTION 'ISU_O_METERREAD_ACTION'
    EXPORTING
      x_okcode = 'SAVE'
    CHANGING
      xy_obj   = ls_obj
    EXCEPTIONS
      OTHERS   = 99.

  IF NOT sy-subrc IS INITIAL.
    macro_add_message_to_log.
    RETURN.
  ENDIF.

  CALL FUNCTION 'ISU_O_METERREAD_CLOSE'
    EXPORTING
      x_no_dialog = 'X'
    CHANGING
      xy_obj      = ls_obj
    EXCEPTIONS
      OTHERS      = 99.

  IF NOT sy-subrc IS INITIAL.
    macro_add_message_to_log.
    RETURN.
  ENDIF.

  ev_etape = 1.

ENDFUNCTION.
