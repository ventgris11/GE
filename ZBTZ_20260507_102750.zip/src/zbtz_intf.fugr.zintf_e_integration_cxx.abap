FUNCTION zintf_e_integration_cxx .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_IDENREG) TYPE  ZIDENREG
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN DEFAULT ABAP_FALSE
*"     REFERENCE(IV_ID_FLUX) TYPE  ZID_FLUX
*"  EXPORTING
*"     REFERENCE(EV_DATA) TYPE  CHAR100
*"     REFERENCE(EV_ERROR) TYPE  CRMT_BOOLEAN
*"----------------------------------------------------------------------

  lv_log_object    = lc_log_object_intf_elec.
  lv_log_subobject = lc_log_subobject_c01.
  lv_msgid         = lc_msgid_intf_elec.

  CASE iv_id_flux.
    WHEN 'C01'.
      lv_log_subobject = lc_log_subobject_c01.
    WHEN 'C12'.
      lv_log_subobject = lc_log_subobject_c12.
    WHEN 'C15'.
      lv_log_subobject = lc_log_subobject_c15.
    WHEN OTHERS.
  ENDCASE.

  CLEAR lv_log_handle .

* Appel en mode &1 pour le flux &2
  IF 1 = 2. MESSAGE i018(zintf_e_messages). ENDIF.
  IF iv_mode_test IS INITIAL.
    macro_add_msg_to_log 'I' '018'
                         'REEL' iv_id_flux '' ''.
  ELSE.
    macro_add_msg_to_log 'I' '018'
                         'TEST' iv_id_flux '' ''.
  ENDIF.

  lv_id_flux = iv_id_flux.
  CASE iv_id_flux.
    WHEN 'C01'.
*  IF lv_id_flux = 'C01'.

* Sélection des données à traiter
      SELECT SINGLE *
        INTO CORRESPONDING FIELDS OF ls_cxx
        FROM zintf_e_c01
        WHERE idenreg EQ iv_idenreg.

      SELECT *
        INTO TABLE lt_c01_2
        FROM zintf_e_c01_2
        WHERE idenreg EQ iv_idenreg
        ORDER BY idenreg
                 id_periode.

      SELECT *
        INTO TABLE lt_c01_3
        FROM zintf_e_c01_3
        WHERE idenreg EQ iv_idenreg
        ORDER BY idenreg
                 id_periode
                 rang_cadran.

*=>> STOU 21.11.2017 GDPTMA-202 - Début
      SELECT * FROM zintf_e_afil
        INTO TABLE lt_afil.
*=>> STOU 21.11.2017 GDPTMA-202 - Fin

*  ELSEIF lv_id_flux = 'C15'.
    WHEN 'C15'.

* Sélection des données à traiter
      SELECT SINGLE *
        FROM zintf_e_c15
        INTO CORRESPONDING FIELDS OF ls_cxx
       WHERE idenreg EQ iv_idenreg.

      SELECT *
         INTO TABLE lt_c15_2
         FROM zintf_e_c15_2
         WHERE idenreg EQ iv_idenreg
         ORDER BY idenreg
                  id_releve.

      SELECT *
         INTO TABLE lt_c15_2b
         FROM zintf_e_c15_2b
         WHERE idenreg EQ iv_idenreg.

      SELECT *
          INTO TABLE lt_c15_3
          FROM zintf_e_c15_3
          WHERE idenreg EQ iv_idenreg
          ORDER BY idenreg
                   id_releve.

      IF ls_cxx-code_operation IS NOT INITIAL.
        SELECT *
          FROM zintf_e_c15_c_op
          INTO CORRESPONDING FIELDS OF TABLE lt_c15_c_op
         WHERE code_operation = ls_cxx-code_operation.
        IF sy-subrc = 0.
          LOOP AT lt_c15_c_op INTO ls_c15_c_op.
          ENDLOOP.
        ENDIF.
      ENDIF.

    WHEN 'C12'.
*  ELSEIF lv_id_flux = 'C12'.

* Sélection des données à traiter
      REFRESH : lt_c12_2  ,
                lt_c12_2b ,
                lt_c12_3  .

      CLEAR ls_cxx .

      SELECT SINGLE *
        INTO CORRESPONDING FIELDS OF ls_cxx
        FROM zintf_e_c12
        WHERE idenreg EQ iv_idenreg.

      SELECT *
         INTO TABLE lt_c12_2
         FROM zintf_e_c12_2
         WHERE idenreg EQ iv_idenreg
         ORDER BY idenreg
                  id_releve.

      SELECT *
         INTO TABLE lt_c12_2b
         FROM zintf_e_c12_2b
         WHERE idenreg EQ iv_idenreg
          ORDER BY idenreg
                   id_compteur .

      SELECT *
          INTO TABLE lt_c12_3
          FROM zintf_e_c12_3
          WHERE idenreg EQ iv_idenreg
          ORDER BY idenreg .

*  ENDIF.
  ENDCASE.

  SELECT *
    FROM zintf_e_mesure
    INTO TABLE lt_mesure .

* Par défaut, le flag erreur est positionné à VRAI
* Seule la réussite de l'intégration positionnera le flag à FAUX
  ev_error = abap_true.

  lv_statut_flux    = ls_cxx-statut.

*--DEBUT STOU GE-2318
  REFRESH : lt_ext_ui . "++GE-1938
  ls_ext_ui-ext_ui = ls_cxx-id_prm  .
  APPEND ls_ext_ui TO lt_ext_ui .
  CALL METHOD zcl_tool=>get_ext_ui_type
    CHANGING
      ct_ext_ui = lt_ext_ui.

  READ TABLE lt_ext_ui INTO ls_ext_ui INDEX 1.
** Ajout LWAT 01.11.2018 : On veut toujours la référence du dossier
  IF ls_ext_ui-type = 'B2C' OR ls_ext_ui-bukrs = 'GDP2'.
    lv_b2c = 'X' . "++GDPTMA-349 C15
*    lv_zz_ref_externe = ls_cxx-num_dossier.
*  ELSE.
*    CLEAR   lv_zz_ref_externe .
  ENDIF.
  lv_zz_ref_externe = ls_cxx-num_dossier.
** Fin Ajout LWAT 01.11.2018
*--FIN   STOU GE-2318

**++DEBUT STOU GE-2318
**  CLEAR lv_b2c .
**  DATA lv_type TYPE char5.
**  CALL METHOD zcl_tool=>is_b2b_or_b2c
**    EXPORTING
**      iv_ext_ui       = ls_cxx-id_prm
**      iv_date         = ls_cxx-date_evenement
**    RECEIVING
**      rv_type         = lv_type
**    EXCEPTIONS
**      unknown         = 1
**      no_swtdoc_found = 2
**      OTHERS          = 3.
**  IF sy-subrc <> 0.
** PRM &1 inconnu
**    IF 1 = 2. MESSAGE e265(zintf_e_messages). ENDIF.
**    macro_add_msg_to_log 'E' '265'
**                     ls_cxx-id_prm '' '' ''.
**    PERFORM update_ligne_cxx USING lc_statut_06_rejet.
**    RETURN.
**  ELSE.
**    IF lv_type = 'B2C'.
**      lv_b2c = 'X' . "++GDPTMA-349 C15
**      lv_zz_ref_externe = ls_cxx-num_dossier.
**    ELSE.
**      CLEAR   lv_zz_ref_externe .
**    ENDIF.
**  ENDIF.
**++FIN   STOU GE-2318

*++DEBUT STOU GE-1215
  lv_int_ui = zcl_tool=>pod_check_exist(
                           iv_pce_num = ls_cxx-id_prm ).

* Récupération du numéro de l'installation
  CLEAR : lv_equnr , ls_egerr .
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = ls_cxx-date_evenement
    IMPORTING
      ev_equnr  = lv_equnr.

  CLEAR ls_egerr.
  SELECT * FROM egerr
           INTO ls_egerr UP TO 1 ROWS
          WHERE equnr EQ lv_equnr
            AND bis   GE ls_cxx-date_evenement
            AND ab    LE ls_cxx-date_evenement.
  ENDSELECT.
*++FIN   STOU GE-1215

*DEB-IBEN-20210107-GE-11157
  PERFORM f_ctrl_classe_temporelle CHANGING ev_error.
  IF ev_error IS NOT INITIAL.
    PERFORM update_ligne_cxx USING lc_statut_06_rejet.
    RETURN.
  ENDIF.
*FIN-IBEN-20210107-GE-11157

  CASE lv_id_flux.
    WHEN 'C01'.
*      lv_date_ref = ls_cxx-date_abonnement. " ++ GE-1510 (LWAT)

      IF ls_cxx-even_declencheur     EQ 'S'.
        PERFORM mise_en_service_contrat      USING iv_mode_test
                                          CHANGING ev_data
                                                   ev_error.
      ELSEIF ls_cxx-even_declencheur EQ 'R'.
        PERFORM mise_hors_service_contrat    USING iv_mode_test
                                          CHANGING ev_error.
      ELSEIF ls_cxx-even_declencheur EQ 'M'
*DEB-IBEN-20190528-GE-5178
         OR ls_cxx-even_declencheur EQ 'C'.
*FIN-IBEN-20190528-GE-5178
        PERFORM modification_contrat         USING iv_mode_test
                                          CHANGING ev_error.
      ELSE.
* Type d'événement &1 non géré pour les infos contrat &2 du PRM &3
        IF 1 = 2. MESSAGE e084(zintf_e_messages). ENDIF.
*DEB-IBEN-20190528-GE-5178
*        macro_add_msg_to_log 'I' '084'
*                             ls_cxx-even_declencheur
*                             ls_cxx-id_flux
*                             ls_cxx-id_prm ''.
**        PERFORM update_ligne_cxx USING lc_statut_06_rejet. "OPE-635 -
*        PERFORM update_ligne_cxx USING lc_statut_11_filtre. "OPE-635 +
        macro_add_msg_to_log 'E' '084'
                             ls_cxx-even_declencheur
                             ls_cxx-id_flux
                             ls_cxx-id_prm ''.
        PERFORM update_ligne_cxx USING lc_statut_06_rejet.
*FIN-IBEN-20190528-GE-5178

* Début STOU GDPTMA-348  -> A activer
*        IF ls_cxx-even_declencheur = 'C'.
*          DATA lv_msg TYPE string .
*          MESSAGE e084(zintf_e_messages) WITH ls_cxx-even_declencheur
*                                              ls_cxx-id_flux
*                                              ls_cxx-id_prm ''
*                                         INTO lv_msg .
*          PERFORM f_update_zpce_a_traiter USING lv_msg.
*        ENDIF.
* Fin   STOU GDPTMA-348
        RETURN.
      ENDIF.
    WHEN 'C15'.

*      lv_date_ref = ls_cxx-date_evenement. " ++ GE-1510 (LWAT)

*** --> GE-2462 - GLIC - 04/02/2019 - On ne prend plus que les FOURNI
*      IF ls_cxx-niv_service = '0' .
*        lv_type_class = 'FOURNI'.
*      ELSE.
*        lv_type_class = 'DISTRI'.
*      ENDIF.
      lv_type_class = 'FOURNI'.
*** <-- GE-2462 - GLIC - 04/02/2019
*++ STOU DEBUT GE-1840
      CASE ls_cxx-type_evenement.
        WHEN 'CONTRAT'.
*      IF ls_cxx-type_evenement   EQ 'CONTRAT' .
          CASE ls_cxx-nature_evenement.
            WHEN 'MDPRM'.
* Début - Suppression AFR - GE-11728
*            WHEN 'MCF'  .
*              IF 1 = 2. MESSAGE e182(zintf_e_messages). ENDIF.
*              macro_add_msg_to_log 'E' '182'
*                                   '' '' '' ''.
*              PERFORM update_ligne_cxx USING lc_statut_06_rejet.
*              RETURN.
* Fin - Suppression AFR - GE-11728
*DEB-IBEN-20200929-GE-9836
            WHEN 'MDCTR'.
              IF 1 = 2. MESSAGE e178(zintf_e_messages). ENDIF.
              macro_add_msg_to_log 'E' '178'
                                   ls_cxx-nature_evenement '' '' ''.
              PERFORM update_ligne_cxx USING lc_statut_06_rejet.
              RETURN.
            WHEN 'MDACT'.
              IF 1 = 2. MESSAGE e178(zintf_e_messages). ENDIF.
              macro_add_msg_to_log 'E' '178'
                                   ls_cxx-nature_evenement '' '' ''.
              PERFORM update_ligne_cxx USING lc_statut_11_filtre.
              RETURN.
*FIN-IBEN-20200929-GE-9836
            WHEN 'PMES' OR 'MES' OR 'RES' OR 'CFNS' OR 'CFNE' OR 'MCT' OR 'MCF'. "Ajout MCF AFR - GE-11728
              "Début-HBD- GE-11087 :  filtrer automatiquement flux C15
            WHEN 'AUTRE'.
              IF   ls_cxx-code_operation EQ '27'
                OR ls_cxx-code_operation EQ '42'
                OR ls_cxx-code_operation EQ '45'.

                IF ls_c15_c_op-code_operation = ls_cxx-code_operation.

                  IF 1 = 2. MESSAGE i332(zintf_e_messages). ENDIF.
                  macro_add_msg_to_log 'I' '339'
                                       ls_cxx-id_prm ls_cxx-idenreg ls_c15_c_op-code_operation ''.
                  PERFORM update_ligne_cxx USING lc_statut_11_filtre.
                  RETURN.

                ENDIF.
              ENDIF.
              "Fin-HBD- GE-11087 :  filtrer automatiquement flux C15
            WHEN OTHERS .
              IF 1 = 2. MESSAGE e183(zintf_e_messages). ENDIF.
              macro_add_msg_to_log 'E' '183' ls_cxx-type_evenement ls_cxx-nature_evenement '' ''.
              PERFORM update_ligne_cxx USING lc_statut_06_rejet.
              RETURN.
          ENDCASE.

*      ENDIF.

        WHEN 'TECHNIQUE'.
*      IF ls_cxx-type_evenement   EQ 'TECHNIQUE' .
          IF ls_cxx-origine_evenement = '1'.
            "Le flux C concerne le contrat d’injection
            IF 1 = 2. MESSAGE e177(zintf_e_messages). ENDIF.
            macro_add_msg_to_log 'E' '177'
                                 '' '' '' ''.
            PERFORM update_ligne_cxx USING lc_statut_06_rejet.
            RETURN.
          ENDIF.

          CASE ls_cxx-nature_evenement.
            WHEN 'MDBRA' OR 'COU' OR 'RET'.
              IF 1 = 2. MESSAGE e178(zintf_e_messages). ENDIF.
              macro_add_msg_to_log 'E' '178' ls_cxx-nature_evenement '' '' ''.
              PERFORM update_ligne_cxx USING lc_statut_06_rejet.
              RETURN.
*          WHEN 'COU'  .
*            IF 1 = 2. MESSAGE e179(zintf_e_messages). ENDIF.
*            macro_add_msg_to_log 'E' '179' ls_cxx-nature_evenement '' '' ''.
*            PERFORM update_ligne_cxx USING lc_statut_06_rejet.
*            RETURN.
*          WHEN 'RET'  .
*            IF 1 = 2. MESSAGE e180(zintf_e_messages). ENDIF.
*            macro_add_msg_to_log 'E' '180'
*                                 '' '' '' ''.
*            PERFORM update_ligne_cxx USING lc_statut_06_rejet.
*            RETURN.

*GE-6096 - GE-6304 - GLIC - 11/09/2019 - début
*            WHEN 'CMAT'  OR 'ENOAS' .
            WHEN 'CMAT'.
*              IF ls_cxx-code_operation IS NOT INITIAL.
              IF ls_cxx-code_operation EQ '45'."GE-11087 - HBD - 19/11/2021
                IF ls_c15_c_op-code_operation = ls_cxx-code_operation.

                  IF 1 = 2. MESSAGE i332(zintf_e_messages). ENDIF.
                  macro_add_msg_to_log 'I' '332'
                                       ls_cxx-id_prm ls_cxx-idenreg ls_c15_c_op-code_operation ''.
                  PERFORM update_ligne_cxx USING lc_statut_11_filtre.
                  RETURN.

                ENDIF.
              ENDIF.
              IF ls_cxx-cat_materiel = 'DISJONCTEUR'.
                IF 1 = 2. MESSAGE i333(zintf_e_messages). ENDIF.
                macro_add_msg_to_log 'I' '333'
                                     ls_cxx-id_prm ls_cxx-idenreg '' ''.
                PERFORM update_ligne_cxx USING lc_statut_11_filtre.
                RETURN.
              ENDIF.
            WHEN 'ENOAS'.
*GE-6096 - GE-6304 - GLIC - 11/09/2019 - fin
*GE-7742 - GLIC - 23/12/2019 - Début
            WHEN 'MDPRM'.
*GE-7742 - GLIC - 23/12/2019 - Fin
*GE-11087 - HBD - 19/11/2021 - Début
            WHEN 'MCF'. "+GE-11728
            WHEN 'AUTRE'.
              IF   ls_cxx-code_operation EQ '27'
                OR ls_cxx-code_operation EQ '42'
                OR ls_cxx-code_operation EQ '45'.

                IF ls_c15_c_op-code_operation = ls_cxx-code_operation.

                  IF 1 = 2. MESSAGE i332(zintf_e_messages). ENDIF.
                  macro_add_msg_to_log 'I' '339'
                                       ls_cxx-id_prm ls_cxx-idenreg ls_c15_c_op-code_operation ''.
                  PERFORM update_ligne_cxx USING lc_statut_11_filtre.
                  RETURN.

                ENDIF.
              ENDIF.
*GE-11087 - HBD - 19/11/2021 - Fin
            WHEN OTHERS .
              IF 1 = 2. MESSAGE e181(zintf_e_messages). ENDIF.
              macro_add_msg_to_log 'E' '181' ls_cxx-type_evenement ls_cxx-nature_evenement '' ''.
              PERFORM update_ligne_cxx USING lc_statut_06_rejet.
              RETURN.
          ENDCASE.

*      ENDIF.
      ENDCASE.

*++ STOU FIN   GE-1840
      IF ls_cxx-nature_evenement     EQ 'MES'
      OR ls_cxx-nature_evenement     EQ 'PMES'  "++GE-1840
      OR ls_cxx-nature_evenement     EQ 'CFNE'.
        PERFORM mise_en_service_contrat   USING iv_mode_test
                                          CHANGING ev_data ev_error.
      ELSEIF ls_cxx-nature_evenement EQ 'RES'
          OR ls_cxx-nature_evenement EQ 'CFNS'.
        PERFORM mise_hors_service_contrat    USING iv_mode_test
                                          CHANGING ev_error.
      ELSEIF ls_cxx-nature_evenement EQ 'CMAT'
          OR ls_cxx-nature_evenement EQ 'MCT'
          OR ls_cxx-nature_evenement EQ 'MCF' "Ajout AFR - GE-11728
          OR ls_cxx-nature_evenement EQ 'ENOAS' "GDPTMA-349 +
          OR ls_cxx-type_evenement   EQ 'MIGRATION' .
        PERFORM modification_contrat   USING    iv_mode_test
                                       CHANGING ev_error.
*++ STOU DEBUT GE-1840
      ELSEIF ls_cxx-nature_evenement EQ 'MDPRM' .
        PERFORM modification_prm USING    iv_mode_test
                                 CHANGING ev_error.
*++ STOU FIN   GE-1840
      ELSE.
*++ STOU DEBUT GE-1840
        "Type événement &1 / Nature événement &2 non géré
        IF 1 = 2. MESSAGE e190(zintf_e_messages). ENDIF.
        macro_add_msg_to_log 'E' '190'
                             ls_cxx-type_evenement
                             ls_cxx-nature_evenement
                              '' ''.
        PERFORM update_ligne_cxx USING lc_statut_06_rejet. "++GE-1840
*++ STOU FIN   GE-1840

*-- STOU DEBUT GE-1840
* Type d'événement &1 non géré pour les infos contrat &2 du PRM &3
*        IF 1 = 2. MESSAGE e084(zintf_e_messages). ENDIF.
*        macro_add_msg_to_log 'E' '084' " -- GE-2488 (LWAT)
*        macro_add_msg_to_log 'I' '084' " ++ GE-2488 (LWAT)
*                             ls_cxx-nature_evenement
*                             ls_cxx-id_flux
*                             ls_cxx-id_prm ''.
*        PERFORM update_ligne_cxx USING lc_statut_11_filtre.
*-- STOU FIN   GE-1840
        RETURN.
      ENDIF.

    WHEN 'C12'.
*      lv_date_ref = ls_cxx-date_evenement. " ++ GE-1510 (LWAT)

      IF ls_cxx-nature_evenement CS 'CFN' OR
         ls_cxx-nature_evenement CS 'MES' OR
         ls_cxx-nature_evenement CS 'PMES'.
*DEB-IBEN-20190813-GE-6381
        IF ls_cxx-nature_evenement CS 'CFN' AND ls_cxx-date_fin IS NOT INITIAL.
          PERFORM mise_hors_service_contrat USING iv_mode_test
                                  CHANGING ev_error.
        ELSE.
*FIN-IBEN-20190813-GE-6381
          PERFORM mise_en_service_contrat   USING iv_mode_test
                                            CHANGING ev_data ev_error.
*DEB-IBEN-20190813-GE-6381
        ENDIF.
*FIN-IBEN-20190813-GE-6381
      ELSEIF ls_cxx-nature_evenement CS 'RES' .
        PERFORM mise_hors_service_contrat USING iv_mode_test
                                          CHANGING ev_error.

      ELSEIF ls_cxx-nature_evenement CS 'CPS' OR
             ls_cxx-nature_evenement CS 'CTF'.
*DEB-IBEN-20210301-GE-11267
**DEB-GLIC-20200220-GE-8389 - On ne modifie plus le contrat mais on remonte un message d'erreur
**        PERFORM modification_contrat      USING iv_mode_test
**                                         CHANGING ev_error.
*        IF 1 = 2. MESSAGE e618(zintf_e_messages). ENDIF.
*        macro_add_msg_to_log 'E' '618'
*                             ls_cxx-id_prm '' '' ''.
*        PERFORM update_ligne_cxx USING lc_statut_06_rejet.
*FIN-GLIC-20200220-GE-8389
        PERFORM modification_contrat_c12  CHANGING ev_error.
*FIN-IBEN-20210301-GE-11267

*DEB-GLIC-20200220-GE-8389 - Ajout CCF
      ELSEIF ls_cxx-nature_evenement CS 'CCF'.
        IF 1 = 2. MESSAGE e619(zintf_e_messages). ENDIF.
        macro_add_msg_to_log 'E' '619'
                             ls_cxx-id_prm '' '' ''.
        PERFORM update_ligne_cxx USING lc_statut_06_rejet.
*FIN-GLIC-20200220-GE-8389

      ELSEIF ls_cxx-nature_evenement IS INITIAL. "++GE-1297
        PERFORM integrer_event_vide .
      ELSE.
* Type d'événement &1 non géré pour les infos contrat &2 du PRM &3
        IF 1 = 2. MESSAGE e084(zintf_e_messages). ENDIF.
        macro_add_msg_to_log 'E' '084'
                             ls_cxx-nature_evenement
                             ls_cxx-id_flux
                             ls_cxx-id_prm ''.
        PERFORM update_ligne_cxx USING lc_statut_06_rejet.
*        PERFORM update_ligne_cxx USING lc_statut_11_filtre.
        RETURN.
      ENDIF.

  ENDCASE.

ENDFUNCTION.
