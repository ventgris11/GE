FUNCTION zintf_g_ctrl_doc_fact_annul.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  TYPES : BEGIN OF ty_data_cycl,
            date_event          TYPE dats,
            factures            TYPE zinvoice_t,
            doc_calc            TYPE zdoc_calcul_t,
            date_limit_doc_calc TYPE dats,
          END OF ty_data_cycl.

  DATA:
    lv_field         TYPE string,
    lv_int_ui        TYPE int_ui,
    lv_anlage        TYPE anlage,
    ls_object        TYPE eedm_isu_objects,
    lt_anlage        TYPE isu_t_eanlkey_h,
    lv_instdata      TYPE isu2a_instdata,
    lt_idispdata     TYPE isu_bi_inst_dispdata_tab,
    lv_idispdata     TYPE isu_bi_inst_dispdata,
    lt_ianl_bdoc     TYPE isu_bi_inst_billdoc_disp_tab,
    lv_ianl_bdoc     TYPE isu_bi_inst_billdoc_disp,
    lv_message       TYPE char255,
    lv_error_annul   TYPE string,
    lv_message_annul TYPE string,
    lv_intopbel      TYPE intopbel,
    pes_data_cycl    TYPE ty_data_cycl.

  FIELD-SYMBOLS :
    <fs_emetteur>,
    <fs_flux>,
    <fs_idenreg>,
    <fs_num_pce>,
    <fs_date_releve>,
    <fs_type>, <fs_raison>.

  DEFINE macro_add_message_to_log.
    MESSAGE &1(zintf_g_messages)
       WITH <fs_emetteur>
            <fs_flux>
            <fs_idenreg>
            &2
       INTO lv_message.
    RETURN.
  END-OF-DEFINITION.

  ev_etape = 1.

  CLEAR: lv_field.
  MOVE 'FLUX-EMETTEUR'     TO lv_field.
  ASSIGN (lv_field)        TO <fs_emetteur>.

  CLEAR: lv_field.
  MOVE 'FLUX-FLUX'         TO lv_field.
  ASSIGN (lv_field)        TO <fs_flux>.

  CLEAR: lv_field.
  MOVE 'FLUX-IDENREG'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_idenreg>.

  CLEAR: lv_field.
  MOVE 'FLUX-NUM_PCE'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_num_pce>.


  CLEAR: lv_field.
  MOVE 'FLUX-DATE_RELEVE'                 TO lv_field.
  ASSIGN (lv_field)                       TO <fs_date_releve>.



*+GE-14730 {
  DATA : lv_days          TYPE vtbbewe-atage,
         lv_date_to       TYPE vtbbewe-dberbis,
         lv_date_from     TYPE vtbbewe-dbervon,
         lv_jours_facture TYPE i.

  FIELD-SYMBOLS : <fs_fin_periode>.
  CLEAR lv_field.
  MOVE 'FLUX-FIN_PERIODE'  TO lv_field.
  ASSIGN (lv_field)        TO <fs_fin_periode>.

  FIELD-SYMBOLS : <fs_type_releve>.
  CLEAR lv_field.
  MOVE 'FLUX-TYPE_RELEVE'  TO lv_field.
  ASSIGN (lv_field)        TO <fs_type_releve>.

  FIELD-SYMBOLS : <fs_type_flux>.
  CLEAR lv_field.
  MOVE 'FLUX-FLUX'  TO lv_field.
  ASSIGN (lv_field)        TO <fs_type_flux>.

  SELECT SINGLE low
           INTO @DATA(lv_low)
           FROM tvarvc
          WHERE name EQ 'ZINTF_G_REXX_C_JOURS_FACTURE'.

  lv_jours_facture = lv_low.
*+GE-14730 }

* Récupération du PCE
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).

  IF lv_int_ui IS INITIAL.
    IF 1 = 2. MESSAGE e240(zintf_g_messages). ENDIF.
*   &1 - &2 - &3 : PCE &4 inconnu
    macro_add_message_to_log e240 <fs_num_pce>.
  ENDIF.

* Récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.

  IF ls_object-installation IS INITIAL.
    IF 1 = 2. MESSAGE e241(zintf_g_messages). ENDIF.
*   &1 - &2 - &3 : Aucune installation trouvée pour le PCE &4
    macro_add_message_to_log e241 <fs_num_pce>.
  ENDIF.

  lv_anlage = ls_object-installation.

  INSERT lv_anlage INTO TABLE lt_anlage.

  CLEAR lt_idispdata.

* Recherche des informations nécessaires aux différentes annulations
  CALL FUNCTION 'ISU_INST_BIVIEW_SELECT'
    EXPORTING
      x_ab         = <fs_date_releve>
      x_ianlkey    = lt_anlage
    IMPORTING
      y_instdata   = lv_instdata
    CHANGING
      xy_idispdata = lt_idispdata.

  CLEAR lv_idispdata.
  READ TABLE lt_idispdata INTO lv_idispdata WITH KEY anlage = lv_anlage.

* Contrôle s'il existe bien des documents de calcul de facturation
  CHECK lv_idispdata-ianl_bdoc[] IS NOT INITIAL.

  lt_ianl_bdoc = lv_idispdata-ianl_bdoc.

* Elimination des documents de calcul de facturation sans numéro
  DELETE lt_ianl_bdoc WHERE belnr IS INITIAL.

* Elimination des documents de calcul de facturation
* liés à des relèves antérieures à la relève corrigée
  DELETE lt_ianl_bdoc WHERE endabrpe LT <fs_date_releve>.

* Contrôle s'il existe bien des documents de calcul de facturation
* liés à des relèves postérieures ou égales à la relève corrigée
  CHECK lt_ianl_bdoc[] IS NOT INITIAL.

*FPE-DEB-GE-7355  "Contrôlé si facture déjà annulée
  LOOP AT lt_ianl_bdoc INTO lv_ianl_bdoc.
    SELECT SINGLE intopbel
      FROM erdk
      INTO lv_intopbel
      WHERE opbel = lv_ianl_bdoc-opbel
      AND intopbel NE ''.
    IF lv_intopbel IS NOT INITIAL.
      DELETE lt_ianl_bdoc WHERE opbel = lv_ianl_bdoc-opbel.
    ENDIF.
  ENDLOOP.
*FPE-FIN-GE-7355


  CHECK lt_ianl_bdoc[] IS NOT INITIAL.
* Tri pour annuler les documents de calcul de facturation
* du plus récent au ancien sur la période considérée


*+GE-14730 {
  IF <fs_type_releve> IS ASSIGNED AND <fs_type_releve> = 'A' AND
     <fs_type_flux> IS ASSIGNED AND ( <fs_type_releve> = 'RE6M' OR <fs_type_releve> = 'RE1M' ) .


    SORT lt_ianl_bdoc BY opbel .
    SELECT *
      FROM erdk
      INTO TABLE @DATA(lt_erdk)
      FOR ALL ENTRIES IN @lt_ianl_bdoc
      WHERE opbel = @lt_ianl_bdoc-opbel.

    DELETE lt_erdk WHERE opbel IS INITIAL.
    SORT lt_erdk BY opbel.
    SORT lt_ianl_bdoc BY endabrpe DESCENDING.

    LOOP AT lt_ianl_bdoc INTO lv_ianl_bdoc WHERE opbel IS NOT INITIAL.

      READ TABLE lt_erdk INTO DATA(ls_erdk) WITH KEY opbel = lv_ianl_bdoc-opbel BINARY SEARCH.
      IF sy-subrc EQ 0.

        CLEAR : lv_days,lv_date_to,lv_date_from.

        lv_date_to   = sy-datum.
        lv_date_from = <fs_fin_periode>.

        CALL FUNCTION 'FIMA_DAYS_AND_MONTHS_AND_YEARS'
          EXPORTING
            i_date_from = lv_date_from
            i_date_to   = lv_date_to
          IMPORTING
            e_days      = lv_days.
        IF sy-subrc EQ 0.
          IF ( abs( lv_days ) > lv_jours_facture ) AND ls_erdk-druckdat IS NOT INITIAL.
            MESSAGE e255(zintf_g_messages)
               WITH <fs_num_pce>
                    lv_ianl_bdoc-opbel
                    <fs_fin_periode>
               INTO lv_message.
            ev_etape = 2.
            RETURN.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDLOOP.
  ENDIF.
*+GE-14730 }

  SORT lt_ianl_bdoc BY endabrpe DESCENDING.

*  ev_etape = 2.                                             "GE-13361

  CALL METHOD zcl_tool=>annule_factures
    EXPORTING
      iv_date         = <fs_date_releve>
      iv_installation = lv_anlage
    IMPORTING
      et_factures     = pes_data_cycl-factures
      et_doc_calcul   = pes_data_cycl-doc_calc
      ev_error        = lv_error_annul
      ev_message      = lv_message_annul.
  IF lv_error_annul IS NOT INITIAL.
    IF lv_error_annul CS 'Annulation Rapprochement'.
    ELSE.

      "Erreur dans méthode annulation.
      ev_etape = 2.                                         "GE-13361
*    ev_etape = 1.                                           "GE-13361
      RETURN.
    ENDIF.
  ENDIF.

  FREE lt_ianl_bdoc.

ENDFUNCTION.
