*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZDSO_RESIL_DEM
*   generation date: 22.04.2019 at 02:53:36
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZDSO_RESIL_DEM     .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.
