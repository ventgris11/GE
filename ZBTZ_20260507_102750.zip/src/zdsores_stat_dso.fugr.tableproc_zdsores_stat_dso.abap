*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDSORES_STAT_DSO
*   generation date: 03.04.2019 at 15:42:03
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDSORES_STAT_DSO    .

  PERFORM TABLEPROC.

ENDFUNCTION.
