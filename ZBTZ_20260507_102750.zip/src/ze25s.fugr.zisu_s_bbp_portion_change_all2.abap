FUNCTION zisu_s_bbp_portion_change_all2.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(X_DATE) LIKE  SYST-DATUM
*"     REFERENCE(X_OPBEL) TYPE  EABP-OPBEL
*"     REFERENCE(X_NO_DIALOG) TYPE  REGEN-NO_DIALOG DEFAULT 'X'
*"     REFERENCE(X_CHANGE) TYPE  REA64-CHANGE DEFAULT SPACE
*"     REFERENCE(X_TAKE_AMOUNT) TYPE  REA64-TAKE_AMOUNT DEFAULT SPACE
*"  EXPORTING
*"     REFERENCE(X_NEWBBP) TYPE  ISU25_T_OBJ
*"     REFERENCE(X_CHANGED) TYPE  REGEN-CHANGED
*"  CHANGING
*"     REFERENCE(X_NO_NEW) TYPE  REA64-NO_NEW DEFAULT SPACE
*"  EXCEPTIONS
*"      INPUT_ERROR
*"      UPDATE_ERROR
*"      OPEN_ERROR
*"      NO_CHANGE_NECESSARY
*"      READ_ERROR
*"----------------------------------------------------------------------

  DATA: l_obj      TYPE isu25_budbilplan,
        h_date     TYPE syst-datum,
        l_active   TYPE kennzx,
        act_date   TYPE d,
        tab_everc  TYPE epc_ever_change_tab,
        lt_auto_pc TYPE isu25_auto_portion_change_tab.

*DEB-IBENRAHHALI-20180945-GE-2142
  DATA: lt_ieabps TYPE isu25_budbildate_table,
        ls_eabps  TYPE eabps,
        ld_max_faedn TYPE eabps-faedn.
*FIN-IBENRAHHALI-20180924-GE-2142

* Export-Parameter sicherheitshalber löschen:
  x_changed = co_false.
  REFRESH x_newbbp.

* Prüfung aller Import-Parameter
  PERFORM f20_check_import_params USING 'ISU_S_BBP_PORTION_CHANGE'
                                        x_date
                                        x_opbel.

* Bisheriges BBP-Objekt lesen
  PERFORM f20_read_object USING x_opbel
                                l_obj.

* Allgemeine Prüfungen des Objekts
  PERFORM f20_check_object USING l_obj
                                 x_take_amount.

  PERFORM f20_check_move_out USING    x_date
                             CHANGING l_obj
                                      h_date.

* Ermittlung des frühesten Termins, zu dem deaktiviert werden kann:
  PERFORM f20_act_date_determine USING h_date
                                       l_obj
                              CHANGING act_date
                                       l_active.

* Bisherige und neue (Termin-)daten lesen
  PERFORM f20_read_termdat USING x_change
                                 l_obj
                                 h_date
                                 l_active
                        CHANGING tab_everc
                                 act_date.

* Prüfung: - Konsistenz der Termindaten
*          - Welche neuen BBPs sollen angelegt werden
  PERFORM check_termdat USING x_change
                              tab_everc
                              l_obj.

* Alter ABP abgrenzen oder anpassen?
  IF x_change = co_true.
    PERFORM f20_change_act_date USING l_obj
                                      act_date
                                      x_no_new
                                      tab_everc.
  ENDIF.

*DEB-IBENRAHHALI-20180945-GE-2142
  lt_ieabps[] = l_obj-ieabps[].
  DELETE lt_ieabps WHERE augst <> '9' OR betrw = 0.
  SORT lt_ieabps BY faedn DESCENDING.
  READ TABLE lt_ieabps INTO ls_eabps INDEX 1.
  IF sy-subrc = 0.
    ld_max_faedn = ls_eabps-faedn + 1.
    IF x_date <= ld_max_faedn.
      act_date = ld_max_faedn.
    ELSE.
      act_date = x_date - 1.
    ENDIF.
  ELSE.
    act_date = x_date - 1.
  ENDIF.
*FIN-IBENRAHHALI-20180924-GE-2142

  IF act_date NE l_obj-eabp-endperiode.

*DEB-IBENRAHHALI-20180924-GE-2142
*    act_date = l_obj-eabp-begperiode + 1. "GE-330
**DEB-IBENRAHHALI-20180715-GE-1554
***   Alten Abschlagsplan abgrenzen
**    PERFORM f20_deactivate_old_object USING act_date
**                                            co_augrd_pc
**                                   CHANGING l_obj.
*    PERFORM f20_change_object_amount CHANGING l_obj.
**FIN-IBENRAHHALI-20180715-GE-1554
    PERFORM f20_change_object_amount CHANGING l_obj.

    PERFORM f20_deactivate_old_object USING act_date
                                            co_augrd_pc
                                   CHANGING l_obj.
*FIN-IBENRAHHALI-20180924-GE-2142

*   Abgegrenztes BBP-Objekt zurückschreiben
    PERFORM f20_update_object USING l_obj.

    x_changed = co_true.
  ENDIF.

* Objektsperren zurücknehmen
  PERFORM f20_close_object USING l_obj.

  IF x_no_new = co_false.
*   Anlegen neuer Abschlagspläne

*   Füllen der Automationsdaten für Betragsübernahme
    IF x_take_amount = co_true.
      PERFORM f20_take_over_amount USING l_obj
                                         tab_everc
                                CHANGING lt_auto_pc.
    ENDIF.

*   Aufruf des Anlegebausteins
    PERFORM f20_create_new_bbp USING act_date
                                     tab_everc
                                     l_obj
                                     x_newbbp[]
                                     x_no_dialog
                                     x_take_amount
                                     lt_auto_pc.
  ENDIF.

* Datenbankcommit nötig
  COMMIT WORK.

ENDFUNCTION.
