class ZCL_DEMAT definition
  public
  final
  create public .

public section.

  constants GC_INT_DATACO type CHAR1 value 'C' ##NO_TEXT.
  constants GC_INT_SPLIO_TRIGGER type CHAR1 value 'T' ##NO_TEXT.
  constants GC_INT_SPLIO_DATA type CHAR1 value 'D' ##NO_TEXT.
  class-data GV_LOG_HANDLE type BALLOGHNDL .

  class-methods GET_URL_ESPACE_CLIENT
    importing
      !IV_GUID type BU_PARTNER
    exporting
      !EV_URL type RVARI_VAL_255 .
  class-methods SEND_EVENT_ACTIVATION_CONTRAT
    importing
      !IV_PCE type EXT_UI
      !IV_DATE_ACTIVATION type DATS
      !IV_NUM_AFFAIRE type ZNUM_DOSSIER .
  class-methods SEND_EVENT_CONFIRM_PAIEMENT
    importing
      !IV_PAIEMENT type KEYZ1_KK
    exceptions
      ERROR .
  class-methods SEND_EVENT_JSON
    importing
      !IV_EVENT type CHAR30
      !IV_EMAIL type AD_SMTPADR optional
      !IS_STRUCT_DATACO type DATA
      !IS_STRUCT_SPLIO_TRIGGER type ZCRM_DEMAT_SPLIO_TRIG_T optional
      !IS_STRUCT_SPLIO_DATA type DATA optional
      !IV_INTERFACE type CHAR1 optional
    exporting
      value(EV_R_JSON) type STRING
      value(EV_R_JSON_SPLIO_TRIGGER) type STRING
      value(EV_R_JSON_SPLIO_DATA) type STRING
    exceptions
      INTERFACE_DESACTIVE
      ERROR_SEND_HTTP
      ERROR_SERIALISATION
      ERROR_EVENEMENT_INCONNU .
  class-methods JSON_RELANCE_ERR
    exporting
      !ET_JSON_OK type ZJSON_ERR_TBL
      !ET_JSON_KO type ZJSON_ERR_TBL .
  class-methods SEND_HTTP_REQUEST_POST
    importing
      !IV_PATH type STRING
      !IV_DESTINATION type RFCDEST
      !IV_BODY type STRING
      !IV_METHOD_TYPE type STRING default 'POST'
      !IV_MEDIA_TYPE type STRING default 'application/x-www-form-urlencoded'
    exporting
      !ER_HTTP_REQUEST type ref to IF_HTTP_CLIENT
      !EV_HTTP_CODE type INT4
      !EV_BODY type STRING
    exceptions
      ERROR_GEN_HTTP
      ERROR_SENDING
      ERROR_RECEIVING .
protected section.

  class-methods GENERATE_HTTP_LINK
    importing
      !IV_DESTINATION type RFCDEST
      !IV_METHOD_TYPE type STRING default IF_HTTP_REQUEST=>CO_REQUEST_METHOD_GET
      !IV_CONTENT_TYPE type STRING default 'application/json; charset=utf-8'
    returning
      value(RR_HTTP_CLIENT) type ref to IF_HTTP_CLIENT
    exceptions
      ERROR .
  class-methods SET_DEFAULT_HTTP_CONF
    importing
      !IR_CLIENT type ref to IF_HTTP_CLIENT
      !IV_METHOD_TYPE type STRING default IF_HTTP_REQUEST=>CO_REQUEST_METHOD_GET
      !IV_CONTENT_TYPE type STRING default 'application/json; charset=utf-8' .
  class-methods SEND_HTTP_REQUEST
    importing
      !IV_PATH type STRING
      !IV_DESTINATION type RFCDEST
      !IV_BODY type STRING
      !IV_METHOD_TYPE type STRING
      !IV_CONTENT_TYPE type STRING optional
    exporting
      !ER_HTTP_REQUEST type ref to IF_HTTP_CLIENT
      !EV_HTTP_CODE type INT4
      !EV_BODY type STRING
    exceptions
      ERROR_GEN_HTTP
      ERROR_SENDING
      ERROR_RECEIVING .
  class-methods INSERT_JSON_ERROR
    importing
      !IV_EVENT type ZEVENT
      !IV_INTERFACE type ZINTERFACE
      !IS_DATACO type DATA optional
      !IS_SPLIO_DATA type ZCRM_DEMAT_SPLIO_DATA optional
      !IS_SPLIO_TRIG type ZCRM_DEMAT_SPLIO_TRIG_T optional
      !IV_EMAIL type AD_SMTPADR optional
      !IV_ERROR type STRING .
  class-methods ADD_LOG
    importing
      !IV_OBJECT type BALOBJ_D
      !IV_SUBOBJECT type BALSUBOBJ
      !IT_MSG type BAL_TT_MSG .
  class-methods ADD_MESSAGE
    importing
      !IV_ID type CHAR26
      !IV_MSGV1 type SYMSGV optional
      !IV_MSGV2 type SYMSGV optional
      !IV_MSGV3 type SYMSGV optional
      !IV_MSGV4 type SYMSGV optional
    exporting
      !ET_MSG type BAL_TT_MSG .
private section.
ENDCLASS.



CLASS ZCL_DEMAT IMPLEMENTATION.


  METHOD add_log.

    DATA :   lv_log_handle TYPE balloghndl,
             lt_log_handle TYPE bal_t_logh,
             ls_log        TYPE bal_s_log,
             ls_msg        TYPE bal_s_msg.

    "Création de la LOG applicative :
    ls_log-object    = iv_object.
    ls_log-subobject = iv_subobject .

    CALL FUNCTION 'BAL_LOG_CREATE'
      EXPORTING
        i_s_log                 = ls_log
      IMPORTING
        e_log_handle            = lv_log_handle
      EXCEPTIONS
        log_header_inconsistent = 1
        OTHERS                  = 2.
    IF sy-subrc <> 0.
*      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.

    "Erreurs techniques :
    LOOP AT it_msg INTO ls_msg .

      CALL FUNCTION 'BAL_LOG_MSG_ADD'
        EXPORTING
          i_log_handle     = lv_log_handle
          i_s_msg          = ls_msg
        EXCEPTIONS
          log_not_found    = 1
          msg_inconsistent = 2
          log_is_full      = 3
          OTHERS           = 4.

      IF sy-subrc <> 0.
*        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*                   WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      ENDIF.

    ENDLOOP.

    APPEND lv_log_handle TO lt_log_handle.

    CALL FUNCTION 'BAL_DB_SAVE'
      EXPORTING
        i_save_all       = 'X'
        i_t_log_handle   = lt_log_handle
      EXCEPTIONS
        log_not_found    = 1
        save_not_allowed = 2
        numbering_error  = 3
        OTHERS           = 4.

    IF sy-subrc <> 0.
*      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.

*    CALL FUNCTION 'BAL_DSP_LOG_DISPLAY'
*      EXPORTING
*        i_t_log_handle       = lt_log_handle
*      EXCEPTIONS
*        profile_inconsistent = 1
*        internal_error       = 2
*        no_data_available    = 3
*        no_authority         = 4
*        OTHERS               = 5.
*
*    IF sy-subrc <> 0.
*      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
*    ENDIF.

    REFRESH lt_log_handle.

  ENDMETHOD.


  METHOD add_message.

    DATA : ls_msg    TYPE bal_s_msg,
           lv_length TYPE i.

    CLEAR : ls_msg,
            lv_length.
    IF iv_id = 'SYST'.
      MOVE-CORRESPONDING sy TO ls_msg .
    ELSE.
      lv_length = strlen( iv_id ) - 6.

      ls_msg-msgid = iv_id+5(lv_length).
      ls_msg-msgno = iv_id+1(3).
      ls_msg-msgty = iv_id(1) .
      ls_msg-msgv1 = iv_msgv1 .
      ls_msg-msgv2 = iv_msgv2 .
      ls_msg-msgv3 = iv_msgv3 .
      ls_msg-msgv4 = iv_msgv4 .
    ENDIF.


    APPEND ls_msg TO et_msg.


  ENDMETHOD.


  METHOD generate_http_link.

    DATA: lv_dummy TYPE string.

    " Generate HTTP link to Manny
    CALL METHOD cl_http_client=>create_by_destination
      EXPORTING
        destination              = iv_destination
      IMPORTING
        client                   = rr_http_client
      EXCEPTIONS
        destination_not_found    = 1
        internal_error           = 2
        argument_not_found       = 3
        destination_no_authority = 4
        plugin_not_active        = 5
        OTHERS                   = 5.

    " Handle of SAP errors
    IF sy-subrc <> 0.
      CASE sy-subrc.
        WHEN 3.
          MESSAGE s000(sr) WITH
            'Echéc de création : Argument non trouvé'
                                        INTO lv_dummy. "#EC NOTEXT
        WHEN 4.
          MESSAGE s000(sr) WITH
            'Echéc de création : Destination non autorisée'
                                        INTO lv_dummy. "#EC NOTEXT
        WHEN 5.
          MESSAGE s000(sr) WITH
           'Echéc de création : plugin non activé'
                                        INTO lv_dummy. "#EC NOTEXT
        WHEN OTHERS.
          MESSAGE s000(sr) WITH 'Echéc création'
                                        INTO lv_dummy. "#EC NOTEXT
      ENDCASE.

      RAISE error.
    ENDIF.

    zcl_demat=>set_default_http_conf( ir_client       = rr_http_client
                                      iv_method_type  = iv_method_type
                                      iv_content_type = iv_content_type
                                    ).

  ENDMETHOD.


METHOD get_url_espace_client.

** Cette méthode permet de vérifier s'il sagit d'un client VEV/HELIUM
  DATA:
        lv_is_pte          TYPE crmt_boolean .

  CALL FUNCTION 'ZBT_HAS_VEV_CONTRACT'
    EXPORTING
      x_partner    = iv_guid
    IMPORTING
      y_client_vev = lv_is_pte.

  " identifier si le client est VEV ou HELIUM
  IF  lv_is_pte = abap_true.

    SELECT SINGLE low FROM tvarvc INTO ev_url  WHERE name = 'ZMAIL_B2C_FOOTER_VEV'.
  ELSE.
    SELECT SINGLE low FROM tvarvc INTO ev_url  WHERE name = 'ZMAIL_B2C_FOOTER_HEL'.

  ENDIF.

ENDMETHOD.


  METHOD insert_json_error.

    DATA : ls_erreur TYPE zjson_err,
           lv_index  TYPE i,
           ls_field  TYPE zcrm_demat_splio_data_field.


    FIELD-SYMBOLS : <fs_champ> TYPE any .

    CLEAR ls_erreur .

    ls_erreur-event           = iv_event .
    ls_erreur-date_lancement  = sy-datum .
    ls_erreur-interface       = iv_interface .
    ls_erreur-email           = iv_email .

    TRY.
        CALL METHOD
cl_system_uuid=>if_system_uuid_static~create_uuid_x16
          RECEIVING
            uuid = ls_erreur-guid.
      CATCH cx_uuid_error .
    ENDTRY.

    CASE iv_interface .
      WHEN zcl_demat=>gc_int_splio_data.
        DO 3 TIMES.
          ADD 1 TO lv_index .
          ASSIGN COMPONENT lv_index OF STRUCTURE is_splio_data
                                    TO <fs_champ> .
          IF sy-subrc = 0.
            IF lv_index = 1.
              ls_erreur-splio_data  = <fs_champ>  .
            ELSE.
              ls_erreur-splio_data  = ls_erreur-splio_trig
                                      && ';' && <fs_champ> .
            ENDIF.
          ELSE.
            EXIT.
          ENDIF.
        ENDDO.

        LOOP AT is_splio_data-fields INTO ls_field.
          ls_erreur-splio_data = ls_erreur-splio_data && ';'
                                                && ls_field-id
                                                && ':' &&
                                                ls_field-value && ';' .
        ENDLOOP.

        "Supprimer le dernier ";"
        SHIFT ls_erreur-splio_data RIGHT DELETING TRAILING '; '.
        CONDENSE ls_erreur-splio_data .

      WHEN zcl_demat=>gc_int_splio_trigger.
        DO .
          ADD 1 TO lv_index .
          ASSIGN COMPONENT lv_index OF STRUCTURE is_splio_trig
                                    TO <fs_champ> .
          IF sy-subrc = 0.
            IF lv_index = 1.
              ls_erreur-splio_trig  = <fs_champ>  .
            ELSE.
              ls_erreur-splio_trig  = ls_erreur-splio_trig
                                      && ';' && <fs_champ> .
            ENDIF.
          ELSE.
            EXIT.
          ENDIF.
        ENDDO.

      WHEN zcl_demat=>gc_int_dataco.
        DO .
          ADD 1 TO lv_index .
          ASSIGN COMPONENT lv_index OF STRUCTURE is_dataco
                                    TO <fs_champ> .
          IF sy-subrc = 0.
            IF lv_index = 1.
              ls_erreur-dataco  = <fs_champ>  .
            ELSE.
              ls_erreur-dataco  = ls_erreur-dataco
                                  && ';' && <fs_champ> .
            ENDIF.
          ELSE.
            EXIT.
          ENDIF.
        ENDDO.
    ENDCASE.

    ls_erreur-msg_error = iv_error.

    INSERT zjson_err FROM ls_erreur  .

  ENDMETHOD.


  METHOD json_relance_err.
    DATA : lt_json_err   TYPE zjson_err_tbl,
           lt_split      TYPE TABLE OF string,
           ls_json_err   TYPE zjson_err,
           ls_splio_data TYPE zcrm_demat_splio_data,
           ls_splio_trig TYPE zcrm_demat_splio_trig_t,
           ls_field      TYPE zcrm_demat_splio_data_field,
           ls_list       TYPE zcrm_demat_splio_data_list, "++GE-668

           lv_id         TYPE string,
           lv_json       TYPE string,
           lv_type       TYPE string,
           lv_champ      TYPE string,
           lv_data       TYPE string,
           lv_fields     TYPE string,
           lv_index      TYPE i,

           lv_struct     TYPE REF TO data.

    FIELD-SYMBOLS : <fs_struct> TYPE any,
                    <fs_champ>  TYPE any.

    REFRESH lt_json_err .
    SELECT *
      FROM zjson_err
      INTO TABLE lt_json_err .
    IF sy-subrc IS INITIAL.
      LOOP AT lt_json_err INTO ls_json_err.
        CLEAR : lv_type ,
                lv_json .
        CASE ls_json_err-interface.
          WHEN zcl_demat=>gc_int_splio_trigger.
            ASSIGN ls_splio_trig TO <fs_struct> .
            IF <fs_struct> IS ASSIGNED.

              SPLIT ls_json_err-splio_trig AT ';' INTO TABLE lt_split .
              CLEAR lv_index .
              LOOP AT lt_split INTO lv_champ.
                ADD 1 TO lv_index  .
                ASSIGN COMPONENT lv_index OF STRUCTURE <fs_struct> TO
<fs_champ> .
                IF <fs_champ> IS ASSIGNED.
                  <fs_champ> = lv_champ .
                  UNASSIGN <fs_champ> .
                ELSE.
                  EXIT.
                ENDIF.
              ENDLOOP.
            ENDIF.

          WHEN zcl_demat=>gc_int_splio_data.
            ASSIGN ls_splio_data TO <fs_struct> .
            IF <fs_struct> IS ASSIGNED.

              SPLIT lv_data AT ';' INTO : ls_splio_data-email
                                          ls_splio_data-firstname
                                          ls_splio_data-lastname ,
                                          TABLE lt_split . "Fields

              LOOP AT lt_split INTO lv_champ.
                IF sy-tabix = lines( lt_split ).
                  ls_list-id = lv_champ.
                  APPEND ls_list TO ls_splio_data-lists.
                ELSE.
                  SPLIT lv_champ AT ':' INTO lv_id
                                             ls_field-value.
                  ls_field-id = lv_id .
                  APPEND ls_field TO ls_splio_data-fields.
                ENDIF.
              ENDLOOP.

            ENDIF.

          WHEN zcl_demat=>gc_int_dataco.

            CASE ls_json_err-event.
              WHEN 'SOUSCRIPTION'.
                lv_type = 'ZCRM_DEMAT_SOUSCRIPTION' .
              WHEN 'INPERIOD_ACTIVATION'.
                lv_type = 'ZINPERIOD_ACTIVATION' .
              WHEN 'ACTIVATION'.
                lv_type = 'ZACTIVATION' .
              WHEN 'ARC_BIM'.
                lv_type = 'ZARC_BIM' .
              WHEN 'FACTURE'.
                lv_type = 'ZFACTURE' .
              WHEN 'PAIEMENT'.
                lv_type = 'ZPAIEMENT' .
              WHEN 'NOUVEL_ECHEANCIER'.
                lv_type = 'ZNOUVEL_ECHEANCIER' .
              WHEN 'SERVICE_CONSO'.
                lv_type = 'ZSERVICE_CONSO' .
              WHEN 'RESILIATION' .
                lv_type = 'ZRESILIATION' .
              WHEN OTHERS.
            ENDCASE.

            CREATE DATA lv_struct TYPE (lv_type).
            ASSIGN lv_struct->* TO <fs_struct>.
            IF <fs_struct> IS ASSIGNED.

              SPLIT ls_json_err-dataco AT ';' INTO TABLE lt_split .
              CLEAR lv_index .
              LOOP AT lt_split INTO lv_champ.
                ADD 1 TO lv_index  .
                ASSIGN COMPONENT lv_index OF STRUCTURE <fs_struct> TO
<fs_champ> .
                IF <fs_champ> IS ASSIGNED.
                  <fs_champ> = lv_champ .
                  UNASSIGN <fs_champ> .
                ELSE.
                  EXIT.
                ENDIF.
              ENDLOOP.
            ENDIF.
        ENDCASE.

        CALL METHOD zcl_demat=>send_event_json
          EXPORTING
            iv_email                = ls_json_err-email
            iv_event                = ls_json_err-event
            iv_interface            = ls_json_err-interface
            is_struct_dataco        = <fs_struct>
            is_struct_splio_data    = ls_splio_data
            is_struct_splio_trigger = ls_splio_trig
          IMPORTING
            ev_r_json               = lv_json
          EXCEPTIONS
            interface_desactive     = 1
            error_send_http         = 2
            error_serialisation     = 3
            OTHERS                  = 4.
        IF sy-subrc IS INITIAL.
          APPEND ls_json_err TO et_json_ok .
        ELSE.
          ls_json_err-date_lancement = sy-datum .
          APPEND ls_json_err TO et_json_ko .
        ENDIF.

      ENDLOOP.

      MODIFY zjson_err FROM TABLE et_json_ko .

      DELETE zjson_err FROM TABLE et_json_ok .

    ENDIF.

  ENDMETHOD.


  method SEND_EVENT_ACTIVATION_CONTRAT.
  endmethod.


METHOD send_event_confirm_paiement.
  DATA: ls_paiement  TYPE zcrm_demat_confirm_paiement,
        ld_rc        TYPE flag,
        ld_bldat     TYPE dfkkzp-bldat,
        ld_email     TYPE ad_smtpadr,
        lv_partner   TYPE bu_partner.

  " Structure générique pour les API SPLIO Data et Trigger
  DATA: ls_json_splio_trigger   TYPE zcrm_demat_splio_trig,
        lt_json_splio_trigger   TYPE TABLE OF zcrm_demat_splio_trig,
        ls_json_splio_data      TYPE zcrm_demat_splio_data,
        ls_json_slio_data_field TYPE zcrm_demat_splio_data_field,
        ls_json_slio_data_list  TYPE zcrm_demat_splio_data_list. "++GE-668

  DATA: ld_opbel   TYPE erdk-opbel,
        ld_ableinh TYPE eanlh-ableinh.

  DATA:   ls_centraldataperson TYPE bapibus1006_central_person,
          ls_centraldataorg    TYPE bapibus1006_central_organ,
          ls_centraldata       TYPE bapibus1006_central,
          ls_address_data      TYPE bapibus1006_address,
          lt_telephone         TYPE TABLE OF bapiadtel,
          lt_email             TYPE TABLE OF bapiadsmtp,
          ls_email             TYPE bapiadsmtp.

  CLEAR zcl_demat=>gv_log_handle.

** Modification LWAT (05.11.2018) : Gestion des différents canaux du lot de paiement
** A réactiver plus tard (A tester par la même occasion ! :-))
*  " Récupération de l'objet du lot de paiement
*  SELECT SINGLE *
*    INTO @DATA(ls_dfkkzp)
*    FROM  dfkkzp WHERE keyz1 = @iv_paiement.
*
*  IF sy-subrc = 0.
*    ls_paiement-facture_amount = ls_dfkkzp-betrz.
*    ld_bldat = ls_dfkkzp-bldat.
*    " En fonction de l'objet rapproché, le traitement est différent
*    CASE ls_dfkkzp-selt1.
*      WHEN 'F'. " Facture
*        SELECT SINGLE opbel partner INTO ( ld_opbel, ls_paiement-user_id ) FROM erdk WHERE opbel = ls_dfkkzp-selw1.
*        SELECT SINGLE eanlh~ableinh INTO ld_ableinh
*               FROM ever JOIN eanlh ON ever~anlage = eanlh~anlage
*                         JOIN dberdlb ON ever~vertrag = dberdlb~vertrag
*                         JOIN erdk ON dberdlb~printdoc = erdk~opbel
*               WHERE eanlh~ab <= sy-datum
*                 AND eanlh~bis >= sy-datum
*                 AND erdk~opbel = ld_opbel.
*      WHEN 'B'. " Numéro de pièce
*        " Non utilisé
*      WHEN 'G'. " Partenaire
*        " Juste avec le partenaire, pas possible d'identifier la facture
*      WHEN 'K'. " Compte de contrats
*        " Juste avec le CC, pas possible d'identifier la facture
*    ENDCASE.
*  ENDIF.
** Fin Modif LWAT (05.11.2018)

  SELECT SINGLE
         erdk~opbel
         erdk~partner
         dfkkzp~betrz
         dfkkzp~bldat
         INTO  ( ld_opbel, ls_paiement-user_id, ls_paiement-facture_amount, ld_bldat )
  FROM dfkkzp
  JOIN erdk ON erdk~opbel = dfkkzp~selw1
  WHERE keyz1 = iv_paiement.

  IF sy-subrc = 0.
    CONCATENATE ld_bldat+6(2)
                ld_bldat+4(2)
                ld_bldat(4)
                INTO ls_paiement-facture_payment_dateonly SEPARATED BY '/'.

    ls_paiement-user_client_type = ld_ableinh(5).

    " Récupération des infos du client
    CALL FUNCTION 'BAPI_BUPA_CENTRAL_GETDETAIL'
      EXPORTING
        businesspartner         = ls_paiement-user_id
      IMPORTING
        centraldata             = ls_centraldata
        centraldataperson       = ls_centraldataperson
        centraldataorganization = ls_centraldataorg
      TABLES
        e_maildatanonaddress    = lt_email
        telefondatanonaddress   = lt_telephone.

    " Récupération du guid du BP
    CALL FUNCTION 'BUPA_NUMBERS_GET'
      EXPORTING
        iv_partner = ls_paiement-user_id
      IMPORTING
        ev_partner = lv_partner.

    READ TABLE lt_email INTO ls_email INDEX 1.
    IF sy-subrc = 0.
      ls_paiement-email = ls_email-e_mail.
      TRANSLATE ls_paiement-email TO LOWER CASE.
    ENDIF.

    ls_paiement-user_lastname = ls_centraldataperson-lastname.
    ls_paiement-user_civility = ls_centraldata-title_key.

    "  Récupération de l'url indiquant s'il s'agit d'un client VEV ou HELIUM
    CALL METHOD zcl_demat=>get_url_espace_client
      EXPORTING
        iv_guid = lv_partner
      IMPORTING
        ev_url  = ls_paiement-espace_client.

  ENDIF.


*************************************************************************************************
******             Données spécifiques aux API Splio (Data && Trigger)                     ******
*************************************************************************************************
  " Récupération des données d'en-tête pour SPLIO trigger et Data
  ls_json_splio_data-email = ls_json_splio_trigger-email = ld_email = ls_paiement-email.
  ls_json_splio_data-firstname = ls_json_splio_trigger-firstname = ls_centraldataperson-firstname.
  ls_json_splio_data-lastname = ls_json_splio_trigger-lastname = ls_centraldataperson-lastname.

  " Récupération des informations propres à Data
  ls_json_slio_data_field-id = '0'. " user_id
  ls_json_slio_data_field-value = ls_paiement-user_id.
  INSERT ls_json_slio_data_field INTO TABLE ls_json_splio_data-fields.

  ls_json_slio_data_field-id = '1'. " civility
  ls_json_slio_data_field-value = ls_paiement-user_civility.
  INSERT ls_json_slio_data_field INTO TABLE ls_json_splio_data-fields.

  ls_json_slio_data_field-id = '2'. " lastname
  ls_json_slio_data_field-value = ls_paiement-user_lastname.
  INSERT ls_json_slio_data_field INTO TABLE ls_json_splio_data-fields.

  ls_json_slio_data_field-id = '11'. " user_client_type
  ls_json_slio_data_field-value = ls_paiement-user_client_type.
  INSERT ls_json_slio_data_field INTO TABLE ls_json_splio_data-fields.

  ls_json_slio_data_field-id = '40'. " facture_amount
  ls_json_slio_data_field-value = condense( conv string( ls_paiement-facture_amount ) ).
  INSERT ls_json_slio_data_field INTO TABLE ls_json_splio_data-fields.

  ls_json_slio_data_field-id = '69'. " facture_payment_dateonly
  ls_json_slio_data_field-value = ls_paiement-facture_payment_dateonly.
  INSERT ls_json_slio_data_field INTO TABLE ls_json_splio_data-fields.

  ls_json_slio_data_field-id = '82'. " espace_client
  ls_json_slio_data_field-value = ls_paiement-espace_client.
  INSERT ls_json_slio_data_field INTO TABLE ls_json_splio_data-fields.

*++STOU DEBUT GE-668
  ls_json_slio_data_list-id = '4'.
  INSERT ls_json_slio_data_list INTO TABLE ls_json_splio_data-lists.
*++STOU DEBUT GE-668

  " Récupération des informations propres à Trigger
  ls_json_splio_trigger-c0 = ls_paiement-user_id.
  ls_json_splio_trigger-c1 = ls_paiement-user_civility.
  ls_json_splio_trigger-c2 = ls_paiement-user_lastname.
  ls_json_splio_trigger-c11 = ls_paiement-user_client_type.
  ls_json_splio_trigger-c40 = condense( conv string( ls_paiement-facture_amount ) ).
  ls_json_splio_trigger-c69 = ls_paiement-facture_payment_dateonly.
  ls_json_splio_trigger-c82 = ls_paiement-espace_client.
  INSERT ls_json_splio_trigger INTO TABLE lt_json_splio_trigger.

*************************************************************************************************
******            Fin - Données spécifiques aux API Splio (Data && Trigger)                ******
*************************************************************************************************

  " On envoie
  CALL METHOD zcl_demat=>send_event_json
    EXPORTING
      iv_event                = 'CONFIRM_PAIEMENT'
      iv_email                = ld_email
      is_struct_dataco        = ls_paiement
      is_struct_splio_trigger = lt_json_splio_trigger
      is_struct_splio_data    = ls_json_splio_data
    EXCEPTIONS
      interface_desactive     = 1
      error_send_http         = 2
      error_serialisation     = 3
      OTHERS                  = 4.

  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
               RAISING error .
  ENDIF.
ENDMETHOD.


METHOD send_event_json.

  DATA :
    lv_http_code      TYPE int4,

    lv_msg            TYPE symsgv,
    ls_msg            TYPE bal_s_msg,
    lt_msg            TYPE bal_tt_msg,

    lv_regex          TYPE string,
    lv_json_string    TYPE string,
    lv_json(1000)     TYPE c,

    lv_response       TYPE string,
    lv_method_type    TYPE string,
    lv_dummy          TYPE string,
    lv_abort_intf     TYPE string,
    lv_rfcdest        TYPE rfcdest,
    lv_partner        TYPE bu_partner,
    lr_cl_crm         TYPE REF TO cl_crm_activities_util,
    lv_filtered_email TYPE crmt_boolean.


  DATA : lv_path TYPE string.

  FIELD-SYMBOLS : <fs_sub>    TYPE any.


*   Appel de SEND_EVENT_JSON avec email &1 / event &2 / interface &3
  MESSAGE i004(zcrm_demat) WITH iv_email iv_event iv_interface
                           INTO lv_dummy.
  zcl_tool=>log_add_msg( EXPORTING
                              iv_log_object     = 'ZB2C_DEMAT'
                              iv_log_subobject  = 'BASIC'
                              iv_test_mode      = abap_false
                    CHANGING cv_log_handle = zcl_demat=>gv_log_handle ).


** Récupération de la configuration pour l'event
  SELECT SINGLE * FROM zcrmc_demat_conf INTO @DATA(ls_demat_conf)
                  WHERE event_name = @iv_event.
  IF sy-subrc <> 0.
    " Evénement & non configuré dans la table ZCRMC_DEMAT_CONF
    MESSAGE e023(zcrm_b2c) WITH iv_event INTO lv_dummy .
    zcl_tool=>log_add_msg( EXPORTING iv_log_object    = 'ZB2C_DEMAT'
                                     iv_log_subobject = 'BASIC'
                                     iv_test_mode     = abap_false
                    CHANGING cv_log_handle = zcl_demat=>gv_log_handle ).
    RAISE error_evenement_inconnu.
  ENDIF.


** Ajout AliA Consulting (LWAT) 2018.02.20 OPE-684 : Filtre sur certaines adresses email
  CLEAR lv_filtered_email.

  " Ce controle ne doit pas être actif sur la production
  CALL FUNCTION 'PRGN_CHECK_SYSTEM_PRODUCTIVE'
    EXCEPTIONS
      client_is_productive = 1
      OTHERS               = 2.
  IF sy-subrc <> 0. " Production ? Pas de controle
    lv_filtered_email = abap_false.
  ELSE.
    lv_filtered_email = abap_true.
    " Récupération de tous les emails autorisés
    SELECT * FROM tvarvc INTO TABLE @DATA(lt_tvarvc) WHERE name = 'ZB2C_SPLIO_ALLOWED_EMAIL'.
    LOOP AT lt_tvarvc INTO DATA(ls_tvarvc).
      IF cl_abap_matcher=>contains( text = to_lower( iv_email ) pattern = to_lower( ls_tvarvc-low ) ) EQ abap_true.
        lv_filtered_email = abap_false.
        EXIT.
      ENDIF.
    ENDLOOP.
  ENDIF.

  IF lv_filtered_email IS NOT INITIAL.
*   Filtrage de l'email &1 (non paramétré dans TVARVC)
    MESSAGE w026(zcrm_b2c) WITH iv_email INTO lv_dummy .
    zcl_tool=>log_add_msg(
             EXPORTING iv_log_object    = 'ZB2C_DEMAT'
                       iv_log_subobject = 'BASIC'
                       iv_test_mode     = abap_false
             CHANGING  cv_log_handle    = zcl_demat=>gv_log_handle ).


    EXIT.
  ENDIF.
** Fin Ajout AliA Consulting (LWAT) 2018.02.20

*   Etat : DataCo [&1] / Splio Data [&2] / Splio Trigger [&3]
  MESSAGE i003(zcrm_demat) WITH ls_demat_conf-int_dataco_active
                                ls_demat_conf-int_splio_data_active
                                ls_demat_conf-int_splio_trigger_active
                           INTO lv_dummy .
  zcl_tool=>log_add_msg( EXPORTING
                           iv_log_object = 'ZB2C_DEMAT'
                           iv_log_subobject = 'BASIC'
                           iv_test_mode = abap_false
                        CHANGING
                           cv_log_handle = zcl_demat=>gv_log_handle ).

  CLEAR lv_path .
  SELECT SINGLE low FROM tvarvc INTO lv_path
          WHERE name = 'ZB2C_SPLIO_PATH'.
  IF sy-subrc NE 0.
    "Paramètre & non trouvé dans la table TVARVC
    MESSAGE e022(zcrm_b2c) WITH 'ZB2C_SPLIO_PATH' INTO lv_msg .
    zcl_tool=>log_add_msg( EXPORTING
                             iv_log_object = 'ZB2C_DEMAT'
                             iv_log_subobject = 'BASIC'
                             iv_test_mode = abap_false
                          CHANGING
                           cv_log_handle = zcl_demat=>gv_log_handle ).

    CONDENSE lv_msg  .
    CALL METHOD zcl_demat=>insert_json_error
      EXPORTING
        iv_event     = iv_event
        iv_interface = zcl_demat=>gc_int_dataco
        is_dataco    = is_struct_dataco
        iv_error     = CONV string( lv_msg ).
  ENDIF.
*********************************************************
*** Gestion de l'envoi vers DataCo
*********************************************************
  IF ls_demat_conf-int_dataco_active IS NOT INITIAL AND
    ( iv_interface IS INITIAL OR
      iv_interface = zcl_demat=>gc_int_dataco ).

*   Appel de l'API &1
    MESSAGE i007(zcrm_demat) WITH 'DataCo' INTO lv_dummy.
    zcl_tool=>log_add_msg( EXPORTING
                             iv_log_object = 'ZB2C_DEMAT'
                             iv_log_subobject = 'DATACO'
                             iv_test_mode = abap_false
                          CHANGING
                             cv_log_handle = zcl_demat=>gv_log_handle ).
    IF lv_path IS INITIAL.

    ELSE.
      " Il faut remplacer le champ user_id par le numéro de client
      ASSIGN COMPONENT 'USER_ID' OF STRUCTURE is_struct_dataco
                                 TO FIELD-SYMBOL(<lr_user_id>).
      IF <lr_user_id> IS ASSIGNED.
        REPLACE FIRST OCCURRENCE OF '#USER_ID#'
                                 IN lv_path WITH <lr_user_id>.
      ENDIF.
      " Pour DataCo, on JSONise la structure et on l'envoie en GET
      ev_r_json = /ui2/cl_json=>serialize( data   = is_struct_dataco
                   pretty_name = /ui2/cl_json=>pretty_mode-low_case ).

      CALL METHOD zcl_demat=>send_http_request
        EXPORTING
          iv_path         = lv_path
          iv_body         = ev_r_json
          iv_destination  = 'ZB2C_DEMAT_CA'
          iv_method_type  = 'PUT' "lv_method_type
        IMPORTING
          ev_http_code    = lv_http_code
          ev_body         = lv_response
        EXCEPTIONS
          error_gen_http  = 1
          error_sending   = 2
          error_receiving = 3
          OTHERS          = 4.

      IF sy-subrc = 0.
        CASE lv_http_code. " En fonction du code, on affiche un message
          WHEN 200. " OK code
*   Appel de &1 : HTTP &2 (&3)
            MESSAGE i005(zcrm_demat) WITH 'DataCo'
                                          lv_http_code
                                          lv_response
                                     INTO lv_dummy.

            zcl_tool=>log_add_msg( EXPORTING
                                     iv_log_object = 'ZB2C_DEMAT'
                                     iv_log_subobject = 'DATACO'
                                     iv_test_mode = abap_false
                                  CHANGING
                             cv_log_handle = zcl_demat=>gv_log_handle ).
          WHEN OTHERS.
*   Erreur &1
            MESSAGE e006(zcrm_demat) WITH lv_response INTO lv_dummy.
            zcl_tool=>log_add_msg( EXPORTING
                                     iv_log_object = 'ZB2C_DEMAT'
                                     iv_log_subobject = 'DATACO'
                                     iv_test_mode = abap_false
                                  CHANGING
                             cv_log_handle = zcl_demat=>gv_log_handle ).

            CALL METHOD zcl_demat=>insert_json_error
              EXPORTING
                iv_event     = iv_event
                iv_interface = zcl_demat=>gc_int_dataco
                is_dataco    = is_struct_dataco
                iv_error     = CONV string( lv_dummy ).
        ENDCASE.

      ELSE.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
             WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
             INTO lv_msg .
*   Erreur &1
        MESSAGE e006(zcrm_demat) WITH lv_msg INTO lv_dummy.

        zcl_tool=>log_add_msg( EXPORTING
                                 iv_log_object    = 'ZB2C_DEMAT'
                                 iv_log_subobject = 'DATACO'
                                 iv_test_mode     = abap_false
                              CHANGING
                             cv_log_handle = zcl_demat=>gv_log_handle ).

        CALL METHOD zcl_demat=>insert_json_error
          EXPORTING
            iv_event     = iv_event
            iv_interface = zcl_demat=>gc_int_dataco
            is_dataco    = is_struct_dataco
            iv_error     = CONV string( lv_dummy ).
      ENDIF.
    ENDIF.
  ENDIF.


  " Il faut impérativement un email pour les API splio
  IF iv_email IS NOT INITIAL.
*********************************************************
*** Gestion de l'envoi vers SPLIO Data
*********************************************************
    IF ls_demat_conf-int_splio_data_active IS NOT INITIAL AND
      ( iv_interface IS INITIAL
              OR iv_interface = zcl_demat=>gc_int_splio_data ).

      MESSAGE i007(zcrm_demat) WITH 'Splio Data' INTO lv_dummy.
      zcl_tool=>log_add_msg( EXPORTING
                              iv_log_object    = 'ZB2C_DEMAT'
                              iv_log_subobject = 'SPLIO_DATA'
                              iv_test_mode     = abap_false
                           CHANGING
                          cv_log_handle = zcl_demat=>gv_log_handle ).

      CLEAR : lv_abort_intf .

      " On vérifie déja si l'email est existant
      CALL METHOD zcl_demat=>send_http_request
        EXPORTING
          iv_path         = '/' && CONV string( iv_email )
          iv_body         = '' " Pas de body pour cet appel
          iv_method_type  = 'GET'
          iv_destination  = 'ZB2C_DEMAT_SPLIO_DATA'
        IMPORTING
          ev_http_code    = lv_http_code
          ev_body         = lv_response
        EXCEPTIONS
          error_gen_http  = 1
          error_sending   = 2
          error_receiving = 3
          OTHERS          = 4.

      IF sy-subrc = 0.
*   Appel de &1 : HTTP &2 (&3)
        MESSAGE i005(zcrm_demat) WITH 'SplioData (GET)'
                                      lv_http_code
                                      lv_response
                                 INTO lv_dummy.

        zcl_tool=>log_add_msg( EXPORTING
                                iv_log_object    = 'ZB2C_DEMAT'
                                iv_log_subobject = 'SPLIO_DATA'
                                iv_test_mode     = abap_false
                             CHANGING
                            cv_log_handle = zcl_demat=>gv_log_handle ).

        CASE  lv_http_code.
          WHEN '404'. " Email n'existe pas, il faut le créer (POST)
            lv_method_type = 'POST'.
          WHEN '200'. " Email existe, il faut le mettre à jour (PUT)
            lv_method_type = 'PUT'.
          WHEN OTHERS.
            "Erreur ...
*          IF sy-subrc NE 0 .
*            MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*                      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
*                      INTO lv_msg .
*          ELSE.
*            "Erreur vérification Mail, Code HTTP : &
*            MESSAGE e024(zcrm_b2c) WITH lv_http_code INTO lv_msg .
*          ENDIF.
            MESSAGE e024(zcrm_b2c) WITH lv_http_code INTO lv_msg .
            zcl_tool=>log_add_msg( EXPORTING
                                    iv_log_object    = 'ZB2C_DEMAT'
                                    iv_log_subobject = 'SPLIO_DATA'
                                    iv_test_mode     = abap_false
                                 CHANGING
                             cv_log_handle = zcl_demat=>gv_log_handle ).

            CONDENSE lv_msg  .

            CALL METHOD zcl_demat=>insert_json_error
              EXPORTING
                iv_event      = iv_event
                iv_interface  = zcl_demat=>gc_int_splio_data
                is_splio_data = is_struct_splio_data
                iv_email      = iv_email
                iv_error      = CONV string( lv_msg ).

            lv_abort_intf = abap_on.
        ENDCASE.
      ELSE.

      ENDIF.

      IF lv_abort_intf = abap_off.
        " Pour splio Data, il faut JSONiser la structure et l'envoyer
        " en POST
        lv_json_string = /ui2/cl_json=>serialize(
               data   = is_struct_splio_data
               pretty_name = /ui2/cl_json=>pretty_mode-low_case ).

        CASE lv_method_type.
          WHEN 'POST'.
            " Mode POST (Création)
            CALL METHOD zcl_demat=>send_http_request_post
              EXPORTING
                iv_path         = '' " Pas de path complémentare pour la création
                iv_body         = lv_json_string
                iv_method_type  = lv_method_type
                iv_destination  = 'ZB2C_DEMAT_SPLIO_DATA'
              IMPORTING
                ev_http_code    = lv_http_code
                ev_body         = lv_response
              EXCEPTIONS
                error_gen_http  = 1
                error_sending   = 2
                error_receiving = 3
                OTHERS          = 4.
          WHEN 'PUT'.
            " Mode PUT (Mise à jour)
            CALL METHOD zcl_demat=>send_http_request
              EXPORTING
                iv_path         = '/' && CONV string( iv_email )
                iv_body         = lv_json_string
                iv_method_type  = lv_method_type
                iv_destination  = 'ZB2C_DEMAT_SPLIO_DATA'
              IMPORTING
                ev_http_code    = lv_http_code
                ev_body         = lv_response
              EXCEPTIONS
                error_gen_http  = 1
                error_sending   = 2
                error_receiving = 3
                OTHERS          = 4.
        ENDCASE.

        IF sy-subrc NE 0 OR lv_http_code <> 200 .
*   Erreur HTTP (Code retour &1 / HTTP &2)
          MESSAGE e027(zcrm_b2c) WITH sy-subrc lv_http_code INTO lv_msg.
*          MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*                    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
*                    INTO lv_msg .

          CONDENSE lv_msg  .

          zcl_tool=>log_add_msg( EXPORTING
                                  iv_log_object    = 'ZB2C_DEMAT'
                                  iv_log_subobject = 'SPLIO_DATA'
                                  iv_test_mode     = abap_false
                               CHANGING
                           cv_log_handle = zcl_demat=>gv_log_handle ).

          CALL METHOD zcl_demat=>insert_json_error
            EXPORTING
              iv_event      = iv_event
              iv_interface  = zcl_demat=>gc_int_splio_data
              is_splio_data = is_struct_splio_data
              iv_email      = iv_email
              iv_error      = CONV string( lv_msg ).
        ELSE.
          lv_dummy = ' SplioData (' && lv_method_type && ')'.
*   Appel de &1 : HTTP &2 (&3)
          MESSAGE i005(zcrm_demat) WITH lv_dummy
                                        lv_http_code
                                        lv_response
                                   INTO lv_dummy.

          zcl_tool=>log_add_msg( EXPORTING
                                  iv_log_object    = 'ZB2C_DEMAT'
                                  iv_log_subobject = 'SPLIO_DATA'
                                  iv_test_mode     = abap_false
                               CHANGING
                           cv_log_handle = zcl_demat=>gv_log_handle ).
        ENDIF.
      ENDIF.
    ENDIF.

*********************************************************
*** Gestion de l'envoi vers SPLIO Trigger
*********************************************************
    "Event actif
    IF ls_demat_conf-int_splio_trigger_active IS NOT INITIAL AND
      ( iv_interface IS INITIAL        " Gestion de la relance
          OR iv_interface = zcl_demat=>gc_int_splio_trigger ) AND
      ls_demat_conf-trigger_id_msg IS NOT INITIAL. " Message ID présent

*   Appel de l'API &1
      MESSAGE i007(zcrm_demat) WITH 'Splio Trigger' INTO lv_dummy.
      zcl_tool=>log_add_msg( EXPORTING
                                iv_log_object    = 'ZB2C_DEMAT'
                                iv_log_subobject = 'SPLIO_TRIG'
                                iv_test_mode     = abap_false
                             CHANGING
                             cv_log_handle = zcl_demat=>gv_log_handle ).

*   ID message envoyé : &1
      MESSAGE i008(zcrm_demat) WITH ls_demat_conf-trigger_id_msg
                               INTO lv_dummy.
      zcl_tool=>log_add_msg( EXPORTING
                                iv_log_object    = 'ZB2C_DEMAT'
                                iv_log_subobject = 'SPLIO_TRIG'
                                iv_test_mode     = abap_false
                             CHANGING
                             cv_log_handle = zcl_demat=>gv_log_handle ).

      CLEAR lv_abort_intf .

      lv_json_string = /ui2/cl_json=>serialize(
               data   = is_struct_splio_trigger
               pretty_name = /ui2/cl_json=>pretty_mode-low_case ).

      lv_json_string = cl_http_utility=>if_http_utility~escape_url(
                           unescaped = lv_json_string ).

      lv_json_string = 'universe=ddb_butagaz&' &&
              'key=9ec31118a7b714caaf6502e855c1d64c6e8fff47&message='
                       && ls_demat_conf-trigger_id_msg &&
                       '&rcpts=' &&
                       lv_json_string.


      CALL METHOD zcl_demat=>send_http_request_post
        EXPORTING
          iv_path         = lv_path
          iv_body         = lv_json_string
          iv_destination  = 'ZB2C_DEMAT_SPLIO_TRIGGER'
        IMPORTING
          ev_http_code    = lv_http_code
          ev_body         = lv_response
        EXCEPTIONS
          error_gen_http  = 1
          error_sending   = 2
          error_receiving = 3
          OTHERS          = 4.
      IF sy-subrc <> 0 OR lv_http_code <> '200'.
        IF sy-subrc <> 0. " Pas eu de retour de l'appel HTTP
          MESSAGE e025(zcrm_b2c) INTO lv_dummy.
        ELSE. " Retour HTTP mais avec une erreur
*   Appel de &1 : HTTP &2 (&3)
          MESSAGE e005(zcrm_demat) WITH lv_dummy
                                        lv_http_code
                                        lv_response
                                   INTO lv_dummy.
        ENDIF.

        zcl_tool=>log_add_msg( EXPORTING
                                  iv_log_object    = 'ZB2C_DEMAT'
                                  iv_log_subobject = 'SPLIO_TRIG'
                                  iv_test_mode     = abap_false
                               CHANGING
                             cv_log_handle = zcl_demat=>gv_log_handle ).

        CONDENSE lv_msg  .

        CALL METHOD zcl_demat=>insert_json_error
          EXPORTING
            iv_event      = iv_event
            iv_interface  = zcl_demat=>gc_int_splio_trigger
            is_splio_trig = is_struct_splio_trigger
            iv_email      = iv_email
            iv_error      = CONV string( lv_msg ).
      ELSE.
*      IF sy-subrc = 0 .
*   Appel de &1 : HTTP &2 (&3)
        MESSAGE i005(zcrm_demat) WITH lv_dummy
                                      lv_http_code
                                      lv_response
                                 INTO lv_dummy.

        zcl_tool=>log_add_msg( EXPORTING
                                  iv_log_object    = 'ZB2C_DEMAT'
                                  iv_log_subobject = 'SPLIO_TRIG'
                                  iv_test_mode     = abap_false
                               CHANGING
                             cv_log_handle = zcl_demat=>gv_log_handle ).

*      ELSE.
      ENDIF.

** << GE-2911(KAID) 27.11.2018 : On veut créer un ticket pour l'envoi d'un mail
** " On récupère le partenaire pour associer le ticket
      ASSIGN COMPONENT 'USER_ID' OF STRUCTURE is_struct_dataco
                                      TO FIELD-SYMBOL(<lr_user>).
      lv_partner = <lr_user>.
      " Création du ticket
      CALL METHOD zcl_crm_utils=>create_ticket_crm
        EXPORTING
          iv_type_mvt     = 'ZMA'
          iv_code_mvt     = iv_event
          iv_partner      = lv_partner.

*      CREATE OBJECT lr_cl_crm.
*      TRY.
*          CALL METHOD lr_cl_crm->if_crm_uiu_destinations~get_crm_destination
*            RECEIVING
*              rv_rfcdest = lv_rfcdest.
*        CATCH cx_crm_erp_activities.
** Accès à l'instance CRM/IS-U impossible => Vérifiez la connexion
*      ENDTRY.
*** Récupération de la configuration du ticket à créer
*      CALL FUNCTION 'ZCRM_DSO_CREATE_TICKET'
*        DESTINATION lv_rfcdest
*        EXPORTING
*          iv_partner     = lv_partner
*          iv_type_mvt    = 'ZMA'
*          iv_code_mvt    = iv_event
*        IMPORTING
*          ev_need_ticket = lv_ticket_id
*          ev_code_retour = lv_code_retour.
*
**      IF lv_code_retour IS NOT INITIAL. " On n'a pas réussi à créer le ticket
***   Impossible de créer un ticket pour l'event &1
**        MESSAGE w005(zcrm_b2c) WITH iv_event INTO lv_dummy.
**        zcl_crm_utils=>log_add_msg_short( EXPORTING iv_log_object = 'ZB2C_DEMAT' iv_log_subobject = 'SPLIO_TRIG' iv_test_mode = abap_false
**                                          CHANGING cv_log_handle = zcl_demat=>gv_log_handle ).
**
**
**      ELSE. " Ticket créé avec succès
***   Le ticket &1 a été créé avec succés (event = &2)
**        MESSAGE i004(zcrm_b2c) WITH lv_ticket_id iv_event INTO lv_dummy.
**        zcl_crm_utils=>log_add_msg_short( EXPORTING iv_log_object = 'ZB2C_DEMAT' iv_log_subobject = 'SPLIO_TRIG' iv_test_mode = abap_false
**                                          CHANGING cv_log_handle = zcl_demat=>gv_log_handle ).
**      ENDIF.
* >> GE-2911 (KAID) 27.11.2018
    ENDIF.
  ENDIF.

ENDMETHOD.


METHOD send_http_request.
  DATA lv_dummy TYPE string .

  " Génération du lien HTTP
  zcl_demat=>generate_http_link(
        EXPORTING iv_destination = iv_destination
                  iv_method_type = iv_method_type
        RECEIVING rr_http_client = DATA(lr_http_request)
        EXCEPTIONS error = 1   ).

  IF sy-subrc <> 0 OR lr_http_request IS NOT BOUND.
    "Impossible de créer le lien HTTP (manquant dans SM59 ?)
    MESSAGE e015(zcrm_b2c) INTO lv_dummy .
    RAISE error_gen_http.
  ENDIF.

  cl_http_utility=>set_request_uri(
          request = lr_http_request->request uri = iv_path ).
  lr_http_request->request->set_cdata(
          data = iv_body length = strlen( iv_body ) offset = 0 ).

  CALL METHOD lr_http_request->send
    EXCEPTIONS
      http_communication_failure = 1
      http_invalid_state         = 2
      http_processing_failed     = 3
      OTHERS                     = 4.

  IF sy-subrc <> 0.
    "Erreur d'envoi HTTP
    MESSAGE e016(zcrm_b2c) WITH iv_method_type INTO lv_dummy.
    RAISE error_sending.
  ENDIF.

  " Get the answer
  CALL METHOD lr_http_request->receive
    EXCEPTIONS
      http_communication_failure = 1
      http_invalid_state         = 2
      http_processing_failed     = 3
      OTHERS                     = 4.
  IF sy-subrc <> 0.
    "Erreur réception HTTP
    MESSAGE e025(zcrm_b2c) WITH iv_method_type INTO lv_dummy.
    RAISE error_receiving.
  ENDIF.
  lr_http_request->response->get_status( IMPORTING
                    code = ev_http_code  ).
                    ev_body = lr_http_request->response->get_cdata( ).

ENDMETHOD.


METHOD send_http_request_post.
  DATA: lr_rest_client TYPE REF TO cl_rest_http_client,
        lv_dummy       TYPE string.

  " Génération du lien HTTP
  zcl_demat=>generate_http_link(
        EXPORTING iv_destination = iv_destination
                  iv_method_type = 'POST'
        RECEIVING rr_http_client = DATA(lr_http_request)
        EXCEPTIONS error = 1   ).

  IF sy-subrc <> 0 OR lr_http_request IS NOT BOUND.
    "Impossible de créer le lien HTTP (manquant dans SM59 ?)
    MESSAGE e015(zcrm_b2c) INTO lv_dummy .
    RAISE error_gen_http.
  ENDIF.

  " Création des objets pour réaliser le POST
  CREATE OBJECT lr_rest_client
    EXPORTING
      io_http_client = lr_http_request.
  DATA(lr_request) =
           lr_rest_client->if_rest_client~create_request_entity( ).

  " Positionnement du media Type
  lr_request->set_content_type( iv_media_type = iv_media_type ).
  " Positionnement des données à envoyer
  lr_request->set_string_data( iv_body ).

  " Positionnement de path
  IF iv_path IS NOT INITIAL.
    cl_http_utility=>set_request_uri(
                   request = lr_http_request->request uri = iv_path ).
  ENDIF.

  " Envoi des données
  TRY.
  lr_rest_client->if_rest_resource~post( lr_request ).
  CATCH cx_rest_client_exception.
    MESSAGE e025(zcrm_b2c) WITH 'POST' INTO lv_dummy .
    RAISE error_receiving.
  ENDTRY.

  " Récupération de la réponse
  DATA(lr_response) =
            lr_rest_client->if_rest_client~get_response_entity( ).

  IF lr_response IS NOT BOUND.
    MESSAGE e025(zcrm_b2c) WITH 'POST' INTO lv_dummy .
    RAISE error_receiving.
  ENDIF.

  " Récupération de la réponse dans la sortie
  ev_http_code = lr_response->get_header_field( '~status_code' ).
  ev_body = lr_response->get_string_data( ).

ENDMETHOD.


  METHOD set_default_http_conf.

    CHECK ir_client IS BOUND.

    " Sets the method to use (GET / POST / PUT / DELETE)
    ir_client->request->set_method( iv_method_type ).

    " Default encoding in UTF-8 / Waiting for JSON
    ir_client->request->set_content_type(
                              iv_content_type ).

    " Default protocol HTTP 1.1
    ir_client->request->set_version(
                      if_http_request=>co_protocol_version_1_1 ).


  ENDMETHOD.
ENDCLASS.
