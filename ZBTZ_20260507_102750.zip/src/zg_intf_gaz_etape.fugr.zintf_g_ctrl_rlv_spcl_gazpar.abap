FUNCTION zintf_g_ctrl_rlv_spcl_gazpar.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
  DATA: lc_field_raison_rlv  TYPE fieldname VALUE 'RAISON_RELEVE',
        lc_field_nb_roue_cpt TYPE fieldname VALUE 'NB_ROUE_COMPTEUR',
        lc_field_num_pce     TYPE fieldname VALUE 'NUM_PCE',
        lc_field_date_releve TYPE fieldname VALUE 'DATE_RELEVE',
        lc_fin_periode       TYPE fieldname VALUE 'FIN_PERIODE',
        lc_field_flux        TYPE fieldname VALUE 'FLUX',
        lc_field_num_serie   TYPE fieldname VALUE 'NUM_SERIE_COMPTEUR',
        lc_field_index_fin   TYPE fieldname VALUE 'INDEX_BRUT_FIN_PERIODE',
        lt_etdz              TYPE TABLE OF  etdz,
        lv_stanzvor          TYPE stanzvor,
        lv_field             TYPE string,
        lv_int_ui            TYPE int_ui,
        ls_object            TYPE eedm_isu_objects,
        lv_date_effet        TYPE datum,
        lv_success           TYPE crmt_boolean,
        ls_dev               TYPE reg42_dev,
        ls_dev_flag          TYPE reg42_dev_input_flag,
        ls_lsernr            TYPE lsernr,
        lv_ko                TYPE c,
        ls_auto              TYPE isu42_devmod_auto,
        lv_db_update         TYPE e_update,
        lv_device            TYPE geraet,
        lv_sernr             TYPE lsernr,
        lv_equnr             TYPE equnr,
        lv_anlage            TYPE anlage,
        lt_easts             TYPE TABLE OF easts,
        ls_easts             TYPE easts,
        lt_auto              TYPE isu17_meterread_auto,
        ls_obj               TYPE isu17_meterread,
        ls_ieabl             TYPE eabl,
        lv_message           TYPE char255,
        lv_energie_entier    TYPE v_zwstand,
        lv_energie_decimal   TYPE n_zwstand,
        lv_subobj            TYPE balsubobj,
        lv_date_depose       TYPE adatsoll,
        BEGIN OF ls_flux,
          idenreg	                      TYPE zintf_g_id_enreg,
          statut                        TYPE zintf_g_statut,
          num_pce                       TYPE ext_ui,
          emetteur                      TYPE zemetteur_id,
          flux                          TYPE zflux_id,
          date_releve                   TYPE zdate_rel,
          type_releve                   TYPE zzisu_type_releve,
          raison_releve                 TYPE zzisu_raison_releve,
          motif_releve                  TYPE zzmotif_rel,
          debut_periode                 TYPE zzisu_date_deb_per,
          index_brut_debut_periode      TYPE zzisu_index_brut_deb,
          qual_index_brut_debut_periode TYPE zzisu_qlf_index_brut_deb,
          index_conv_debut_periode      TYPE z_index_conv_deb_per,
          qual_index_conv_debut_periode TYPE zqual_index_conv_deb_per,
          fin_periode                   TYPE zdate_fin_per,
          index_brut_fin_periode        TYPE zidx_fin_per,
          qual_index_brut_fin_periode   TYPE zzisu_qlf_index_brut_fin,
          index_conv_fin_periode        TYPE zindex_conv_fin_per,
          qual_index_conv_fin_periode   TYPE zqual_index_conv_fin_per,
          volume_conv                   TYPE zvol_conv,
          qualif_volume_conv            TYPE zqual_vol_conv,
          qualif_pcs                    TYPE zqual_pcs,
          vol_brut_conso                TYPE zzisu_vol_brut,
          qualif_vol_brut_conso         TYPE zzisu_qlf_vol_brut,
          energie_conso                 TYPE zzisu_energie,
          qualif_energie_conso          TYPE zzisu_qlf_energie,
          motif_correction              TYPE zzisu_motif_corr,
          origine_correction            TYPE zzisu_orig_corr,
        END   OF ls_flux.

  DEFINE macro_add_message_to_log.
    MESSAGE ID sy-msgid
          TYPE sy-msgty
        NUMBER sy-msgno
          INTO lv_message
          WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    zcl_tool=>log_add_msg(
      EXPORTING iv_log_object    = zcl_tool=>gc_log_object_intf_gaz
                iv_log_subobject = lv_subobj
                iv_test_mode     = iv_mode_test
      CHANGING  cv_log_handle    = cv_log_handle ).
  END-OF-DEFINITION.


  FIELD-SYMBOLS: <fs_num_pce>,<fs_date_releve>,<fs_nb_roue_compteur>,<fs_raison_releve>,
                 <fs_fin_periode>,<fs_flux>,<fs_num_serie>,<fs_idx_fin_periode>,<fs_idenreg>,
                 <fs_etdz>             TYPE etdz,
                 <fs_flux_re6m>        TYPE zintf_g_re6m,
                 <fs_flux_re1m>        TYPE zintf_g_re1m,
                 <fs_flux_remm>        TYPE zintf_g_remm.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_raison_rlv INTO lv_field.
  ASSIGN (lv_field) TO <fs_raison_releve>.
  IF <fs_raison_releve> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.
  IF <fs_num_pce> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_nb_roue_cpt INTO lv_field.
  ASSIGN (lv_field) TO <fs_nb_roue_compteur>.
  IF <fs_nb_roue_compteur> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_releve>.
  IF <fs_date_releve> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_fin_periode INTO lv_field.
  ASSIGN (lv_field) TO <fs_fin_periode>.
  IF <fs_fin_periode> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_flux INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.
  IF <fs_flux> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_serie INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_serie>.
  IF <fs_num_serie> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_index_fin INTO lv_field.
  ASSIGN (lv_field) TO <fs_idx_fin_periode>.
  IF <fs_idx_fin_periode> IS NOT ASSIGNED.
  ENDIF.

  CLEAR lv_field.
  MOVE 'FLUX-IDENREG'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_idenreg>.

  ev_etape = 1.

* Pour récupération de INT_UI
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).
  IF lv_int_ui IS INITIAL.
  ENDIF.

* Pour récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.


* On récupère les information de la table ETDZ
  IF ls_object-installation IS INITIAL.
  ENDIF.
  CALL FUNCTION 'ISU_DB_INSTALL_STRUC_SELECT'
    EXPORTING
      x_anlage     = ls_object-installation
    TABLES
      t_ietdz      = lt_etdz
    EXCEPTIONS
      not_found    = 1
      system_error = 2
      OTHERS       = 3.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  lv_anlage = ls_object-installation.

  "Récuperer le nbre de chiffres avant la virgule ( nbre de roues )
  LOOP AT lt_etdz ASSIGNING <fs_etdz> WHERE ab LE <fs_date_releve> AND bis GE <fs_date_releve>.
    EXIT.
  ENDLOOP.
  IF sy-subrc = 0.
    MOVE <fs_etdz>-stanzvor TO lv_stanzvor.
  ENDIF.

  "Vérif. raison de relève = 90 & nbre de roues flux != nbre de roues du compteur actuel
  IF <fs_raison_releve> EQ '90' AND lv_stanzvor NE <fs_nb_roue_compteur>.

    "------------------creation de la 02 de dépose--------------------------
    lv_date_depose = <fs_fin_periode> - 1.
    " Ouverture de l'objet relève
    CALL FUNCTION 'ISU_O_METERREAD_OPEN'
      EXPORTING
        x_anlage     = lv_anlage
        x_adatsoll   = lv_date_depose
        x_action     = '01'
        x_ablesgr    = '02'
        x_wmode      = '3'
        x_no_dialog  = 'X'
        x_upd_online = 'X'
        x_no_enqueue = 'X'
        x_ebene      = 'I'
        x_auto       = lt_auto
      IMPORTING
        y_obj        = ls_obj
      EXCEPTIONS
        OTHERS       = 99.

    CLEAR ls_ieabl.
    READ TABLE ls_obj-ieabl INTO ls_ieabl INDEX 1.
    IF NOT sy-subrc IS INITIAL.
* (ID &1) PCE &2 Installation &3 sans relève en date du &4
      MESSAGE e094(zintf_g_messages)
         WITH <fs_idenreg>
              <fs_num_pce>
              lv_anlage
              <fs_date_releve>
         INTO lv_message.
      RETURN.
    ENDIF.

    IF <fs_flux> EQ 'RE6M'.
      ASSIGN flux TO <fs_flux_re6m>.
      MOVE-CORRESPONDING <fs_flux_re6m> TO ls_flux.
    ELSEIF <fs_flux> EQ 'RE1M'.
      ASSIGN flux TO <fs_flux_re1m>.
      MOVE-CORRESPONDING <fs_flux_re1m> TO ls_flux.
    ELSE.
      ASSIGN flux TO <fs_flux_remm>.
      MOVE-CORRESPONDING <fs_flux_remm> TO ls_flux.
    ENDIF.

    lv_energie_entier  = trunc( ls_flux-index_brut_fin_periode ).
    lv_energie_decimal =  frac( ls_flux-index_brut_fin_periode ).

    ls_ieabl-zwnummer             = 1.
    ls_ieabl-v_zwstand            = lv_energie_entier.
    ls_ieabl-n_zwstand            = lv_energie_decimal.
    ls_ieabl-v_zwstndab           = lv_energie_entier.
    ls_ieabl-n_zwstndab           = lv_energie_decimal.
    ls_ieabl-adattats             = ls_flux-date_releve.
    ls_ieabl-ablstat              = '1'.

    IF ls_flux-vol_brut_conso < 0.
      ls_ieabl-ablhinw            = 'Z4'.
    ENDIF.

    IF ls_flux-qual_index_brut_fin_periode = 'E'.
      ls_ieabl-istablart          = 'Z4'.
    ELSE.
      ls_ieabl-istablart          = '01'.
    ENDIF.
    ls_ieabl-ablestyp             = '01'.

    ls_ieabl-zztype_rel              = ls_flux-type_releve.
    ls_ieabl-zzraison_rel            = ls_flux-raison_releve.
    ls_ieabl-zzdate_debut            = ls_flux-debut_periode.
    ls_ieabl-zzindex_brut_debut      = ls_flux-index_brut_debut_periode.
    ls_ieabl-zzqual_index_brut_debut = ls_flux-qual_index_brut_debut_periode.

    IF ls_flux-flux EQ 'REMM'.
      ls_ieabl-zzindex_conv_debut       = ls_flux-index_conv_debut_periode.
      ls_ieabl-zzqual_index_conv_debut  = ls_flux-qual_index_conv_debut_periode.
    ENDIF.

    ls_ieabl-zzdate_fin            = ls_flux-fin_periode.
    ls_ieabl-zzqual_index_brut_fin = ls_flux-qual_index_brut_fin_periode.

    IF ls_flux-flux EQ 'REMM'.
      ls_ieabl-zzindex_conv_fin      = ls_flux-index_conv_fin_periode.
      ls_ieabl-zzqual_index_conv_fin = ls_flux-qual_index_conv_fin_periode.
    ENDIF.

    ls_ieabl-zzvolume_brut        = ls_flux-vol_brut_conso.
    ls_ieabl-zzqual_volume_brut   = ls_flux-qualif_vol_brut_conso.

    IF ls_flux-flux EQ 'REMM'.
      ls_ieabl-zzvolume_brut_conv = ls_flux-volume_conv.
      ls_ieabl-zzqual_volume_conv = ls_flux-qualif_volume_conv.
      ls_ieabl-zzqual_coeff_pcs   = ls_flux-qualif_pcs.
    ENDIF.

    ls_ieabl-zzenergie            = ls_flux-energie_conso.
    ls_ieabl-zzqualif_energie     = ls_flux-qualif_energie_conso.

    IF ls_flux-flux EQ 'RE6M'.
      ls_ieabl-zzmotif_corr       = ls_flux-motif_correction.
      ls_ieabl-zzorig_corr        = ls_flux-origine_correction.
    ENDIF.

    ls_ieabl-zzidenreg            = ls_flux-idenreg.

    MODIFY ls_obj-ieabl FROM ls_ieabl INDEX 1.

    CALL FUNCTION 'ISU_O_METERREAD_OPEN_SUBOBJ'
      EXPORTING
        x_action   = '01'
        x_auto     = lt_auto
        x_adatsoll = lv_date_depose
      CHANGING
        xy_obj     = ls_obj
      EXCEPTIONS
        OTHERS     = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_message_to_log.
      RETURN.
    ENDIF.

    CALL FUNCTION 'ISU_O_METERREAD_INPUT'
      CHANGING
        xy_obj = ls_obj
      EXCEPTIONS
        OTHERS = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_message_to_log.
      RETURN.
    ENDIF.

* Préparation de la sauvegarde
    CALL FUNCTION 'ISU_O_METERREAD_ACTION'
      EXPORTING
        x_okcode = 'PSAV'
      CHANGING
        xy_obj   = ls_obj
      EXCEPTIONS
        OTHERS   = 99.


* sauvegarde
    CALL FUNCTION 'ISU_O_METERREAD_ACTION'
      EXPORTING
        x_okcode = 'SAVE'
      CHANGING
        xy_obj   = ls_obj
      EXCEPTIONS
        OTHERS   = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_message_to_log.
      RETURN.
    ENDIF.

    CALL FUNCTION 'ISU_O_METERREAD_CLOSE'
      EXPORTING
        x_no_dialog = 'X'
      CHANGING
        xy_obj      = ls_obj
      EXCEPTIONS
        OTHERS      = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_message_to_log.
      RETURN.
    ENDIF.
    "------------------------------------------------------------------------------
    "Dépose à (fin_période - 1) et index de fin && Pose à (fin_période)
    "------------------------------------------------------------------------------

    lv_date_effet = <fs_fin_periode>.

    PERFORM install_depose_fiap USING    ls_object-installation
                                         lv_date_effet
                                         ls_flux-index_brut_fin_periode
                                CHANGING lv_success.

*    CALL METHOD zcl_tool=>install_depose_fiap
*      EXPORTING
*        iv_install    = ls_object-installation
*        iv_date_effet = lv_date_effet
*      RECEIVING
*        ev_success    = lv_success.

    IF lv_success IS INITIAL.
      "generer un message W non bloqauant
      MESSAGE ID sy-msgid TYPE 'W' NUMBER sy-msgno WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 INTO DATA(lv_msg).
    ELSE.
      COMMIT WORK AND WAIT.
    ENDIF.
    "------------------------------------------------------------------------------
    "faire une pose à la FIN_PERIODE et se rendre à l’étape n°7
    "------------------------------------------------------------------------------

    IF <fs_flux> = 'RE6M' OR <fs_flux> = 'RE1M'.
      CASE <fs_nb_roue_compteur>.
        WHEN '4'.
          ls_dev-matnr      = 'ART_6M_4'.
          ls_dev-zwgruppe   = 'GAZ_6M_4'.
          ls_dev_flag-matnr = 'ART_6M_4'.
        WHEN '5'.
          ls_dev-matnr      = 'ART_6M_5'.
          ls_dev-zwgruppe   = 'GAZ_6M_5'.
          ls_dev_flag-matnr = 'ART_6M_5'.
        WHEN '6'.
          ls_dev-matnr      = 'ART_6M_6'.
          ls_dev-zwgruppe   = 'GAZ_6M_6'.
          ls_dev_flag-matnr = 'ART_6M_6'.
        WHEN '7'.
          ls_dev-matnr      = 'ART_6M_7'.
          ls_dev-zwgruppe   = 'GAZ_6M_7'.
          ls_dev_flag-matnr = 'ART_6M_7'.
      ENDCASE.
    ELSEIF <fs_flux> = 'REMM'.
      CASE <fs_nb_roue_compteur>.
        WHEN '4'.
          ls_dev-matnr      = 'ART_MM_4'.
          ls_dev-zwgruppe   = 'GAZ_MM_4'.
          ls_dev_flag-matnr = 'ART_MM_4'.
        WHEN '5'.
          ls_dev-matnr      = 'ART_MM_5'.
          ls_dev-zwgruppe   = 'GAZ_MM_5'.
          ls_dev_flag-matnr = 'ART_MM_5'.
        WHEN '6'.
          ls_dev-matnr      = 'ART_MM_6'.
          ls_dev-zwgruppe   = 'GAZ_MM_6'.
          ls_dev_flag-matnr = 'ART_MM_6'.
        WHEN '7'.
          ls_dev-matnr      = 'ART_MM_7'.
          ls_dev-zwgruppe   = 'GAZ_MM_7'.
          ls_dev_flag-matnr = 'ART_MM_7'.
        WHEN '8'.
          ls_dev-matnr      = 'ART_MM_8'.
          ls_dev-zwgruppe   = 'GAZ_MM_8'.
          ls_dev_flag-matnr = 'ART_MM_8'.
        WHEN '9'.
          ls_dev-matnr      = 'ART_MM_9'.
          ls_dev-zwgruppe   = 'GAZ_MM_9'.
          ls_dev_flag-matnr = 'ART_MM_9'.
      ENDCASE.
    ELSEIF <fs_flux> = 'REJM' OR <fs_flux> = 'REJJ'.
      ls_dev-matnr      = 'ART_JM/JJ'.
      ls_dev-zwgruppe   = 'G_JM_JJ'.
      ls_dev_flag-matnr = 'ART_JM/JJ'.
    ENDIF.



    ls_dev-ab         = <fs_fin_periode> .
    ls_dev-bis        = '99991231'.

    ls_dev-sparte     = 'ZG'.
    ls_dev-egerr_info =  <fs_num_serie>.
    APPEND ls_dev TO ls_auto-dev.

    " MAJ DEV FLAG
    ls_dev_flag-ab         = <fs_fin_periode>.
    ls_dev_flag-bis        = '99991231'.
    ls_dev_flag-zwgruppe   = 'X'.
    ls_dev_flag-egerr_info = 'X'.
    APPEND ls_dev_flag TO ls_auto-dev_flag.

    ls_auto-contr-okcode = 'SAVE'.


* créer fiche info appareil
    CALL FUNCTION 'ISU_S_SMALL_DEVICE_CREATE'
      EXPORTING
        x_matnr        = ls_dev-matnr            " Type appareil
        x_keydate      = <fs_fin_periode>
        x_upd_online   = 'X'
        x_no_dialog    = 'X'
        x_auto         = ls_auto
        x_int_num      = 'X'
      IMPORTING
        y_db_update    = lv_db_update
        y_equnr        = lv_equnr
        y_device       = lv_sernr
      EXCEPTIONS
        not_found      = 1
        invalid        = 2
        foreign_lock   = 3
        input_error    = 4
        system_error   = 5
        internal_error = 6
        not_qualified  = 7
        not_customized = 8
        cancelled      = 9
        OTHERS         = 10.

    IF  sy-subrc EQ 0
    AND NOT lv_db_update IS INITIAL.
* 'OK'
    ELSE.
*      ev_etape = 2.
      lv_ko = 'X'.
      EXIT.
* 'KO'
    ENDIF.


    IF lv_ko IS INITIAL.
      CONSTANTS: lc_365(3) VALUE 365.

      DATA: ld_date       TYPE datum,
            ld_perverbr   TYPE perverbr,
            ld_thgver     TYPE thgver,
            ld_tarifart   TYPE tarifart,
            ld_date_c(10) TYPE c,
            ld_db_update  TYPE xfeld,
            ls_zw         TYPE isu07_zw,
            lt_zw         TYPE isu07_zwt,
            ls_ger        TYPE isu07_auto_ger,
            ls_auto_pose  TYPE isu07_install_auto.

      " Pose de la fiche appareil créé
* Récupération :
* de la consommation périodique actuelle (CAR de facturation )
* de la catégorie de tarif
* de la conversion gaz
* Les données sont à récupérer à J-1 par rapport à la date de pose
      ld_date = <fs_date_releve> - 1.
* Si JJ/JM alors pas de consommation périodique donc on ne sélectionne pas
* dans cette table
      IF ls_dev-matnr EQ 'ART_JM/JJ'.
        SELECT easts~tarifart eadz~thgver
               INTO (ld_tarifart,ld_thgver)
               UP TO 1 ROWS
               FROM easts AS easts
               INNER JOIN eadz AS eadz
               ON eadz~logikzw EQ easts~logikzw
               AND eadz~bis GE easts~ab
               AND eadz~ab LE easts~bis
               WHERE easts~anlage EQ lv_anlage
               AND easts~ab LE ld_date
               AND easts~bis GE ld_date
               AND eadz~bis GE ld_date
               AND eadz~ab LE ld_date.
        ENDSELECT.
      ELSE.
        SELECT * INTO TABLE lt_easts
               FROM easts
               WHERE easts~anlage EQ lv_anlage
                 AND ab  LE ld_date
                 AND bis GE ld_date.

        SORT lt_easts BY bis DESCENDING.
        READ TABLE lt_easts INTO ls_easts INDEX 1.
        IF sy-subrc EQ 0.
          ld_tarifart = ls_easts-tarifart.

          SELECT perverbr thgver
              INTO (ld_perverbr,ld_thgver) UP TO 1 ROWS
               FROM easte
               INNER JOIN eadz
               ON eadz~logikzw EQ easte~logikzw
              AND eadz~bis GE easte~ab
              AND eadz~ab LE easte~bis
             WHERE easte~logikzw = ls_easts-logikzw
               AND easte~ab LE ld_date
               AND eadz~bis GE ld_date
               AND eadz~ab LE ld_date.
          ENDSELECT.
        ENDIF.
      ENDIF.
      IF NOT sy-subrc IS INITIAL.
* Problème dans le modèle de données
*        ev_etape = 2.
        lv_ko = 'X'.

      ELSE.
* Données cadran(s)
        ls_zw-zwnummere       = '001'.
        ls_zw-zwstandce       = <fs_idx_fin_periode>.
        ls_zw-spartype        = '02'.
        ls_zw-geraete         = lv_sernr.
        ls_zw-matnre          = ls_dev-matnr.
        ls_zw-anzerg          = 1.
        ls_zw-thgver          = ld_thgver.

        IF ls_dev-matnr NE 'ART_JM/JJ'.
          ls_zw-anzdaysofperiod = lc_365.
          ls_zw-perverbr        = ld_perverbr.
        ENDIF.
        ls_zw-tarifart        = ld_tarifart.
        IF ls_dev-matnr EQ 'ART_JM/JJ'.
          ls_zw-kondigre = 'GAZ_RTP'.
        ENDIF.
        APPEND ls_zw TO lt_zw.
* Données d'appareil
        ls_ger-matnr     = ls_dev-matnr.
        ls_ger-geraetneu = lv_sernr.
        ls_ger-ausbau    = space.
        ls_ger-sparteneu = 'ZG'.
        ls_ger-action    = '04'.
        APPEND ls_ger TO ls_auto_pose-auto_ger.
* Données de cadran(s)
        ls_auto_pose-auto_zw = lt_zw.
        ls_auto_pose-interface-anlage        = lv_anlage.
        ls_auto_pose-interface-eadat         = <fs_fin_periode>.
        ls_auto_pose-interface-action        = '04'.
        ls_auto_pose-interface-upd_online    = 'X'.
        ls_auto_pose-interface-no_dialog     = 'X'.
        ls_auto_pose-interface-no_event      = 'X'.
        ls_auto_pose-interface-no_statistic  = 'X'.
        ls_auto_pose-interface-no_change_doc = 'X'.
        ls_auto_pose-okcode                  = 'SAVE'.
        ls_auto_pose-zwstand                 = 'X'.
        ls_auto_pose-consumption             = 'X'.

        CALL FUNCTION 'ISU_S_WORKLIST_INSTALL'
          EXPORTING
            x_anlage         = lv_anlage
            x_eadat          = <fs_fin_periode>
            x_geraetneu      = lv_sernr
            x_matnr          = ls_dev-matnr
            x_action         = '04'       " Pose pour calcul de facturation
            x_spartee        = 'ZG' "02
            x_upd_online     = 'X'
            x_no_dialog      = 'X'
            x_no_event       = 'X'
            x_no_statistic   = 'X'
            x_no_change_doc  = 'X'
            x_called_by_idoc = space
          IMPORTING
            y_db_update      = ld_db_update
          CHANGING
            xy_auto          = ls_auto_pose
  "         xy_ext_cont      = lt_cont[]
          EXCEPTIONS
            not_found        = 1
            foreign_lock     = 2
            invalid          = 3
            internal_error   = 4
            not_qualified    = 5
            input_error      = 6
            system_error     = 7
            not_customized   = 8
            OTHERS           = 9.
        IF NOT sy-subrc IS INITIAL.
*          ev_etape = 2.
          "generer un message W non bloqauant
          MESSAGE ID sy-msgid TYPE 'W' NUMBER sy-msgno WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 INTO lv_msg.
        ELSE.
          ev_etape = 1.
        ENDIF.
      ENDIF.

    ENDIF.

*  ELSE.
*    ev_etape = 2.
  ENDIF.

ENDFUNCTION.





FORM install_depose_fiap USING    pv_anlage  TYPE anlage
                                  pv_date    TYPE eadat
                                  pv_index   TYPE zidx_fin_per
                         CHANGING pv_success TYPE flag.

  DATA: lv_nb_cadrans TYPE i,
        ls_zw         TYPE isu07_zw,
        ls_auto       TYPE isu07_install_auto,
        ls_auto_ger   TYPE isu07_auto_ger,
        lv_db_update  TYPE e_update,
        lv_message    TYPE string,
        lv_matnr      TYPE matnr,
        lv_zwgruppe   TYPE e_zwgruppe,
        lv_equnr      TYPE equnr,
        lv_sernr      TYPE lsernr,
        lv_geraet     TYPE geraet,
        lt_cadrans    TYPE TABLE OF ezwg,
        ls_cadrans    TYPE ezwg.
  INCLUDE: iee07action.

  CLEAR pv_success.

  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_installation = pv_anlage
      iv_date         = pv_date
    IMPORTING
      ev_matnr        = lv_matnr
      ev_equnr        = lv_equnr.

* On doit déterminer le matériel (article) et le groupe de cadrans
  SELECT       egerr~matnr
               egerr~geraet
               egerr~zwgruppe
         INTO (lv_matnr,
               lv_sernr,
               lv_zwgruppe) UP TO 1 ROWS
         FROM eastl AS eastl
   INNER JOIN egerr AS egerr
           ON egerr~logiknr EQ eastl~logiknr
          AND egerr~bis     GE eastl~ab
          AND egerr~ab      LE eastl~bis
        WHERE eastl~anlage  EQ pv_anlage
          AND eastl~bis     GE pv_date
          AND eastl~ab      LE pv_date
          AND egerr~bis     GE pv_date
          AND egerr~ab      LE pv_date.
  ENDSELECT.

  IF sy-subrc NE 0.
*   ADIF : Impossible de trouver le numéro d'équipement &1 dans EGERR
    MESSAGE e066(zintf_g_messages)
       WITH lv_equnr
       INTO lv_message.
    EXIT.
  ENDIF.

  " Vérification du type d'appareil pour déterminer le nombre de cadrans
  REFRESH lt_cadrans.
  SELECT * FROM ezwg
     INTO TABLE lt_cadrans
          WHERE zwgruppe = lv_zwgruppe.

  IF sy-subrc NE 0.
* Impossible de trouver la configuration de l'équipement => On quitte !
* ADIF : Configuration des cadrans du produit &1 inexistante
    MESSAGE e067(zintf_g_messages)
       WITH lv_matnr
       INTO lv_message.
    EXIT.
  ENDIF.

  ls_auto-interface-anlage        = pv_anlage.
* Dépose pour calcul de facturation
  ls_auto-interface-action        = co_close_relation.
  ls_auto-interface-eadat         = pv_date.
  ls_auto-interface-upd_online    = abap_true.
  ls_auto-interface-no_dialog     = abap_true.
  ls_auto-interface-no_event      = abap_true.
  ls_auto-interface-no_statistic  = abap_true.
  ls_auto-interface-no_change_doc = abap_true.
* Sauvegarde
  ls_auto-okcode                = 'SAVE'.
  ls_auto-zwstand                 = abap_true.

  " Dépose de tous les cadrans
  LOOP AT lt_cadrans INTO ls_cadrans.
    CLEAR ls_zw.
    ls_zw-geraeta   = lv_sernr.
    ls_zw-spartype  = ls_cadrans-spartyp.
    ls_zw-matnra    = lv_matnr.
    ls_zw-zwstandca = pv_index.
    ls_zw-zwnummera = ls_cadrans-zwnummer.
    ls_zw-spartypa  = '02'. "Gaz
    ls_zw-anzerg    = ls_cadrans-anzerg.
    APPEND ls_zw TO ls_auto-auto_zw.
  ENDLOOP.

* Données de l'appareil
  ls_auto_ger-geraetalt = lv_sernr.
  ls_auto_ger-matnralt  = lv_matnr.
  ls_auto_ger-sparte  = 'ZG'. "Gaz

* Dépose pour calcul de facturation
  ls_auto_ger-action    = co_close_relation.
  ls_auto_ger-ausbau    = abap_true.
  APPEND ls_auto_ger TO ls_auto-auto_ger.

* Dépose FIAP
  CALL FUNCTION 'ISU_S_WORKLIST_INSTALL'
    EXPORTING
      x_anlage        = pv_anlage
      x_eadat         = pv_date
      x_geraetalt     = ls_auto_ger-geraetalt
      x_matnralt      = ls_auto_ger-matnralt
* Dépose pour calcul de facturation
      x_action        = co_close_relation
      x_spartea       = ls_auto_ger-sparte "'ZG'
      x_upd_online    = abap_true
      x_no_dialog     = abap_true
      x_no_event      = abap_true
      x_no_statistic  = abap_true
      x_no_change_doc = abap_true
    IMPORTING
      y_db_update     = lv_db_update
    CHANGING
      xy_auto         = ls_auto
    EXCEPTIONS
      not_found       = 1
      foreign_lock    = 2
      invalid         = 3
      internal_error  = 4
      not_qualified   = 5
      input_error     = 6
      system_error    = 7
      not_customized  = 8
      OTHERS          = 99.


  IF sy-subrc NE 0 .
    CLEAR pv_success.
*   ADIF : &1 impossible de la FIAP de l'installation &2 au &3
    MESSAGE e060(zintf_g_messages)
       WITH 'Dépose'
            pv_anlage
            pv_date
       INTO lv_message.
  ELSE.
    pv_success = abap_true.
  ENDIF.

ENDFORM.
