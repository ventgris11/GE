*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZOPERANDE_MTCONS
*   generation date: 25.03.2019 at 09:30:17
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZOPERANDE_MTCONS   .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.
