FUNCTION zfkk_sample_0311.
*"--------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(PARA_0300) TYPE  FKKMA_0300
*"     VALUE(I_FAEDN_LOW) TYPE  FAEDN_KK OPTIONAL
*"     VALUE(I_FAEDN_HIGH) TYPE  FAEDN_KK OPTIONAL
*"  EXPORTING
*"     VALUE(E_FLAG) LIKE  BOOLE-BOOLE
*"  TABLES
*"      T_FKKOP STRUCTURE  FKKOP
*"      T_FKKVKP STRUCTURE  FKKVKP
*"      T_FIMSG STRUCTURE  FIMSG
*"  EXCEPTIONS
*"      INTERNAL_ERROR
*"--------------------------------------------------------------------

*  DATA : lt_fkkop_cpy     TYPE TABLE OF fkkop,
*         ls_fkkop_cpy     TYPE fkkop,
*         ls_fkkop         TYPE fkkop,
*         lv_montant_total TYPE betrw_kk.
*
*  lt_fkkop_cpy = t_fkkop[].
*
*  SORT lt_fkkop_cpy BY opbel.
*  DELETE ADJACENT DUPLICATES FROM lt_fkkop_cpy COMPARING opbel.
*
*
*  LOOP AT lt_fkkop_cpy INTO ls_fkkop_cpy.
*    LOOP AT t_fkkop INTO ls_fkkop WHERE opbel = ls_fkkop_cpy-opbel.
*      ADD ls_fkkop-betrw TO lv_montant_total .
*    ENDLOOP.
*
*    IF lv_montant_total LE 15 .
*      DELETE t_fkkop WHERE opbel = ls_fkkop_cpy-opbel.
*    ENDIF.
*
*    CLEAR lv_montant_total .
*  ENDLOOP.


ENDFUNCTION.
