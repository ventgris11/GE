*----------------------------------------------------------------------*
***INCLUDE LEV00F01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  write_anchor_erchz
*&---------------------------------------------------------------------*
FORM WRITE_ANCHOR_ERCHZ USING    X_SS   TYPE ISU2A_SS
                        CHANGING XY_OBJ TYPE ISU2A_BILLING_DATA.

  CALL FUNCTION 'ISU_WRITE_ANCHOR_ERCHZ'
       EXPORTING
            X_SS   = X_SS
       CHANGING
            XY_OBJ = XY_OBJ
        EXCEPTIONS
            GENERAL_FAULT = 1.

  IF SY-SUBRC <> 0.
    MAC_ERR_REPEAT GENERAL_FAULT.
  ENDIF.

ENDFORM.                    " write_anchor_erchz
* >>>>> note 913701
*&---------------------------------------------------------------------*
*&      Form  fill_price_cat_timeslices
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_TEMP_IPREI  text
*      <--P_IT_PC_TS  text
*----------------------------------------------------------------------*
form fill_price_cat_timeslices
                  using    x_iprei    type isu2a_iprei
                  changing xy_ipc_ts  type ipcat_ts.

  data: wprei      type isu2a_prei,
        wa_pc_ts   type pcat_ts,
        s_preisart type E_PREISART,
        first      type kennzx value 'X'.

* x_iprei is sorted by AB ascending.
  loop at x_iprei
    into wprei.
    if not first is initial.
*     prepare the first entry
      wa_pc_ts-ab  = wprei-ab.
      wa_pc_ts-bis = wprei-bis.
      wa_pc_ts-preisart = wprei-preisart.
      s_preisart = wprei-preisart.
      clear first.
    endif.                   "first
    if wprei-preisart <> s_preisart.
*     the price category has changed in the billing period - close the
*     former timeslice and open a new one.
      s_preisart = wprei-preisart.
      append wa_pc_ts to xy_ipc_ts.
      clear wa_pc_ts.
      wa_pc_ts-ab = wprei-ab.
      wa_pc_ts-bis = wprei-bis.
      wa_pc_ts-preisart = wprei-preisart.
    endif.
    if wa_pc_ts-bis lt wprei-bis.
*     prolong the timeslice
      wa_pc_ts-bis = wprei-bis.
    endif.
    append wprei to wa_pc_ts-t_iprei.

  endloop.    " x_iprei
* append the last timeslice to the table
  append wa_pc_ts to xy_ipc_ts.

endform.                    " fill_price_cat_timeslices
* <<<<< note 913701
