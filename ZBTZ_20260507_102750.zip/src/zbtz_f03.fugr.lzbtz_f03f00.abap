*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 16.10.2018 at 16:49:50
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
