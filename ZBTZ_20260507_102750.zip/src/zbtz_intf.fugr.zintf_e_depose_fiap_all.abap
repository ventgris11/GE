FUNCTION zintf_e_depose_fiap_all .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_ANLAGE) TYPE  ANLAGE
*"     REFERENCE(IV_DATE_DEPOSE) TYPE  DATS
*"     REFERENCE(IV_DATE_CADRAN) TYPE  DATS OPTIONAL
*"     REFERENCE(IV_ID_FLUX) TYPE  ZID_FLUX
*"     REFERENCE(IT_CADRANS) TYPE  ZINTF_CAD_RES_T OPTIONAL
*"     REFERENCE(IV_IDENREG) TYPE  ZIDENREG
*"     REFERENCE(IV_ID_PRM) TYPE  EXT_UI
*"     REFERENCE(IV_MES) TYPE  FLAG OPTIONAL
*"     REFERENCE(IV_RELEVE_02) TYPE  FLAG OPTIONAL
*"     REFERENCE(IT_STRUC_RXX) TYPE  ZINTF_CONSO_NEG_T OPTIONAL
*"  EXPORTING
*"     REFERENCE(EV_STATUT) TYPE  I
*"  CHANGING
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA : ls_cadran TYPE zintf_cad_res.
  ev_statut = 2.

*DEB-IBEN-20190225-GE-4368
  IF cv_log_handle IS NOT INITIAL.
    lv_log_handle = cv_log_handle.
  ENDIF.
*FIN-IBEN-20190225-GE-4368

  lv_date = iv_date_depose + 1.

  CALL METHOD zcl_tool=>install_depose_fiap
    EXPORTING
      iv_install    = iv_anlage
      iv_date_effet = lv_date
      iv_sparte     = 'ZE'
    RECEIVING
      ev_success    = lv_success.

  IF lv_success IS INITIAL.
* Le message d'erreur est émis dans la méthode
    RETURN.
  ENDIF.

  "Pas de MAJ index en cas date MES = Date dépose
  IF iv_mes = abap_true.
    ev_statut = 1.
    RETURN.
  ENDIF.

  IF iv_date_cadran IS INITIAL.
    lv_date = iv_date_depose .
  ELSE.
    lv_date = iv_date_cadran .
  ENDIF.

  REFRESH:
      lt_mr_data,
      lt_mr_reason.

  CALL FUNCTION 'BAPI_MTRREADDOC_GETLIST'
    EXPORTING
      installation      = iv_anlage
      mrdocumenttype    = '2'
    IMPORTING
      return            = ls_return
    TABLES
      mrdocumentdata    = lt_mr_data
      mrdocumentreasons = lt_mr_reason.

  INSERT iv_anlage INTO TABLE lt_anlage.

  lv_ok = abap_true .

  LOOP AT it_cadrans INTO ls_cadran.

***STOU DEBUT GE-1255
*    CLEAR ls_mr_data.
*    READ TABLE lt_mr_data
*          INTO ls_mr_data
*      WITH KEY targetmrdate = lv_date
*               register     = ls_cadran-register.

    LOOP AT lt_mr_data INTO ls_mr_data
                       WHERE targetmrdate = lv_date
                         AND register     = ls_cadran-register.
***STOU FIN   GE-1255

      CLEAR : ls_obj ,
              lt_auto .
* Ouverture de l'objet relève
      CALL FUNCTION 'ISU_O_METERREAD_OPEN'
        EXPORTING
          x_adatsoll            = lv_date
          x_action              = '01'
          x_ablbelnr            = ls_mr_data-mridnumber
          x_wmode               = '2'
          x_select2             = '1'
          x_no_dialog           = 'X'
          x_upd_online          = 'X'
          x_no_enqueue          = 'X'
          x_auto                = lt_auto
        IMPORTING
          y_obj                 = ls_obj
        EXCEPTIONS
          not_found             = 1
          foreign_lock          = 2
          internal_error        = 3
          input_error           = 4
          existing              = 5
          number_error          = 6
          general_fault         = 7
          system_error          = 8
          manual_abort          = 9
          gasdat_not_found      = 10
          no_mrrel_registers    = 11
          internal_warning      = 12
          not_authorized        = 13
          not_qualified         = 14
          anpstorno_not_allowed = 15
          already_billed        = 16
*         error_message         = 17
          OTHERS                = 16.

      IF NOT sy-subrc IS INITIAL.
        lv_ok = abap_false.
        macro_add_msg_system_to_log.
        RETURN.
      ENDIF.

      CLEAR ls_ieabl.
      READ TABLE ls_obj-ieabl
            INTO ls_ieabl     INDEX 1.

      IF NOT sy-subrc IS INITIAL.
        lv_ok = abap_false.
* Aucune relève pour l'installation &1 du PRM &2 en date du &3
        MESSAGE e171(zintf_e_messages)
           WITH iv_anlage
                iv_id_prm
                iv_date_depose
           INTO lv_message.
        RETURN.
      ENDIF.

      lv_index_entier    = trunc( ls_cadran-index_cad ).
      lv_index_decimales =  frac( ls_cadran-index_cad ).

      ls_ieabl-zwnummer             = ls_mr_data-register.
      ls_ieabl-v_zwstand            = lv_index_entier.
      ls_ieabl-n_zwstand            = lv_index_decimales.
      ls_ieabl-v_zwstndab           = lv_index_entier.
      ls_ieabl-n_zwstndab           = lv_index_decimales.
      ls_ieabl-adattats             = lv_date.
      ls_ieabl-ablstat              = '1'.
      ls_ieabl-istablart            = '01'.
      ls_ieabl-ablestyp             = '01'.
      ls_ieabl-zzidenreg            = iv_idenreg.

*FPE-GE-3953-Check conso nég
      IF it_struc_rxx IS NOT INITIAL.
        DATA : ls_struc_rxx TYPE zintf_conso_neg.
        CLEAR ls_struc_rxx.
        READ TABLE it_struc_rxx INTO ls_struc_rxx WITH KEY idenreg = iv_idenreg
                                                           register = ls_mr_data-register.
        ls_ieabl-ablhinw = ls_struc_rxx-ablhinw.
        IF  ls_ieabl-ablhinw = 'Z5'.
          ls_ieabl-ablstat = '2'.
        ENDIF.
      ENDIF.
*FPE-GE-3953-Check conso nég

      MODIFY ls_obj-ieabl
        FROM ls_ieabl     INDEX 1.

      CALL FUNCTION 'ISU_O_METERREAD_OPEN_SUBOBJ'
        EXPORTING
          x_action   = '01'
          x_auto     = lt_auto
          x_adatsoll = lv_date
        CHANGING
          xy_obj     = ls_obj
        EXCEPTIONS
*         error_message = 1
          OTHERS     = 99.

      IF NOT sy-subrc IS INITIAL.
        lv_ok = abap_false.
        macro_add_msg_system_to_log.
        RETURN.
      ENDIF.

      CALL FUNCTION 'ISU_O_METERREAD_INPUT'
        CHANGING
          xy_obj = ls_obj
        EXCEPTIONS
*         error_message = 1
          OTHERS = 99.

      IF NOT sy-subrc IS INITIAL.
        lv_ok = abap_false.
        macro_add_msg_system_to_log.
        RETURN.
      ENDIF.

* Préparation de la sauvegarde
      CALL FUNCTION 'ISU_O_METERREAD_ACTION'
        EXPORTING
          x_okcode = 'PSAV'
        CHANGING
          xy_obj   = ls_obj
        EXCEPTIONS
*         error_message = 1
          OTHERS   = 99.

      IF NOT sy-subrc IS INITIAL.
        lv_ok = abap_false.
        macro_add_msg_system_to_log.
        RETURN.
      ENDIF.

* sauvegarde
      CALL FUNCTION 'ISU_O_METERREAD_ACTION'
        EXPORTING
          x_okcode = 'SAVE'
        CHANGING
          xy_obj   = ls_obj
        EXCEPTIONS
*         error_message = 1
          OTHERS   = 99.

      IF NOT sy-subrc IS INITIAL.
        lv_ok = abap_false.
        macro_add_msg_system_to_log.
        RETURN.
      ENDIF.

      CALL FUNCTION 'ISU_O_METERREAD_CLOSE'
        EXPORTING
          x_no_dialog = 'X'
        CHANGING
          xy_obj      = ls_obj
        EXCEPTIONS
*         error_message = 1
          OTHERS      = 99.

      IF NOT sy-subrc IS INITIAL.
        lv_ok = abap_false.
        macro_add_msg_system_to_log.
        RETURN.
      ENDIF.
    ENDLOOP. "++GE-1255

    IF iv_releve_02 = abap_on.
      lv_releve_active = '1'.
      PERFORM creation_ordre_releve_02 USING iv_idenreg
                                             lv_releve_active
                                             lv_date
                                             ls_mr_data-register
                                             ls_cadran-index_cad
                                    CHANGING lv_ok.

      IF lv_ok EQ abap_false.
        EXIT.
      ENDIF.
    ENDIF.
  ENDLOOP.

  IF lv_ok = abap_true.
    ev_statut = 1.
  ENDIF.


ENDFUNCTION.
