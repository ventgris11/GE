*---------------------------------------------------------------------*
*  INCLUDE LFKPZI00                                                   *
*---------------------------------------------------------------------*

*---------------------------------------------------------------------*
*      Module  EXIT                                                   *
*---------------------------------------------------------------------*
MODULE EXIT.

  LEAVE TO SCREEN 0.

ENDMODULE.


*---------------------------------------------------------------------*
*      Module  OK_CODE                                                *
*---------------------------------------------------------------------*
MODULE OK_CODE.

* interpretation of F2
  IF OK_CODE EQ 'SELE' AND XDISPLAY IS INITIAL.
    GET CURSOR LINE H_INDEX.
    H_INDEX = H_INDEX + STEPL - 1.
    READ TABLE T_F4 INDEX H_INDEX.
    IF SY-SUBRC EQ 0.
      IF T_F4-PRIOR IS INITIAL.
        T_F4-PRIOR = 100.
      ELSE.
        CLEAR T_F4-PRIOR.
      ENDIF.
      MODIFY T_F4 INDEX H_INDEX.
    ENDIF.
  ENDIF.

* set flag for sort
  LOOP AT T_F4.
    IF T_F4-PRIOR IS INITIAL.
      CLEAR T_F4-XSELE.
    ELSE.
      T_F4-XSELE = 'X'.
      IF XPRIOR IS INITIAL.
        T_F4-PRIOR = 1.
      ENDIF.
    ENDIF.
    MODIFY T_F4.
  ENDLOOP.

* scrolling
  IF OK_CODE CA '+-'.
    CALL FUNCTION 'FI_CUST_SCROLL'
         EXPORTING
              I_INPUT = SPACE
              I_LNFIR = STEPL
              I_LNMAX = TFILL
              I_LOOPC = 14
              I_OKCOD = OK_CODE
         IMPORTING
              E_LNFIR = STEPL.
  ENDIF.

* adjust priorities
  PERFORM SORT.
  IF T_F4-PRIOR GT H_LENGTH.
    H_PRIOR = H_LENGTH.
    MESSAGE I125 WITH H_PRIOR.
    IF OK_CODE NA '+-'.
      LOOP AT T_F4 WHERE PRIOR GT H_LENGTH.
        IF SY-TABIX GE 15.
          STEPL = SY-TABIX.
        ELSEIF STEPL GE 15.
          STEPL = 1.
        ENDIF.
        EXIT.
      ENDLOOP.
    ENDIF.
    CLEAR OK_CODE.
  ENDIF.

* end of selection?
  IF OK_CODE EQ 'CONT'.
    LEAVE TO SCREEN 0.
  ENDIF.
  CLEAR OK_CODE.

ENDMODULE.


*---------------------------------------------------------------------*
*      Module  PAYMENT_METHOD_PUT  INPUT                              *
*---------------------------------------------------------------------*
MODULE PAYMENT_METHOD_PUT.

  READ TABLE T_F4 INDEX STEPL.
  T_F4-PRIOR = H_PRIOR.
  MODIFY T_F4 INDEX STEPL.

ENDMODULE.
