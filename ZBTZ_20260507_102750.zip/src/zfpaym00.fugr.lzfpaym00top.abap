FUNCTION-POOL ZFPAYM00.                      "MESSAGE-ID ..

