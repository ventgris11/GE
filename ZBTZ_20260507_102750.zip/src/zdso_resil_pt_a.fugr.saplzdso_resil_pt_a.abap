* regenerated at 14.04.2019 12:20:32
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDSO_RESIL_PT_ATOP.               " Global Data
  INCLUDE LZDSO_RESIL_PT_AUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDSO_RESIL_PT_AF...               " Subroutines
* INCLUDE LZDSO_RESIL_PT_AO...               " PBO-Modules
* INCLUDE LZDSO_RESIL_PT_AI...               " PAI-Modules
* INCLUDE LZDSO_RESIL_PT_AE...               " Events
* INCLUDE LZDSO_RESIL_PT_AP...               " Local class implement.
* INCLUDE LZDSO_RESIL_PT_AT99.               " ABAP Unit tests
  INCLUDE LZDSO_RESIL_PT_AF00                     . " subprograms
  INCLUDE LZDSO_RESIL_PT_AI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
