@AbapCatalog.sqlViewName: 'ZCDS_LS_PIECE_MT'
@AbapCatalog.compiler.CompareFilter: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Vue liste pièces montant HT'
define view ZCDS_LS_PIECE_MT_view as select from zcds_liste_piece {
zcds_liste_piece.opbel,
zcds_liste_piece.bukrs,
zcds_liste_piece.blart,
zcds_liste_piece.bldat,
zcds_liste_piece.faedn,
zcds_liste_piece.gpart,
zcds_liste_piece.vkont,
zcds_liste_piece.vtref,
zcds_liste_piece.spart,
(case when sum_skfbt <> 0 then sum_skfbt else sum_betrw end) as montant_ht
}
