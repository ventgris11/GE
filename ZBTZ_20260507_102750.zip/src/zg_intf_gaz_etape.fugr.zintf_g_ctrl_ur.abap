FUNCTION zintf_g_ctrl_ur.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA:   lc_field_num_pce     TYPE fieldname VALUE 'NUM_PCE',
          lc_field_date_releve TYPE fieldname VALUE 'DATE_RELEVE',
          lc_field_type_releve TYPE fieldname VALUE 'TYPE_RELEVE',
          lc_field_raison      TYPE fieldname VALUE 'RAISON_RELEVE',
          lc_field_date_fin    TYPE fieldname VALUE 'FIN_PERIODE',
          lv_field             TYPE string.

  DATA:
    lv_anlage  TYPE eanlh-anlage,
    lt_result  TYPE STANDARD TABLE OF efindres,
    ls_findpar TYPE efindpar,
    ls_eanlh   TYPE eanlh.

  FIELD-SYMBOLS:
    <ls_result>             TYPE efindres.

  CONSTANTS :
    lc_instln     TYPE swo_objtyp VALUE 'INSTLN'.

  FIELD-SYMBOLS: <fs_num_pce>, <fs_date_releve>, <fs_type>, <fs_raison>, <fs_flux>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.
  IF <fs_num_pce> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_type_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_type>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_raison INTO lv_field.
  ASSIGN (lv_field) TO <fs_raison>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' 'FLUX' INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_releve>.
  IF <fs_date_releve> IS NOT ASSIGNED.
  ENDIF.


* Déterminer le N° d'installation
  CLEAR:
    ls_findpar,
    lt_result.

  ls_findpar-i_pod  = <fs_num_pce>.
  ls_findpar-d_date = <fs_date_releve>.

  CALL FUNCTION 'ISU_FINDER'
    EXPORTING
      x_objtype                   = lc_instln
      x_findpar                   = ls_findpar
    TABLES
      yt_result                   = lt_result
    EXCEPTIONS
      insufficient_selection      = 1
      objtype_not_supported       = 2
      additional_selection_needed = 3.

  IF sy-subrc EQ 0.
* Récupérer l'installation (objet INSTLN)
    READ TABLE lt_result WITH KEY objtype = lc_instln ASSIGNING <ls_result>.
    IF <ls_result> IS ASSIGNED.
      lv_anlage = <ls_result>-objkey.
      UNASSIGN <ls_result>.
    ENDIF.
  ELSE.
    RETURN.
  ENDIF.

* Vérification de la cohérence de l'UR de l'installation avec l'id flux
  IF lv_anlage IS NOT INITIAL.
    SELECT SINGLE * FROM eanlh
             INTO ls_eanlh
             WHERE anlage EQ lv_anlage
               AND bis   GE <fs_date_releve>
               AND ab    LE <fs_date_releve>.
    IF sy-subrc EQ 0.
      CASE <fs_flux>.
        WHEN 'RE6M'.
          FIND 'M6' IN ls_eanlh-ableinh.
          IF sy-subrc = 0.
            ev_etape = 2.
          ELSE.
            FIND '6M' IN ls_eanlh-ableinh.
            IF sy-subrc = 0.
              ev_etape = 2.
            ELSE.
              ev_etape = 1.
            ENDIF.
          ENDIF.
        WHEN 'RE1M'.
          FIND 'M1' IN ls_eanlh-ableinh.
          IF sy-subrc = 0.
            ev_etape = 2.
          ELSE.
            FIND '1M' IN ls_eanlh-ableinh.
            IF sy-subrc = 0.
              ev_etape = 2.
            ELSE.
              ev_etape = 1.
            ENDIF.
          ENDIF.
      ENDCASE.
    ENDIF.
  ENDIF.

ENDFUNCTION.
