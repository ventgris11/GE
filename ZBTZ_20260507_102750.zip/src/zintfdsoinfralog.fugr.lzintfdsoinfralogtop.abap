* regenerated at 13.06.2019 19:00:33
FUNCTION-POOL ZINTFDSOINFRALOG           MESSAGE-ID SV.

* INCLUDE LZINTFDSOINFRALOGD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZINTFDSOINFRALOGT00                    . "view rel. data dcl.
