*&---------------------------------------------------------------------*
*&  Include           LFKCIINI
*&---------------------------------------------------------------------*

* ----------------------------------------------------------------------
* initialise and preassign global variables
* ----------------------------------------------------------------------

LOAD-OF-PROGRAM.

* set flag whether legal dunning is active
  CALL FUNCTION 'FKK_COLL_ESOA_ACTIVE'
    IMPORTING
      e_xescoll = gv_flg_coll_esoa_active.
