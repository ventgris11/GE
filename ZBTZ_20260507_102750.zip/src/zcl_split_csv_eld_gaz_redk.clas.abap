CLASS zcl_split_csv_eld_gaz_redk DEFINITION
  PUBLIC
  INHERITING FROM zcl_split_csv_eld_gaz
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    METHODS treat_file REDEFINITION.
    METHODS create_files REDEFINITION.
    METHODS exec_python REDEFINITION.

    METHODS constructor
      IMPORTING
        !i_emet       TYPE zemetteur_id
        !i_idflux     TYPE zconv_flux
        !i_rep_in     TYPE fileintern
        !i_rep_ar     TYPE fileintern
        !i_rep_refuse TYPE fileintern .

  PROTECTED SECTION.
    TYPES:
      BEGIN OF ty_file_redk,
        name_of_file  TYPE eps2filnam,
        nb_of_lines   TYPE i,
        id_flux       TYPE zconv_flux,
        lines_of_file TYPE table_of_strings,
      END OF ty_file_redk .
    TYPES:
      tt_file_redk TYPE STANDARD TABLE OF ty_file_redk .

    DATA pt_redk TYPE tt_file_redk .
    DATA p_num_seq_redk(5) TYPE n.

  PRIVATE SECTION.

    METHODS get_frequence
      IMPORTING
        !i_line        TYPE table_of_strings
      RETURNING
        VALUE(r_value) TYPE zconv_flux .

ENDCLASS.



CLASS ZCL_SPLIT_CSV_ELD_GAZ_REDK IMPLEMENTATION.


  METHOD constructor.

    super->constructor( i_emet = i_emet i_idflux = i_idflux i_rep_in = i_rep_in i_rep_ar = i_rep_ar i_rep_refuse = i_rep_refuse ).
    p_num_seq_redk = 00001.

  ENDMETHOD.


  METHOD create_files.

    DATA :
      ls_longtext TYPE ty_longtext,
      lv_filename TYPE string.

    DATA :
          lt_file_name_parts TYPE TABLE OF string.

    LOOP AT pt_redk ASSIGNING FIELD-SYMBOL(<ls_redk>).

      CLEAR : lv_filename.

      " Récupération du chemin + nom de fichier
      CALL FUNCTION 'FILE_GET_NAME'
        EXPORTING
          logical_filename = 'ZISU_GAZ_ELD_A_TRANSFORMER'
          operating_system = 'VMS'
          parameter_1      = p_emet
          parameter_2      = <ls_redk>-id_flux
          parameter_3      = <ls_redk>-name_of_file
        IMPORTING
          file_name        = lv_filename
        EXCEPTIONS
          file_not_found   = 1
          OTHERS           = 2.

      " Open the file
      IF po_files_manager->open_dataset_output( lv_filename ) IS NOT INITIAL.
        TRY.

            LOOP AT <ls_redk>-lines_of_file ASSIGNING FIELD-SYMBOL(<ls_line>).
              po_files_manager->transfer_to_dataset( x_file = lv_filename x_data = <ls_line> ).
            ENDLOOP.

            CLOSE DATASET lv_filename.

            ls_longtext = <ls_redk>-name_of_file.
            " Fichier &1&2&3&4 créé avec succès
            MESSAGE s011(zsplit_csv_eld_gaz) WITH ls_longtext-msgv1 ls_longtext-msgv2 ls_longtext-msgv3 ls_longtext-msgv4 INTO DATA(lv_dummy).
            po_log->add_sy_msg( ).

          CATCH zcx_utils_file_error .

            ls_longtext = <ls_redk>-name_of_file.
            " Erreur lors de l'écriture du fichier &1&2&3&4
            MESSAGE e005(zsplit_csv_eld_gaz) WITH ls_longtext-msgv1 ls_longtext-msgv2 ls_longtext-msgv3 ls_longtext-msgv4 INTO lv_dummy.
            po_log->add_sy_msg( ).

        ENDTRY.
      ENDIF.

    ENDLOOP.

  ENDMETHOD.


  METHOD exec_python.

    DATA :
      lv_parameter       TYPE btcxpgpar,
      lv_status          TYPE btcxpgstat,
      lv_exitcode        TYPE btcxpgexit,
      ls_longtext        TYPE ty_longtext,
      lt_exec_protocol   TYPE TABLE OF btcxpm,
      lt_file_name_parts TYPE TABLE OF string.

    lv_parameter = `--file ` && i_name && ` --flux REDK --emetteur ` && p_emet.

    CALL FUNCTION 'SXPG_COMMAND_EXECUTE'
      EXPORTING
        commandname                   = 'ZGENERATE_CSV_G'
        additional_parameters         = lv_parameter
      IMPORTING
        status                        = lv_status
        exitcode                      = lv_exitcode
      TABLES
        exec_protocol                 = lt_exec_protocol
      EXCEPTIONS
        no_permission                 = 1
        command_not_found             = 2
        parameters_too_long           = 3
        security_risk                 = 4
        wrong_check_call_interface    = 5
        program_start_error           = 6
        program_termination_error     = 7
        x_error                       = 8
        parameter_expected            = 9
        too_many_parameters           = 10
        illegal_command               = 11
        wrong_asynchronous_parameters = 12
        cant_enq_tbtco_entry          = 13
        jobcount_generation_error     = 14
        OTHERS                        = 15.

    IF sy-subrc  NE 0
    OR lv_status EQ 'E'.
      ls_longtext = i_name.
      " Fichier &1&2 : Erreur lors de l'appel du script python
      MESSAGE e004(zsplit_csv_eld_gaz) WITH ls_longtext-msgv1 ls_longtext-msgv2 INTO DATA(lv_dummy).
      po_log->add_sy_msg( ).
      " Raise the exception
      RAISE EXCEPTION TYPE zcx_split_eld_gaz_error.

    ENDIF.

  ENDMETHOD.


  METHOD get_frequence.

    DATA :
      lv_date_releve TYPE dats,
      lv_pce         TYPE ext_ui.

    READ TABLE i_line ASSIGNING FIELD-SYMBOL(<ls_data>) INDEX 1.
    IF sy-subrc EQ 0.
      lv_date_releve = <ls_data>.

      READ TABLE i_line ASSIGNING <ls_data> INDEX 6.
      IF sy-subrc = 0.
        IF <ls_data> IS INITIAL.
          READ TABLE i_line ASSIGNING <ls_data> INDEX 7.
          IF sy-subrc = 0.
            IF <ls_data> IS INITIAL.
              " Référence n'existe pas
              MESSAGE e014(zsplit_csv_eld_gaz) WITH lv_pce INTO DATA(lv_dummy).
              po_log->add_sy_msg( ).
            ELSE.
              lv_pce = <ls_data>.
            ENDIF.
          ENDIF.
        ELSE.
          lv_pce = <ls_data>.
        ENDIF.
      ENDIF.

      lv_pce = 'G_' && lv_pce.

      SELECT frequence, date_creation, heure_creation INTO TABLE @DATA(lt_frequence)
        FROM zintf_g_adif
        WHERE num_pce = @lv_pce.
      IF sy-subrc EQ 0.
        SORT lt_frequence BY date_creation DESCENDING heure_creation DESCENDING.
        READ TABLE lt_frequence ASSIGNING FIELD-SYMBOL(<ls_frequence>) INDEX 1.
        IF sy-subrc EQ 0.
          r_value = 'RE' && <ls_frequence>-frequence.
        ENDIF.
      ENDIF.
    ENDIF.

    CHECK r_value IS INITIAL.

    SELECT SINGLE int_ui INTO @DATA(lv_int_ui)
      FROM euitrans
      WHERE ext_ui = @lv_pce.

    IF lv_int_ui IS NOT INITIAL.
      SELECT moveindate, zzg_type_pce INTO TABLE @DATA(lt_freq)
        FROM eideswtdoc
        WHERE pod = @lv_int_ui
          AND zzg_type_pce <> @space.

      SORT lt_freq BY moveindate DESCENDING.
      READ TABLE lt_freq ASSIGNING FIELD-SYMBOL(<ls_freq>) INDEX 1.
      IF sy-subrc EQ 0.
        r_value = 'RE' && <ls_freq>-zzg_type_pce.
      ENDIF.

    ENDIF.

    CHECK r_value IS INITIAL.

    " Fréquence non trouvée pour le PCE &1
    MESSAGE e008(zsplit_csv_eld_gaz) WITH lv_pce INTO lv_dummy.
    po_log->add_sy_msg( ).

  ENDMETHOD.


  METHOD treat_file.

    DATA :
      lv_numero_cad      TYPE string,
      lt_data            TYPE table_of_strings,
      lt_file_name_parts TYPE table_of_strings,
      lv_date            TYPE string,
      ls_add_redk        TYPE ty_file_redk,
      ls_header_tech     TYPE string,
      ls_header_fonc     TYPE string,
      ls_footer          TYPE string.

    REFRESH pt_redk.

    LOOP AT i_lines ASSIGNING FIELD-SYMBOL(<ls_line>).

      " En têtes ( technique et fonctionnel )
      IF sy-tabix EQ 1.
        ls_header_tech = <ls_line>.

        SPLIT ls_header_tech AT ';' INTO TABLE lt_data.
        READ TABLE lt_data ASSIGNING FIELD-SYMBOL(<ls_data>) INDEX 5.
        IF sy-subrc EQ 0.

          CASE p_emet.
            WHEN 'GRNB'.
              IF <ls_data> NE c_grnb_emet.
                " L'émetteur de l'entête &1 ne correspond pas à l'émetteur &2
                MESSAGE e012(zsplit_csv_eld_gaz) WITH <ls_data> p_emet INTO DATA(lv_dummy).
                po_log->add_sy_msg( ).
                RAISE EXCEPTION TYPE zcx_split_eld_gaz_error.
              ENDIF.
            WHEN 'DREU'.
              IF <ls_data> NE c_dreu_emet.
                " L'émetteur de l'entête &1 ne correspond pas à l'émetteur &2
                MESSAGE e012(zsplit_csv_eld_gaz) WITH <ls_data> p_emet INTO lv_dummy.
                po_log->add_sy_msg( ).
                RAISE EXCEPTION TYPE zcx_split_eld_gaz_error.
              ENDIF.
            WHEN OTHERS.
              " Aucun autre cas gérés pour le moment
          ENDCASE.

          <ls_data> = p_emet.

        ENDIF.

        CLEAR : ls_header_tech.
        LOOP AT lt_data ASSIGNING <ls_data>.
          IF ls_header_tech IS INITIAL.
            ls_header_tech = <ls_data>.
          ELSE.
            ls_header_tech = ls_header_tech && ';' && <ls_data>.
          ENDIF.
        ENDLOOP.

      ELSEIF sy-tabix EQ 2.
        ls_header_fonc = <ls_line>.

      ELSE.

        SPLIT <ls_line> AT ';' INTO TABLE lt_data.
        ls_add_redk-id_flux = me->get_frequence( i_line = lt_data ).
        IF ls_add_redk-id_flux IS INITIAL.
          RAISE EXCEPTION TYPE zcx_split_eld_gaz_error.
        ENDIF.

        READ TABLE pt_redk ASSIGNING FIELD-SYMBOL(<ls_redk>) WITH KEY id_flux = ls_add_redk-id_flux.
        IF sy-subrc NE 0. " Le tableau pour cette fréquence n'existe pas encore
          APPEND ls_header_tech TO ls_add_redk-lines_of_file.
          APPEND ls_header_fonc TO ls_add_redk-lines_of_file.
          APPEND <ls_line> TO ls_add_redk-lines_of_file.
          ls_add_redk-nb_of_lines = 1.
          APPEND ls_add_redk TO pt_redk.
          CLEAR ls_add_redk.

        ELSE.
          <ls_redk>-nb_of_lines = <ls_redk>-nb_of_lines + 1.
          APPEND <ls_line> TO <ls_redk>-lines_of_file.
        ENDIF.

      ENDIF.

    ENDLOOP.

    LOOP AT pt_redk ASSIGNING <ls_redk>.

      CLEAR : lv_numero_cad.

      " Gestion de header technique avec id flux
      READ TABLE <ls_redk>-lines_of_file ASSIGNING FIELD-SYMBOL(<ls_header>) INDEX 1.
      IF sy-subrc EQ 0.
        SPLIT <ls_header> AT ';' INTO TABLE lt_data.
        CLEAR <ls_header>.

        LOOP AT lt_data ASSIGNING <ls_data>.
          IF sy-tabix EQ 1.
            <ls_header> = <ls_redk>-id_flux.
            CONTINUE.
          ELSEIF sy-tabix EQ 9.
            lv_numero_cad = <ls_data>.
            CONDENSE lv_numero_cad NO-GAPS.
          ENDIF.
          <ls_header> = <ls_header> && ';' && <ls_data>.
        ENDLOOP.

      ENDIF.

      " Créer le nom de fichier
      " Récupération de la date et heure du fichier de base
      SPLIT i_name AT '_' INTO TABLE lt_file_name_parts.
      READ TABLE lt_file_name_parts ASSIGNING FIELD-SYMBOL(<ls_part>) INDEX 2.
      IF sy-subrc EQ 0.
        lv_date = <ls_part>.
      ENDIF.
      <ls_redk>-name_of_file = <ls_redk>-id_flux && '_00001_1_' && p_emet && '_' && lv_numero_cad && '_' && lv_date && '_' && p_num_seq_redk && '.csv'.
      p_num_seq_redk = p_num_seq_redk + 1.

      " Gestion du footer
      ls_footer = sy-datlo && sy-timlo && ';' && <ls_redk>-nb_of_lines && ';;' && 'EOF'.
      APPEND ls_footer TO <ls_redk>-lines_of_file.

    ENDLOOP.

  ENDMETHOD.
ENDCLASS.
