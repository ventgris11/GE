FUNCTION zintf_g_ctrl_matr .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA: lc_field_num_pce     TYPE fieldname VALUE 'NUM_PCE',
        lc_field_date_releve TYPE fieldname VALUE 'DATE_RELEVE',
        lc_field_num_serie   TYPE fieldname VALUE 'NUM_SERIE_COMPTEUR',
        lc_field_type_releve TYPE fieldname VALUE 'TYPE_RELEVE',     "++GE-2200
        lc_field_raison      TYPE fieldname VALUE 'RAISON_RELEVE',   "++GE-2200
        lc_field_date_fin    TYPE fieldname VALUE 'FIN_PERIODE',     "++GE-2200
        lv_field             TYPE string,
        lv_int_ui            TYPE int_ui.

  DATA:
    lv_equnr     TYPE egerr-equnr,
    lt_result    TYPE STANDARD TABLE OF efindres,
    ls_findpar   TYPE efindpar,
    ls_egerr     TYPE egerr,
    ls_egerr_old TYPE egerr.

  FIELD-SYMBOLS:
    <ls_result>             TYPE efindres.

  CONSTANTS :
    lc_device     TYPE swo_objtyp  VALUE 'DEVICE',
    lc_upd_update TYPE c LENGTH 1 VALUE 'U'.

  FIELD-SYMBOLS: <fs_num_pce>, <fs_date_releve>, <fs_num_serie>,
                 <fs_type>, <fs_raison>, <fs_flux>. "++GE-2200

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.
  IF <fs_num_pce> IS NOT ASSIGNED.
  ENDIF.


  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_type_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_type>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_raison INTO lv_field.
  ASSIGN (lv_field) TO <fs_raison>.

*++ STOU DEBUT GE-2200
  CLEAR: lv_field.
  CONCATENATE 'FLUX-' 'FLUX' INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.

*-- STOU DEBUT GE-2204
*  IF <fs_flux> = 'RE6M' AND <fs_raison> IS ASSIGNED AND <fs_type> IS ASSIGNED .
*    IF <fs_raison> = '87' AND <fs_type> = 'S'.
*      CLEAR: lv_field.
*      CONCATENATE 'FLUX-' lc_field_date_fin INTO lv_field.
*      ASSIGN (lv_field) TO <fs_date_releve>.
*    ELSE.
*      CLEAR: lv_field.
*      CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
*      ASSIGN (lv_field) TO <fs_date_releve>.
*    ENDIF.
*  ELSE.
*    CLEAR: lv_field.
*    CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
*    ASSIGN (lv_field) TO <fs_date_releve>.
*  ENDIF.
*-- STOU FIN   GE-2204


  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_releve>.
  IF <fs_date_releve> IS NOT ASSIGNED.
  ENDIF.

*++ STOU FIN   GE-2200

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_serie INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_serie>.
  IF <fs_num_serie> IS NOT ASSIGNED.
  ENDIF.


* Déterminer le N° d'équipement
  CLEAR:
    ls_findpar,
    lt_result.

  ev_etape = 1.

  ls_findpar-i_pod  = <fs_num_pce>.
  ls_findpar-d_date = <fs_date_releve>.

  CALL FUNCTION 'ISU_FINDER'
    EXPORTING
      x_objtype                   = lc_device
      x_findpar                   = ls_findpar
    TABLES
      yt_result                   = lt_result
    EXCEPTIONS
      insufficient_selection      = 1
      objtype_not_supported       = 2
      additional_selection_needed = 3.

  IF sy-subrc EQ 0.
* Récupérer le N° d'équipement (objet DEVICE)
    READ TABLE lt_result WITH KEY objtype = lc_device ASSIGNING <ls_result> .
    IF <ls_result> IS ASSIGNED.
      lv_equnr = <ls_result>-objkey.
    ENDIF.
  ELSE.
    RETURN.
  ENDIF.

  SELECT * FROM egerr
           INTO ls_egerr_old
           UP TO 1 ROWS
           WHERE equnr EQ lv_equnr
             AND bis   GE <fs_date_releve>
             AND ab    LE <fs_date_releve>.
  ENDSELECT.

  CHECK sy-subrc EQ 0.
  "    AND ls_egerr_old-egerr_info IS INITIAL.

  ls_egerr = ls_egerr_old.
  ls_egerr-egerr_info = <fs_num_serie>.

  CALL FUNCTION 'ISU_DB_EGERR_UPDATE'
    EXPORTING
      x_egerr         = ls_egerr
      x_egerr_old     = ls_egerr_old
      x_upd_mode      = lc_upd_update
      x_no_change_doc = 'X'.


ENDFUNCTION.
