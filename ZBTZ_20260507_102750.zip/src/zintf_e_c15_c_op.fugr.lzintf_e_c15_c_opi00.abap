*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 12.09.2019 at 11:03:16
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
