FUNCTION zintf_e_integration_f12 .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_IDENREG) TYPE  ZIDENREG
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN DEFAULT ABAP_FALSE
*"     REFERENCE(IV_ID_FLUX) TYPE  ZID_FLUX
*"  EXPORTING
*"     REFERENCE(EV_ERROR) TYPE  CRMT_BOOLEAN
*"----------------------------------------------------------------------

  DATA: ls_id_enreg             TYPE zintf_g_donnees_generique,
        lv_log_handle           TYPE balloghndl,
        lv_art_sd_remise_grd    TYPE rvari_val_255,
        lv_num_dossier_affaire  TYPE string,
        lv_int_ui               TYPE int_ui,
        lv_pourcent_rem_grd     TYPE wert,
        lv_taux_rem             TYPE betrw_kk,
        lv_ko                   TYPE flag,
        lv_bukrs                TYPE stdbk_kk,
        lv_societe              TYPE bukrs,
        lv_blocage              TYPE flag,
        lv_sparte               TYPE sparte,
        lv_posnr                TYPE posnr,
*        lv_message              TYPE string,
        lr_switch_doc           TYPE REF TO cl_isu_ide_switchdoc,
        ls_switch_doc           TYPE eideswtdoc,
        ls_object               TYPE eedm_isu_objects,
        lt_mr_data              TYPE TABLE OF bapieabl,
        lt_mr_reason            TYPE TABLE OF bapieablg,
        lv_date                 TYPE datum,
        ls_sales_order_header   TYPE zisus_sales_order_header,
        lt_sales_order_header   TYPE TABLE OF zisus_sales_order_header,
        ls_sales_order_item     TYPE zisus_sales_order_item,
        lt_debit_note_item_tmp  TYPE zisut_sales_order_item,
        lt_credit_note_item_tmp TYPE zisut_sales_order_item,
        lt_debit_note_item      TYPE zisut_sales_order_item,
        lt_credit_note_item     TYPE zisut_sales_order_item,
        lv_vbeln                TYPE vbeln,
        lt_return               TYPE bapiret2_t,
        ls_return               TYPE bapiret2,
        ls_return1              TYPE bapireturn1,
        lv_anlage               TYPE anlage,
        lv_temp_matnr           TYPE string,
        lv_emetteur             TYPE zemetteur_id,
        lv_idenreg              TYPE zintf_g_id_enreg,
        lv_id_evt               TYPE string,
        lv_fin                  TYPE string,
        v_date                  TYPE zdate_fin_frais.

  CLEAR ev_error.

  lv_log_object    = lc_log_object_intf_elec.
  lv_log_subobject = lc_log_subobject_f12.
  lv_msgid         = lc_msgid_intf_elec.

* Appel en mode &1 pour le flux &2
  IF 1 = 2. MESSAGE i018(zintf_e_messages). ENDIF.
  IF iv_mode_test IS INITIAL.
    macro_add_msg_to_log 'I' '018'
                         'REEL' iv_id_flux '' ''.
  ELSE.
    macro_add_msg_to_log 'I' '018'
                         'TEST' iv_id_flux '' ''.
  ENDIF.

  REFRESH : lt_f12.

* Sélection des données à traiter
  SELECT * FROM zintf_e_f12
  INTO CORRESPONDING FIELDS OF TABLE lt_f12
  WHERE idenreg EQ iv_idenreg.

  SORT lt_f12 BY num_dossier id_prm.



  LOOP AT lt_f12 INTO ls_f12.

    CLEAR : lv_blocage, ls_sales_order_item, ls_sales_order_header,
lv_ko.
    REFRESH :
    lt_sales_order_header,
    lt_debit_note_item,
    lt_credit_note_item.

    ls_temp_f12 = ls_f12.
*   F12 : Traitement de l'enregistrement &1

    IF 1 = 2. MESSAGE i164(zintf_e_messages). ENDIF.

    macro_add_msg_to_log 'I' '164'
                             ls_f12-idenreg '' '' ''.

*********************************************************************
*******Etape n°1 : Vérifier si l’enregistrement est pertinent *******
*********************************************************************

    IF ls_temp_f12-code_recap = 'CGEST'
       OR ls_temp_f12-code_recap = 'CCOMP'
       OR ls_temp_f12-code_recap = 'CSF'
*       OR ls_temp_f12-code_recap = 'CSV' --GE-69
       OR ls_temp_f12-code_recap = 'CSPE'
       OR ls_temp_f12-code_recap = 'CMDPS'
*DEB-IBEN-20200515-GE-8115
*       OR ls_temp_f12-code_recap = 'CAC'
*       OR ls_temp_f12-code_recap = 'CAS'
*       OR ls_temp_f12-code_recap = 'CRGPT'
*FIN-IBEN-20200515-GE-8115
       OR ( ls_temp_f12-code_recap = 'CREAC'  "++GDPTMA-314
            AND ls_temp_f12-id_ev = 'VEREACG' ) "++GE-69
       OR ls_temp_f12-code_recap = 'CGCU' . "GDPTMA-314  +

      IF 1 = 2. MESSAGE i162(zintf_e_messages) INTO lv_message. ENDIF.

      macro_add_msg_to_log 'I' '162' '' '' '' ''.

      PERFORM update_ligne_f12 USING lc_statut_11_filtre iv_id_flux.


      CONTINUE.
    ENDIF.


    lv_num_dossier_affaire = ls_temp_f12-num_dossier.
    SPLIT ls_temp_f12-id_ev AT '-' INTO lv_id_evt lv_fin.
    lv_temp_matnr = lv_id_evt.



****************************************************
*******Etape n°2 : Vérifier l’existence du PRM*******
****************************************************
*    IF ls_temp_f12-DATE_FIN_FRAIS GE sy-datum.
    lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num =
ls_temp_f12-id_prm ).
    IF lv_int_ui IS INITIAL.

      MESSAGE e160(zintf_e_messages) WITH ls_temp_f12-id_prm INTO lv_msg_bpem.

      CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
        EXPORTING
          iv_interface_name = 'F12'
          iv_sparte         = 'ZE'
          is_structure      = ls_temp_f12.

      macro_add_msg_to_log 'E' '160' ls_temp_f12-id_prm '' '' ''.

      PERFORM update_ligne_f12 USING lc_statut_06_rejet iv_id_flux.

      CONTINUE.

    ENDIF.


****************************************************
*******Etape n°3.2 : Récupération des données pour commande SD  *******
****************************************************
    CLEAR : ls_sales_order_header, lv_posnr.
    IF ls_temp_f12-date_effet IS INITIAL.
      v_date = ls_temp_f12-date_fin.
    ELSE.
      v_date = ls_temp_f12-date_effet.
    ENDIF.

*+GE-8115 {
    DATA : lv_art_turpe TYPE c.
    SELECT zzposte_id
      FROM zparam_fact_b2b
      INTO @DATA(lv_zzposte_id)
      UP TO 1 ROWS
      WHERE zzposte2_lib = @lv_temp_matnr.
    ENDSELECT.
    IF sy-subrc EQ 0.
      lv_art_turpe = 'X'.
    ELSE.
      CLEAR lv_art_turpe.
    ENDIF.
*+GE-8115 }

* Récupération de l'installation
    SELECT SINGLE anlage
                  FROM euiinstln
                  INTO lv_anlage
                  WHERE int_ui EQ lv_int_ui
                  AND   datefrom LE v_date
                  AND   dateto GE v_date.

    IF sy-subrc EQ 0.

      SELECT SINGLE sparte
        FROM eanl
        INTO lv_sparte
        WHERE anlage = lv_anlage.

* Récupération du partenaire, du compte de contrats et des conditions
*de paiement
      SELECT SINGLE fkkvkp~gpart fkkvkp~vkont fkkvkp~stdbk
        "fkkvkp~zahlkond
         INTO (ls_sales_order_header-partn_numb,
               ls_sales_order_header-fkk_conacct, lv_bukrs )
        ",ls_sales_order_header-pmnttrms )
         FROM ever AS ever
              INNER JOIN fkkvkp AS fkkvkp
                ON fkkvkp~vkont EQ ever~vkonto
         WHERE ever~anlage  EQ lv_anlage
           AND   ever~einzdat LE v_date
           AND   ever~auszdat GE v_date.
      IF sy-subrc NE 0.
        lv_ko = 'X'.
      ENDIF.
    ELSE.
      lv_ko = 'X'.
    ENDIF.

    lv_societe = lv_bukrs.

    IF lv_bukrs = 'GDP1'.
      lv_bukrs = 'ZGDP'.
    ENDIF.
* Récupération des dates de document et de prix en en-tête
    IF lv_ko IS INITIAL.

*++ STOU Début GE-69
      IF ls_temp_f12-code_recap = 'CSV' .
        "1.	Rechercher si le PRM a le motif de blocage «R»
        "au niveau de son compte de contrat valable à la date de fin du flux
        SELECT SINGLE *
          FROM dfkklocks
          INTO ls_dfkklocks_old
          WHERE lotyp  = '06'
            AND proid  = '05'
            AND gpart  = ls_sales_order_header-partn_numb
            AND vkont  = ls_sales_order_header-fkk_conacct
            AND lockr  = 'R'.

        IF sy-subrc NE 0 .
          IF 1 = 2. MESSAGE i162(zintf_e_messages) INTO lv_message. ENDIF.
          macro_add_msg_to_log 'I' '162' '' '' '' ''.
          PERFORM update_ligne_f12 USING lc_statut_11_filtre iv_id_flux.
          CONTINUE.
        ELSE.
          "2.	Rechercher si la date de fin du flux correspond à une date de résiliation
          CLEAR : ls_return1  ,
                  lt_mr_data  ,
                  lt_mr_reason.
          CALL FUNCTION 'BAPI_MTRREADDOC_GETLIST'
            EXPORTING
              installation      = lv_anlage
              mrreason          = '03' "Relève résiliation
              mrdocumenttype    = '2' "Résultat relève
            IMPORTING
              return            = ls_return1
            TABLES
              mrdocumentdata    = lt_mr_data
              mrdocumentreasons = lt_mr_reason.
          READ TABLE lt_mr_data TRANSPORTING NO FIELDS
                     WITH KEY actualmrdate = ls_temp_f12-date_fin .
          IF sy-subrc IS INITIAL.
            "Supprimer le motif de blocage "R".
            CALL FUNCTION 'FKK_DB_LOCK_UPDATE'
              EXPORTING
                i_lock        = ls_dfkklocks
                i_oldlock     = ls_dfkklocks_old
                i_x_lock_del  = abap_true
              EXCEPTIONS
                update_failed = 1
                OTHERS        = 2.
            IF sy-subrc <> 0.
              IF 1 = 2. MESSAGE e253(zintf_e_messages). ENDIF.
              macro_add_msg_to_log 'E' '253' '' '' '' ''.
              PERFORM update_ligne_f12 USING lc_statut_06_rejet iv_id_flux.
              CONTINUE.
            ELSE.
              IF 1 = 2. MESSAGE i165(zintf_e_messages) INTO lv_message. ENDIF.
              macro_add_msg_to_log 'I' '165' '' '' '' ''.
              IF 1 = 2. MESSAGE i162(zintf_e_messages) INTO lv_message. ENDIF.
              macro_add_msg_to_log 'I' '162' ls_sales_order_header-fkk_conacct '' '' ''.
              PERFORM update_ligne_f12 USING lc_statut_11_filtre iv_id_flux.
              CONTINUE.
            ENDIF.
          ELSE.
            IF 1 = 2. MESSAGE i162(zintf_e_messages) INTO lv_message. ENDIF.
            macro_add_msg_to_log 'I' '162' '' '' '' ''.
            PERFORM update_ligne_f12 USING lc_statut_11_filtre iv_id_flux.
            CONTINUE.
          ENDIF.

        ENDIF.
      ENDIF.
*++ STOU FIN   GE-69

      ls_sales_order_header-doc_date = sy-datum.
      ls_sales_order_header-price_date = sy-datum.
      ls_sales_order_header-doc_type = 'ZDIS'.
      ls_sales_order_header-purch_no_c = ls_temp_f12-id_prm.
      ls_sales_order_header-req_date_h = ls_temp_f12-date_fin.
      ls_sales_order_header-id_demande_intern = lv_num_dossier_affaire.
      ls_sales_order_header-bill_date = sy-datum.
*++STOU DEBUT GE-69
      IF ( ls_temp_f12-code_recap = 'CREAC'  AND
         ls_temp_f12-id_ev      = 'VEREACF' )
        OR lv_art_turpe IS NOT INITIAL.                     "+GE-8115
        ls_sales_order_header-ref_1 = ls_temp_f12-pu.
      ENDIF.
*++STOU FIN   GE-69
      INSERT ls_sales_order_header INTO TABLE lt_sales_order_header.

    ELSE.

      MESSAGE e163(zintf_e_messages) WITH
                           ls_temp_f12-id_prm INTO lv_message.

      CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
        EXPORTING
          iv_interface_name = 'F12'
          iv_sparte         = 'ZE'
          is_structure      = ls_temp_f12.


      macro_add_msg_to_log 'E' '163' '' '' '' ''.

      PERFORM update_ligne_f12 USING lc_statut_06_rejet iv_id_flux.

      CONTINUE.

    ENDIF.

    IF lv_ko IS INITIAL.
**************************************************************
******* Etape n°3.1 : Blocage des postes     *******
**************************************************************
      DATA ls_zparam_sd  TYPE zparam_sd .

      SELECT SINGLE *
            FROM zparam_sd
            INTO ls_zparam_sd
      WHERE matnr = lv_temp_matnr
        AND bukrs = lv_societe.

      IF sy-subrc = 0.
        lv_blocage = 'X'.
      ENDIF.

*Gestion des items
      lv_posnr = lv_posnr + 10.
      ls_sales_order_item-posnr = lv_posnr.
      "          CONCATENATE 'D' ls_temp_f12-id_art INTO lv_temp_matnr.

      ls_sales_order_item-matnr = lv_temp_matnr.
      ls_sales_order_item-bstdk = ls_temp_f12-date_effet.

      IF lv_blocage IS NOT INITIAL.
        ls_sales_order_item-bill_block = '09'.
      ENDIF.

      ls_sales_order_item-bstdk_e = ls_temp_f12-date_envoi.
      ls_sales_order_item-ref_1 = lv_num_dossier_affaire.
*STOU DEBUT GE-69
*GLIC DEBUT GE-3570
      IF ( ls_temp_f12-code_recap = 'CREAC'  AND
           ls_temp_f12-id_ev      = 'VEREACF' )
         OR lv_art_turpe IS NOT INITIAL.                    "+GE-8115.
*       ls_sales_order_item-kbetr      = ls_temp_f12-pu.
*       ls_sales_order_item-target_qty = ls_temp_f12-qte.
        ls_sales_order_item-kbetr      = ls_temp_f12-montant.
        ls_sales_order_item-target_qty = '1'.
        IF  lv_art_turpe IS INITIAL.                        "+GE-8115
          ls_sales_order_item-target_qu  = ls_temp_f12-unite_qte.
        ENDIF.
        ls_sales_order_item-bstdk      = ls_temp_f12-date_debut.
        ls_sales_order_item-bstdk_e    = ls_temp_f12-date_fin.
        ls_sales_order_item-bstkd_e    = ls_temp_f12-qte.
        ls_sales_order_item-ref_1      = ls_temp_f12-pu.
      ELSE.
        ls_sales_order_item-kbetr = ls_temp_f12-montant.
      ENDIF.
*GLIC FIN GE-3570
*STOU FIN   GE-69

      ls_sales_order_item-waers = 'EUR'.

      ls_sales_order_item-id_demande_intern = lv_num_dossier_affaire.
      ls_sales_order_item-emetteur = ls_temp_f12-emetteur.
      ls_sales_order_item-idenreg = ls_temp_f12-idenreg.

**Ajout de la gestion des dates :
      IF ls_temp_f12-code_deb_cred EQ 'Y'.
        " Poste des notes de débit
        ls_sales_order_item-kschl = 'ZPRE'.
        APPEND ls_sales_order_item TO lt_debit_note_item.

      ELSEIF ls_temp_f12-code_deb_cred EQ 'Z'.
*++ STOU DEBUT GE-69
        IF ls_temp_f12-code_recap = 'CREAC'  AND
           ls_temp_f12-id_ev = 'VEREACF' .
          IF 1 = 2. MESSAGE e253(zintf_e_messages). ENDIF.
          macro_add_msg_to_log 'E' '253' '' '' '' ''.
          PERFORM update_ligne_f12 USING lc_statut_06_rejet iv_id_flux.
          CONTINUE.
        ENDIF.
*++ STOU FIN   GE-69
        "Poste des notes de crédit
        ls_sales_order_item-kschl = 'ZPRC'.
        APPEND ls_sales_order_item TO lt_credit_note_item.

      ENDIF.



      SELECT SINGLE string1
      INTO lv_art_sd_remise_grd
      FROM ettifn
      WHERE anlage = lv_anlage
      AND operand = 'EUDRPGRD'
      AND ab LE ls_temp_f12-date_effet
      AND bis GE ls_temp_f12-date_effet.
*<<<IBE-06/07/2017-Adaptation B2C
      IF sy-subrc = 0.
        SELECT SINGLE kondm INTO lv_art_sd_remise_grd FROM mvke WHERE matnr = lv_temp_matnr
        AND vkorg = 'GDP2'
        AND vtweg = 'Z1'
        AND kondm = lv_art_sd_remise_grd.
      ENDIF.
*IBE>>>
      IF sy-subrc = 0.
*<<<IBE-10/07/2017-Adaptation Interface Frais éligible au blocage
*  S'il y a la remise à appliquer, on met le statut en rejet l’enregistrement
* (message d'erreur: Remise appliquée sur l'article bloqué à la facturation SD ) sans créer la commande
        IF lv_blocage IS NOT INITIAL.
          IF 1 = 2. MESSAGE e120(zintf_e_messages). ENDIF.

          macro_add_msg_to_log 'E' '120' ls_temp_f12-id_prm '' '' ''.

          PERFORM update_ligne_f12 USING lc_statut_06_rejet iv_id_flux.

          CONTINUE.
        ENDIF.
*IBE>>>
        SELECT SINGLE low
           INTO lv_art_sd_remise_grd
           FROM tvarvc
          WHERE name EQ 'ZINTF_E_ART_SD_REMISE_GRD'.

        SELECT SINGLE wert1
        INTO lv_pourcent_rem_grd
        FROM ettifn
        WHERE anlage = lv_anlage
        AND operand = 'EFCRPGRD'
        AND ab LE ls_temp_f12-date_debut
        AND bis GE ls_temp_f12-date_debut.

        lv_taux_rem = lv_pourcent_rem_grd.

        IF sy-subrc = 0.

          "Gestion des items
          lv_posnr = lv_posnr + 10.
          ls_sales_order_item-posnr = lv_posnr.
          "          CONCATENATE 'D' ls_temp_f12-id_art INTO lv_temp_matnr.
          lv_temp_matnr = lv_art_sd_remise_grd.
          ls_sales_order_item-matnr = lv_temp_matnr.
          ls_sales_order_item-bstdk = ls_temp_f12-date_effet.

          IF lv_blocage IS NOT INITIAL.
            ls_sales_order_item-bill_block = '09'.
          ENDIF.

          ls_sales_order_item-bstdk_e = ls_temp_f12-date_envoi.
          ls_sales_order_item-ref_1 = lv_num_dossier_affaire.

*++ STOU DEBUT GE-69
          IF ( ls_temp_f12-code_recap = 'CREAC'  AND
             ls_temp_f12-id_ev      = 'VEREACF' )
             OR lv_art_turpe IS NOT INITIAL.                "+GE-8115.
*              ls_sales_order_item-kbetr      = ls_temp_f12-pu.
*              ls_sales_order_item-target_qty = ls_temp_f12-qte.
*              ls_sales_order_item-target_qu  = ls_temp_f12-unite_qte.
*              ls_sales_order_item-bstdk      = ls_temp_f12-date_debut.
*              ls_sales_order_item-bstdk_e    = ls_temp_f12-date_fin .
          ELSE.
            ls_sales_order_item-kbetr = ls_temp_f12-montant
                                      *  lv_taux_rem * -1.
          ENDIF.
*++ STOU FIN   GE-69
*            ls_sales_order_item-kbetr = ls_temp_f12-montant   "--GE-69
*                                      *  lv_taux_rem * -1.
          IF  ls_sales_order_item-kschl = 'ZPRE'.
            ls_sales_order_item-kschl = 'ZPRC'.
          ELSEIF  ls_sales_order_item-kschl = 'ZPRC'.
            ls_sales_order_item-kschl = 'ZPRE'.
          ENDIF.
          ls_sales_order_item-waers = 'EUR'.

          ls_sales_order_item-id_demande_intern =
                                 lv_num_dossier_affaire.
          ls_sales_order_item-emetteur = ls_temp_f12-emetteur.
          ls_sales_order_item-idenreg = ls_temp_f12-idenreg.

          APPEND ls_sales_order_item TO lt_credit_note_item.
        ENDIF.

      ENDIF.
    ENDIF. "lv ko is intial
    "MFO  ENDLOOP.

    SORT lt_sales_order_header BY id_demande_intern.
    SORT lt_debit_note_item BY id_demande_intern.

    LOOP AT lt_debit_note_item INTO ls_sales_order_item.
****************************************************
*******Etape n°4 : Création d’une note de débit  *******
****************************************************
      INSERT ls_sales_order_item INTO TABLE lt_debit_note_item_tmp.
      lv_emetteur = ls_sales_order_item-emetteur.
      lv_idenreg  = ls_sales_order_item-idenreg.
      READ TABLE lt_sales_order_header INTO ls_sales_order_header WITH
KEY id_demande_intern = ls_sales_order_item-id_demande_intern.
      AT END OF id_demande_intern.
        IF  ls_sales_order_header IS NOT INITIAL.
          CALL METHOD zcl_tool=>create_sales_order
            EXPORTING
              is_sales_order_header = ls_sales_order_header
              it_sales_order_item   = lt_debit_note_item_tmp
              iv_spart              = lv_sparte
              iv_societe_div        = lv_bukrs
            IMPORTING
              et_return             = lt_return
            RECEIVING
              ev_vbeln              = lv_vbeln.

          IF lv_vbeln IS NOT INITIAL.

            IF 1 = 2.
              MESSAGE i167(zintf_e_messages) WITH
       lv_vbeln
ls_sales_order_item-id_demande_intern INTO lv_message. ENDIF.

              macro_add_msg_to_log 'I' '167' lv_vbeln '' '' ''.

              PERFORM update_ligne_f12 USING lc_statut_07_integre iv_id_flux.



            ELSE.


              READ TABLE lt_return INTO ls_return WITH KEY type = 'E'.
              "f12 : &1 &2 &3 &4

              MESSAGE e158(zintf_e_messages) WITH ls_return-message
                                             INTO lv_message.

              CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
                EXPORTING
                  iv_interface_name = 'F12'
                  iv_sparte         = 'ZE'
                  is_structure      = ls_f12.

              macro_add_msg_to_log 'E' '158' ls_return-message
               '' '' ''.

              PERFORM update_ligne_f12 USING lc_statut_06_rejet iv_id_flux.

              CONTINUE.

            ENDIF.

            CLEAR lt_debit_note_item_tmp.
          ENDIF.
        ENDAT.
      ENDLOOP.
****************************************************
*******Etape n°5 : Création d’une note de crédit*******
****************************************************
      SORT lt_credit_note_item BY id_demande_intern.
      LOOP AT lt_credit_note_item INTO ls_sales_order_item.
        INSERT ls_sales_order_item INTO TABLE lt_credit_note_item_tmp.
        lv_emetteur = ls_sales_order_item-emetteur.
        lv_idenreg  = ls_sales_order_item-idenreg.
        READ TABLE lt_sales_order_header INTO ls_sales_order_header WITH
  KEY id_demande_intern = ls_sales_order_item-id_demande_intern.
        AT END OF id_demande_intern.
          IF  ls_sales_order_header IS NOT INITIAL.
            CALL METHOD zcl_tool=>create_sales_order
              EXPORTING
                is_sales_order_header = ls_sales_order_header
                it_sales_order_item   = lt_credit_note_item_tmp
                iv_spart              = lv_sparte
                iv_societe_div        = lv_bukrs
              IMPORTING
                et_return             = lt_return
              RECEIVING
                ev_vbeln              = lv_vbeln.

            IF lv_vbeln IS NOT INITIAL.
              IF 1 = 2.
                MESSAGE i167(zintf_e_messages) WITH
   lv_vbeln
INTO lv_message. ENDIF.

                macro_add_msg_to_log 'I' '167'  lv_vbeln '' '' ''.

                PERFORM update_ligne_f12 USING lc_statut_07_integre iv_id_flux.



              ELSE.

                READ TABLE lt_return INTO ls_return WITH KEY type = 'E'.
                "f12 : &1 &2 &3 &4

                MESSAGE e158(zintf_e_messages) WITH
                                              ls_return-message INTO lv_message.

                CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
                  EXPORTING
                    iv_interface_name = 'F12'
                    iv_sparte         = 'ZE'
                    is_structure      = ls_f12.

                macro_add_msg_to_log 'E' '158'
                ls_return-message '' '' ''.

                PERFORM update_ligne_f12 USING lc_statut_06_rejet iv_id_flux.

                CONTINUE.

              ENDIF.

              CLEAR lt_credit_note_item_tmp.
            ENDIF.

          ENDAT.
        ENDLOOP.
        IF iv_mode_test IS INITIAL.
          COMMIT WORK AND WAIT.
        ELSE.
          ROLLBACK WORK.
        ENDIF.

      ENDLOOP.

      IF iv_mode_test IS INITIAL.
        COMMIT WORK AND WAIT.
      ELSE.
        ROLLBACK WORK.
      ENDIF.

    ENDFUNCTION.
