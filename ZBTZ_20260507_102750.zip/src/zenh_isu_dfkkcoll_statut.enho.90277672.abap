"Name: \FU:FKK_DB_DFKKCOLL_MODE\SE:BEGIN\EI
ENHANCEMENT 0 ZENH_ISU_DFKKCOLL_STATUT.
*DEB-IBEN-20190212-GE-1538
DATA: lt_abap_stack TYPE  abap_callstack,
      lt_sys_stack  TYPE  sys_callst.

FIELD-SYMBOLS: <ls_dfkkcoll> TYPE dfkkcoll.

  CALL FUNCTION 'SYSTEM_CALLSTACK'
   IMPORTING
     callstack          = lt_abap_stack
     et_callstack       = lt_sys_stack.
*
  READ TABLE lt_abap_stack TRANSPORTING NO FIELDS
    WITH KEY blockname = 'ZFKK_COLL_AGENCY_RELEASE_0350'.
  IF sy-subrc = 0.
    LOOP AT t_fkkcoll ASSIGNING <ls_dfkkcoll>.
      <ls_dfkkcoll>-agsta = '20'.
    ENDLOOP.
  ENDIF.
*FIN-IBEN-20190212-GE-1538
ENDENHANCEMENT.
