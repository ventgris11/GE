*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 16.10.2018 at 16:49:50
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZINTF_E_F03A....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_F03A                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_F03A                  .
CONTROLS: TCTRL_ZINTF_E_F03A
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZINTF_E_F03A                  .
TABLES: ZINTF_E_F03A                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
