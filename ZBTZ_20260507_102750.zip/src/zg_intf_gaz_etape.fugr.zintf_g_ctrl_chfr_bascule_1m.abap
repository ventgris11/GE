FUNCTION zintf_g_ctrl_chfr_bascule_1m.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  TYPES : BEGIN OF ty_maj_crm,
            key   TYPE char40,
            value TYPE text132,
          END OF ty_maj_crm.

  DATA:
    lv_field         TYPE string,
    lv_message       TYPE char255,
    lt_result        TYPE STANDARD TABLE OF efindres,
    ls_findpar       TYPE efindpar,
    lt_eanlh         TYPE TABLE OF eanlh,
    ls_eanlh         TYPE eanlh,
    ls_object        TYPE eedm_isu_objects,
    lv_int_ui        TYPE int_ui,
    lv_anlage        TYPE eanlh-anlage,
    lv_ableinh       TYPE eanlh-ableinh,
    lv_ableinh_month TYPE string,
    lv_day_dtr       TYPE string,
    lv_dtr           TYPE dats,
    lv_ur            TYPE string,
    lv_ur_check      TYPE string,
    lv_type          TYPE char5,
    lv_ryt_pay       TYPE char4,
    lv_success       TYPE crmt_boolean,
    lv_msg           TYPE string,
    lv_annee         TYPE string,
    lv_rfcdest       TYPE rfcdest,
    lr_cl_crm        TYPE REF TO cl_crm_activities_util,
    ls_eanl          TYPE eanl,
    lt_eanlh_i       TYPE TABLE OF eanlh,
    lt_eanlh_d       TYPE TABLE OF eanlh,
    lv_number        TYPE tbtcjob-jobcount,
    lv_name          TYPE tbtcjob-jobname,
    lv_sparte        TYPE sparte,
    lt_maj_crm       TYPE TABLE OF ty_maj_crm,
    ls_maj_crm       TYPE ty_maj_crm,
    lv_date          TYPE dats
    .

  FIELD-SYMBOLS:
    <fs_emetteur>,
    <fs_flux>,
    <fs_num_pce>,
    <fs_date_releve>,
    <fs_date_debut_periode>,
    <ls_result> TYPE efindres.

  CONSTANTS :
  lc_instln TYPE swo_objtyp VALUE 'INSTLN'.

  DEFINE macro_add_message_to_log.
    ev_etape = 2.
    MESSAGE &1(zintf_g_messages)
       WITH &2
            &3
            &4
            &5
       INTO lv_message.
    RETURN.
  END-OF-DEFINITION.


  CLEAR: lv_field.
  MOVE 'FLUX-EMETTEUR'                    TO lv_field.
  ASSIGN (lv_field)                       TO <fs_emetteur>.

  CLEAR: lv_field.
  MOVE 'FLUX-FLUX'                        TO lv_field.
  ASSIGN (lv_field)                       TO <fs_flux>.

  CLEAR: lv_field.
  MOVE 'FLUX-NUM_PCE'                     TO lv_field.
  ASSIGN (lv_field)                       TO <fs_num_pce>.

  CLEAR: lv_field.
  MOVE 'FLUX-DATE_RELEVE'                 TO lv_field.
  ASSIGN (lv_field)                       TO <fs_date_releve>.

  CLEAR: lv_field.
  MOVE 'FLUX-DEBUT_PERIODE'              TO lv_field.
  ASSIGN (lv_field)                      TO <fs_date_debut_periode>.


  " Récupération type client B2B/B2C
  CALL METHOD zcl_tool=>is_b2b_or_b2c
    EXPORTING
      iv_ext_ui = <fs_num_pce>
      iv_date   = <fs_date_releve>
    RECEIVING
      rv_type   = lv_type.

  "Récupération destination pour appel MF CRM
  lv_rfcdest = zcl_tool=>get_rfc_for_crm( ).


  " Récupération du secteur d'activité du POD
  CALL FUNCTION 'ISU_INT_UI_DETERMINE'
    EXPORTING
      x_ext_pod         = <fs_num_pce>
      x_keydate         = <fs_date_debut_periode>
    IMPORTING
      y_sparte          = lv_sparte
    EXCEPTIONS
      not_found         = 1
      programming_error = 2
      system_error      = 3
      OTHERS            = 4.

  " Déterminer le N° d'installation
  CLEAR:
    ls_findpar,
    lt_result.

  ls_findpar-i_pod  = <fs_num_pce>.
  ls_findpar-d_date = <fs_date_releve>.

  CALL FUNCTION 'ISU_FINDER'
    EXPORTING
      x_objtype                   = lc_instln
      x_findpar                   = ls_findpar
    TABLES
      yt_result                   = lt_result
    EXCEPTIONS
      insufficient_selection      = 1
      objtype_not_supported       = 2
      additional_selection_needed = 3.
  IF sy-subrc = 0.
    " Récupérer l'installation (objet INSTLN)
    READ TABLE lt_result WITH KEY objtype = lc_instln ASSIGNING <ls_result>.
    IF <ls_result> IS ASSIGNED.
      lv_anlage = <ls_result>-objkey.
      UNASSIGN <ls_result>.
    ENDIF.
  ELSE.
    RETURN.
  ENDIF.
  " Vérification de l'UR posée sur le PCE à la date de relève
  IF lv_anlage IS NOT INITIAL.
    SELECT *
      FROM eanlh
      INTO TABLE lt_eanlh
      WHERE anlage EQ lv_anlage.
    IF sy-subrc EQ 0.
      SORT lt_eanlh BY bis DESCENDING.
      READ TABLE lt_eanlh INTO ls_eanlh INDEX 1.
      IF <fs_flux> = 'RE1M' AND ( ls_eanlh-ableinh CS '6M' OR ls_eanlh-ableinh CS 'M6' ).
        lv_ryt_pay = ls_eanlh-ableinh+4(1).
        lv_ableinh_month = ls_eanlh-ableinh(2).
        lv_day_dtr = <fs_date_releve>+6(2).
        lv_annee = <fs_date_releve>(4).
        CONCATENATE lv_annee lv_ableinh_month lv_day_dtr INTO lv_dtr.
*DEB-FPE-GE-7294 "Vérification cohérence dtr
        CONCATENATE lv_annee lv_ableinh_month '01' INTO lv_date.
        CALL FUNCTION 'OIL_LAST_DAY_OF_MONTH'
          EXPORTING
            i_date     = lv_date
          IMPORTING
            e_last_day = lv_date.
        IF lv_dtr GT lv_date.
          lv_dtr = lv_date.
        ENDIF.
*FIN-FPE-GE-7294

        "alimentation tables internes pour MAJ eanlh
        CLEAR ls_eanl.
        SELECT SINGLE *
          FROM eanl
          INTO ls_eanl
          WHERE anlage = lv_anlage.

        CLEAR ls_eanlh.
        SELECT *
          FROM eanlh
          INTO TABLE lt_eanlh_i
          WHERE anlage EQ lv_anlage.
        IF sy-subrc = 0.
*DEB-FPE-GE-7295 - Update dernière tranche UR si DDAP UR > DDAP FLUX
          SORT lt_eanlh_i BY bis DESCENDING.
          READ TABLE lt_eanlh_i INTO ls_eanlh INDEX 1.
          IF ls_eanlh-ab GT <fs_date_debut_periode>.
            "on prépare l'update dans le cas ou date de début UR post date début flux
            CLEAR lt_eanlh_i.
*FIN-FPE-GE-7295
          ELSE.
            CLEAR ls_eanlh.
            SORT lt_eanlh_i BY ab DESCENDING.
            LOOP AT lt_eanlh_i INTO ls_eanlh
              WHERE ab LE <fs_date_releve>
              AND bis GE <fs_date_releve>.
              EXIT.
            ENDLOOP.
            IF sy-subrc = 0.
              REFRESH lt_eanlh_i.

              APPEND ls_eanlh TO lt_eanlh_d.

              DATA(lv_date_bis) = ls_eanlh-bis.
              ls_eanlh-bis = <fs_date_releve> - 1.
              APPEND ls_eanlh TO lt_eanlh_i.

              ls_eanlh-bis = lv_date_bis.
              ls_eanlh-ab = <fs_date_releve>.
            ENDIF.
          ENDIF.
        ENDIF.
        " Détermination de la nouvelle valeur de l'UR selon le type
        IF lv_type = 'B2B'.
          "Appel Méthode pour détermination de la nouvelle UR
          CALL METHOD zcl_tool=>get_ur_from_crm
            EXPORTING
              iv_energie         = lv_sparte
              iv_segment         = lv_type
              iv_type_pce        = '1M'
              iv_rythme_paiement = lv_ryt_pay
              iv_dtr             = lv_dtr
            RECEIVING
              rv_ur              = lv_ur.
          IF sy-subrc EQ 0.
*DEB-FPE-GE-7304
*            vérification existence UR en base
            SELECT SINGLE termschl
              INTO lv_ur_check
              FROM te422
              WHERE termschl = lv_ur.
            IF lv_ur_check IS INITIAL.
              IF 1 = 2. MESSAGE e505(zintf_g_messages). ENDIF.
              macro_add_message_to_log e505 <fs_flux> <fs_num_pce> lv_ur lv_dtr.
            ENDIF.
*FIN-FPE-GE-7304
            ls_eanlh-ableinh = lv_ur.
            APPEND ls_eanlh TO lt_eanlh_i.
            ls_maj_crm-key = 'ZZ0011A0_'. "dtr
            ls_maj_crm-value = lv_dtr.
            APPEND ls_maj_crm TO lt_maj_crm.
            CLEAR ls_maj_crm.
            ls_maj_crm-key = 'PD_UITYPE'. "rythme relève
            ls_maj_crm-value = '0006'.    "0006 pour PCE 1M
            APPEND ls_maj_crm TO lt_maj_crm.
            "Appel MF CRM pour MAJ données PCE
            CALL FUNCTION 'ZREPL_TECHOBJ_UPDATE_V2' DESTINATION lv_rfcdest
              EXPORTING
                iv_ext_ui     = <fs_num_pce>
                it_parameters = lt_maj_crm
              IMPORTING
                ev_success    = lv_success
                ev_message    = lv_msg.
            IF lv_success = abap_false.
              "Erreur MAJ CRM
              RETURN.
            ELSE.
              "aucune erreur après appels MF donc MAJ eanlh.
              IF lt_eanlh_d IS NOT INITIAL.
                CALL FUNCTION 'ISU_DB_EANL_UPDATE'
                  EXPORTING
                    x_eanl          = ls_eanl
                    x_eanl_old      = ls_eanl
                    x_upd_mode      = 'U'
                  TABLES
                    xt_eanlh_insert = lt_eanlh_i
                    xt_eanlh_delete = lt_eanlh_d.
              ELSE.
                CALL FUNCTION 'ISU_DB_EANL_UPDATE'
                  EXPORTING
                    x_eanl          = ls_eanl
                    x_eanl_old      = ls_eanl
                    x_upd_mode      = 'U'
                  TABLES
                    xt_eanlh_update = lt_eanlh_i.
              ENDIF.
            ENDIF.
          ELSE.
            ev_etape = 2.
          ENDIF.
        ELSEIF lv_type = 'B2C'.
          "Appel méthode pour détermination de la nouvelle UR
          CALL METHOD zcl_tool=>get_ur_from_crm
            EXPORTING
              iv_energie         = lv_sparte
              iv_segment         = lv_type
              iv_type_pce        = '1M'
              iv_rythme_paiement = lv_ryt_pay
              iv_dtr             = lv_dtr
            RECEIVING
              rv_ur              = lv_ur.
          IF sy-subrc EQ 0.
*DEB-FPE-GE-7304
            "vérification existence UR en base
            SELECT SINGLE termschl
              INTO lv_ur_check
              FROM te422
              WHERE termschl = lv_ur.
            IF lv_ur_check IS INITIAL.
              IF 1 = 2. MESSAGE e505(zintf_g_messages). ENDIF.
              macro_add_message_to_log e505 <fs_flux> <fs_num_pce> lv_ur lv_dtr.
            ENDIF.
*FIN-FPE-GE-7304
            ls_eanlh-ableinh = lv_ur.
            APPEND ls_eanlh TO lt_eanlh_i.
            ls_maj_crm-key = 'ZZ0011A0_'. "dtr
            ls_maj_crm-value = lv_dtr.
            APPEND ls_maj_crm TO lt_maj_crm.
            CLEAR ls_maj_crm.
            ls_maj_crm-key = 'PD_UITYPE'. "rythme relève
            ls_maj_crm-value = '0006'.    "0006 pour PCE 1M
            APPEND ls_maj_crm TO lt_maj_crm.
            "Appel MF CRM pour MAJ données PCE
            CALL FUNCTION 'ZREPL_TECHOBJ_UPDATE_V2' DESTINATION lv_rfcdest
              EXPORTING
                iv_ext_ui     = <fs_num_pce>
                it_parameters = lt_maj_crm
              IMPORTING
                ev_success    = lv_success
                ev_message    = lv_msg.
            IF lv_success = abap_false.
              "Erreur MAJ CRM
              RETURN.
            ELSE.
              "aucune erreur après appels MF donc MAJ eanlh.
              IF lt_eanlh_d IS NOT INITIAL.
                CALL FUNCTION 'ISU_DB_EANL_UPDATE'
                  EXPORTING
                    x_eanl          = ls_eanl
                    x_eanl_old      = ls_eanl
                    x_upd_mode      = 'U'
                  TABLES
                    xt_eanlh_insert = lt_eanlh_i
                    xt_eanlh_delete = lt_eanlh_d.
              ELSE.
                CALL FUNCTION 'ISU_DB_EANL_UPDATE'
                  EXPORTING
                    x_eanl          = ls_eanl
                    x_eanl_old      = ls_eanl
                    x_upd_mode      = 'U'
                  TABLES
                    xt_eanlh_update = lt_eanlh_i.
              ENDIF.
            ENDIF.
          ELSE.
            ev_etape = 2.
          ENDIF.
          ev_etape = 1.
        ENDIF.
      ENDIF.
    ELSE.
      IF 1 = 2. MESSAGE e502(zintf_g_messages). ENDIF.
      macro_add_message_to_log e502 <fs_date_releve> '' '' ''.
    ENDIF.
  ENDIF.

ENDFUNCTION.
