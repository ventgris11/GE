*----------------------------------------------------------------------*
*   INCLUDE LFKPZFC0                                                   *
*----------------------------------------------------------------------*

*---------------------------------------------------------------------*
*       FORM CHECK_BANK_COMBINATION                                   *
*---------------------------------------------------------------------*
FORM CHECK_BANK_COMBINATION.
  CLEAR: H_NUM04.

* no optimization possible if analysis for house bank not required
  IF IMPORT-CHKHB IS INITIAL.
    CLEAR:
      TFK042E-XOPTP,
      TFK042E-XOPTB.
  ENDIF.

* optimize according to postal code.
  IF NOT TFK042E-XOPTP IS INITIAL.
    IF NOT BUS000_EXT-POST_CODE3 IS INITIAL.
      H_PSTLZ = BUS000_EXT-POST_CODE3.
    ELSEIF NOT BUS000_EXT-POST_CODE2 IS INITIAL.
      H_PSTLZ = BUS000_EXT-POST_CODE2.
    ELSE.
      H_PSTLZ = BUS000_EXT-POST_CODE1.
    ENDIF.
    SELECT * FROM T042P WHERE BUKRS EQ IMPORT-OPBUK
                        AND   LAND1 EQ BUS000_EXT-COUNTRY
                        AND   PSTLB GE H_PSTLZ
                        AND   PSTLV LE H_PSTLZ.
      EXIT.
    ENDSELECT.
    IF SY-SUBRC EQ 0 AND NOT T042P-HBKID IS INITIAL.
      READ TABLE T_HBANK WITH KEY HBKID = T042P-HBKID.
      IF SY-SUBRC EQ 0.
        H_NUM04 = SY-TABIX.
        READ TABLE T_PBANK INDEX 1.
        EXIT.
      ELSE.
        MSGV1 = BUS000_EXT-COUNTRY.
        MSGV2 = H_PSTLZ.
        MSGV3 = T042P-HBKID.
        PERFORM MESSAGE USING 043.     "optimal bank not possible
      ENDIF.
    ENDIF.
  ENDIF.

* optimize according to bank group
" Note 2029081: XBKKT/XPGIR must not influence HOUSE bank optimization
*  IF NOT ( FKK042Z-XBKKT IS INITIAL AND
*           FKK042Z-XPGIR IS INITIAL ) AND
*     NOT   TFK042E-XOPTB IS INITIAL.
    IF NOT TFK042E-XOPTB IS INITIAL.    SUBRC = 4.
    LOOP AT T_PBANK WHERE BGRUP NE SPACE.
    ENDLOOP.
    IF SY-SUBRC NE 0.
      PERFORM MESSAGE USING 044.       "no partner bank with group found
    ELSE.
      LOOP AT T_HBANK WHERE BGRUP NE SPACE.
        H_INDEX = SY-TABIX.
        READ TABLE T_PBANK WITH KEY BGRUP = T_HBANK-BGRUP.
        IF SY-SUBRC EQ 0.
          H_NUM04 = H_INDEX.
          SUBRC = 0.
          EXIT.
        ELSE.
          MSGV1 = T_HBANK-BGRUP.
          MSGV2 = T_HBANK-HBKID.
          PERFORM MESSAGE USING 045.   "group of house bank not found
        ENDIF.
      ENDLOOP.
      IF SY-SUBRC NE 0.
        PERFORM MESSAGE USING 046.     "no house bank with group found
      ENDIF.
    ENDIF.
    IF SUBRC EQ 0.
      EXIT.
    ELSE.
      PERFORM MESSAGE USING 047.       "optimization not possible
    ENDIF.
  ENDIF.

* no optimization necessary/possible
  READ TABLE T_PBANK INDEX 1.
  READ TABLE T_HBANK INDEX 1.
  H_NUM04 = '0001'.

* event 650: some other optimization wanted?
* PERFORM EXIT_0650.
ENDFORM.                    "CHECK_BANK_COMBINATION


*---------------------------------------------------------------------*
*       FORM CHECK_HOUSE_BANK                                         *
*---------------------------------------------------------------------*
FORM CHECK_HOUSE_BANK USING P_SUBRC LIKE SY-SUBRC.
  DATA: H_TABIX LIKE SY-TABIX.
  P_SUBRC = 4.
  H_TABIX = 1.

* add data from bank master record
  IF NOT IMPORT-CHKHB IS INITIAL.
    PERFORM READ_HOUSE_BANK.
* no house bank found?
    DESCRIBE TABLE T_HBANK LINES TFILL.
    IF TFILL EQ 0.
      MSGV1 = TFK042E-ZLSCH.
      MSGV2 = IMPORT-WAERS.
      MSGV3 = TFK042E-OPBUK.
      PERFORM MESSAGE USING 041.       "no house bank found
      EXIT.
    ENDIF.

* check specified house bank if any (t_hbank is filled with all!)
    IF  (    TFK042E-XEIBV        NE SPACE
          OR IMPORT-SRT1-PDKEY    CN ' 0' )
    AND IMPORT-EIGBV  NE SPACE.
      CALL FUNCTION 'FKK_EIGBV_CHECK'
        EXPORTING
          I_BUKRS      = IMPORT-OPBUK
          I_EIGBV      = IMPORT-EIGBV
        IMPORTING
          E_TFK042H    = TFK042H
        EXCEPTIONS
          NOT_EXISTING = 1
          OTHERS       = 2.
      IF SY-SUBRC = 0.
        CLEAR: H_TABIX.
        LOOP AT T_HBANK.
          IF    TFK042H-HBKID = T_HBANK-HBKID
          AND (    TFK042H-HKTID = T_HBANK-HKTID
                OR TFK042H-HKTID = SPACE ).
            H_TABIX = SY-TABIX.
            EXIT.
          ENDIF.
        ENDLOOP.
        IF H_TABIX IS INITIAL.
          MSGV1 = IMPORT-OPBUK.
          MSGV2 = IMPORT-EIGBV.
          MSGV3 = BUS000_EXT-PARTNER.
          PERFORM MESSAGE USING 064.     "eigbv not fitting
          EXIT.
        ELSE.
          READ TABLE T_HBANK INDEX H_TABIX.
        ENDIF.
      ELSE.
        MSGV1 = IMPORT-OPBUK.
        MSGV2 = IMPORT-EIGBV.
        MSGV3 = BUS000_EXT-PARTNER.
        PERFORM MESSAGE USING 063.       "no eigbv data found
        EXIT.
      ENDIF.
    ELSE.
      READ TABLE T_HBANK INDEX H_TABIX.      "default: take first
    ENDIF.
  ELSE.
    CLEAR: T_HBANK[], T_HBANK.
  ENDIF.

* house banks found
  P_SUBRC = 0.
ENDFORM.                    "CHECK_HOUSE_BANK

*---------------------------------------------------------------------*
*       FORM CHECK_PARTNER_BANK                                       *
*---------------------------------------------------------------------*
FORM CHECK_PARTNER_BANK USING P_SUBRC LIKE SY-SUBRC.
  DATA: L_TEST(1) TYPE C.
  DATA: L_MSGNO(2) TYPE C.
  DATA: L_STORB TYPE STORB_KK.
  DATA: L_OPBEL TYPE OPBEL_KK.
  DATA: L_EXTKEY TYPE SEPA_STR_MANDATE_KEY_EXTERNAL.
  DATA: L_INTKEY TYPE SEPA_STR_MANDATE_KEY.
  DATA: L_CRIT TYPE SEPA_GET_CRITERIA_MANDATE.
  DATA: LT_MANTAB TYPE SEPA_TAB_DATA_MANDATE_DATA.
  DATA: LS_MANTAB TYPE SEPA_STR_DATA_MANDATE_DATA.
  DATA: L_NOT_VALID TYPE BOOLEAN.
  DATA: L_STATUS TYPE SEPA_STATUS.
  DATA: L_TABIX TYPE SY-TABIX.
  DATA: L_SEPA_PMS TYPE FKK_SEPA_PMS.
  DATA: L_TABIXP TYPE SY-TABIX.
  DATA: L_MSGTY LIKE T100C-MSGTS.
  DATA: L_SKIP_ALL TYPE BOOLEAN.
  DATA: L_CHOSEN TYPE SEPA_STR_DATA_MANDATE_DATA.
  DATA: H_TABIX LIKE SY-TABIX.
  DATA: LT_OPEN     TYPE SEPA_TAB_MANDATE_KEY_EXTERNAL,
        LS_OPEN     TYPE SEPA_STR_MANDATE_KEY_EXTERNAL,
        LT_MESSAGES TYPE BAPIRET1_LIST,
        LS_MESSAGE  TYPE BAPIRET1,
        LS_FIMSG    TYPE FIMSG.
  DATA: LT_MESSA TYPE TABLE OF MESSA_KK,
        LS_MESSA TYPE          MESSA_KK,
        L_FIMSG  TYPE          FIMSG.
  DATA: L_ITEMS_GP           TYPE GPART_KK,      "unique GPART from items
*       L_SND_DIR_ID         TYPE XFELD,         "obsolete 5007922
        L_ONE_MANDATE_LOCKED TYPE XFELD.         "Note 1981984

* TODO L_IBAN??
  DATA: L_IBAN TYPE IBAN.
  P_SUBRC = 4.

* check of partner's banks necessary?
  IF FKK042Z-XBKKT IS INITIAL AND FKK042Z-XPGIR IS INITIAL
    AND FKK042Z-XIBAN IS INITIAL.       " Note 1767584
    CLEAR T_PBANK.
    REFRESH T_PBANK.
    P_SUBRC = 0.
    EXIT.
  ENDIF.

* read partner's banks
  PERFORM READ_PARTNER_BANK.
  IF SY-SUBRC NE 0.
    PERFORM MESSAGE USING 038.         "no partner's bank found
    EXIT.
  ENDIF.
  CLEAR: T_PBANK-SEPA_PMS.
  MODIFY T_PBANK TRANSPORTING SEPA_PMS WHERE SEPA_PMS-MGUID NE SPACE.

* check postal giro
  IF NOT FKK042Z-XPGIR IS INITIAL.
* ...CH/EZAG: payment method with XGPIR=X, accept bank with
* ...BNKA-XGPIR = SPACE and BNKA-PSKTO NE SPACE.
    IF T005-LANDK = 'CH'
    OR T005-INTCA = 'CH'.
      DELETE T_PBANK WHERE XPGRO EQ SPACE
                     AND   PSKTO EQ SPACE.
    ELSE.
      DELETE T_PBANK WHERE XPGRO EQ SPACE.
    ENDIF.

* ...new check, see note 1288693
    LOOP AT T_PBANK.
      H_TABIX = SY-TABIX.
      IF T_PBANK-PSKTO NE SPACE AND
         T_PBANK-XPGRO NE SPACE.
        CALL FUNCTION 'POSTAL_GIRO_ACCOUNT_CHECK'
          EXPORTING
            BANK_COUNTRY        = T005-LANDK
            POSTAL_GIRO_ACCOUNT = T_PBANK-BANKN
          EXCEPTIONS
            NOT_VALID           = 4.
        IF SY-SUBRC <> 0.
          DELETE T_PBANK INDEX H_TABIX.
          PERFORM MESSAGE USING 094. "PostalGiro enthält unzulässige Zeichen
        ENDIF.
      ENDIF.
    ENDLOOP.
    DESCRIBE TABLE T_PBANK LINES TFILL.
    IF TFILL EQ 0.
      PERFORM MESSAGE USING 039.       "partner's bank not postal giro
      EXIT.
    ENDIF.
  ENDIF.

* only local banks allowed?
  IF TFK042E-XAUSB IS INITIAL.
    DELETE T_PBANK WHERE BANKS NE T001-LAND1.
    DESCRIBE TABLE T_PBANK LINES TFILL.
    IF TFILL EQ 0.
      PERFORM MESSAGE USING 040.       "partner's bank not local
      EXIT.
    ENDIF.
  ENDIF.

* check allowed partner bank country (TFK042L)
  DATA:
    L_TFK042L TYPE TFK042L.
  STATICS:
    SV_QREAD   TYPE C,
    ST_TFK042L LIKE TABLE OF TFK042L.
  IF SV_QREAD IS INITIAL.
    SELECT * FROM TFK042L INTO TABLE ST_TFK042L.        "#EC CI_GENBUFF
    SV_QREAD = 'X'.
  ENDIF.
* ...something defined for country/payment method?
  READ TABLE ST_TFK042L INTO L_TFK042L
       WITH KEY LAND1 = FKK042Z-LAND1
                ZLSCH = FKK042Z-ZLSCH.
* ...yes: then partner bank country has to be listed explicitly
  IF SY-SUBRC = 0.
    LOOP AT T_PBANK.
      H_TABIX = SY-TABIX.
      READ TABLE ST_TFK042L INTO L_TFK042L
           WITH KEY LAND1 = FKK042Z-LAND1
                    ZLSCH = FKK042Z-ZLSCH
                    BANKS = T_PBANK-BANKS.
      IF SY-SUBRC NE 0.
        DELETE T_PBANK INDEX H_TABIX.
      ENDIF.
    ENDLOOP.
    DESCRIBE TABLE T_PBANK LINES TFILL.
    IF TFILL EQ 0.
      MSGV1 = FKK042Z-ZLSCH.
      MSGV2 = FKK042Z-LAND1.
      MSGV3 = T_PBANK-BANKS.
      PERFORM MESSAGE USING 282.  "no partner bank in country allowed in TFK042QL
      EXIT.
    ENDIF.
  ENDIF.

* IBAN is necessary and missing? (S=SWIFT,X=IBAN,Y=SWIFT+IBAN)
  IF FKK042Z-XIBAN CA 'XY'.
    DELETE T_PBANK WHERE TMPIBAN EQ SPACE.
    DESCRIBE TABLE T_PBANK LINES TFILL.
    IF TFILL EQ 0.
      PERFORM MESSAGE USING 066.       "no partner bank with IBAN
      EXIT.
    ENDIF.
  ENDIF.

* SWIFT-Code is necessary and missing?
  IF FKK042Z-XIBAN CA 'SY'.
    DELETE T_PBANK WHERE BNKA-SWIFT EQ SPACE.
    DESCRIBE TABLE T_PBANK LINES TFILL.
    IF TFILL EQ 0.
      PERFORM MESSAGE USING 093.       "no partner bank with SWIFT-Code
      EXIT.
    ENDIF.
  ENDIF.

* SEPA mandate is necessary and missing?
  IF FKK042Z-XSEPA NE SPACE.
    LOOP AT T_PBANK WHERE IBAN NE SPACE.
      L_TABIXP = SY-TABIX.
      CLEAR: L_SEPA_PMS.

* ...get all mandates for GPART / IBAN / FI-CA
      L_CRIT-ANWND     = '1'.
      L_CRIT-SND_IBAN  = T_PBANK-IBAN.
* ...if GPART was entered in FKKVKP-ABWRE this one pays and should have the mandate
*     L_CRIT-SND_ID    = IMPORT-SRT1-GPART.
      L_CRIT-SND_TYPE  = 'BUS1006'.
      L_CRIT-SND_ID    = BUS000_EXT-PARTNER.

*     L_CRIT-REC_ID    = IMPORT-OPBUK.
* (REC_CRDID may come from TFK042B or may come using event 0571!)
*     L_CRIT-REC_CRDID = IMPORT-42B-REC_CRDID.
      CALL FUNCTION 'SEPA_MANDATES_API_GET'
        EXPORTING
          I_SEL_CRITERIA = L_CRIT
        IMPORTING
          ET_MANDATES    = LT_MANTAB.
*     DELETE LT_MANTAB WHERE SND_ID NE IMPORT-SRT1-GPART.
      DELETE LT_MANTAB WHERE REC_ID NE IMPORT-OPBUK.

* ...if mandate was specified from caller, delete all others
      IF NOT IMPORT-MNDID IS INITIAL.
        DELETE LT_MANTAB WHERE MNDID NE IMPORT-MNDID.
      ENDIF.

* ...prepare SND_DIR_ID with leading zeroes (for comparison with L_ITEMS_GP later on)
      LOOP AT LT_MANTAB INTO LS_MANTAB WHERE SND_DIR_ID NE SPACE.
        PERFORM ALPHAFORMAT(SAPFS000) USING LS_MANTAB-SND_DIR_ID L_ITEMS_GP.
        LS_MANTAB-SND_DIR_ID = L_ITEMS_GP.
        MODIFY LT_MANTAB FROM LS_MANTAB.
      ENDLOOP.

* ...check every mandate if it is usuable (activ, not locked)
      IF LINES( LT_MANTAB ) > 0.

* ...determine unique GPART from items to be cleared
        CLEAR: L_ITEMS_GP.
        LOOP AT T_0650IT.
          IF L_ITEMS_GP IS INITIAL.
            L_ITEMS_GP = T_0650IT-GPART.
          ELSE.
            IF L_ITEMS_GP NE T_0650IT-GPART.
              CLEAR: L_ITEMS_GP.
              EXIT.
            ENDIF.
          ENDIF.
        ENDLOOP.

* ...if we have a unique GPART, do we have usable mandates specified for this GPART
* (SND_DIR_ID = unique-GPART)? If yes, only these should be considered
* Changed with note 1895616 ("usable" mandates only)
* Removed with note 5007922. It can be the case that a mandate with SND_DIR_ID is
* being sorted out in event 653, because it refers to a different contract account.
* If there is a valid mandate w/o SND_DIR_ID, it would not be used at all. The
* prioritization of mandates with filled REF_TYPE is guaranteed in FKK_SAMPLE_0653.
*        IF L_ITEMS_GP NE SPACE.
*          LOOP AT LT_MANTAB INTO LS_MANTAB WHERE SND_DIR_ID = L_ITEMS_GP.
*            IF LS_MANTAB-STATUS = '1' "active
*            AND ( LS_MANTAB-VAL_FROM_DATE IS INITIAL
*               OR ( LS_MANTAB-VAL_FROM_DATE LE SY-DATLO AND LS_MANTAB-VAL_TO_DATE GE SY-DATLO ) ).
*              L_SND_DIR_ID = 'X'.
*              EXIT.
*            ENDIF.
*          ENDLOOP.
*        ENDIF.


* ...now check each mandate
        LOOP AT LT_MANTAB INTO LS_MANTAB.
          L_TABIX = SY-TABIX.
          CLEAR: L_NOT_VALID.
          L_INTKEY-MGUID = LS_MANTAB-MGUID.

* ...validity should be execution day, not today (note 1881111)
          DATA: L_STARTS_IN  TYPE I,
                L_ENDS_IN    TYPE I,
                L_CHECK_DATE TYPE DATUM.
          L_STARTS_IN = 9999.
          L_ENDS_IN   = 9999.
          IF LS_MANTAB-VAL_FROM_DATE > SY-DATLO.
            L_STARTS_IN = LS_MANTAB-VAL_FROM_DATE - SY-DATLO.  "validity starts in L_STARTS_IN days
          ENDIF.
          IF LS_MANTAB-VAL_TO_DATE >= SY-DATLO.                " Note 2022445
            L_ENDS_IN = LS_MANTAB-VAL_TO_DATE - SY-DATLO.      "validity ends in L_ENDS_IN days
          ENDIF.
* ...do this check only if validity ending in / starting in next 14 days (performance)
          IF L_STARTS_IN < 20                                  "should cover all calendar abnormalities
          OR L_ENDS_IN   < 20.                                 "should also work for prenotifications!

* determine (latest) due date of items, because checkdate can not be BEFORE due date of items
            DATA: L_MAX_FAEDT TYPE FAEDN_KK.
            DATA: L_FAEDT TYPE FAEDN_KK.
            LOOP AT T_0650IT.
              CALL FUNCTION 'FKK_DUE_DATE_DETERMINE'
                EXPORTING
                  I_BUDAT = IMPORT-BUDAT
                  I_FAEDS = T_0650IT-FAEDS
                  I_FAEDN = T_0650IT-FAEDN
                  I_STUDT = T_0650IT-STUDT
                IMPORTING
                  E_FAEDT = L_FAEDT.
              IF L_FAEDT > L_MAX_FAEDT.
                L_MAX_FAEDT = L_FAEDT.
              ENDIF.
            ENDLOOP.

* partner bank was sent in T_PBANK (contains only 1 entry!)
* house bank was determined in FORM CHECK_HOUSEBANK (needs to be called BEFORE CHECK_PARTNERBANK therefore)
            DATA: LS_PARTNERBANK TYPE BUS0BK.
            MOVE-CORRESPONDING T_PBANK TO LS_PARTNERBANK.
* call new function module to determine checkdate for mandate validity
* ...depending on mandate (FRST/RCUR/CORE/COR1/B2B including calendar options)
* ...depending on item due date
            CALL FUNCTION 'FKK_SEPA_CALC_EARLIEST_DAY'
              EXPORTING
                I_MANDAT      = LS_MANTAB
                I_PYBUK       = IMPORT-OPBUK
                I_HOUSEBANK   = T_HBANK-T012
                I_PARTNERBANK = LS_PARTNERBANK
*               I_0661        = IMPORT-0661
                I_FAEDT       = L_MAX_FAEDT
                I_BASICS      = MAD_BASICS
              IMPORTING
*               E_EARLIEST    = L_EARLIEST
                E_CHECKDATE   = L_CHECK_DATE
*               E_INST_CODE   =
*               E_SEQ_TYPE    =
                E_FIMSG       = LS_FIMSG.
            IF LS_FIMSG IS NOT INITIAL.
              MSGID = SY-MSGID.
              MSGV1 = SY-MSGV1.
              MSGV2 = SY-MSGV2.
              MSGV3 = SY-MSGV3.
              MSGV4 = SY-MSGV4.
              PERFORM MESSAGE USING SY-MSGNO.
              DELETE LT_MANTAB INDEX L_TABIX.
              CONTINUE. "try next mandate
            ENDIF.
*            PERFORM SEPA_CALC_EARLIEST_DAY(SAPLFKPMASS)
*              USING    LS_MANTAB
*                       T_HBANK-T012
*              CHANGING L_CHECK_DATE.
          ELSE.
            L_CHECK_DATE = SY-DATLO.
          ENDIF.

* ...>2 289: mandate &1 is being checked
          MSGV1 = LS_MANTAB-MNDID.
          PERFORM MESSAGE USING 289.
          CALL FUNCTION 'SEPA_MANDATE_API_CHECK_VALID'
            EXPORTING
              I_ANWND             = '1'
              I_STR_MANDATE_KEY   = L_INTKEY
* (depending on mandate type, the date should be + 2 / + 5 days...)
*             I_DATE              = SY-DATLO
              I_DATE              = L_CHECK_DATE        "note 1881111
            IMPORTING
              ET_MESSAGES         = LT_MESSAGES
*        IF NOT LT_MESSAGES IS INITIAL.
*          READ TABLE LT_MESSAGES INTO LS_MESSAGE INDEX 1.
              E_MANDATE_NOT_VALID = L_NOT_VALID
              E_MANDATE_STATUS    = L_STATUS
            EXCEPTIONS
              GLOBAL_LOCK_ACTIVE  = 4.

* special treatment for one-time-mandate, used, but reopened / returned.
* LASTUSE-fields remain filled, status switches from 6 to 1 again and mandate
* should be usable again => ignore the NOT_VALID here
*          IF  L_NOT_VALID             NE SPACE   "formally not valid (API returns that)
*          AND LS_MANTAB-LASTUSE_DOCID NE SPACE   "formerly used
*          AND LS_MANTAB-PAY_TYPE      EQ '1'     "one-time-mandate
*          AND LS_MANTAB-STATUS        EQ '1'.    "mandate active (FKK_SEPA_RESETS resettet status!)
*            L_TEST = 'A'.
*            LOOP AT LT_MESSAGES INTO LS_MESSAGE.
*              IF LS_MESSAGE-TYPE = 'E'.
*                IF LS_MESSAGE-NUMBER = '057'.
*                  L_TEST = 'B'.
*                ELSE.
*                  L_TEST = 'C'.
*                  EXIT.
*                ENDIF.
*              ENDIF.
*            ENDLOOP.
*
** ...error 257 is the only error message in LT_MESSAGES
*            IF L_TEST = 'B'.
*              L_OPBEL = LS_MANTAB-LASTUSE_DOCID.
*              SELECT SINGLE STORB INTO L_STORB FROM DFKKKO WHERE OPBEL = L_OPBEL.
*              IF  SY-SUBRC    EQ 0
*              AND NOT L_STORB IS INITIAL.
*                CLEAR: L_NOT_VALID.              "take it as valid (will this work...?)
*              ENDIF.
*            ENDIF.
*          ENDIF.

          IF  SY-SUBRC    EQ 0
          AND L_NOT_VALID EQ SPACE
          AND L_STATUS    EQ '1'.

* do we have a unique business partner in the items?
            IF L_ITEMS_GP IS INITIAL.
* ...no
* ......mandate without SND_DIR_ID can be used always
              IF LS_MANTAB-SND_DIR_ID IS INITIAL.
                MSGV1 = LS_MANTAB-MNDID.
                PERFORM MESSAGE USING 293.
* ......mandate with SND_DIR_ID can be used if SND_DIR_ID appears in items
              ELSE.
                READ TABLE T_0650IT WITH KEY GPART = LS_MANTAB-SND_DIR_ID.
                IF SY-SUBRC = 0.
                  MSGV1 = LS_MANTAB-MNDID.
                  PERFORM MESSAGE USING 293.
                ELSE.
                  MSGV1 = LS_MANTAB-MNDID.
                  MSGV2 = LS_MANTAB-SND_DIR_ID.
                  PERFORM MESSAGE USING 309.
                  DELETE LT_MANTAB INDEX L_TABIX.
                  CONTINUE.
                ENDIF.
              ENDIF.
            ELSE.
* ...yes
* ......is the unique partner the partner we debit?
              IF L_ITEMS_GP = BUS000_EXT-PARTNER.
* .........yes (father paying only his own items)
* ...........skip mandates specified to other SND_DIR_ID's
                IF  LS_MANTAB-SND_DIR_ID NE SPACE
                AND LS_MANTAB-SND_DIR_ID NE L_ITEMS_GP.
                  MSGV1 = LS_MANTAB-MNDID.
                  MSGV2 = LS_MANTAB-SND_DIR_ID.
                  PERFORM MESSAGE USING 309.
                  DELETE LT_MANTAB INDEX L_TABIX.
                  CONTINUE.
                ENDIF.
              ELSE.
* .........no (father is paying only items of daughter)
* ..............no: exclude only those with SND_DIR_ID someone else
                "Changed with note 5007922. mandates w/o SND_DIR_ID
                "must NOT be sorted out.
                  IF  LS_MANTAB-SND_DIR_ID NE SPACE
                  AND LS_MANTAB-SND_DIR_ID NE L_ITEMS_GP.
                    MSGV1 = LS_MANTAB-MNDID.
                    MSGV2 = LS_MANTAB-SND_DIR_ID.
                    PERFORM MESSAGE USING 309.
                    DELETE LT_MANTAB INDEX L_TABIX.
                    CONTINUE.
                ENDIF.
              ENDIF.
            ENDIF.
* message "mandat verwendbar"
          ELSE.
            MSGV1 = LS_MANTAB-MNDID.
            PERFORM MESSAGE USING 290.
* message "mandat nicht benutzbar"
* mandate aus liste der möglichen entfernen
            DELETE LT_MANTAB INDEX L_TABIX.
          ENDIF.
        ENDLOOP.
      ELSE.
* message "gar keine mandate"
*  <<< Note 1813402 In case of call from EA19 to choose the correct bankID for a
*      SEPA payment method don´t skip right after the first checked bankID
        L_MSGNO = '91'.    "no partner bank with SEPA
        CONTINUE.
* >>> Note 1813402
      ENDIF.

* ...check usuable mandates for reference id/type
* ...(export all possible mandates, import selected one, check reference data)
      IF LINES( LT_MANTAB ) > 0.
        PERFORM EXIT_FUNC_MODULE USING '0653'.
        CLEAR: LT_MESSA[].
        CALL FUNCTION T_TFKFBC-FUNCC
          EXPORTING
            IT_MANDATES   = LT_MANTAB
            I_SRT1        = IMPORT-SRT1
          IMPORTING
            E_MANDATE     = L_CHOSEN
            E_SKIP_ALL    = L_SKIP_ALL
          TABLES
            T_ITEMS       = T_0650IT
            T_MESSAGES    = LT_MESSA
          EXCEPTIONS
            ERROR_MESSAGE = 4.

* ...something chosen?
        IF SY-SUBRC EQ 0.
* ...messages from event 0653?
          LOOP AT LT_MESSA INTO LS_MESSA.
            CLEAR: L_FIMSG.
            MOVE-CORRESPONDING LS_MESSA TO L_FIMSG.
            CALL FUNCTION 'FI_MESSAGE_COLLECT'
              EXPORTING
                I_FIMSG = L_FIMSG.
          ENDLOOP.
          IF L_SKIP_ALL     NE SPACE
          OR L_CHOSEN-MNDID IS INITIAL.
            PERFORM MESSAGE USING 292.
            EXIT.
          ELSE.
            MSGV1 = L_CHOSEN-MNDID.
            PERFORM MESSAGE USING 291.
            MOVE-CORRESPONDING L_CHOSEN TO L_SEPA_PMS.
            L_SEPA_PMS-CRDID = L_CHOSEN-REC_CRDID.
          ENDIF.
        ELSE.
          PERFORM MESSAGE USING 292.
          EXIT.
        ENDIF.

* cross ref
        IF 1 = 2.
          SET EXTENDED CHECK OFF.
          CALL FUNCTION 'FKK_SAMPLE_0653'.
          SET EXTENDED CHECK ON.
        ENDIF.
      ELSE.
* message "no mandate left" message 092
*  <<< Note 1813402 In case of call from EA19 to choose the correct bankID for a
*      SEPA payment method don´t skip right after the first checked bankID
        L_MSGNO = '92'.  "no partner bank with SEPA
        CONTINUE.
* >>> Note 1813402
      ENDIF.

* open selected mandate (enqueue for later add usage!)
      IF IMPORT-XSIMU IS INITIAL.
        READ TABLE LT_MANTAB INTO LS_MANTAB WITH KEY MGUID = L_SEPA_PMS-MGUID.
        IF SY-SUBRC = 0.
          CLEAR: LT_OPEN[], LT_MESSAGES[].
          MOVE-CORRESPONDING LS_MANTAB TO LS_OPEN.
          APPEND LS_OPEN TO LT_OPEN.
          CALL FUNCTION 'SEPA_MANDATES_API_OPEN'
            EXPORTING
              I_TAB_MANDATE_KEY_EXTERNAL = LT_OPEN
              I_GET_ORIGIN_KEYS          = 'X'
            IMPORTING
              ET_MESSAGES                = LT_MESSAGES.
          IF NOT LT_MESSAGES IS INITIAL.
            READ TABLE LT_MESSAGES INTO LS_MESSAGE INDEX 1.
            IF LS_MESSAGE-ID = 'SEPA' AND LS_MESSAGE-NUMBER = '060'. "Note 1981984
              L_ONE_MANDATE_LOCKED = 'X'.
            ENDIF.
            MSGID = LS_MESSAGE-ID.
            MSGV1 = LS_MESSAGE-MESSAGE_V1.
            MSGV2 = LS_MESSAGE-MESSAGE_V2.
            MSGV3 = LS_MESSAGE-MESSAGE_V3.
            MSGV4 = LS_MESSAGE-MESSAGE_V4.
            PERFORM MESSAGE USING LS_MESSAGE-NUMBER.
            EXIT.
          ENDIF.

          "The lock in SEPA_MANDATES_API_OPEN is internally set with the same scope as
          "the very first enqueue call in the 'LUW', so typically scope = 3. Those locks are
          "only released with funciton module SEPA_MANDATES_API_MULT_INIT. Collect those locks
          "and release them for earlier deletion after the group has been processed. The deletion
          "happens in the next call of SAPLFKPMASS COMMIT_WORK.
          CALL FUNCTION 'FKK_SEPA_MANDATE_LOCK_COLLECT'
            EXPORTING
              IV_REC_CRDID = LS_MANTAB-ORIGIN_REC_CRDID
              IV_MNDID     = LS_MANTAB-ORIGIN_MNDID
              IV_SND_ID    = LS_MANTAB-SND_ID.

        ENDIF.
      ENDIF.

* enter MGUID in T_PBANK
      T_PBANK-SEPA_PMS = L_SEPA_PMS.
      MODIFY T_PBANK INDEX L_TABIXP.
    ENDLOOP.

* something left?
    DELETE T_PBANK WHERE SEPA_PMS-MGUID IS INITIAL.
    DESCRIBE TABLE T_PBANK LINES TFILL.
    IF TFILL EQ 0.
      IF L_ONE_MANDATE_LOCKED = 'X'. "Note 1981984
        H_MSGNO = '334'. "indicator for locked mandate, leads to POKEN 34
        MSGV1   = LS_MESSAGE-MESSAGE_V1.
      ELSE.
        H_MSGNO = '331'. "indicator for SEPA failed in general
        MSGV1 = L_CRIT-SND_IBAN.
        MSGV2 = L_CRIT-REC_CRDID.
        MSGV3 = L_CRIT-SND_ID.
        MSGV4 = IMPORT-OPBUK.
      ENDIF.
      IF L_MSGNO = '91'.
        PERFORM MESSAGE USING 091.       "no partner bank with SEPA
      ELSEIF L_MSGNO = '92'.
        PERFORM MESSAGE USING 092.       "no mandate left"
      ENDIF.
*  >>> Note 1813402
      EXIT.
    ENDIF.
  ENDIF.

* IBAN without national account number is not allowed?
* ... we do not have such a customizing flag
* IF FKK042Z-XIBANONLY EQ SPACE.
*   DELETE T_PBANK WHERE BANKN EQ SPACE.
*                    AND IBAN  NE SPACE.
*   DESCRIBE TABLE T_PBANK LINES TFILL.
*   IF TFILL EQ 0.
*     PERFORM MESSAGE USING 082.       "missing BANKN not allowed
*   ENDIF.
* ENDIF.

* delete banks with LOEVM (deletion flag set)
  CALL FUNCTION 'READ_CUSTOMIZED_MESSAGE'
    EXPORTING
      I_ARBGB = '>2'
      I_DTYPE = 'E'
      I_MSGNR = '074'
    IMPORTING
      E_MSGTY = L_MSGTY.
  CASE L_MSGTY.
* ...only S-message, no EXIT
    WHEN 'S'.
      LOOP AT T_PBANK WHERE BNKA-LOEVM EQ SPACE.
        EXIT.
      ENDLOOP.
      IF SY-SUBRC NE 0.
        PERFORM MESSAGE USING 074.
*       EXIT.                        " no EXIT!
      ENDIF.
* ...E-message (default) and do not use bank (delete from T_PBANK)
    WHEN 'E'.
      DELETE T_PBANK WHERE BNKA-LOEVM NE SPACE.
      DESCRIBE TABLE T_PBANK LINES TFILL.
      IF TFILL EQ 0.
        PERFORM MESSAGE USING 074.       "no partner bank without LOEVM
        EXIT.
      ENDIF.
    WHEN '-'.
  ENDCASE.

* partner's banks are ok
  P_SUBRC = 0.
ENDFORM.                    "CHECK_PARTNER_BANK

*---------------------------------------------------------------------*
*       FORM CHECK_PAYMENT_METHOD                                     *
*---------------------------------------------------------------------*
FORM CHECK_PAYMENT_METHOD USING P_SUBRC LIKE SY-SUBRC.
  DATA: H_NOADR LIKE BOOLE-BOOLE.
  DATA: L_CCNUM TYPE CCNUM.
  DATA: L_RCODE TYPE SY-SUBRC.
  DATA: LV_IS_VALID LIKE BOOLE-BOOLE.  "Note 1241883
  P_SUBRC = 4.

* check debit / credit
  IF IMPORT-CHSIG NE SPACE.
    IF NOT FKK042Z-XEINZ IS INITIAL.
*      IF IMPORT-RBETR LT 0
*      OR IMPORT-RWBTR LT 0.
      IF IMPORT-RWBTR LT 0.
        PERFORM MESSAGE USING 030.      "wrong payment method for credit
        EXIT.
      ENDIF.
    ELSE.
*      IF IMPORT-RBETR GT 0
*      OR IMPORT-RWBTR GT 0.
      IF IMPORT-RWBTR GT 0.
        PERFORM MESSAGE USING 031.       "wrong payment method for debit
        EXIT.
      ENDIF.
    ENDIF.
  ENDIF.

* check minimum and maximum amount of payment method
* ...if payment method not in item: check always (IMPORT-CHKAM = 'X')
* ...if payment method is in item: only if TFK042E-XAMCH is set
  IF NOT IMPORT-CHKAM  IS INITIAL
  OR     TFK042E-XAMCH NE SPACE.
    H_CALC = ABS( IMPORT-RBETR ).
    IF NOT H_CALC BETWEEN TFK042E-VONBT AND TFK042E-BISBT.
      WRITE TFK042E-VONBT TO MSGV1 CURRENCY T001-WAERS LEFT-JUSTIFIED.
      WRITE TFK042E-BISBT TO MSGV2 CURRENCY T001-WAERS LEFT-JUSTIFIED.
      MSGV3 = TFK042E-OPBUK.
      MSGV4 = TFK042E-ZLSCH.
      PERFORM MESSAGE USING 029.       "amount not in allowed interval
      EXIT.
    ENDIF.
  ENDIF.

* ESR payment method without ESR data on item level?
  IF  FKK042Z-XESRD NE SPACE
  AND IMPORT-LFDNR  IS INITIAL.
    PERFORM MESSAGE USING 067.
    EXIT.
  ENDIF.

* Payment order not allowed if brasilian WT accumulation is active (event 0177 changed T_ITEMS-AQSBW)
  IF  FKK042Z-XNOPO NE SPACE
  AND FKK042Z-XEINZ IS INITIAL.
* ...this checks XWTAC for paying company code
* ...better: check XWTAC for T_0650IT-BUKRS (if any item of such a BUKRS is involved, forbid payment order)
    IF TFK001B-XWTAC NE SPACE.
*    LOOP AT T_0650IT WHERE AQSBW_OLD NE 0
*                     AND   AQSBW_OLD NE T_0650IT-AQSBW.
*      EXIT.
*    ENDLOOP.
*    IF SY-SUBRC = 0.
      PERFORM MESSAGE USING 311.
      EXIT.
    ENDIF.
  ENDIF.

* foreign currency?
  IF TFK042E-XFWAE IS INITIAL AND IMPORT-WAERS NE T001-WAERS.
    PERFORM MESSAGE USING 025.
    EXIT.
  ENDIF.

* foreign currency allowed, but only for some currencies?
  IF TFK042E-XFWAE NE SPACE AND IMPORT-WAERS NE T001-WAERS.
    DESCRIBE TABLE T_TFK042W LINES SY-TFILL.
    IF SY-TFILL > 0.
      READ TABLE T_TFK042W WITH KEY LAND1 = FKK042Z-LAND1
                                    ZLSCH = FKK042Z-ZLSCH
                                    WAERS = IMPORT-WAERS.
      IF SY-SUBRC NE 0.
        MSGV1 = IMPORT-WAERS.
        PERFORM MESSAGE USING 057.
        EXIT.
      ENDIF.
    ENDIF.
  ENDIF.

* foreign business partner not allowed and address exists
* and country is not company code country => error
  IF TFK042E-XAUSL IS INITIAL AND BUS000_EXT-COUNTRY NE T001-LAND1
                              AND IMPORT-NOADR       EQ SPACE.
    PERFORM MESSAGE USING 026.
    EXIT.
  ENDIF.

* street or PO box obligatory?
  IF NOT FKK042Z-XSTRA IS INITIAL AND BUS000_EXT-STREET     IS INITIAL
                                  AND BUS000_EXT-PO_BOX     IS INITIAL
                                  AND BUS000_EXT-POST_CODE3 IS INITIAL
                                  AND BUS000_EXT-POST_CODE2 IS INITIAL.
    " note 1396345
    PERFORM MESSAGE USING 028.
    EXIT.
  ENDIF.

* street or PO box without city will not work (for checks)
  IF NOT FKK042Z-XSTRA IS INITIAL AND BUS000_EXT-CITY1      IS INITIAL.
    PERFORM MESSAGE USING 028.
    EXIT.
  ENDIF.

* address is necessary, but missing?
  H_NOADR = IMPORT-NOADR.  "caller already noticed missing address
  IF  BUS000_EXT-CITY1 IS INITIAL
  OR (      BUS000_EXT-STREET     IS INITIAL
        AND BUS000_EXT-PO_BOX     IS INITIAL
        AND BUS000_EXT-POST_CODE3 IS INITIAL
        AND BUS000_EXT-POST_CODE2 IS INITIAL ).  "Note 1396345
    H_NOADR = 'X'.
  ENDIF.

*>>Note 1241883
  IF H_NOADR = 'X'.
    CLEAR: LV_IS_VALID.
    PERFORM ADDRESS_VALID(ZZFPY1) IF FOUND
      USING    BUS000_EXT
               FKK042Z                   "Note 1259567
      CHANGING LV_IS_VALID.
    IF LV_IS_VALID NE SPACE.
      CLEAR: H_NOADR.
    ENDIF.
  ENDIF.
*>>Note 1241883

  IF  FKK042Z-XADDR IS INITIAL
  AND H_NOADR       NE SPACE.
    MSGV1 = FKK042Z-ZLSCH.
    MSGV2 = BUS000_EXT-PARTNER.
    PERFORM MESSAGE USING 065.
    EXIT.
  ENDIF.

* check payment card
  IF FKK042Z-XVERR EQ 'C'.
    READ TABLE T_BUS0CC INDEX 1.
    IF SY-SUBRC = 0.

* card excluded on parameter screen?
      IF  IMPORT-CCINS NE SPACE
      AND IMPORT-CCINS NE T_BUS0CC-CCINS.
        MSGV1 = IMPORT-CCINS.
        MSGV2 = T_BUS0CC-CCINS.
        PERFORM MESSAGE USING 197.
        EXIT.
      ENDIF.

* read card data
      L_RCODE = 4.
      IF  T_BUS0CC-CCARD_ID NE '&BD&'
      AND T_BUS0CC-CCARD_ID NE '&OPC&'.
        CALL FUNCTION 'CCA_READ_BP_CARD_DATA'
          EXPORTING
            I_CCINS       = T_BUS0CC-CCINS
            I_CCNUM       = T_BUS0CC-CCNUM
            I_CARD_GUID   = T_BUS0CC-CARD_GUID
          IMPORTING
            E_CCARD       = CCARD
          EXCEPTIONS
            ERROR_MESSAGE = 4.
        L_RCODE = SY-SUBRC.
      ENDIF.
      IF L_RCODE = 0.

* replace validity dates with OPC data if available
        IF NOT IMPORT-OPC-DATBI IS INITIAL.
          CCARD-DATAB = IMPORT-OPC-DATAB.
          CCARD-DATBI = IMPORT-OPC-DATBI.
        ENDIF.

* card locked?
        IF NOT CCARD-CCLOCK IS INITIAL.
          SELECT SINGLE * FROM TB035T WHERE SPRAS  = SY-LANGU
                                      AND   CCLOCK = CCARD-CCLOCK.
          IF  SY-SUBRC     EQ 0
          AND TB035T-BEZ40 NE SPACE.
            MSGV1 = TB035T-BEZ40.
            PERFORM MESSAGE USING 171.
          ELSE.
            MSGV1 = CCARD-CCLOCK.
            PERFORM MESSAGE USING 171.
          ENDIF.
          EXIT.
        ENDIF.

* card not valid (any more)?
        IF SY-DATUM < CCARD-DATAB
        OR ( NOT CCARD-DATBI IS INITIAL
             AND SY-DATUM    >  CCARD-DATBI ).
          IF IMPORT-OPC-AUNUM IS INITIAL.
            MSGV1 = CCARD-DATAB.
            MSGV2 = CCARD-DATBI.
            PERFORM MESSAGE USING 172.
            EXIT.
          ENDIF.
        ENDIF.
      ELSE.

* "no card data" is not an error for one time card
        IF  T_BUS0CC-CCARD_ID NE '&BD&'
        AND T_BUS0CC-CCARD_ID NE '&OPC&'.
          MSGV1 = T_BUS0CC-CCINS.
          CALL FUNCTION 'FKK_MASK_DATA'
            EXPORTING
              I_CCNUM = T_BUS0CC-CCNUM
            IMPORTING
              E_CCNUM = L_CCNUM.
          MSGV2 = L_CCNUM.
          PERFORM MESSAGE USING 173.
          EXIT.
        ENDIF.

* check validity of OPC data if available
        IF SY-DATUM < IMPORT-OPC-DATAB
        OR ( NOT IMPORT-OPC-DATBI IS INITIAL
             AND SY-DATUM    >  IMPORT-OPC-DATBI ).
          IF IMPORT-OPC-AUNUM IS INITIAL.
            MSGV1 = IMPORT-OPC-DATAB.
            MSGV2 = IMPORT-OPC-DATBI.
            PERFORM MESSAGE USING 172.
            EXIT.
          ENDIF.
        ENDIF.
      ENDIF.
    ELSE.
      MSGV1 = BUS000_EXT-PARTNER.
      PERFORM MESSAGE USING 072.
      EXIT.
    ENDIF.
  ENDIF.

* payment method is ok
  P_SUBRC = 0.
ENDFORM.                    "CHECK_PAYMENT_METHOD
