FUNCTION-POOL ZEV35.     "MESSAGE-ID ..

INCLUDE IEVARDAT.
INCLUDE ieagetmngbasis.

* Special declarations for COMPUT27
TYPES:  BEGIN OF WCENTRAL_TYPE,
            OPERAND          TYPE   E_OPERAND,
            LOGIKZW          TYPE   LOGIKZW,
            DATE             LIKE   ERCH-BEGABRPE,
            FROM_ORIG        LIKE   ERCH-BEGABRPE,
            TO_ORIG          LIKE   ERCH-ENDABRPE,
            QNT_NEW          TYPE   ISU2A_PACK16,
            QNT_OLD          TYPE   ISU2A_PACK16,
            VOL_STABLE_NEW   TYPE   ISU2A_PACK16,
            VOL_STABLE_OLD   TYPE   ISU2A_PACK16,
            VOL_INTER_NEW    TYPE   ISU2A_PACK16,
            VOL_INTER_OLD    TYPE   ISU2A_PACK16,
            DCV_V_S          TYPE   ISU2A_PACK16,
            DCV_V_I          TYPE   ISU2A_PACK16,
            OMQ              TYPE   ISU2A_PACK16,
            V_S_PROJ         TYPE   ISU2A_PACK16,
            V_I_PROJ         TYPE   ISU2A_PACK16,
            ID               TYPE   ISU2A_PACK16,
            VERTRAG          LIKE   EVER-VERTRAG,
            QNT_PD_NEW       TYPE   ISU2A_PACK16,
            PROCESS          TYPE   CHAR5,
          END OF WCENTRAL_TYPE.
TYPES: ICENTRAL_TYPE TYPE WCENTRAL_TYPE OCCURS 0.
*>>> note 584706
TYPES:   BEGIN OF WINFO,
            FROM        LIKE   ERCH-BEGABRPE,
            TO          LIKE   ERCH-ENDABRPE,
            ZEITANT     LIKE   ERCHZ-ZEITANT,
            VOL_CONS    TYPE   ISU2A_PACK16,
            DCV         TYPE   ISU2A_PACK16,
            TUD         TYPE   ISU2A_PACK16,
            VOL_TRANS   TYPE   ISU2A_PACK16,
            WINTER_LOAD TYPE   ISU2A_PACK16,
          END OF WINFO.
TYPES:   IINFO   TYPE  WINFO  OCCURS 0.
*<<< note 584706
