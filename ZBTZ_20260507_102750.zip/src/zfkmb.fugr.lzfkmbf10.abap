*----------------------------------------------------------------------*
*   INCLUDE LFKMBF10                                                   *
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  READ_T001
*&---------------------------------------------------------------------*
FORM read_t001 USING bukrs TYPE bukrs.

  sy-subrc = 0.

  CHECK bukrs NE t001-bukrs.

  SELECT SINGLE * FROM t001
    WHERE bukrs = bukrs.

ENDFORM.                                                    " READ_T001

*&---------------------------------------------------------------------*
*&      Form  READ_TFK047A
*&---------------------------------------------------------------------*
*       Lesen der Tabelle TFK047A
**----------------------------------------------------------------------
FORM read_tfk047a USING mahnv TYPE tfk047a-mahnv.

  sy-subrc = 0.

  CHECK mahnv NE tfk047a-mahnv.

  SELECT SINGLE * FROM tfk047a
    WHERE mahnv = mahnv.

ENDFORM.                               " READ_TFK047A

*&---------------------------------------------------------------------*
*&      Form  READ_TFK047B
*&---------------------------------------------------------------------*
*       Lesen der Tabelle TFK047B
**----------------------------------------------------------------------
FORM read_tfk047b USING mahnv TYPE tfk047b-mahnv
                        mahns TYPE tfk047b-mahns
                  CHANGING c_tfk047b TYPE tfk047b.

  STATICS s_tfk047b TYPE tfk047b.

  sy-subrc = 0.
  IF mahnv NE s_tfk047b-mahnv OR mahns NE s_tfk047b-mahns.
    SELECT SINGLE * FROM tfk047b INTO s_tfk047b
                      WHERE mahnv = mahnv
                        AND mahns = mahns.
*   SY-SUBRC is handled outside
    c_tfk047b = s_tfk047b.
  ELSE.
    c_tfk047b = s_tfk047b.
  ENDIF.

ENDFORM.                               " READ_TFK047B

*&---------------------------------------------------------------------*
*&      Form  READ_TFK047C
*&---------------------------------------------------------------------*
*       Lesen der Tabelle TFK047C                                      *
*----------------------------------------------------------------------*
FORM read_tfk047c USING mahnv TYPE mahnv_kk
                        mahns TYPE mahns_kk
                        waers TYPE waers.

  sy-subrc = 0.
  CHECK mahnv <> tfk047c-mahnv
     OR mahns <> tfk047c-mahns
     OR waers <> tfk047c-waers.

  SELECT SINGLE * FROM tfk047c  WHERE mahnv = mahnv
                                  AND mahns = mahns
                                  AND waers = waers.
  IF sy-subrc <> 0.
*   Customizing entry for all currencies with amout limit zero
*   is also allowed
    SELECT SINGLE * FROM tfk047c  WHERE mahnv = mahnv
                                    AND mahns = mahns
                                    AND waers = space
                                    AND minbt = 0.
  ENDIF.

ENDFORM.                               " READ_TFK047C

*&---------------------------------------------------------------------*
*&      Form  READ_TFK047S
*&---------------------------------------------------------------------*
FORM read_tfk047s USING mansp TYPE tfk047s-mansp.

  sy-subrc = 0.

  CHECK tfk047s-mansp NE mansp.

  SELECT SINGLE * FROM tfk047s
    WHERE mansp = mansp.

ENDFORM.                               " READ_TFK047S

*&---------------------------------------------------------------------*
*&      Form  MESSAGE_APPEND
*&---------------------------------------------------------------------*
FORM message_append USING msgid LIKE sy-msgid
                          msgty LIKE sy-msgty
                          msgno LIKE sy-msgno
                          msgv1 TYPE any
                          msgv2 TYPE any
                          msgv3 TYPE any
                          msgv4 TYPE any
                          msgpr TYPE c.

  t_fimsg-msgpr = msgpr.
  t_fimsg-msgid = msgid.
  t_fimsg-msgty = msgty.
  t_fimsg-msgno = msgno.
  WRITE msgv1 TO t_fimsg-msgv1 LEFT-JUSTIFIED.
  WRITE msgv2 TO t_fimsg-msgv2 LEFT-JUSTIFIED.
  WRITE msgv3 TO t_fimsg-msgv3 LEFT-JUSTIFIED.
  WRITE msgv4 TO t_fimsg-msgv4 LEFT-JUSTIFIED.
  APPEND t_fimsg.

ENDFORM.                               " MESSAGE_APPEND

*&---------------------------------------------------------------------*
*&      Form  WRITE_DUNNING_HISTORY
*&---------------------------------------------------------------------*
FORM write_dunning_history.

  CALL FUNCTION 'FKK_WRITE_DUNNING_HISTORY'
    TABLES
      i_fkkmako = n_fkkmako
      i_fkkmaze = n_fkkmaze
    EXCEPTIONS
      OTHERS    = 0.

  REFRESH: n_fkkmako, n_fkkmaze.

ENDFORM.                               " WRITE_DUNNING_HISTORY

*&---------------------------------------------------------------------*
*&      Form  VERGLEICHE_WERT
*&---------------------------------------------------------------------*
FORM vergleiche_wert USING wert1 TYPE any
                           wert2 TYPE any.

  IF NOT wert1 IS INITIAL
    AND wert1 NE wert2.
    CLEAR wert1.
  ENDIF.

ENDFORM.                    " VERGLEICHE_WERT


*&---------------------------------------------------------------------*
*&      Form  UEBERTRAGE_WERT
*&---------------------------------------------------------------------*
FORM uebertrage_wert USING wert1 TYPE any
                           wert2 TYPE any.

  IF wert2 IS INITIAL.
    wert2 = wert1.
  ENDIF.

ENDFORM.                    " UEBERTRAGE_WERT
*&---------------------------------------------------------------------*
*&      Form  calculate_credit_rating
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_I_FKKMAGRP_GPART  text
*      -->P_I_AUSDT  text
*      <--P_I_FKKMAKO_BONIT  text
*----------------------------------------------------------------------*
FORM calculate_credit_rating  USING    u_gpart
                                       u_ausdt
                              CHANGING c_bonit.

  STATICS: s_gpart LIKE fkkmako-gpart,
           s_bonit LIKE fkkmako-bonit.

  IF u_gpart NE s_gpart.
    CLEAR s_bonit.
    CALL FUNCTION 'FKK_CALCULATE_CREDIT_RATING'
      EXPORTING
        i_gpart = u_gpart
        i_datum = u_ausdt
      IMPORTING
        e_bonit = s_bonit.
    MOVE u_gpart TO s_gpart.
  ENDIF.

  MOVE s_bonit TO c_bonit.

ENDFORM.                    " calculate_credit_rating
*&--------------------------------------------------------------------*
*&      Form  dunning_level_by_hierarchy
*&--------------------------------------------------------------------*
*       text
*---------------------------------------------------------------------*
*      -->U_T_FKKMAZE
*      -->U_RT_MAHNV
*      -->U_F_FKKOP
*      -->C_MAHNS
*      -->C_MAHNN
*      -->C_MSTYP
*      -->C_MAHND
*      -->C_ITEM_FOUND
*---------------------------------------------------------------------*
FORM dunning_level_by_hierarchy  TABLES   u_t_fkkmaze  STRUCTURE fkkmaze
                                          u_t_fkkmako  STRUCTURE fkkmako
                                          u_rt_mahnv   TYPE fkk_rt_mahnv
                                 USING    u_f_fkkop    TYPE fkkop_struc
                                 CHANGING c_mahns      TYPE fkkmaze-mahns
                                          c_mahnn      TYPE fkkmaze-mahnn
                                          c_mstyp      TYPE fkkmaze-mstyp
                                          c_mahnd      TYPE fkkmaze-ausdt
                                          c_item_found TYPE xfeld
                                          c_step_last  TYPE step_cm_kk
                                          c_strat_last TYPE strat_cm_kk
                                          c_itemgrp_last  TYPE itemgrp_cm_kk
                                          c_grpfield_last TYPE grpfield_cm_kk.

  DATA: l_f_fkkop TYPE fkkop_struc.
  DATA: l_orupz   LIKE fkkop-orupz.

  CLEAR: c_mahns,
         c_mahnn,
         c_mstyp,
         c_mahnd,
         c_item_found,
         c_step_last,
         c_strat_last,
         c_itemgrp_last,
         c_grpfield_last.

  MOVE: u_f_fkkop TO l_f_fkkop.

* Search with OPUPZ
  LOOP AT u_t_fkkmaze WHERE ( opbel =  l_f_fkkop-opbel AND
                              opupw =  l_f_fkkop-opupw AND
                              opupk =  l_f_fkkop-opupk AND
                              opupz =  l_f_fkkop-opupz AND
                              mahnv IN u_rt_mahnv      AND
                              xinfo =  space               ).
*   EXIT LOOP
    EXIT.
  ENDLOOP.

  IF NOT sy-subrc IS INITIAL.
*   Entry with lower OPUPZ?
    LOOP AT u_t_fkkmaze WHERE ( opbel =  l_f_fkkop-opbel AND
                                opupw =  l_f_fkkop-opupw AND
                                opupk =  l_f_fkkop-opupk AND
                                opupz <  l_f_fkkop-opupz AND
                                mahnv IN u_rt_mahnv      AND
                                xinfo =  space               ).
*     EXIT LOOP
      EXIT.
    ENDLOOP.
    IF NOT sy-subrc IS INITIAL.
*     No lower sub-item for this document in the table => no further search
      EXIT.
    ENDIF.

* Search with ORUPZ
    DO.
      IF l_f_fkkop-augbl IS INITIAL.
        LOOP AT u_t_fkkmaze WHERE ( opbel = l_f_fkkop-opbel AND
                                    opupw = l_f_fkkop-opupw AND
                                    opupk = l_f_fkkop-opupk AND
                                    opupz = l_f_fkkop-orupz AND
                                   mopupz < l_f_fkkop-opupz AND
                                    mahnv IN u_rt_mahnv     AND
                                    xinfo =  space              ).
*         EXIT LOOP
          EXIT.
        ENDLOOP.
      ELSE.
*       Cleared items: only considered as dunned if created after dunning run (logic like note 728269)
        LOOP AT u_t_fkkmaze WHERE ( opbel = l_f_fkkop-opbel AND
                                    opupw = l_f_fkkop-opupw AND
                                    opupk = l_f_fkkop-opupk AND
                                    opupz = l_f_fkkop-orupz AND
                                   mopupz < l_f_fkkop-opupz AND
                                   mopupz NE space          AND  "No old records
                                    mahnv IN u_rt_mahnv     AND
                                    xinfo =  space              ).
*         EXIT LOOP
          EXIT.
        ENDLOOP.
      ENDIF.

      IF sy-subrc IS INITIAL.
        IF u_t_fkkmaze-mahnv IS INITIAL.
*       Dunned item from flexible dunning. Get collection step.
          READ TABLE u_t_fkkmako WITH KEY laufd = u_t_fkkmaze-laufd
                                          laufi = u_t_fkkmaze-laufi
                                          gpart = u_t_fkkmaze-gpart
                                          mazae = u_t_fkkmaze-mazae.
          IF sy-subrc IS INITIAL.
            MOVE: u_t_fkkmako-step     TO c_step_last,
                  u_t_fkkmako-strat    TO c_strat_last,
                  u_t_fkkmako-itemgrp  TO c_itemgrp_last,
                  u_t_fkkmako-grpfield TO c_grpfield_last.
          ENDIF.
        ENDIF.
*       Amount of the sub-item was already dunned
        c_mahns      = u_t_fkkmaze-mahns.
        c_mahnn      = u_t_fkkmaze-mahnn.
        c_mstyp      = u_t_fkkmaze-mstyp.
        c_mahnd      = u_t_fkkmaze-ausdt.
        c_item_found = 'X'.

*       EXIT DO...ENDDO if record for ORUPZ found
        EXIT.
      ENDIF.

      CASE l_f_fkkop-orupz.
        WHEN '000'.
*         no predecessor.
          EXIT.

        WHEN '001'.
*         predecessor = '000'
          MOVE: l_f_fkkop-orupz TO l_f_fkkop-opupz,
                '000'           TO l_f_fkkop-orupz.

        WHEN OTHERS.
*         Read predecessor with 'OPUPZ = ORUPZ' from DFKKOP
          SELECT SINGLE orupz FROM dfkkop
                              INTO l_orupz
                              WHERE opbel  = l_f_fkkop-opbel
                               AND  opupw  = l_f_fkkop-opupw
                               AND  opupk  = l_f_fkkop-opupk
                               AND  opupz  = l_f_fkkop-orupz. "predecessor
*         Record found?
          IF     sy-subrc         IS INITIAL AND
             NOT l_orupz          IS INITIAL.
            MOVE: l_f_fkkop-orupz TO l_f_fkkop-opupz,
                  l_orupz         TO l_f_fkkop-orupz.
          ELSE.
*           EXIT DO...ENDDO if no predecessor is found
            EXIT.
          ENDIF.
      ENDCASE.

    ENDDO.

  ELSE.
* Record found directly with OPUPZ
    IF u_t_fkkmaze-mahnv IS INITIAL.
*     Dunned item from flexible dunning. Get collection step.
      READ TABLE u_t_fkkmako WITH KEY laufd = u_t_fkkmaze-laufd
                                      laufi = u_t_fkkmaze-laufi
                                      gpart = u_t_fkkmaze-gpart
                                      mazae = u_t_fkkmaze-mazae.
      IF sy-subrc IS INITIAL.
        MOVE: u_t_fkkmako-step     TO c_step_last,
              u_t_fkkmako-strat    TO c_strat_last,
              u_t_fkkmako-itemgrp  TO c_itemgrp_last,
              u_t_fkkmako-grpfield TO c_grpfield_last.
      ENDIF.
    ENDIF.
    c_mahns      = u_t_fkkmaze-mahns.
    c_mahnn      = u_t_fkkmaze-mahnn.
    c_mstyp      = u_t_fkkmaze-mstyp.
    c_mahnd      = u_t_fkkmaze-ausdt.
    c_item_found = 'X'.
  ENDIF.

ENDFORM.                    " dunning_level_by_hierarchy
