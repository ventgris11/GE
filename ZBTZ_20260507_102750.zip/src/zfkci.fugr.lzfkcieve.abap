*----------------------------------------------------------------------*
*   INCLUDE LFKCIEVE                                                   *
*----------------------------------------------------------------------*

*----------------------------------------------------------------------*
* selection-screen's
*----------------------------------------------------------------------*
*data: begin of t_param, inkgp type inkgpi_kk, end of t_param. "0403del
* dynpro 1100: inkgp
SELECTION-SCREEN BEGIN OF SCREEN 1100 AS SUBSCREEN.
*select-options so_inkgp for t_param-inkgp. "dfkkcoll-inkgp. "0403del
SELECT-OPTIONS so_inkgp FOR tfk050b-inkgp.                  "0403ins
SELECTION-SCREEN END OF SCREEN 1100.
* dynpro 1200
SELECTION-SCREEN BEGIN OF SCREEN 1200 AS SUBSCREEN.
SELECTION-SCREEN BEGIN OF BLOCK bl1 WITH FRAME TITLE text-i01.
PARAMETERS:
"  xcpart  TYPE xcpart_kk MODIF ID soa,
  xcpart  TYPE xcpart_kk,
  xausg   TYPE xausg_kk,
  xback   TYPE xback_kk.
PARAMETERS:
  xstorno TYPE xstorno_kk,
  xreclr  TYPE xreclr_kk,
  xretrn  TYPE xretrn_kk,
  xrever  TYPE xrever_kk,
  xwroff  TYPE xwroff_kk.
SELECTION-SCREEN SKIP 1.
SELECTION-SCREEN BEGIN OF LINE.
SELECTION-SCREEN COMMENT 1(15) text-p11 FOR FIELD sumknz MODIF ID soa.
SELECTION-SCREEN POSITION 19.
PARAMETERS:
  sumknz TYPE sumknz_kk MODIF ID soa.
SELECTION-SCREEN END OF LINE.
SELECTION-SCREEN END OF BLOCK bl1.
SELECTION-SCREEN BEGIN OF BLOCK bl2 WITH FRAME TITLE text-i02.
SELECTION-SCREEN BEGIN OF LINE.
SELECTION-SCREEN COMMENT 1(15) text-p12 FOR FIELD datei MODIF ID soa.
SELECTION-SCREEN POSITION 19.
PARAMETERS: datei LIKE filename-fileintern LOWER CASE MODIF ID soa.
SELECTION-SCREEN END OF LINE.
SELECTION-SCREEN END OF BLOCK bl2.
SELECTION-SCREEN END OF SCREEN 1200.

*----------------------------------------------------------------------*
* at selection-screen
*----------------------------------------------------------------------*
AT SELECTION-SCREEN.                   " entspricht PAI

* Write basic parameter to Memory
  g_fkkcollinfo-r_inkgp[]  = so_inkgp[].
  g_fkkcollinfo-xcpart     = xcpart.
  g_fkkcollinfo-xausg      = xausg.
  g_fkkcollinfo-xback      = xback.
  g_fkkcollinfo-xrever     = xrever.
  g_fkkcollinfo-xreclr     = xreclr.
  g_fkkcollinfo-xretrn     = xretrn.
  g_fkkcollinfo-xstorno    = xstorno.
  g_fkkcollinfo-xwroff     = xwroff.
  g_fkkcollinfo-sumknz     = sumknz.
  g_fkkcollinfo-datei      = datei.

* for esoa version: clear not supported options
  IF gv_flg_coll_esoa_active = 'X'.
"    CLEAR g_fkkcollinfo-xcpart.
    CLEAR g_fkkcollinfo-sumknz.
    CLEAR g_fkkcollinfo-datei.
  ENDIF.

  EXPORT addons FROM g_fkkcollinfo TO MEMORY ID 'FKKMADADDONS'.

*----------------------------------------------------------------------*
* at selection-screen output
*----------------------------------------------------------------------*
AT SELECTION-SCREEN OUTPUT.            " entspricht PBO

* Parameter import
  IF sy-ucomm(1) <> '%'.
    IMPORT addons TO g_fkkcollinfo FROM MEMORY ID 'FKKMADADDONS'.
    IF NOT g_fkkcollinfo IS INITIAL.
* for esoa version: clear not supported options
      IF gv_flg_coll_esoa_active = 'X'.
"        CLEAR g_fkkcollinfo-xcpart.
        CLEAR g_fkkcollinfo-sumknz.
        CLEAR g_fkkcollinfo-datei.
      ENDIF.
      so_inkgp[] = g_fkkcollinfo-r_inkgp[].
      xcpart     = g_fkkcollinfo-xcpart.
      xausg      = g_fkkcollinfo-xausg.
      xback      = g_fkkcollinfo-xback.
      xrever     = g_fkkcollinfo-xrever.
      xreclr     = g_fkkcollinfo-xreclr.
      xretrn     = g_fkkcollinfo-xretrn.
      xstorno    = g_fkkcollinfo-xstorno.
      xwroff     = g_fkkcollinfo-xwroff.
      sumknz     = g_fkkcollinfo-sumknz.
      datei      = g_fkkcollinfo-datei.
    ELSE.
* check posting area
      IF g_param IS INITIAL.
*       perform check_posting_area.
*       xcpart   = g_xcpart.
*       xausg    = g_xausg.
*       xback    = g_xback.
*       xrever   = g_xrever.
*       xreclr   = g_xreclr.
*       xretrn   = g_xretrn.
*       xwroff   = g_xwroff.
*       if  not g_xrever is initial
*        or not g_xreclr is initial
*        or not g_xretrn is initial.
*         xstorno  = 'X'.
*       else.
*         clear xstorno.
*       endif.
        PERFORM get_tfk050i.
* for esoa version: clear not supported options
        IF gv_flg_coll_esoa_active = 'X'.
 "         CLEAR g_fkkcollinfo-xcpart.
          CLEAR g_fkkcollinfo-sumknz.
          CLEAR g_fkkcollinfo-datei.
        ENDIF.
        so_inkgp[] = g_fkkcollinfo-r_inkgp[].
        xcpart     = g_fkkcollinfo-xcpart.
        xausg      = g_fkkcollinfo-xausg.
        xback      = g_fkkcollinfo-xback.
        xrever     = g_fkkcollinfo-xrever.
        xreclr     = g_fkkcollinfo-xreclr.
        xretrn     = g_fkkcollinfo-xretrn.
        xstorno    = g_fkkcollinfo-xstorno.
        xwroff     = g_fkkcollinfo-xwroff.
        sumknz     = g_fkkcollinfo-sumknz.
        datei      = g_fkkcollinfo-datei.
        g_param  = 'X'.
      ENDIF.
    ENDIF.
  ENDIF.

* for esoa version: clear not supported options
  IF gv_flg_coll_esoa_active = 'X'.
"    CLEAR xcpart.
    CLEAR sumknz.
    CLEAR datei.
  ENDIF.

  DATA: h_wmode TYPE wmode_kk.

  CALL FUNCTION 'FKK_AKTIV2_WMODE_GET'
    IMPORTING
      e_wmode = h_wmode.

  IF h_wmode = '03'.
    LOOP AT SCREEN.
      IF (    ( screen-group3 = 'PBU' )
           OR ( screen-group3 = 'VPU' ) ).
        CONTINUE.
      ENDIF.
      screen-input = 0.
      MODIFY SCREEN.
    ENDLOOP.
  ENDIF.

* modify screen for esoa version
  IF gv_flg_coll_esoa_active = 'X'.
    LOOP AT SCREEN.
      CHECK screen-group1 = 'SOA'.
      screen-active = 0.
      MODIFY SCREEN.
    ENDLOOP.
  ENDIF.



*>> begin of insert                                          "0403
*----------------------------------------------------------------------*
* at selection-screen on value-request
*----------------------------------------------------------------------*
AT SELECTION-SCREEN ON VALUE-REQUEST FOR so_inkgp-low.
  PERFORM get_ibvalues CHANGING so_inkgp-low.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR so_inkgp-high.
  PERFORM get_ibvalues CHANGING so_inkgp-high.
*>> end of insert                                            "0403
