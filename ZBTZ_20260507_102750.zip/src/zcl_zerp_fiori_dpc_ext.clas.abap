class ZCL_ZERP_FIORI_DPC_EXT definition
  public
  inheriting from ZCL_ZERP_FIORI_DPC
  create public .

public section.
protected section.
private section.
ENDCLASS.



CLASS ZCL_ZERP_FIORI_DPC_EXT IMPLEMENTATION.
ENDCLASS.
