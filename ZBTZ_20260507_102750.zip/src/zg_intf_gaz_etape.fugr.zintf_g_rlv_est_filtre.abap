FUNCTION zintf_g_rlv_est_filtre .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA:
    lc_field_idenreg   TYPE fieldname VALUE 'IDENREG',
    lc_field_type_flux TYPE fieldname VALUE 'FLUX',
    lc_field_statut    TYPE fieldname VALUE 'STATUT',
    lv_field           TYPE string,
    lv_statut          TYPE  zintf_g_statut.

  FIELD-SYMBOLS: <fs>.
  FIELD-SYMBOLS: <fs_id>.


  CONCATENATE 'FLUX-' lc_field_type_flux INTO lv_field.
  ASSIGN (lv_field) TO <fs>.
  IF <fs> IS ASSIGNED AND
      ( <fs> = 'RE1M' OR <fs> = 'RE6M' ) .


    CONCATENATE 'FLUX-' lc_field_idenreg INTO lv_field.
    ASSIGN (lv_field) TO <fs_id>.
    IF <fs_id> IS ASSIGNED  .
      CASE <fs>.
        WHEN 'RE1M'.
          SELECT SINGLE statut FROM zintf_g_re1m
            INTO lv_statut
        WHERE idenreg = <fs_id>.
        WHEN 'RE6M'.
          SELECT SINGLE statut FROM zintf_g_re6m
            INTO lv_statut
        WHERE idenreg = <fs_id>.
      ENDCASE.
      IF lv_statut = '11'.
        CONCATENATE 'FLUX-' lc_field_statut INTO lv_field.
        ASSIGN (lv_field) TO <fs>.
        IF <fs> IS ASSIGNED.
          <fs> = '11'.
          ev_etape = 1.
        ENDIF.
      ELSE.
        ev_etape = 2.
      ENDIF.
    ENDIF.
  ENDIF.

ENDFUNCTION.
