*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 20.10.2018 at 17:29:03
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
