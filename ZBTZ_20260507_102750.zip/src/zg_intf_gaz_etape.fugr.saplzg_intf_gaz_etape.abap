*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZG_INTF_GAZ_ETAPETOP.             " Global Data
  INCLUDE LZG_INTF_GAZ_ETAPEUXX.             " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZG_INTF_GAZ_ETAPEF...             " Subroutines
* INCLUDE LZG_INTF_GAZ_ETAPEO...             " PBO-Modules
* INCLUDE LZG_INTF_GAZ_ETAPEI...             " PAI-Modules
* INCLUDE LZG_INTF_GAZ_ETAPEE...             " Events
* INCLUDE LZG_INTF_GAZ_ETAPEP...             " Local class implement.
* INCLUDE LZG_INTF_GAZ_ETAPET99.             " ABAP Unit tests
