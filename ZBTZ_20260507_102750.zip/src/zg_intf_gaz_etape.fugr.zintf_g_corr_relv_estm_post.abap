FUNCTION zintf_g_corr_relv_estm_post .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
* Déclaration de données: constantes, variables et structures
  DATA: lv_field  TYPE string,
        lv_anlage TYPE anlage,
        lv_date   TYPE dats.
*
  DATA: lt_eabl     LIKE eabl OCCURS 0.
*
  CLEAR: lv_anlage,
         lv_date,
         lt_eabl,
         lt_eabl[].

* Récupération des données de l'installation
  PERFORM reprise_installation USING flux
                            CHANGING lv_anlage
                                     lv_date.

* Sélection des relèves estimées
  PERFORM selection_releves_estimees TABLES lt_eabl
                                      USING lv_anlage
                                            lv_date.

* Nouvelles estimations des relèves psotérieures.
  CHECK lt_eabl[] IS NOT INITIAL.
  PERFORM nouvelles_estimations_releves TABLES lt_eabl
                                         USING lv_anlage.


ENDFUNCTION.

FORM reprise_installation USING p_flux        TYPE any
                       CHANGING p_anlage      TYPE anlage
                                p_date        TYPE dats.

  DATA:  lv_field  TYPE string,
         lv_int_ui TYPE int_ui,
         ls_object TYPE eedm_isu_objects.

  FIELD-SYMBOLS: <fs_num_pce>,
                 <fs_date_releve>,
                 <fs_type>, <fs_raison>, <fs_flux>."++GE-2200
*
  CLEAR lv_field.
  MOVE 'P_FLUX-NUM_PCE' TO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.
  CHECK sy-subrc EQ 0.

*++ STOU DEBUT GE-2200
  CLEAR: lv_field.
  MOVE 'P_FLUX-TYPE_RELEVE' TO lv_field.
  ASSIGN (lv_field) TO <fs_type>.

  CLEAR: lv_field.
  MOVE 'P_FLUX-RAISON_RELEVE' TO lv_field.
  ASSIGN (lv_field) TO <fs_raison>.

  CLEAR: lv_field.
  MOVE 'P_FLUX-FLUX' TO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.
*-- STOU DEBUT GE-2204
*  IF <fs_flux> = 'RE6M' AND <fs_raison> IS ASSIGNED AND <fs_type> IS ASSIGNED .
*    IF <fs_raison> = '87' AND <fs_type> = 'S'.
*      CLEAR: lv_field.
*      MOVE 'P_FLUX-FIN_PERIODE' TO lv_field.
*      ASSIGN (lv_field) TO <fs_date_releve>.
*    ELSE.
*      CLEAR: lv_field.
*      MOVE 'P_FLUX-DATE_RELEVE' TO lv_field.
*      ASSIGN (lv_field) TO <fs_date_releve>.
*    ENDIF.
*  ELSE.
*    CLEAR: lv_field.
*    MOVE 'P_FLUX-DATE_RELEVE' TO lv_field.
*    ASSIGN (lv_field) TO <fs_date_releve>.
*  ENDIF.
*-- STOU FIN   GE-2204


  CLEAR: lv_field.
  MOVE 'FLUX-DATE_RELEVE'                 TO lv_field.
  ASSIGN (lv_field)                       TO <fs_date_releve>.

*++ STOU FIN   GE-2200
*
*  CLEAR lv_field.
*  MOVE 'P_FLUX-DATE_RELEVE' TO lv_field.
*  ASSIGN (lv_field) TO <fs_date_releve>.
  CHECK sy-subrc EQ 0.

* Récupération de INT_UI
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).
  IF lv_int_ui IS INITIAL.
  ENDIF.

* Récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.
  IF ls_object-installation IS INITIAL.
  ENDIF.

  p_anlage = ls_object-installation.
  p_date   = <fs_date_releve>.

ENDFORM.
*----------------------------------------------------------------------*
* Recherche et récupération des relèves estimées
* postérieures à la date donnée en paramètre
*----------------------------------------------------------------------*
FORM selection_releves_estimees
               TABLES pt_eabl  STRUCTURE eabl
                USING p_anlage TYPE anlage
                      p_date   TYPE dats.

* sélection des relèves estimées de l'installation
  SELECT b~ablbelnr b~adatsoll b~ablestyp
    APPENDING CORRESPONDING FIELDS OF TABLE pt_eabl
               FROM eablg AS a
         INNER JOIN eabl  AS b
                 ON a~ablbelnr = b~ablbelnr
    WHERE a~anlage    EQ p_anlage
      AND a~unterdr   NE 'X'
      AND a~adatsoll  GE p_date
      AND b~istablart EQ '03'.

ENDFORM.
*----------------------------------------------------------------------*
* Relèves postérieures mises à jour
* Appel de la transaction EL29
*----------------------------------------------------------------------*

FORM nouvelles_estimations_releves TABLES pt_eabl  STRUCTURE eabl
                                    USING p_anlage TYPE anlage.
  DATA: lv_date(10) TYPE c.
  DATA: lv_message  TYPE char255.
  DATA: bdcdata     LIKE bdcdata    OCCURS 0 WITH HEADER LINE.
  DATA: bdcmsgcoll  LIKE bdcmsgcoll OCCURS 0 WITH HEADER LINE.

  LOOP AT pt_eabl.
    CLEAR : bdcdata,
            bdcdata[],
            bdcmsgcoll,
            bdcmsgcoll[].

    CONCATENATE pt_eabl-adatsoll+6(2)
                '.'
                pt_eabl-adatsoll+4(2)
                '.'
                pt_eabl-adatsoll(4)
           INTO lv_date.

    PERFORM bdc_dynpro  TABLES bdcdata
                         USING 'SAPLEL01'
                               '0120'.
    PERFORM bdc_field   TABLES bdcdata
                         USING 'BDC_OKCODE'
                               '/00'.
    PERFORM bdc_field   TABLES bdcdata
                         USING 'RELX1-ANLAGE_T'
                               'X'.
    PERFORM bdc_field   TABLES bdcdata
                         USING 'REL28D-ANLAGE'
                               p_anlage.
    PERFORM bdc_field   TABLES bdcdata
                         USING 'REL28D-ADAT'
                               lv_date.

    PERFORM bdc_dynpro  TABLES bdcdata
                         USING 'SAPLEL01' '0240'.
    PERFORM bdc_field   TABLES bdcdata
                         USING 'BDC_OKCODE'
                               '=ESTM'.
    PERFORM bdc_field   TABLES bdcdata
                         USING 'REABLD-LINE_MARK(01)'
                               'X'.
    PERFORM bdc_dynpro  TABLES bdcdata
                         USING 'SAPLEL01'
                               '0240'.
    PERFORM bdc_field   TABLES bdcdata
                         USING 'BDC_OKCODE'
                               '=SAVE'.

    CALL TRANSACTION 'EL29' USING bdcdata
                            MODE 'N'
                            MESSAGES INTO bdcmsgcoll.

    LOOP AT bdcmsgcoll WHERE msgtyp NE 'I'.
*      CONCATENATE 'La relève n°' pt_eabl-ablbelnr
*                  'à la date du' lv_date
*                  'n''a pas été estimée'
*             INTO lv_message SEPARATED BY space.
      MESSAGE ID bdcmsgcoll-msgid
            TYPE bdcmsgcoll-msgtyp
          NUMBER bdcmsgcoll-msgnr
            INTO lv_message
            WITH bdcmsgcoll-msgv1
                 bdcmsgcoll-msgv2
                 bdcmsgcoll-msgv3
                 bdcmsgcoll-msgv4.
    ENDLOOP.
  ENDLOOP.
ENDFORM.

*----------------------------------------------------------------------*
* Nouvel écran
*----------------------------------------------------------------------*
FORM bdc_dynpro TABLES pt_bdcdata STRUCTURE bdcdata
                 USING p_program
                       p_dynpro.

  CLEAR pt_bdcdata.
  pt_bdcdata-program  = p_program.
  pt_bdcdata-dynpro   = p_dynpro.
  pt_bdcdata-dynbegin = 'X'.
  APPEND pt_bdcdata.

ENDFORM.
*----------------------------------------------------------------------*
* Insertion d'un champ d'écran
*----------------------------------------------------------------------*
FORM bdc_field TABLES pt_bdcdata STRUCTURE bdcdata
                USING p_fnam
                      p_fval.

  CLEAR pt_bdcdata.
  pt_bdcdata-fnam = p_fnam.
  pt_bdcdata-fval = p_fval.
  APPEND pt_bdcdata.

ENDFORM.
