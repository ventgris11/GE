* regenerated at 16.10.2018 16:49:50
FUNCTION-POOL ZBTZ_F03                   MESSAGE-ID SV.

* INCLUDE LZBTZ_F03D...                      " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZBTZ_F03T00                            . "view rel. data dcl.
