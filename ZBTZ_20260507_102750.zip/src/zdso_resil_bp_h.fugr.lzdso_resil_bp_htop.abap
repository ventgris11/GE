* regenerated at 21.04.2019 17:54:28
FUNCTION-POOL ZDSO_RESIL_BP_H            MESSAGE-ID SV.

* INCLUDE LZDSO_RESIL_BP_HD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDSO_RESIL_BP_HT00                     . "view rel. data dcl.
