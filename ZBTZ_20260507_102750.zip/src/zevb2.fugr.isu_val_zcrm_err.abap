FUNCTION isu_val_zcrm_err.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(X_TE327) LIKE  TE327 STRUCTURE  TE327
*"  CHANGING
*"     REFERENCE(XY_OBJ) TYPE  ISU2A_BILLING_DATA
*"     REFERENCE(XY_OUTCNSO) LIKE  ERCHO-OUTCNSO
*"  EXCEPTIONS
*"      GENERAL_FAULT
*"----------------------------------------------------------------------
  DATA: werchz    LIKE erchz,
        nettobtr  LIKE erchz-nettobtr,
        outsorted TYPE c,
        deviation LIKE ercho-deviation.

  DATA:
    lr_cl_crm        TYPE REF TO cl_crm_activities_util,
    lv_rfcdest       TYPE rfcdest,
    lv_code_retour   TYPE i.


  CREATE OBJECT lr_cl_crm.

  TRY.
      CALL METHOD lr_cl_crm->if_crm_uiu_destinations~get_crm_destination
        RECEIVING
          rv_rfcdest = lv_rfcdest.

    CATCH cx_crm_erp_activities.
* Accès à l'instance CRM/IS-U impossible => Vérifiez la connexion
      MESSAGE e085(zintf_e_messages) RAISING general_fault.
  ENDTRY.

  CALL FUNCTION 'ZREPL_CHECK_BLOCAGE' DESTINATION lv_rfcdest
    EXPORTING
      iv_contract_isu  = xy_obj-st-vertrag
      iv_date          = sy-datum
    IMPORTING
      ev_code_retour   = lv_code_retour
      ev_blocage_found = outsorted.

  deviation =  lv_code_retour.
*FIN-IBE-20210625-GE-11522

  IF NOT outsorted IS INITIAL.
    CALL FUNCTION 'ISU_OUTSORT_IERCHO_WRITE'
      EXPORTING
        x_validation = x_te327-validation
        x_deviation  = deviation
      CHANGING
        xy_iercho    = xy_obj-bill-iercho
        xy_outcnso   = xy_outcnso.
  ENDIF.
ENDFUNCTION.
