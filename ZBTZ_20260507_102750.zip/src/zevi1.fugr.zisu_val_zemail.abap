FUNCTION zisu_val_zemail.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(X_TE328) LIKE  TE328 STRUCTURE  TE328
*"  CHANGING
*"     REFERENCE(XY_OBJ) TYPE  ISU21_INVOICE_UNIT
*"     REFERENCE(XY_OUTCNSO) LIKE  ERDO-OUTCNSO
*"  EXCEPTIONS
*"      GENERAL_FAULT
*"----------------------------------------------------------------------
  DATA: deviation LIKE ercho-deviation,
        outsorted TYPE c,
        amount    LIKE erdk-total_amnt.

*DEB-IBEN-20210127-GE-10455
  DATA: ld_type_envoi TYPE zisu_type_envoi-type_envoi,
        lt_bapiadsmtp TYPE TABLE OF bapiadsmtp.

  SELECT SINGLE type_envoi INTO ld_type_envoi
  FROM zisu_type_envoi
  WHERE sendcontrol_rh = xy_obj-print_doc-erdk-zzsendcontrol_rh
  AND coprc = xy_obj-print_doc-erdk-zzcoprc
  AND ctrl_zemail = 'X'.

  CHECK sy-subrc = 0.

  CALL FUNCTION 'BAPI_BUPA_ADDRESS_GETDETAIL'
    EXPORTING
      businesspartner = xy_obj-print_doc-erdk-zzdest_fact
    TABLES
      bapiadsmtp      = lt_bapiadsmtp
    .

  IF lt_bapiadsmtp[] IS INITIAL.
    outsorted = 'X'.
  ENDIF.
*FIN-IBEN-20210127-GE-10455

  IF NOT outsorted IS INITIAL.
    CALL FUNCTION 'ISU_OUTSORT_IERDO_WRITE'
      EXPORTING
        x_validat_in = x_te328-validat_in
        x_deviation  = deviation
      CHANGING
        xy_ierdo     = xy_obj-print_doc-t_erdo
        xy_outcnso   = xy_outcnso.
  ENDIF.
ENDFUNCTION.
