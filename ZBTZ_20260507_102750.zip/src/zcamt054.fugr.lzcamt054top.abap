* regenerated at 17.07.2018 19:01:49
FUNCTION-POOL ZCAMT054                   MESSAGE-ID SV.

* INCLUDE LZCAMT054D...                      " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCAMT054T00                            . "view rel. data dcl.
