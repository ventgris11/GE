*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 21.04.2019 at 17:54:28
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZDSO_RESIL_BP_H.................................*
DATA:  BEGIN OF STATUS_ZDSO_RESIL_BP_H               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDSO_RESIL_BP_H               .
CONTROLS: TCTRL_ZDSO_RESIL_BP_H
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDSO_RESIL_BP_H               .
TABLES: ZDSO_RESIL_BP_H                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
