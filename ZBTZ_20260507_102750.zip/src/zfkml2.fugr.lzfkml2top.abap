FUNCTION-POOL zfkml2.                        "MESSAGE-ID ..


TYPES : BEGIN OF ty_poste,
             selw1    TYPE selw1_kk,
             betrz    TYPE betrz_kk ,
             facture  TYPE e_printdoc  ,
        END OF ty_poste.


DATA : gt_postes TYPE TABLE OF ty_poste ,
       gs_poste  TYPE          ty_poste ,

       gt_erdk   TYPE TABLE OF erdk,
       gs_erdk   TYPE erdk         .

FIELD-SYMBOLS <fs_poste> TYPE ty_poste.
