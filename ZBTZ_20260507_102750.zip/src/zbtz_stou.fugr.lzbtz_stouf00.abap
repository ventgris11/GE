*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 31.07.2017 at 14:56:04
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
