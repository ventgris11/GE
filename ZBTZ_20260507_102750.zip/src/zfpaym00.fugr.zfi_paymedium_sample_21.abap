FUNCTION ZFI_PAYMEDIUM_SAMPLE_21 .
*"--------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(I_FPAYH) LIKE  FPAYH STRUCTURE  FPAYH
*"     VALUE(I_FPAYHX) LIKE  FPAYHX STRUCTURE  FPAYHX
*"     VALUE(I_FORMAT_PARAMS) TYPE  FPM_SELPAR-PARAM
*"     VALUE(I_FORMAT_PARAMS_C) TYPE  FPM_SELPAR-PARAM
*"     VALUE(I_FILENAME) LIKE  REGUT-FSNAM
*"     VALUE(I_XFILESYSTEM) TYPE  DFILESYST
*"  TABLES
*"      T_FILE_OUTPUT STRUCTURE  FPM_FILE
*"  CHANGING
*"     REFERENCE(C_FILENAME) LIKE  REGUT-FSNAM
*"--------------------------------------------------------------------

DATA  :
    c_date          TYPE char8,
    lt_nom_paiement TYPE TABLE OF znom_paiement,
    ls_nom_paiement TYPE znom_paiement.

  WRITE sy-datum TO c_date DDMMYY.


  SELECT * INTO TABLE lt_nom_paiement FROM znom_paiement.
  IF sy-subrc = 0.
    LOOP AT lt_nom_paiement INTO ls_nom_paiement.
      IF c_filename CS ls_nom_paiement-fichier_src.
        EXIT.
      ELSE.
        CLEAR ls_nom_paiement.
      ENDIF.
    ENDLOOP.
  ENDIF.

  IF ls_nom_paiement IS NOT INITIAL.
    IF ls_nom_paiement-changdate <> sy-datum.
      ls_nom_paiement-changdate = sy-datum.
      CLEAR ls_nom_paiement-sequence.
    ENDIF.
    ADD 1 TO ls_nom_paiement-sequence.
    CONCATENATE ls_nom_paiement-fichier_cbl ls_nom_paiement-sequence
'_' c_date '_' sy-uzeit INTO c_filename.
    MODIFY znom_paiement FROM ls_nom_paiement.
  ELSE.
    CONCATENATE c_filename '_' c_date '_' sy-uzeit INTO c_filename.
  ENDIF.



ENDFUNCTION.
