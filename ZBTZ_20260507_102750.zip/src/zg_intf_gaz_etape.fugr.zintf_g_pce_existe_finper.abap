FUNCTION zintf_g_pce_existe_finper .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA: lc_field_num_pce     TYPE fieldname VALUE 'NUM_PCE',
        lc_field_date_releve TYPE fieldname VALUE 'DATE_RELEVE',
        lc_field_flux        TYPE fieldname VALUE 'FLUX',
        lc_field_emetteur    TYPE fieldname VALUE 'EMETTEUR',
        lc_field_idenreg     TYPE fieldname VALUE 'IDENREG',
        lv_field             TYPE string,
        lv_int_ui            TYPE int_ui,
        lv_message           TYPE char255,
        installation         TYPE TABLE OF  bapiisupodinstln,
        lv_date              TYPE dats,
        ls_bpem              TYPE zbpem_flux_struct,
        lv_interface         TYPE zisu_flxid.


  FIELD-SYMBOLS: <fs_num_pce>,  <fs_date_releve>, <fs_emetteur>,
                 <fs_flux>, <fs_idenreg>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_emetteur INTO lv_field.
  ASSIGN (lv_field) TO <fs_emetteur>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_flux INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_idenreg INTO lv_field.
  ASSIGN (lv_field) TO <fs_idenreg>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_releve>.

  IF <fs_date_releve> IS ASSIGNED AND <fs_num_pce> IS ASSIGNED.
    lv_date = <fs_date_releve>.
    "on check l'existence d'une installation à J-1 de la date de relève
    CALL FUNCTION 'BAPI_ISUPOD_GETINSTALLATION'
      EXPORTING
        pointofdelivery = <fs_num_pce>
        keydate         = lv_date
*       REFRESH_BUFFER  = ' '
      TABLES
        installation    = installation
*       RETURN          =
      .

    IF installation IS INITIAL.
      MESSAGE e210(zintf_g_messages) WITH <fs_emetteur> <fs_flux>
<fs_idenreg> <fs_num_pce> INTO lv_message.

      CLEAR ls_bpem.
      ls_bpem-num_pce = <fs_num_pce>.
      CASE <fs_flux>.
        WHEN 'ADIF'.
          ls_bpem-date_effet_cont = <fs_date_releve>.
        WHEN 'RE6M' OR 'RE1M' OR 'REMM' OR 'REJJ' OR 'REJM'.
          ls_bpem-date_releve     = <fs_date_releve>.
        WHEN 'AFAC'.
          ls_bpem-date_fin_prest  = <fs_date_releve>.
      ENDCASE.

      lv_interface    = <fs_flux> .
      ls_bpem-idenreg = <fs_idenreg>.
      CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
        EXPORTING
          iv_interface_name = lv_interface
          iv_sparte         = 'ZG'
          is_structure      = ls_bpem.

      ev_etape = 2.
    ELSE.
      ev_etape = 1.
    ENDIF.
  ELSE.
    "Erreur technique
  ENDIF.

ENDFUNCTION.
