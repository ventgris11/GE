FUNCTION zfkk_sample_0234.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(I_FKKZK) TYPE  DFKKZK
*"----------------------------------------------------------------------

  IF i_fkkzk-keyz1 CS 'TCFE'.
    "Ne rien envoyer à SPLIO
  ELSE.
* Appel SPLIO
    CALL METHOD zcl_demat=>send_event_confirm_paiement
      EXPORTING
        iv_paiement = i_fkkzk-keyz1
      EXCEPTIONS
        error       = 1
        OTHERS      = 2.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.
  ENDIF.

ENDFUNCTION.
