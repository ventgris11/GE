* regenerated at 21.04.2019 16:50:39
FUNCTION-POOL ZDSO_RESIL_BP              MESSAGE-ID SV.

* INCLUDE LZDSO_RESIL_BPD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDSO_RESIL_BPT00                       . "view rel. data dcl.
