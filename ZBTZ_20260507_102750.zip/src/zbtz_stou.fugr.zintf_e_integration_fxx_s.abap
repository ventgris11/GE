FUNCTION ZINTF_E_INTEGRATION_FXX_S.
*"--------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_IDENREG) TYPE  ZIDENREG
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN DEFAULT ABAP_FALSE
*"     REFERENCE(IV_ID_FLUX) TYPE  ZID_FLUX
*"  EXPORTING
*"     REFERENCE(EV_ERROR) TYPE  CRMT_BOOLEAN
*"--------------------------------------------------------------------

  DATA: ls_id_enreg             TYPE zintf_g_donnees_generique,
        lv_log_handle           TYPE balloghndl,
        lv_art_sd_remise_grd    TYPE rvari_val_255,
        lt_fxx                  TYPE TABLE OF zintf_e_fxx,
        lt_fxx_temp             TYPE TABLE OF zintf_e_fxx,
        lv_num_dossier_affaire  TYPE string,
*        ls_fxx                 TYPE zintf_e_fxx,
        ls_temp_fxx             TYPE zintf_e_fxx,
        ls_fxx_temp             TYPE zintf_e_fxx,
        lv_int_ui               TYPE int_ui,
        lv_pourcent_rem_grd     TYPE wert,
        lv_taux_rem             TYPE betrw_kk,
        lv_ko                   TYPE flag,
        lv_bukrs                TYPE stdbk_kk,
        lv_blocage              TYPE flag,
        lv_sparte               TYPE sparte,
        lv_posnr                TYPE posnr,
*        lv_message              TYPE string,
        lr_switch_doc           TYPE REF TO cl_isu_ide_switchdoc,
        ls_switch_doc           TYPE eideswtdoc,
        ls_object               TYPE eedm_isu_objects,
        lt_mr_data              TYPE TABLE OF bapieabl,
        lt_mr_reason            TYPE TABLE OF bapieablg,
        lv_date                 TYPE datum,
        ls_sales_order_header   TYPE zisus_sales_order_header,
        lt_sales_order_header   TYPE TABLE OF zisus_sales_order_header,
        ls_sales_order_item     TYPE zisus_sales_order_item,
        lt_debit_note_item_tmp  TYPE zisut_sales_order_item,
        lt_credit_note_item_tmp TYPE zisut_sales_order_item,
        lt_debit_note_item      TYPE zisut_sales_order_item,
        lt_credit_note_item     TYPE zisut_sales_order_item,
        lv_vbeln                TYPE vbeln,
        lt_return               TYPE bapiret2_t,
        ls_return               TYPE bapiret2,
        lv_anlage               TYPE anlage,
        lv_temp_matnr           TYPE string,
        lv_emetteur             TYPE zemetteur_id,
        lv_idenreg              TYPE zintf_g_id_enreg,
        lv_id_evt               TYPE string,
        lv_fin                  TYPE string,
        v_date                  TYPE zdate_fin_frais.

  CLEAR ev_error.

  lv_log_object    = lc_log_object_intf_elec.
  IF iv_id_flux = 'F03A'.
    lv_log_subobject = lc_log_subobject_f03.
  ELSEIF iv_id_flux = 'F15D'.
    lv_log_subobject = lc_log_subobject_f15.

  ENDIF.
  lv_msgid         = lc_msgid_intf_elec.

* Appel en mode &1 pour le flux &2
  IF 1 = 2. MESSAGE i018(zintf_e_messages). ENDIF.
  IF iv_mode_test IS INITIAL.
    macro_add_msg_to_log 'I' '018'
                         'REEL' iv_id_flux '' ''.
  ELSE.
    macro_add_msg_to_log 'I' '018'
                         'TEST' iv_id_flux '' ''.
  ENDIF.

  IF iv_id_flux = 'F03A'.
* Sélection des données à traiter
    SELECT * FROM zintf_e_f03a
    INTO TABLE lt_fxx
    WHERE idenreg EQ iv_idenreg.

    SORT lt_fxx BY num_dossier id_prm.

  ELSEIF iv_id_flux = 'F15D'.
* Sélection des données à traiter
    SELECT * FROM zintf_e_f15d
    APPENDING CORRESPONDING FIELDS OF TABLE lt_fxx
    WHERE idenreg EQ iv_idenreg.

    SORT lt_fxx BY id_affaire id_prm.
  ENDIF.


  LOOP AT lt_fxx INTO ls_fxx.

    CLEAR : lv_blocage, ls_sales_order_item, ls_sales_order_header,
lv_ko.
    REFRESH :
    lt_sales_order_header,
    lt_debit_note_item,
    lt_credit_note_item.

    ls_temp_fxx = ls_fxx.
*   fxx : Traitement de l'enregistrement &1

    IF 1 = 2. MESSAGE i164(zintf_e_messages). ENDIF.

    macro_add_msg_to_log 'I' '164'
                             ls_fxx-idenreg '' '' ''.

**************************************************************
*******Etape n°1 : Vérifier si la ligne est pertinente *******
**************************************************************

    IF iv_id_flux = 'F03A'.



      IF ls_temp_fxx-groupe_article <> 'G2'.
        IF 1 = 2. MESSAGE i162(zintf_e_messages) INTO lv_message. ENDIF.

        macro_add_msg_to_log 'I' '162' '' '' '' ''.

        PERFORM update_ligne_fxx USING lc_statut_11_filtre iv_id_flux.


        CONTINUE.
      ENDIF.

      lv_num_dossier_affaire = ls_temp_fxx-num_dossier.
      lv_temp_matnr = ls_temp_fxx-id_article.

    ELSEIF iv_id_flux = 'F15D'.

      IF ls_temp_fxx-nature_e_v <> '002'.
        IF 1 = 2. MESSAGE i162(zintf_e_messages) INTO lv_message. ENDIF.

        macro_add_msg_to_log 'I' '162' '' '' '' ''.

        PERFORM update_ligne_fxx USING lc_statut_11_filtre iv_id_flux.

        CONTINUE.
      ENDIF.

      lv_num_dossier_affaire = ls_temp_fxx-id_affaire.
      SPLIT ls_temp_fxx-id_e_v AT '-' INTO lv_id_evt lv_fin.
      lv_temp_matnr = lv_id_evt.
    ENDIF.


****************************************************
*******Etape n°2 : Vérifier l’existence du PCE*******
****************************************************
*    IF ls_temp_fxx-DATE_FIN_FRAIS GE sy-datum.
    lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num =
ls_temp_fxx-id_prm ).
    IF lv_int_ui IS INITIAL.

      IF 1 = 2. MESSAGE e160(zintf_e_messages). ENDIF.

      macro_add_msg_to_log 'E' '160' ls_temp_fxx-id_prm '' '' ''.

      PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.

      CONTINUE.

    ENDIF.


****************************************************
*******Etape n°3.2 : Récupération des données pour commande SD  *******
****************************************************
    "    ON CHANGE OF ls_temp_fxx-id_demande_intern.
    CLEAR : ls_sales_order_header, lv_posnr.

    v_date = ls_temp_fxx-date_fin_frais.


* Récupération de l'installation
    SELECT SINGLE anlage
                  FROM euiinstln
                  INTO lv_anlage
                  WHERE int_ui EQ lv_int_ui
                  AND   datefrom LE v_date
                  AND   dateto GE v_date.

    IF sy-subrc EQ 0.

      SELECT SINGLE sparte
        FROM eanl
        INTO lv_sparte
        WHERE anlage = lv_anlage.

* Récupération du partenaire, du compte de contrats et des conditions
*de paiement
      SELECT SINGLE fkkvkp~gpart fkkvkp~vkont fkkvkp~stdbk
        "fkkvkp~zahlkond
INTO (ls_sales_order_header-partn_numb,
ls_sales_order_header-fkk_conacct, lv_bukrs )
        ",ls_sales_order_header-pmnttrms )
FROM ever AS ever
INNER JOIN fkkvkp AS fkkvkp
ON fkkvkp~vkont EQ ever~vkonto
WHERE ever~anlage  EQ lv_anlage
AND   ever~einzdat LE v_date
AND   ever~auszdat GE v_date.
      IF sy-subrc NE 0.
        lv_ko = 'X'.
      ENDIF.
    ELSE.
      lv_ko = 'X'.
    ENDIF.

* Récupération des dates de document et de prix en en-tête
    IF lv_ko IS INITIAL.
      ls_sales_order_header-doc_date = sy-datum.
      ls_sales_order_header-price_date = sy-datum.
      ls_sales_order_header-doc_type = 'ZDIS'.
      ls_sales_order_header-purch_no_c = ls_temp_fxx-id_prm.
      ls_sales_order_header-req_date_h = ls_temp_fxx-date_fin_frais.
      ls_sales_order_header-id_demande_intern =
lv_num_dossier_affaire.
      ls_sales_order_header-bill_date = sy-datum.
      INSERT ls_sales_order_header INTO TABLE lt_sales_order_header.

    ELSE.
      IF 1 = 2.
        MESSAGE e163(zintf_e_messages) WITH
ls_temp_fxx-id_prm INTO lv_message. ENDIF.

        macro_add_msg_to_log 'E' '163' '' '' '' ''.

        PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.

        CONTINUE.

      ENDIF.

      IF lv_ko IS INITIAL.
**************************************************************
******* Etape n°3.1 : Blocage des postes     *******
**************************************************************

        SELECT SINGLE *
        FROM zparam_sd
        WHERE
        matnr = lv_temp_matnr
        AND
        bukrs = lv_bukrs.

        IF sy-subrc = 0.
          lv_blocage = 'X'.
        ENDIF.

*Gestion des items
        lv_posnr = lv_posnr + 10.
        ls_sales_order_item-posnr = lv_posnr.
       "          CONCATENATE 'D' ls_temp_fxx-id_art INTO lv_temp_matnr.

        ls_sales_order_item-matnr = lv_temp_matnr.
        ls_sales_order_item-bstdk = ls_temp_fxx-date_deb_frais.

        IF lv_blocage IS NOT INITIAL.
          ls_sales_order_item-bill_block = '09'.
        ENDIF.

        ls_sales_order_item-bstdk_e = ls_temp_fxx-date_fin_frais.
        ls_sales_order_item-ref_1 = lv_num_dossier_affaire.

        ls_sales_order_item-kbetr = ls_temp_fxx-mt_ht.
        ls_sales_order_item-waers = 'EUR'.

        ls_sales_order_item-id_demande_intern =
  lv_num_dossier_affaire.
        ls_sales_order_item-emetteur = ls_temp_fxx-emetteur.
        ls_sales_order_item-idenreg = ls_temp_fxx-idenreg.

**Ajout de la gestion des dates :
        IF iv_id_flux = 'F03A'.
          IF ls_temp_fxx-code_debit_credit EQ 'Y'.
            " Poste des notes de débit
            ls_sales_order_item-kschl = 'ZPRE'.
            APPEND ls_sales_order_item TO lt_debit_note_item.

          ELSEIF ls_temp_fxx-code_debit_credit EQ 'Z'.
            "Poste des notes de crédit
            ls_sales_order_item-kschl = 'ZPRC'.
            APPEND ls_sales_order_item TO lt_credit_note_item.

          ENDIF.
        ELSEIF iv_id_flux = 'F15D'.

          IF ls_temp_fxx-id_e_v CS '-A'.
            "Poste des notes de crédit
            ls_sales_order_item-kschl = 'ZPRC'.
            APPEND ls_sales_order_item TO lt_credit_note_item.
          ELSE.
            " Poste des notes de débit
            ls_sales_order_item-kschl = 'ZPRE'.
            APPEND ls_sales_order_item TO lt_debit_note_item.
          ENDIF.
        ENDIF.


        SELECT SINGLE string1
        INTO lv_art_sd_remise_grd
        FROM ettifn
        WHERE anlage = lv_anlage
        AND operand = 'EUDRPGRD'
        AND ab LE ls_temp_fxx-date_deb_frais
        AND bis GE ls_temp_fxx-date_deb_frais.
*<<<IBE-06/07/2017-Adaptation B2C
        IF sy-subrc = 0.
SELECT SINGLE kondm INTO lv_art_sd_remise_grd FROM mvke WHERE matnr = ls_temp_fxx-id_article
AND vkorg = 'GDP2'
AND vtweg = 'Z1'
AND kondm = lv_art_sd_remise_grd.
        ENDIF.
*IBE>>>
        IF sy-subrc = 0.
*<<<IBE-10/07/2017-Adaptation Interface Frais éligible au blocage
*  S'il y a la remise à appliquer, on met le statut en rejet l’enregistrement
* (message d'erreur: Remise appliquée sur l'article bloqué à la facturation SD ) sans créer la commande
          IF lv_blocage IS NOT INITIAL.
            IF 1 = 2. MESSAGE e120(zintf_e_messages). ENDIF.

            macro_add_msg_to_log 'E' '120' ls_temp_fxx-id_prm '' '' ''.

           PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.

            CONTINUE.
          ENDIF.
*IBE>>>
          SELECT SINGLE low
             INTO lv_art_sd_remise_grd
             FROM tvarvc
            WHERE name EQ 'ZINTF_E_ART_SD_REMISE_GRD'.

          SELECT SINGLE wert1
          INTO lv_pourcent_rem_grd
          FROM ettifn
          WHERE anlage = lv_anlage
          AND operand = 'EFCRPGRD'
          AND ab LE ls_temp_fxx-date_deb_frais
          AND bis GE ls_temp_fxx-date_deb_frais.

          lv_taux_rem =
          lv_pourcent_rem_grd / 100.

          IF sy-subrc = 0.

            "Gestion des items
            lv_posnr = lv_posnr + 10.
            ls_sales_order_item-posnr = lv_posnr.
       "          CONCATENATE 'D' ls_temp_fxx-id_art INTO lv_temp_matnr.
            lv_temp_matnr = lv_art_sd_remise_grd.
            ls_sales_order_item-matnr = lv_temp_matnr.
            ls_sales_order_item-bstdk = ls_temp_fxx-date_deb_frais.

            IF lv_blocage IS NOT INITIAL.
              ls_sales_order_item-bill_block = '09'.
            ENDIF.

            ls_sales_order_item-bstdk_e = ls_temp_fxx-date_fin_frais.
            ls_sales_order_item-ref_1 = lv_num_dossier_affaire.

            ls_sales_order_item-kbetr = ls_temp_fxx-mt_ht
                                      *  lv_taux_rem * -1.
            IF  ls_sales_order_item-kschl = 'ZPRE'.
              ls_sales_order_item-kschl = 'ZPRC'.
            ELSEIF  ls_sales_order_item-kschl = 'ZPRC'.
              ls_sales_order_item-kschl = 'ZPRE'.
            ENDIF.
            ls_sales_order_item-waers = 'EUR'.

            ls_sales_order_item-id_demande_intern =
      lv_num_dossier_affaire.
            ls_sales_order_item-emetteur = ls_temp_fxx-emetteur.
            ls_sales_order_item-idenreg = ls_temp_fxx-idenreg.

            APPEND ls_sales_order_item TO lt_credit_note_item.
          ENDIF.

        ENDIF.
      ENDIF. "lv ko is intial
      "MFO  ENDLOOP.

      SORT lt_sales_order_header BY id_demande_intern.
      SORT lt_debit_note_item BY id_demande_intern.

      LOOP AT lt_debit_note_item INTO ls_sales_order_item.
****************************************************
*******Etape n°4 : Création d’une note de débit  *******
****************************************************
        INSERT ls_sales_order_item INTO TABLE lt_debit_note_item_tmp.
        lv_emetteur = ls_sales_order_item-emetteur.
        lv_idenreg  = ls_sales_order_item-idenreg.
        READ TABLE lt_sales_order_header INTO ls_sales_order_header WITH
  KEY id_demande_intern = ls_sales_order_item-id_demande_intern.
        AT END OF id_demande_intern.
          IF  ls_sales_order_header IS NOT INITIAL.
            CALL METHOD zcl_tool=>create_sales_order
              EXPORTING
                is_sales_order_header = ls_sales_order_header
                it_sales_order_item   = lt_debit_note_item_tmp
                iv_spart              = lv_sparte
                iv_societe_div        = lv_bukrs
              IMPORTING
                et_return             = lt_return
              RECEIVING
                ev_vbeln              = lv_vbeln.

            IF lv_vbeln IS NOT INITIAL.

              IF 1 = 2.
                MESSAGE i167(zintf_e_messages) WITH
         lv_vbeln
  ls_sales_order_item-id_demande_intern INTO lv_message. ENDIF.

                macro_add_msg_to_log 'I' '167' lv_vbeln '' '' ''.

         PERFORM update_ligne_fxx USING lc_statut_07_integre iv_id_flux.



              ELSE.


                READ TABLE lt_return INTO ls_return WITH KEY type = 'E'.
                "fxx : &1 &2 &3 &4

                IF 1 = 2.
                  MESSAGE e158(zintf_e_messages) WITH
ls_temp_fxx-emetteur
ls_temp_fxx-idenreg ls_return-message INTO lv_message. ENDIF.

                  macro_add_msg_to_log 'E' '158' ls_return-message
                   '' '' ''.

           PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.

                  CONTINUE.

                ENDIF.

                CLEAR lt_debit_note_item_tmp.
              ENDIF.
            ENDAT.
          ENDLOOP.
****************************************************
*******Etape n°5 : Création d’une note de crédit*******
****************************************************
          SORT lt_credit_note_item BY id_demande_intern.
          LOOP AT lt_credit_note_item INTO ls_sales_order_item.
          INSERT ls_sales_order_item INTO TABLE lt_credit_note_item_tmp.
            lv_emetteur = ls_sales_order_item-emetteur.
            lv_idenreg  = ls_sales_order_item-idenreg.
        READ TABLE lt_sales_order_header INTO ls_sales_order_header WITH
  KEY id_demande_intern = ls_sales_order_item-id_demande_intern.
            AT END OF id_demande_intern.
              IF  ls_sales_order_header IS NOT INITIAL.
                CALL METHOD zcl_tool=>create_sales_order
                  EXPORTING
                    is_sales_order_header = ls_sales_order_header
                    it_sales_order_item   = lt_credit_note_item_tmp
                    iv_spart              = lv_sparte
                    iv_societe_div        = lv_bukrs
                  IMPORTING
                    et_return             = lt_return
                  RECEIVING
                    ev_vbeln              = lv_vbeln.

                IF lv_vbeln IS NOT INITIAL.
                  IF 1 = 2.
                    MESSAGE i167(zintf_e_messages) WITH
       lv_vbeln
INTO lv_message. ENDIF.

                    macro_add_msg_to_log 'I' '167'  lv_vbeln '' '' ''.

         PERFORM update_ligne_fxx USING lc_statut_07_integre iv_id_flux.



                  ELSE.

                READ TABLE lt_return INTO ls_return WITH KEY type = 'E'.
                    "fxx : &1 &2 &3 &4

                    IF 1 = 2.
                      MESSAGE e158(zintf_e_messages) WITH
ls_temp_fxx-emetteur
ls_temp_fxx-idenreg ls_return-message INTO lv_message. ENDIF.

                      macro_add_msg_to_log 'E' '158'
                      ls_return-message '' '' ''.

           PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.

                      CONTINUE.

                    ENDIF.

                    CLEAR lt_credit_note_item_tmp.
                  ENDIF.

                ENDAT.
              ENDLOOP.
              IF iv_mode_test IS INITIAL.
                COMMIT WORK AND WAIT.
              ELSE.
                ROLLBACK WORK.
              ENDIF.

            ENDLOOP.

            IF iv_mode_test IS INITIAL.
              COMMIT WORK AND WAIT.
            ELSE.
              ROLLBACK WORK.
            ENDIF.

          ENDFUNCTION.


FORM update_ligne_fxx USING ev_statut TYPE zintf_g_statut
      ev_id_flux TYPE zid_flux.

  DATA:
  lv_texte_statut TYPE text30.

  CASE ev_statut.
    WHEN '01'. lv_texte_statut = 'A intégrer               '.
    WHEN '02'. lv_texte_statut = 'A rejouer                '.
    WHEN '03'. lv_texte_statut = 'MEA - Synchronisation CRM'.
    WHEN '04'. lv_texte_statut = 'MEA - Rejet              '.
    WHEN '05'. lv_texte_statut = 'Acquitté                 '.
    WHEN '06'. lv_texte_statut = 'Rejet                    '.
    WHEN '07'. lv_texte_statut = 'Intégré                  '.
    WHEN '10'. lv_texte_statut = 'En attente d''action CRM  '.
    WHEN '11'. lv_texte_statut = 'Filtré                   '.
    WHEN '12'. lv_texte_statut = 'Synchronisé              '.
    WHEN '13'. lv_texte_statut = 'Gelé                     '.
    WHEN '14'. lv_texte_statut = 'Action manuelle          '.
    WHEN '15'. lv_texte_statut = 'MEA - Action manuelle    '.
    WHEN '16'. lv_texte_statut = 'MEA - Intégration        '.
  ENDCASE.

* Mise à jour de la ligne fxx
  ls_fxx-statut      = ev_statut.
  ls_fxx-msg         = lv_message.
  ls_fxx-msgty       = sy-msgty.
  ls_fxx-msgid       = sy-msgid.
  ls_fxx-msgno       = sy-msgno.
  ls_fxx-msgv1       = sy-msgv1.
  ls_fxx-msgv2       = sy-msgv2.
  ls_fxx-msgv3       = sy-msgv3.
  ls_fxx-msgv4       = sy-msgv4.
  ls_fxx-date_modif  = sy-datum.
  ls_fxx-heure_modif = sy-uzeit.
  ls_fxx-changedby   = sy-uname.

  IF ev_id_flux = 'F03A'.
    MOVE-CORRESPONDING ls_fxx TO ls_f03a.
    UPDATE zintf_e_f03a FROM ls_f03a.
  ENDIF.

  IF ev_id_flux = 'F15D'.
    MOVE-CORRESPONDING ls_fxx TO ls_f15d.
    UPDATE zintf_e_f15d FROM ls_f15d.
  ENDIF.

  IF 1 = 2. MESSAGE i161(zintf_e_messages). ENDIF.
* PRM &1 Installation &2 Flux &3 => &4
  macro_add_msg_to_log 'I' '161'
                       ls_fxx-idenreg
                       ls_fxx-id_flux
                       ls_fxx-id_prm
                       lv_texte_statut.

ENDFORM.
