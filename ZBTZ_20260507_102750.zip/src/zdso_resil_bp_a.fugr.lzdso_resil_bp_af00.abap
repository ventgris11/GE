*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 21.04.2019 at 17:53:02
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
