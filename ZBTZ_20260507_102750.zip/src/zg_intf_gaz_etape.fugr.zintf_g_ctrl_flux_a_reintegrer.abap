FUNCTION ZINTF_G_CTRL_FLUX_A_REINTEGRER .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
* Modification   (GE-11713)                                            *
* DATE       : 11/10/2021                                              *                                                                                                                                                                      *
* USER       : HBENDHAFER                                              *
* TAG        : HBD                                                     *
* Description: Désactiver l'ancien comportement(en commentaire)        *
*                   -> rediriger vers integration releve spéciale      *
* OT         : DI1K928953                                              *
*"----------------------------------------------------------------------
*&-< Début suppression : HBD-GE-11713
*  DATA:
*    lv_field           TYPE string,
*    lv_pattern         TYPE string,
*    lr_cl_abap_matcher TYPE REF TO cl_abap_matcher.
*
*  FIELD-SYMBOLS:
*    <fs_type_releve>,
*    <fs_raison_releve>.
*
*  CLEAR lv_field.
*  MOVE 'FLUX-TYPE_RELEVE'   TO lv_field.
*  ASSIGN (lv_field) TO <fs_type_releve>.
*
*  CHECK <fs_type_releve> IS ASSIGNED.
*
*  CLEAR lv_field.
*  MOVE 'FLUX-RAISON_RELEVE' TO lv_field.
*  ASSIGN (lv_field) TO <fs_raison_releve>.
*
*  CHECK <fs_raison_releve> IS ASSIGNED.

* Si la raison de relève corrigée a une des valeurs suivantes:
*
* 71 Relève normale
* 72 Relève normale avec index autorelevé
* 73 Relève normale calculée
* 75 Auto Relevé Fournisseur
* 76 Auto-relevé fournisseur sur index réel
*
* la relève corrigée réintégre le processus de la relève normale
* sinon elle réintégre le processus de la relève spéciale
*
*  lv_pattern
*   = '71|72|73|75|76'.
*
*  lr_cl_abap_matcher
*   = cl_abap_matcher=>create( pattern = lv_pattern
*                              text    = <fs_raison_releve> ).
*
*  IF lr_cl_abap_matcher->match( ) IS INITIAL.
*    ev_etape = 2.  "Relève corrigée reprise en tant que relève spéciale
*  ELSE.
*    ev_etape = 1.  "Relève corrigée reprise en tant que relève normale
*  ENDIF.
*&- Fin suppression : HBD-GE-11713  >

  "HBD - GE-11713
 ev_etape = 1. "-Relève corrigée reprise en tant que relève spéciale

ENDFUNCTION.
