* regenerated at 07.04.2019 13:04:36
FUNCTION-POOL ZDSORES_STAT_RG            MESSAGE-ID SV.

* INCLUDE LZDSORES_STAT_RGD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDSORES_STAT_RGT00                     . "view rel. data dcl.
