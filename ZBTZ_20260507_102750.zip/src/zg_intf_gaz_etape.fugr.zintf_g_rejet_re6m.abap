FUNCTION zintf_g_rejet_re6m .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
  DATA:          lv_string  TYPE string,
                 lv_message TYPE char255
                 .

  FIELD-SYMBOLS: <lr_flux>     TYPE any,
                 <lr_struc>    TYPE any,
                 <lr_idenreg>  TYPE any,
                 <lr_emetteur> TYPE any.


  lv_string = 'FLUX-NUM_PCE'.
  ASSIGN (lv_string) TO <lr_struc>.
  lv_string = 'FLUX-IDENREG'.
  ASSIGN (lv_string) TO <lr_idenreg> .
  lv_string = 'FLUX-FLUX'.
  ASSIGN (lv_string) TO <lr_flux> .
  lv_string = 'FLUX-EMETTEUR'.
  ASSIGN (lv_string) TO <lr_emetteur> .

*  MESSAGE e204(zintf_g_messages) WITH <lr_emetteur> <lr_flux> <lr_idenreg> INTO lv_message. "--GE-2362
*++ DEBUT STOU GE-2362
  MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 INTO lv_message.
*++ FIN   STOU GE-2362

  " Mise à jour de la ligne d'ADIF
  lv_string = 'FLUX-STATUT'.
  ASSIGN (lv_string) TO <lr_struc>.
  <lr_struc> = zcl_tool=>gc_statut_rejet.

  lv_string = 'FLUX-MSG'.
  ASSIGN (lv_string) TO <lr_struc>.
  <lr_struc> = lv_message.

  lv_string = 'FLUX-MSGNO'.
  ASSIGN (lv_string) TO <lr_struc>.
  <lr_struc> = sy-msgno.


  lv_string = 'FLUX-MSGTY'.
  ASSIGN (lv_string) TO <lr_struc>.
  <lr_struc> = sy-msgty.

  lv_string = 'FLUX-MSGID'.
  ASSIGN (lv_string) TO <lr_struc>.
  <lr_struc> = sy-msgid.

  lv_string = 'FLUX-MSGV1'.
  ASSIGN (lv_string) TO <lr_struc>.
  <lr_struc> = sy-msgv1.

  lv_string = 'FLUX-MSGV2'.
  ASSIGN (lv_string) TO <lr_struc>.
  <lr_struc> = sy-msgv2.

  lv_string = 'FLUX-MSGV3'.
  ASSIGN (lv_string) TO <lr_struc>.
  <lr_struc> = sy-msgv3.

  lv_string = 'FLUX-MSGV4'.
  ASSIGN (lv_string) TO <lr_struc>.
  <lr_struc> = sy-msgv4.

  ev_etape = 1.

ENDFUNCTION.
