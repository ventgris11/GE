FUNCTION zintf_e_depose_fiap .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_ANLAGE) TYPE  ANLAGE
*"     REFERENCE(IV_DATE_DEPOSE) TYPE  DATS
*"     REFERENCE(IV_ID_FLUX) TYPE  ZID_FLUX
*"     REFERENCE(IV_RES) TYPE  BOOLEAN OPTIONAL
*"     REFERENCE(IV_INDEX_CAD_1) TYPE  ZINDEX
*"     REFERENCE(IV_INDEX_CAD_2) TYPE  ZINDEX OPTIONAL
*"     REFERENCE(IV_INDEX_CAD_3) TYPE  ZINDEX OPTIONAL
*"     REFERENCE(IV_INDEX_CAD_4) TYPE  ZINDEX OPTIONAL
*"     REFERENCE(IV_NB_CADRANS) TYPE  ZNB_CADRANS
*"     REFERENCE(IV_IDENREG) TYPE  ZIDENREG
*"     REFERENCE(IV_ID_PRM) TYPE  EXT_UI
*"     REFERENCE(IV_MODE_TEST) TYPE  BOOLEAN OPTIONAL
*"     REFERENCE(IV_ABLHINW) TYPE  ABLHINW OPTIONAL
*"     REFERENCE(IV_ABLHINW2) TYPE  ABLHINW OPTIONAL
*"  EXPORTING
*"     REFERENCE(EV_STATUT) TYPE  I
*"  CHANGING
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  ev_statut = 2.

  lv_date = iv_date_depose - 1.

  CALL METHOD zcl_tool=>install_depose_fiap
    EXPORTING
      iv_install    = iv_anlage
      iv_date_effet = iv_date_depose
      iv_sparte     = 'ZE'
    RECEIVING
      ev_success    = lv_success.

  IF lv_success IS INITIAL.
* Le message d'erreur est émis dans la méthode
    RETURN.
  ENDIF.

  REFRESH:
      lt_mr_data,
      lt_mr_reason.

  CALL FUNCTION 'BAPI_MTRREADDOC_GETLIST'
    EXPORTING
      installation      = iv_anlage
      mrdocumenttype    = '2'
    IMPORTING
      return            = ls_return
    TABLES
      mrdocumentdata    = lt_mr_data
      mrdocumentreasons = lt_mr_reason.

  INSERT iv_anlage INTO TABLE lt_anlage.

*++STOU DEBUT GE-1624
*  CLEAR ls_mr_data.
*  READ TABLE lt_mr_data
*        INTO ls_mr_data
*    WITH KEY targetmrdate = lv_date
*             register     = '1'.

  LOOP AT lt_mr_data INTO ls_mr_data
                    WHERE targetmrdate = lv_date
                      AND register     = '1'.
* Ouverture de l'objet relève
    CALL FUNCTION 'ISU_O_METERREAD_OPEN'
      EXPORTING
        x_adatsoll   = lv_date
        x_action     = '01'
        x_ablbelnr   = ls_mr_data-mridnumber
        x_wmode      = '2'
        x_select2    = '1'
        x_no_dialog  = 'X'
        x_upd_online = 'X'
        x_no_enqueue = 'X'
        x_auto       = lt_auto
      IMPORTING
        y_obj        = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS       = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

    CLEAR ls_ieabl.
    READ TABLE ls_obj-ieabl
          INTO ls_ieabl     INDEX 1.

    IF NOT sy-subrc IS INITIAL.
* Aucune relève pour l'installation &1 du PRM &2 en date du &3
      MESSAGE e171(zintf_e_messages)
         WITH iv_anlage
              iv_id_prm
              iv_date_depose
         INTO lv_message.
      RETURN.
    ENDIF.

    lv_index_entier    = trunc( iv_index_cad_1 ).
    lv_index_decimales =  frac( iv_index_cad_1 ).

    ls_ieabl-zwnummer             = 1.
    ls_ieabl-v_zwstand            = lv_index_entier.
    ls_ieabl-n_zwstand            = lv_index_decimales.
    ls_ieabl-v_zwstndab           = lv_index_entier.
    ls_ieabl-n_zwstndab           = lv_index_decimales.
    ls_ieabl-adattats             = lv_date.
    ls_ieabl-ablstat              = '1'.
    ls_ieabl-istablart            = '01'.
    ls_ieabl-ablestyp             = '01'.
    ls_ieabl-zzidenreg            = iv_idenreg.

*FPE-GE-3953-Check conso nég
    IF iv_ablhinw IS NOT INITIAL.
      ls_ieabl-ablhinw = iv_ablhinw.
      IF  ls_ieabl-ablhinw = 'Z5'.
        ls_ieabl-ablstat = '2'.
      ENDIF.
    ENDIF.
*FPE-GE-3953-Check conso nég

    MODIFY ls_obj-ieabl
      FROM ls_ieabl     INDEX 1.

    CALL FUNCTION 'ISU_O_METERREAD_OPEN_SUBOBJ'
      EXPORTING
        x_action   = '01'
        x_auto     = lt_auto
        x_adatsoll = lv_date
      CHANGING
        xy_obj     = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS     = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

    CALL FUNCTION 'ISU_O_METERREAD_INPUT'
      CHANGING
        xy_obj = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

* Préparation de la sauvegarde
    CALL FUNCTION 'ISU_O_METERREAD_ACTION'
      EXPORTING
        x_okcode = 'PSAV'
      CHANGING
        xy_obj   = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS   = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

* sauvegarde
    CALL FUNCTION 'ISU_O_METERREAD_ACTION'
      EXPORTING
        x_okcode = 'SAVE'
      CHANGING
        xy_obj   = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS   = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

    CALL FUNCTION 'ISU_O_METERREAD_CLOSE'
      EXPORTING
        x_no_dialog = 'X'
      CHANGING
        xy_obj      = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS      = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.
  ENDLOOP . "++GE-1624

  IF iv_res = abap_false.
    lv_releve_active = '1'.
    PERFORM creation_ordre_releve_02 USING iv_idenreg
                                           lv_releve_active
                                           lv_date
                                           ls_mr_data-register
                                           iv_index_cad_1
                                  CHANGING lv_ok.

    CHECK lv_ok EQ abap_true.
  ENDIF.

*  IF iv_nb_cadrans NE '02'.
  IF iv_nb_cadrans EQ '01'.
    ev_statut = 1.
    RETURN.
  ENDIF.

************************************************************************
***************************   Cadran n°2  ******************************
************************************************************************

*  CLEAR ls_mr_data.
*  READ TABLE lt_mr_data
*        INTO ls_mr_data
*    WITH KEY targetmrdate = lv_date
*             register     = '2'.

  LOOP AT lt_mr_data INTO ls_mr_data
                     WHERE targetmrdate = lv_date
                       AND register     = '2'.
* Ouverture de l'objet relève
    CALL FUNCTION 'ISU_O_METERREAD_OPEN'
      EXPORTING
        x_adatsoll   = lv_date
        x_action     = '01'
        x_ablbelnr   = ls_mr_data-mridnumber
        x_wmode      = '2'
        x_select2    = '1'
        x_no_dialog  = 'X'
        x_upd_online = 'X'
        x_no_enqueue = 'X'
        x_auto       = lt_auto
      IMPORTING
        y_obj        = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS       = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

    CLEAR ls_ieabl.
    READ TABLE ls_obj-ieabl
          INTO ls_ieabl     INDEX 1.

    IF NOT sy-subrc IS INITIAL.
* Aucune relève pour l'installation &1 du PRM &2 en date du &3
      MESSAGE e171(zintf_e_messages)
         WITH iv_anlage
              iv_id_prm
              iv_date_depose
         INTO lv_message.
      RETURN.
    ENDIF.

    lv_index_entier    = trunc( iv_index_cad_2 ).
    lv_index_decimales =  frac( iv_index_cad_2 ).

    ls_ieabl-zwnummer             = 2.
    ls_ieabl-v_zwstand            = lv_index_entier.
    ls_ieabl-n_zwstand            = lv_index_decimales.
    ls_ieabl-v_zwstndab           = lv_index_entier.
    ls_ieabl-n_zwstndab           = lv_index_decimales.
    ls_ieabl-adattats             = lv_date.
    ls_ieabl-ablstat              = '1'.
    ls_ieabl-istablart            = '01'.
    ls_ieabl-ablestyp             = '01'.
    ls_ieabl-zzidenreg            = iv_idenreg.

*FPE-GE-3953-Check conso nég
    IF iv_ablhinw2 IS NOT INITIAL.
      ls_ieabl-ablhinw = iv_ablhinw2.
      IF  ls_ieabl-ablhinw = 'Z5'.
        ls_ieabl-ablstat = '2'.
      ENDIF.
    ENDIF.
*FPE-GE-3953-Check conso nég

    MODIFY ls_obj-ieabl
      FROM ls_ieabl       INDEX 1.

    CALL FUNCTION 'ISU_O_METERREAD_OPEN_SUBOBJ'
      EXPORTING
        x_action   = '01'
        x_auto     = lt_auto
        x_adatsoll = lv_date
      CHANGING
        xy_obj     = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS     = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

    CALL FUNCTION 'ISU_O_METERREAD_INPUT'
      CHANGING
        xy_obj = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

* Préparation de la sauvegarde
    CALL FUNCTION 'ISU_O_METERREAD_ACTION'
      EXPORTING
        x_okcode = 'PSAV'
      CHANGING
        xy_obj   = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS   = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

* sauvegarde
    CALL FUNCTION 'ISU_O_METERREAD_ACTION'
      EXPORTING
        x_okcode = 'SAVE'
      CHANGING
        xy_obj   = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS   = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

    CALL FUNCTION 'ISU_O_METERREAD_CLOSE'
      EXPORTING
        x_no_dialog = 'X'
      CHANGING
        xy_obj      = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS      = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

  ENDLOOP.

  IF iv_res = abap_false.
    lv_releve_active = '1'.
    PERFORM creation_ordre_releve_02 USING iv_idenreg
                                           lv_releve_active
                                           lv_date
                                           ls_mr_data-register
                                           iv_index_cad_2
                                  CHANGING lv_ok.

    CHECK lv_ok EQ abap_true.
  ENDIF.

*++DEBUT STOU 1215
  IF iv_nb_cadrans EQ '02'.
    ev_statut = 1.
    RETURN.
  ENDIF.

************************************************************************
***************************   Cadran n°3  ******************************
************************************************************************

*  CLEAR ls_mr_data.
*  READ TABLE lt_mr_data
*        INTO ls_mr_data
*    WITH KEY targetmrdate = lv_date
*             register     = '3'.

  LOOP AT lt_mr_data INTO ls_mr_data
                     WHERE targetmrdate = lv_date
                       AND register     = '3'.
* Ouverture de l'objet relève
    CALL FUNCTION 'ISU_O_METERREAD_OPEN'
      EXPORTING
        x_adatsoll   = lv_date
        x_action     = '01'
        x_ablbelnr   = ls_mr_data-mridnumber
        x_wmode      = '2'
        x_select2    = '1'
        x_no_dialog  = 'X'
        x_upd_online = 'X'
        x_no_enqueue = 'X'
        x_auto       = lt_auto
      IMPORTING
        y_obj        = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS       = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

    CLEAR ls_ieabl.
    READ TABLE ls_obj-ieabl
          INTO ls_ieabl     INDEX 1.

    IF NOT sy-subrc IS INITIAL.
* Aucune relève pour l'installation &1 du PRM &2 en date du &3
      MESSAGE e171(zintf_e_messages)
         WITH iv_anlage
              iv_id_prm
              iv_date_depose
         INTO lv_message.
      RETURN.
    ENDIF.

    lv_index_entier    = trunc( iv_index_cad_3 ).
    lv_index_decimales =  frac( iv_index_cad_3 ).

    ls_ieabl-zwnummer             = 3.
    ls_ieabl-v_zwstand            = lv_index_entier.
    ls_ieabl-n_zwstand            = lv_index_decimales.
    ls_ieabl-v_zwstndab           = lv_index_entier.
    ls_ieabl-n_zwstndab           = lv_index_decimales.
    ls_ieabl-adattats             = lv_date.
    ls_ieabl-ablstat              = '1'.
    ls_ieabl-istablart            = '01'.
    ls_ieabl-ablestyp             = '01'.
    ls_ieabl-zzidenreg            = iv_idenreg.

    MODIFY ls_obj-ieabl
      FROM ls_ieabl       INDEX 1.

    CALL FUNCTION 'ISU_O_METERREAD_OPEN_SUBOBJ'
      EXPORTING
        x_action   = '01'
        x_auto     = lt_auto
        x_adatsoll = lv_date
      CHANGING
        xy_obj     = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS     = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

    CALL FUNCTION 'ISU_O_METERREAD_INPUT'
      CHANGING
        xy_obj = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

* Préparation de la sauvegarde
    CALL FUNCTION 'ISU_O_METERREAD_ACTION'
      EXPORTING
        x_okcode = 'PSAV'
      CHANGING
        xy_obj   = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS   = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

* sauvegarde
    CALL FUNCTION 'ISU_O_METERREAD_ACTION'
      EXPORTING
        x_okcode = 'SAVE'
      CHANGING
        xy_obj   = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS   = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

    CALL FUNCTION 'ISU_O_METERREAD_CLOSE'
      EXPORTING
        x_no_dialog = 'X'
      CHANGING
        xy_obj      = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS      = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

  ENDLOOP.

  IF iv_res = abap_false.
    lv_releve_active = '1'.
    PERFORM creation_ordre_releve_02 USING iv_idenreg
                                           lv_releve_active
                                           lv_date
                                           ls_mr_data-register
                                           iv_index_cad_3
                                  CHANGING lv_ok.

    CHECK lv_ok EQ abap_true.
  ENDIF.

  IF iv_nb_cadrans EQ '03'.
    ev_statut = 1.
    RETURN.
  ENDIF.

************************************************************************
***************************   Cadran n°4  ******************************
************************************************************************

*  CLEAR ls_mr_data.
*  READ TABLE lt_mr_data
*        INTO ls_mr_data
*    WITH KEY targetmrdate = lv_date
*             register     = '4'.

  LOOP AT lt_mr_data INTO ls_mr_data
                     WHERE targetmrdate = lv_date
                       AND register     = '4'.

* Ouverture de l'objet relève
    CALL FUNCTION 'ISU_O_METERREAD_OPEN'
      EXPORTING
        x_adatsoll   = lv_date
        x_action     = '01'
        x_ablbelnr   = ls_mr_data-mridnumber
        x_wmode      = '2'
        x_select2    = '1'
        x_no_dialog  = 'X'
        x_upd_online = 'X'
        x_no_enqueue = 'X'
        x_auto       = lt_auto
      IMPORTING
        y_obj        = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS       = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

    CLEAR ls_ieabl.
    READ TABLE ls_obj-ieabl
          INTO ls_ieabl     INDEX 1.

    IF NOT sy-subrc IS INITIAL.
* Aucune relève pour l'installation &1 du PRM &2 en date du &3
      MESSAGE e171(zintf_e_messages)
         WITH iv_anlage
              iv_id_prm
              iv_date_depose
         INTO lv_message.
      RETURN.
    ENDIF.

    lv_index_entier    = trunc( iv_index_cad_4 ).
    lv_index_decimales =  frac( iv_index_cad_4 ).

    ls_ieabl-zwnummer             = 4.
    ls_ieabl-v_zwstand            = lv_index_entier.
    ls_ieabl-n_zwstand            = lv_index_decimales.
    ls_ieabl-v_zwstndab           = lv_index_entier.
    ls_ieabl-n_zwstndab           = lv_index_decimales.
    ls_ieabl-adattats             = lv_date.
    ls_ieabl-ablstat              = '1'.
    ls_ieabl-istablart            = '01'.
    ls_ieabl-ablestyp             = '01'.
    ls_ieabl-zzidenreg            = iv_idenreg.

    MODIFY ls_obj-ieabl
      FROM ls_ieabl       INDEX 1.

    CALL FUNCTION 'ISU_O_METERREAD_OPEN_SUBOBJ'
      EXPORTING
        x_action   = '01'
        x_auto     = lt_auto
        x_adatsoll = lv_date
      CHANGING
        xy_obj     = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS     = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

    CALL FUNCTION 'ISU_O_METERREAD_INPUT'
      CHANGING
        xy_obj = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

* Préparation de la sauvegarde
    CALL FUNCTION 'ISU_O_METERREAD_ACTION'
      EXPORTING
        x_okcode = 'PSAV'
      CHANGING
        xy_obj   = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS   = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

* sauvegarde
    CALL FUNCTION 'ISU_O_METERREAD_ACTION'
      EXPORTING
        x_okcode = 'SAVE'
      CHANGING
        xy_obj   = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS   = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

    CALL FUNCTION 'ISU_O_METERREAD_CLOSE'
      EXPORTING
        x_no_dialog = 'X'
      CHANGING
        xy_obj      = ls_obj
      EXCEPTIONS
*       error_message = 1
        OTHERS      = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      RETURN.
    ENDIF.

  ENDLOOP.

  IF iv_res = abap_false.
    lv_releve_active = '1'.
    PERFORM creation_ordre_releve_02 USING iv_idenreg
                                           lv_releve_active
                                           lv_date
                                           ls_mr_data-register
                                           iv_index_cad_4
                                  CHANGING lv_ok.

    CHECK lv_ok EQ abap_true.
  ENDIF.
*++FIN   STOU 1215

  ev_statut = 1.
ENDFUNCTION.
