*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZINTF_E_C15
*   generation date: 02.10.2020 at 14:54:38
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZINTF_E_C15         .

  PERFORM TABLEPROC.

ENDFUNCTION.
