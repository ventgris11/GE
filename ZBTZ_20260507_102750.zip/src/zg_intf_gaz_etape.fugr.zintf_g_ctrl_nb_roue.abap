FUNCTION zintf_g_ctrl_nb_roue .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA: lc_field_num_pce     TYPE fieldname VALUE 'NUM_PCE',
        lc_field_date_releve TYPE fieldname VALUE 'DATE_RELEVE',
        lc_field_nb_roue_cpt TYPE fieldname VALUE 'NB_ROUE_COMPTEUR',
        "Début: HBD_GE-13361: REXX - Erreur 225 - Nombre de roue incorrect
        lc_index_brut_debut  TYPE fieldname VALUE 'INDEX_BRUT_DEBUT_PERIODE',
        lc_index_brut_fin    TYPE fieldname VALUE 'INDEX_BRUT_FIN_PERIODE',
        lc_raison_releve     TYPE fieldname VALUE 'RAISON_RELEVE',
        "Fin  : HBD_GE-13361: REXX - Erreur 225 - Nombre de roue incorrect
        lv_field             TYPE string,
        lv_int_ui            TYPE int_ui,
        lv_anlage            TYPE anlage,
        ls_object            TYPE eedm_isu_objects,
        lt_etdz              TYPE TABLE OF etdz,
        ls_etdz              TYPE etdz,
        lv_stanzvor          TYPE stanzvor,
        lv_message           TYPE char255
        .

  FIELD-SYMBOLS: <fs_num_pce>, <fs_date_releve>, <fs_nb_roue_compteur>, <fs_etdz> TYPE etdz.
  "Début: HBD_GE-13361: REXX - Erreur 225 - Nombre de roue incorrect
  FIELD-SYMBOLS: <fs_indx_brut_fin>,<fs_indx_brut_debut>,<fs_raison_releve>.

  "Début: HBD_GE-13361: REXX - Erreur 225 - Nombre de roue incorrect
  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_index_brut_debut INTO lv_field.
  ASSIGN (lv_field) TO <fs_indx_brut_debut>.
  IF <fs_indx_brut_debut> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_index_brut_fin INTO lv_field.
  ASSIGN (lv_field) TO <fs_indx_brut_fin>.
  IF <fs_indx_brut_fin> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_raison_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_raison_releve>.
  IF <fs_raison_releve> IS NOT ASSIGNED.
  ENDIF.
  "FIN: HBD_GE-13361: REXX - Erreur 225 - Nombre de roue incorrect


  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.
  IF <fs_num_pce> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_releve>.
  IF <fs_date_releve> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_nb_roue_cpt INTO lv_field.
  ASSIGN (lv_field) TO <fs_nb_roue_compteur>.
  IF <fs_nb_roue_compteur> IS NOT ASSIGNED.
  ENDIF.

* Pour récupération de INT_UI
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).
  IF lv_int_ui IS INITIAL.
  ENDIF.

* Pour récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.

* On récupère les information de la table ETDZ
  IF ls_object-installation IS INITIAL.
  ENDIF.
  CALL FUNCTION 'ISU_DB_INSTALL_STRUC_SELECT'
    EXPORTING
      x_anlage = ls_object-installation
    TABLES
*     T_IEASTL =
*     T_IEASTS =
*     T_IEASTI =
*     T_IEASTIH            =
*     T_IEZUG  =
*     T_IEZUZ  =
*     T_IEADZ  =
      t_ietdz  = lt_etdz
*     T_IEASTL_OLD         =
*     T_IEASTS_OLD         =
*     T_IEASTI_OLD         =
*     T_IEASTIH_OLD        =
*     T_IEZUG_OLD          =
*     T_IEZUZ_OLD          =
*     T_IEADZ_OLD          =
*     T_IETDZ_OLD          =
*     T_IEADZ_QD           =
*     T_IEADZ_QD_OLD       =
*     EXCEPTIONS
*     NOT_FOUND            = 1
*     SYSTEM_ERROR         = 2
*     OTHERS   = 3
    .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

* On récupère le nombre de chiffre avant virgule (STANZVOR) du premier cadran du compteur

*** GLIC - 19/05/2016 - Sélection de l'appareil en fonction de la date de relève ***

  LOOP AT lt_etdz ASSIGNING <fs_etdz> WHERE ab LE <fs_date_releve> AND bis GE <fs_date_releve>.
    EXIT.
  ENDLOOP.
  IF sy-subrc = 0.
    MOVE <fs_etdz>-stanzvor TO lv_stanzvor.
  ENDIF.

*    READ TABLE lt_etdz INTO ls_etdz INDEX 1.
*    MOVE ls_etdz-STANZVOR to lv_STANZVOR.

*** GLIC - 19/05/2016 - Fin ***

  "Début: HBD_GE-13361: REXX - Erreur 225 - Nombre de roue incorrect
* On compare le nombre de roue compteur avec le nombre de chiffre avant virgule
*  IF lv_stanzvor = <fs_nb_roue_compteur>.
 "Début: IRO_GE-14746 : REXX - Erreur 225 - Consommations nulles tombant en erreur (changer > en >=) et inversion 61/62
*    IF ( <fs_indx_brut_fin> GT <fs_indx_brut_debut> AND ( <fs_indx_brut_fin> LE 10 ** ( <fs_nb_roue_compteur> - 1 ) ) )
*      OR <fs_raison_releve> EQ '61'.
    IF ( <fs_indx_brut_fin> GE <fs_indx_brut_debut> ) AND ( <fs_indx_brut_fin> LE ( 10 ** lv_stanzvor  - 1 ) )
      OR <fs_raison_releve> EQ '62'.
"Fin: IRO_GE-14746
    ev_etape = 1.
  ELSE.
*  ELSE.
    IF lv_stanzvor = <fs_nb_roue_compteur>.
      ev_etape = 1.
    ELSE.
      ev_etape = 2.
      MESSAGE e225(zintf_g_messages) INTO lv_message.
    ENDIF.
*  ENDIF.
  ENDIF.

* "On compare le nombre de roue compteur avec le nombre de chiffre avant virgule
*  IF lv_STANZVOR = <FS_NB_ROUE_COMPTEUR>.
*         EV_ETAPE = 1.
*  ELSE.
*         EV_ETAPE = 2.
*          MESSAGE e225(zintf_g_messages) INTO lv_message.
*  ENDIF.

  "Fin  : HBD_GE-13361: REXX - Erreur 225 - Nombre de roue incorrect

ENDFUNCTION.
