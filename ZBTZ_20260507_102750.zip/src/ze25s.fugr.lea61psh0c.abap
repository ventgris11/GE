*----------------------------------------------------------------------*
*   INCLUDE LEA61PSH0C                                                 *
*----------------------------------------------------------------------*

CONSTANTS: up        TYPE c  VALUE 'U',
           down      TYPE c  VALUE 'D',
           all       TYPE c  VALUE 'A'.

CONSTANTS: cont200_grid_name  TYPE scrfname VALUE 'D200_CONTAINER_GRID',
           cont300_grid_name  TYPE scrfname VALUE 'D300_CONTAINER_GRID',
           cont400_grid_name  TYPE scrfname VALUE 'D400_CONTAINER_GRID',
           cont520_grid_name  TYPE scrfname VALUE 'D520_CONTAINER_GRID',
           cont540_grid_name  TYPE scrfname VALUE 'D540_CONTAINER_GRID',
           cont550_grid_name  TYPE scrfname VALUE 'D550_CONTAINER_GRID',
           cont551_grid_name  TYPE scrfname VALUE 'D551_CONTAINER_GRID',
           cont560_grid_name  TYPE scrfname VALUE 'D560_CONTAINER_GRID',
           cont200_tree_name  TYPE scrfname VALUE 'D200_CONTAINER_TREE'.

*.. PS header status
CONSTANTS: co_psstat_actv   TYPE e_psstatus    VALUE '00', "active
           co_psstat_pend   TYPE e_psstatus    VALUE '01', "pending
           co_psstat_stop   TYPE e_psstatus    VALUE '02', "stopped
           co_psstat_deac   TYPE e_psstatus    VALUE '03', "deactive
           co_psstat_stpe   TYPE e_psstatus    VALUE '12', "stop/pend
           co_psstat_depe   TYPE e_psstatus    VALUE '13'. "deac/pend

*.. PS line status
CONSTANTS: co_pslstat_adjper(2) TYPE c             VALUE '01',
           co_pslstat_adjint(2) TYPE c             VALUE '02',
           co_pslstat_deact(2)  TYPE c             VALUE '03',
           co_pslstat_canc(2)   TYPE c             VALUE '04',
*... some of them are reserved for use by customer
           co_pslstat_borper(2)     TYPE c         VALUE '1M',
           co_pslstat_borint(2)     TYPE c         VALUE '2M',
           co_pslstat_refund(2)     TYPE c         VALUE '1R',
           co_pslstat_jointsing(2)  TYPE c         VALUE 'JS'.

*.. deactivation reason
CONSTANTS: co_deact_mo  LIKE eabpl-deactivstat VALUE '1', "Move Out
           co_deact_so  TYPE eabpl-deactivstat VALUE '2', "Lines Optim.
           co_deact_bd  TYPE eabpl-deactivstat VALUE '3', "Basic Data
           co_deact_lc  TYPE eabpl-deactivstat VALUE '4', "Line Change
           co_deact_pt  TYPE eabpl-deactivstat VALUE '5', "PS Terminate
           co_deact_zw  TYPE eabpl-deactivstat VALUE '6', "Interim bill
           co_deact_tu  TYPE eabpl-deactivstat VALUE '7', "Periocid bill
           co_deact_rv  TYPE eabpl-deactivstat VALUE '8'. "reversal

*.. PS payment frequencies
CONSTANTS: co_pfreq_hamo        TYPE e_payfreq     VALUE 'T', "twice a month
           co_pfreq_week        TYPE c             VALUE 'W', "weekly
           co_pfreq_fort        TYPE c             VALUE 'F', "fortn.
           co_pfreq_mont        TYPE c             VALUE 'M', "monthly
           co_pfreq_bimo        TYPE c             VALUE 'B', "bimonthly
           co_pfreq_quar        TYPE c             VALUE 'Q', "quarterly
           co_pfreq_hfyr        TYPE c             VALUE 'H', "halfyr
           co_pfreq_year        TYPE c             VALUE 'Y'. "yearly

*.. misc.
CONSTANTS: co_msg_appl_log_ps   LIKE balhdr-object   VALUE 'IU25PS',
           co_init_endper       LIKE eabp-endperiode VALUE '99991231',
           co_move_out(3)       TYPE c               VALUE 'MO ',
           co_move_out_rev(3)   TYPE c               VALUE 'MOR',
           co_ps_crt(3)         TYPE c               VALUE 'CRT',
           co_ps_crt_add(3)     TYPE c               VALUE 'ADD',
*... FI-CA document source key for automatic acc. maintenance
           co_herkf_04          LIKE fkkko-herkf     VALUE '04'.

*.. change status of a payment scheme line
CONSTANTS: co_psl_adj           TYPE e_chgstatus     VALUE space,
           co_psl_no_adj        TYPE e_chgstatus     VALUE '01',
           co_psl_no_zwiadj     TYPE e_chgstatus     VALUE '02'.

CONSTANTS: co_int_full_recov    TYPE e_recvrat1      VALUE 'F',
           co_int_part_recov    TYPE e_recvrat1      VALUE 'P',
           co_int_no_recov      TYPE e_recvrat1      VALUE 'N',
           co_int_init_recov    TYPE e_recvrat1      VALUE space.

*.. creation reason for FI-CA clearing document in sample line
CONSTANTS: co_fica_mo           LIKE eabpl-ficacrtreason VALUE '1'.

*.. call ID for reversal within the payment scheme functionality
CONSTANTS: co_callr_ps          LIKE fkkfields-callr VALUE 'PS'.

* RODMUPDMOD Update Mode (Delta Process)
CONSTANTS:
   co_rodmupdmod_delete        TYPE rodmupdmod  VALUE 'D',
   co_rodmupdmod_add           TYPE rodmupdmod  VALUE 'A',
   co_rodmupdmod_new_image     TYPE rodmupdmod  VALUE 'N',
   co_rodmupdmod_after_image   TYPE rodmupdmod  VALUE ' ',
   co_rodmupdmod_before_image  TYPE rodmupdmod  VALUE 'X',
   co_rodmupdmod_reverse_image TYPE rodmupdmod  VALUE 'R',
   co_rodmupdmod_update_image  TYPE rodmupdmod  VALUE 'Y'.
