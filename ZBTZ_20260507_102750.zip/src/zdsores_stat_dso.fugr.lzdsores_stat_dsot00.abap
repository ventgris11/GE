*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 03.04.2019 at 15:42:03
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZDSORES_STAT_DSO................................*
DATA:  BEGIN OF STATUS_ZDSORES_STAT_DSO              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDSORES_STAT_DSO              .
CONTROLS: TCTRL_ZDSORES_STAT_DSO
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDSORES_STAT_DSO              .
TABLES: ZDSORES_STAT_DSO               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
