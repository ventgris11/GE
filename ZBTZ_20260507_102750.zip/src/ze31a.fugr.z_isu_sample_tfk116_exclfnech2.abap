FUNCTION Z_ISU_SAMPLE_TFK116_EXCLFNECH2.
*"--------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(X_VERVAR) LIKE  TFK115-VERVAR
*"     VALUE(X_VERART) LIKE  TFK110-VERART OPTIONAL
*"     VALUE(X_BLDAT) LIKE  FKKKO-BLDAT OPTIONAL
*"     VALUE(X_IFNAM) LIKE  TFK116-IFNAM
*"     VALUE(X_XSORT) LIKE  BOOLE-BOOLE DEFAULT SPACE
*"  TABLES
*"      T_E516_FKKCL STRUCTURE  E516_FKKCL
*"      T_SELTAB STRUCTURE  ISELTAB OPTIONAL
*"--------------------------------------------------------------------
* Ce MF a pour objectif de filtrer les pièces de type FA avec une date d'échéance dans le futr à J + x

  DATA :
    lv_date_limite              TYPE dats,
    lv_tvarv_rappro_futur_nb_jr TYPE rvari_val_255,
    lv_rappro_futur_nb_jr       TYPE i
    .

  SELECT SINGLE low FROM tvarvc
    INTO lv_tvarv_rappro_futur_nb_jr
    WHERE name = 'ZRAPPRO_FUTUR_NB_JR_LIMITE'.

  IF sy-subrc <> 0.
    lv_date_limite = sy-datum + 5.
  ELSE.
    lv_rappro_futur_nb_jr = lv_tvarv_rappro_futur_nb_jr.
    lv_date_limite = sy-datum + lv_rappro_futur_nb_jr.
  ENDIF.


  CASE x_ifnam.
    WHEN 'Z_EXCL_F_NECH'. " Controle sur le nom de la zone

      LOOP AT t_e516_fkkcl ASSIGNING FIELD-SYMBOL(<lr_e516_fkkcl>).
        "On ne regarde que les postes liés à une facture
        IF
          (     <lr_e516_fkkcl>-blart = 'FA'
          OR    <lr_e516_fkkcl>-blart = 'AF'
          OR    <lr_e516_fkkcl>-blart = 'BB'
          OR    <lr_e516_fkkcl>-blart = 'PA'
          OR (  <lr_e516_fkkcl>-blart = 'RP' AND <lr_e516_fkkcl>-spart IS NOT INITIAL )
          OR (  <lr_e516_fkkcl>-blart = 'RC' AND <lr_e516_fkkcl>-spart IS NOT INITIAL )
          OR (  <lr_e516_fkkcl>-blart = 'GC' AND <lr_e516_fkkcl>-spart IS NOT INITIAL ) ).
          IF <lr_e516_fkkcl>-faedn GT lv_date_limite.
            <lr_e516_fkkcl>-e_zreg_te516 = '2'.
          ENDIF.

        ENDIF.

      ENDLOOP.
  ENDCASE.

ENDFUNCTION.
