*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 15.08.2017 at 21:09:43
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
