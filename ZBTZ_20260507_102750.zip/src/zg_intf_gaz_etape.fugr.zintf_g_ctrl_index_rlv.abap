FUNCTION zintf_g_ctrl_index_rlv .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
* Modification   (GE-11713)                                            *
* DATE       : 05/10/2021                                              *                                                                                                                                                                      *
* USER       : HBENDHAFER                                              *
* TAG        : HBD                                                     *
* Description: Commenter RG ligne 172                                  *
* OT         : DI1K928978/DI1K928991                                   *
*"----------------------------------------------------------------------

  DATA:
    lv_field     TYPE string,
    lv_equnr     TYPE equnr,
    lt_eabl      TYPE TABLE OF eabl,
    ls_eabl      TYPE eabl,
    lv_message   TYPE char255,
    lv_ok        TYPE crmt_boolean,
    ls_bpem      TYPE zbpem_flux_struct,
    lv_interface TYPE zisu_flxid.

  FIELD-SYMBOLS:
    <fs_emetteur>,
    <fs_flux>,
    <fs_idenreg>,
    <fs_num_pce>,
    <fs_debut_periode>,
    <fs_index_brut_debut>,
    <fs_index_brut_fin>,
    <fs_qual_index_brut_fin>,
    <fs_vol_brut_conso>,
    <fs_ind_pass_zero>.

  CLEAR lv_field.
  MOVE 'FLUX-EMETTEUR'                    TO lv_field.
  ASSIGN (lv_field)                       TO <fs_emetteur>.

  CLEAR lv_field.
  MOVE 'FLUX-FLUX'                        TO lv_field.
  ASSIGN (lv_field)                       TO <fs_flux>.

  CLEAR lv_field.
  MOVE 'FLUX-IDENREG'                     TO lv_field.
  ASSIGN (lv_field)                       TO <fs_idenreg>.

  CLEAR lv_field.
  MOVE 'FLUX-NUM_PCE'                     TO lv_field.
  ASSIGN (lv_field)                       TO <fs_num_pce>.

  CLEAR lv_field.
  MOVE 'FLUX-DEBUT_PERIODE'               TO lv_field.
  ASSIGN (lv_field)                       TO <fs_debut_periode>.

  CLEAR lv_field.
  MOVE 'FLUX-INDEX_BRUT_DEBUT_PERIODE'    TO lv_field.
  ASSIGN (lv_field)                       TO <fs_index_brut_debut>.

  CLEAR lv_field.
  MOVE 'FLUX-INDEX_BRUT_FIN_PERIODE'      TO lv_field.
  ASSIGN (lv_field)                       TO <fs_index_brut_fin>.

  CLEAR lv_field.
  MOVE 'FLUX-QUAL_INDEX_BRUT_FIN_PERIODE' TO lv_field.
  ASSIGN (lv_field)                       TO <fs_qual_index_brut_fin>.

  CLEAR lv_field.
  MOVE 'FLUX-VOL_BRUT_CONSO'              TO lv_field.
  ASSIGN (lv_field)                       TO <fs_vol_brut_conso>.

  CLEAR lv_field.
  MOVE 'FLUX-IND_PASSAGE_ZERO_INDEX_BRUT' TO lv_field.
  ASSIGN (lv_field)                       TO <fs_ind_pass_zero>.

  IF sy-subrc NE 0.
    CLEAR lv_field.
    MOVE 'ABAP_FALSE'                     TO lv_field.
    ASSIGN (lv_field)                     TO <fs_ind_pass_zero>.
  ENDIF.

  ev_etape = 2.

  CLEAR ls_bpem.
  ls_bpem-num_pce =  <fs_num_pce>.
  IF <fs_debut_periode> IS ASSIGNED .
    CASE <fs_flux>.
      WHEN 'ADIF'.
        ls_bpem-date_effet_cont = <fs_debut_periode>.
      WHEN 'RE6M' OR 'REMM' OR 'REJJ' OR 'REJM'.
        ls_bpem-date_releve     = <fs_debut_periode>.
      WHEN 'AFAC'.
        ls_bpem-date_fin_prest  = <fs_debut_periode>.
    ENDCASE.
  ENDIF.

  CLEAR ls_eabl.
  GET PARAMETER ID 'EAB' FIELD ls_eabl-ablbelnr.


  CLEAR:
    lv_ok,
    lt_eabl[].

  zcl_tool=>get_all_eabl_from_equipment(
    EXPORTING
      iv_ext_ui = <fs_num_pce>
      iv_equnr  = lv_equnr
      iv_date   = <fs_debut_periode>
    IMPORTING
      ev_ok     = lv_ok
      ev_equnr  = lv_equnr
      et_eabl   = lt_eabl ).


  IF lv_ok EQ abap_false OR lt_eabl[] IS INITIAL.
* &1 - &2 - &3 : Aucune relève pertinente pour le PCE &4
    MESSAGE e242(zintf_g_messages)
      WITH <fs_emetteur>
           <fs_flux>
           <fs_idenreg>
           <fs_num_pce>
      INTO lv_message.

    lv_interface    = <fs_flux>.
    ls_bpem-idenreg = <fs_num_pce>.

    CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
      EXPORTING
        iv_interface_name = lv_interface
        iv_sparte         = 'ZG'
        is_structure      = ls_bpem.

    RETURN.
  ENDIF.

  SORT lt_eabl BY adat DESCENDING.

*&-on se base sur l'index de la relève précédente
  DATA: lv_ablbelnr TYPE eabl-ablbelnr.
  lv_ablbelnr = ls_eabl-ablbelnr.
  CLEAR ls_eabl.
  READ TABLE lt_eabl INTO ls_eabl
   WITH KEY ablbelnr = lv_ablbelnr.


  IF sy-subrc NE 0.
    ev_etape = 1.
    RETURN.
  ENDIF.

* C'est nécessairement la relève retenue
* lors du contrôle de cohérence de la date début de période
* dans l'étape précédente

  IF <fs_index_brut_debut> NE ls_eabl-v_zwstand.
* &1 - &2 - &3 : non continuité d'index avec la relève précédente
    MESSAGE e208(zintf_g_messages)
       WITH <fs_emetteur>
            <fs_flux>
            <fs_idenreg>
       INTO lv_message.
    RETURN.
  ENDIF.
  "HBD-GE-11713: RG à commenter
*  IF  <fs_index_brut_fin> GT ls_eabl-v_zwstand
*  AND <fs_vol_brut_conso> GT 0
*  AND <fs_ind_pass_zero>  EQ 'N'.
*    IF ( ls_eabl-ablestyp EQ '01'
*         AND <fs_qual_index_brut_fin> CA 'CEM' )
*    OR ( ls_eabl-ablestyp EQ '03'
*         AND <fs_qual_index_brut_fin> EQ 'E' ).
** &1 - &2 - &3 : Index inférieur au précédent - à traiter manuellement
*      MESSAGE e229(zintf_g_messages)
*         WITH <fs_emetteur>
*              <fs_flux>
*              <fs_idenreg>
*         INTO lv_message.
*      RETURN.
*    ENDIF.
*  ENDIF.

  ev_etape = 1.

ENDFUNCTION.
