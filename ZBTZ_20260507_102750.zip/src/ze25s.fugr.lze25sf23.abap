*----------------------------------------------------------------------*
*   INCLUDE LE25SF23                                                   *
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  f23_check_import_params
*&---------------------------------------------------------------------*
*       checks of all import parameters
*----------------------------------------------------------------------*
FORM f23_check_import_params USING p_fk042c LIKE regen-kennzx
                                   p_datum  TYPE d
                                   p_waers  LIKE tfk042c-waers
                                   p_rwaer  LIKE tfk042c-rwaer
                                   p_opbel  LIKE eabp-opbel.

* local memory to save performance
  STATICS: l_waers LIKE tfk042c-waers,
           l_rwaer LIKE tfk042c-rwaer.

* check if x_opbel is initial
  IF p_opbel IS INITIAL.
    mac_msg_putx co_msg_error '215' 'TU'
                 'X_OPBEL' 'ISU_S_BBP_CONVERT_EURO'
                 space space input_error.
    IF 1 = 2. MESSAGE e215(tu) WITH space space. ENDIF.
  ENDIF.

  IF p_fk042c = co_false.
*   check if x_date is initial
    IF p_datum IS INITIAL.
      mac_msg_putx co_msg_error  '215' 'TU'
                   'X_DATUM' 'ISU_S_BBP_CONVERT_EURO'
                   space space input_error.
      IF 1 = 2. MESSAGE e215(tu) WITH space space. ENDIF.
    ENDIF.
*   check if x_waers is initial
    IF p_waers IS INITIAL.
      mac_msg_putx co_msg_error '215' 'TU'
                   'X_WAERS' 'ISU_S_BBP_CONVERT_EURO'
                   space space input_error.
      IF 1 = 2. MESSAGE e215(tu) WITH space space. ENDIF.
    ENDIF.
*   check if x_rwaer is initial
    IF p_rwaer IS INITIAL.
      mac_msg_putx co_msg_error  '215' 'TU'
                   'X_RWAER' 'ISU_S_BBP_CONVERT_EURO'
                   space space input_error.
      IF 1 = 2. MESSAGE e215(tu) WITH space space. ENDIF.
    ENDIF.

*   check validity of both currencies (only if necessary)
    IF p_waers NE l_waers.
      CALL FUNCTION 'ISU_DB_TCURC_SINGLE'
        EXPORTING
          x_waers      = p_waers
        EXCEPTIONS
          not_found    = 1
          system_error = 2
          OTHERS       = 3.
      IF sy-subrc <> 0.
        mac_msg_putx co_msg_error sy-msgno sy-msgid
                     sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
                     input_error.
      ENDIF.
      l_waers = p_waers.
    ENDIF.
    IF p_rwaer NE l_rwaer.
      CALL FUNCTION 'ISU_DB_TCURC_SINGLE'
        EXPORTING
          x_waers      = p_rwaer
        EXCEPTIONS
          not_found    = 1
          system_error = 2
          OTHERS       = 3.
      IF sy-subrc <> 0.
        mac_msg_putx co_msg_error sy-msgno sy-msgid
                     sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
                     input_error.
      ENDIF.
      l_rwaer = p_rwaer.
    ENDIF.
  ENDIF.

ENDFORM.                    " f23_check_import_params
*&---------------------------------------------------------------------*
*&      Form  read_tfk042c
*&---------------------------------------------------------------------*
*       - all entries for proid '0004' are read once (performance)
*       - the relevant entry for vkonto-opbuk is read
*----------------------------------------------------------------------*
FORM read_tfk042c TABLES pt_fk042c STRUCTURE tfk042c
                   USING p_obj     TYPE isu25_budbilplan
                CHANGING p_datum   LIKE tfk042c-datum
                         p_waers   LIKE tfk042c-waers
                         p_rwaer   LIKE tfk042c-rwaer.

  IF pt_fk042c[] IS INITIAL.
    SELECT * FROM tfk042c INTO TABLE pt_fk042c WHERE proid EQ co_proid.
    SORT pt_fk042c BY datum DESCENDING.
    IF pt_fk042c[] IS INITIAL.
      PERFORM f20_close_object USING p_obj.
*     no entry in table TFK042C
      mac_msg_putx co_msg_error '245' 'TU' space space space space
                   conversion_error.
      IF 1 = 2. MESSAGE e245(tu). ENDIF.
    ENDIF.
  ENDIF.

  READ TABLE pt_fk042c WITH KEY proid = co_proid
                                opbuk = p_obj-vkonto-opbuk
                                waers = p_obj-eabp-waers.
  IF sy-subrc NE 0.
    PERFORM f20_close_object USING p_obj.
*   no entry in table TFK042C
    mac_msg_putx co_msg_information '339' 'TU' co_proid
                 p_obj-vkonto-opbuk p_obj-eabp-waers space
                 no_change_necessary.
    IF 1 = 2. MESSAGE e339(tu) WITH space space space. ENDIF.
  ENDIF.
  p_datum = pt_fk042c-datum.
  p_waers = pt_fk042c-waers.
  p_rwaer = pt_fk042c-rwaer.

ENDFORM.                    " read_tfk042c
*&---------------------------------------------------------------------*
*&      Form  f23_check_object
*&---------------------------------------------------------------------*
FORM f23_check_object USING p_fk042c LIKE regen-kennzx
                            p_waers  LIKE tfk042c-waers
                            p_obj    TYPE isu25_budbilplan
                            j_tvo    LIKE teivv-tvorg.

  DATA: wa_ejvl  LIKE ejvl,
        wa_eabps LIKE eabps,
        l_fdate  LIKE ejvl-fdate.

* checks if budget billing plan has statistical or debit entry procedure
  IF p_obj-eabp-kzabsver NE co_absver_stat AND
     p_obj-eabp-kzabsver NE co_absver_soll.
    PERFORM f20_close_object USING p_obj.
*   conversion of budbilplan &1 not possible
    mac_msg_putx co_msg_error '335' 'TU'
                p_obj-eabp-opbel space space space
                input_error.
    IF 1 = 2. MESSAGE e335(tu) WITH space. ENDIF.
  ENDIF.

* checks if the budget billing plan has the necessary currency
  IF p_fk042c = co_false AND
     p_obj-eabp-waers NE p_waers.
    PERFORM f20_close_object USING p_obj.
*   budbilplan &1 has not the currency &2
    mac_msg_putx co_msg_error '338' 'TU'
                p_obj-eabp-opbel p_waers space space
                no_change_necessary.
    IF 1 = 2. MESSAGE e338(tu) WITH space space. ENDIF.
  ENDIF.

* check if jvl-object exists
  IF p_obj-intejvl[] IS INITIAL.
    EXIT.
  ENDIF.

* checks if jvl-object is locked
  LOOP AT p_obj-intejvl INTO wa_ejvl.
*   the youngest fdate has to be taken
    IF wa_ejvl-fdate GT l_fdate.
      l_fdate = wa_ejvl-fdate.
    ENDIF.
  ENDLOOP.
  IF sy-datum LT l_fdate.
    PERFORM f20_close_object USING p_obj.
*   in budbilplan &1 the jvl is not locked
    mac_msg_putx co_msg_error '346' 'TU'
                p_obj-eabp-opbel space space space
                jvl_active.
    IF 1 = 2. MESSAGE e346(tu) WITH space. ENDIF.
  ENDIF.

* checks if jvl-object is active (debit payment)
  LOOP AT p_obj-intejvl INTO wa_ejvl.
    READ TABLE p_obj-iejvls INTO wa_eabps
      WITH KEY vtref = wa_ejvl-vertrag
               tvorg = j_tvo.
    IF sy-subrc NE 0.
*     debit payment
      LOOP AT p_obj-iejvls INTO wa_eabps.
        IF wa_eabps-augrd NE co_augrd_jvl.
          PERFORM f20_close_object USING p_obj.
*         jvl-object of budbilplan &1 is active
          mac_msg_putx co_msg_error '347' 'TU'
                      p_obj-eabp-opbel space space space
                      jvl_active.
          IF 1 = 2. MESSAGE e347(tu) WITH space. ENDIF.
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDLOOP.

ENDFORM.                    " f23_check_object
*&---------------------------------------------------------------------*
*&      Form  f23_act_date_determine
*&---------------------------------------------------------------------*
FORM f23_act_date_determine USING p_x_date   TYPE d
                                  p_l_obj    TYPE isu25_budbilplan
                         CHANGING p_act_date TYPE d.

  DATA: tab_count   LIKE sy-tabix,
        comp_count  LIKE sy-tabix,
        f_active(1) TYPE c VALUE co_true,
        wa_eabps    LIKE eabps.

  DEFINE mac_position_check.
    if &1 gt p_l_obj-eabp-endperiode.
      subtract 1 from: tab_count,
                       comp_count.
      continue.
    endif.
  END-OF-DEFINITION.

  CLEAR f_vz_out.
  LOOP AT p_l_obj-ieabps INTO wa_eabps WHERE vorauszahl = 'L'.
    IF wa_eabps-faedn   GT p_l_obj-eabp-endperiode AND
       wa_eabps-solldat LE p_l_obj-eabp-endperiode.
      f_vz_out = co_true.
    ENDIF.
  ENDLOOP.

* determine if JVL has been cleared
  LOOP AT p_l_obj-iejvls INTO wa_eabps.
    IF NOT wa_eabps-augbl IS INITIAL AND
       wa_eabps-augbl NE wa_eabps-opbel.
*     no conversion necessary since no positions are active
      PERFORM f20_close_object USING p_l_obj.
*     conversion of budbilplan &1 not necessary
      mac_msg_putx co_msg_error '336' 'TU'
                   p_l_obj-eabp-opbel space space space
                   no_change_necessary.
      IF 1 = 2. MESSAGE e336(tu) WITH space. ENDIF.
    ENDIF.
  ENDLOOP.

* read positions starting with last entry
  DESCRIBE TABLE p_l_obj-ieabps LINES tab_count.
  comp_count = tab_count.

  WHILE tab_count GT 0.
    READ TABLE p_l_obj-ieabps INTO wa_eabps INDEX tab_count.
*   check if position is out of period
    IF p_l_obj-eabp-kzabsver = co_absver_soll OR
       ( wa_eabps-vorauszahl = 'L' AND
         f_vz_out = co_true ).
*     remember position:
      p_act_date = wa_eabps-solldat.
      mac_position_check wa_eabps-solldat.
    ELSE.
*     remember position:
      p_act_date = wa_eabps-faedn.
      mac_position_check wa_eabps-faedn.
    ENDIF.

*   check if position can be changed
    IF ( NOT wa_eabps-augbl IS INITIAL AND
         wa_eabps-augbl NE '*' AND
         wa_eabps-augbl NE wa_eabps-opbel ) OR
       NOT wa_eabps-abwbl IS INITIAL OR
       NOT wa_eabps-xpyor IS INITIAL OR
     ( NOT wa_eabps-pdtyp IS INITIAL AND
           wa_eabps-pdtyp NE '1' ) OR
       wa_eabps-faedn LT p_x_date OR
       ( NOT wa_eabps-xaesp IS INITIAL AND
         NOT wa_eabps-invoicing_party IS INITIAL ) OR
       ( wa_eabps-augbl EQ '*' AND
         wa_eabps-betrw NE wa_eabps-betro ) OR
       ( NOT wa_eabps-augrd IS INITIAL AND
         wa_eabps-augrd NE co_augrd_jvl AND
         wa_eabps-augrd NE co_augrd_deact AND
         wa_eabps-augrd NE co_augrd_stopped ) OR
       NOT wa_eabps-mahndat IS INITIAL.
      f_active = co_false.
      EXIT.
    ENDIF.
    SUBTRACT 1 FROM tab_count.
  ENDWHILE.

  IF tab_count EQ comp_count.
*   no conversion necessary since no positions are active
    PERFORM f20_close_object USING p_l_obj.
*   conversion of budbilplan &1 not necessary
    mac_msg_putx co_msg_error '336' 'TU'
                p_l_obj-eabp-opbel space space space
                no_change_necessary.
    IF 1 = 2. MESSAGE e336(tu) WITH space. ENDIF.
  ENDIF.

  IF f_active = co_true.
*   all positions are active
    p_act_date = p_l_obj-eabp-begperiode + 1.
  ENDIF.

ENDFORM.                    " f23_act_date_determine
*&---------------------------------------------------------------------*
*&      Form  f23_convert_bbp
*&---------------------------------------------------------------------*
*&      euro-conversion of budget billing plan (old and new one)
*&---------------------------------------------------------------------*
FORM f23_convert_bbp USING p_act_date TYPE d
                           p_waers    LIKE tfk042c-waers
                           p_rwaer    LIKE tfk042c-rwaer
                           p_obj      TYPE isu25_budbilplan.

  DATA: wa_eabp     LIKE eabp,
        wa_eabps    LIKE eabps,
        h_vtref     LIKE eabps-vtref,
        h_betrw     LIKE eabps-betrw,
        h_faedn     LIKE eabps-faedn,
        x_error     TYPE c,
        fkktaxexc   TYPE fkktaxexc,
        l_exc_key   TYPE txexk_kk,
        l_txdat     TYPE txdat_kk.
  FIELD-SYMBOLS: <date> TYPE d.

  IF p_obj-eabp-kzabsver = co_absver_soll.
    ASSIGN wa_eabps-solldat TO <date>.
  ELSE.
    ASSIGN wa_eabps-faedn TO <date>.
  ENDIF.

  LOOP AT p_obj-inteabp INTO wa_eabp.
    IF wa_eabp-waers NE p_waers.
*     wrong currency in head EABP:
*     this happens only if the EABPs have different currencies
      PERFORM f20_close_object USING p_obj.
*     budbilplan &1 has not the currency &2
      ROLLBACK WORK.
      mac_msg_putx co_msg_error '338' 'TU'
                   wa_eabp-opbel p_waers space space conversion_error.
      IF 1 = 2. MESSAGE e338(tu) WITH space space. ENDIF.
    ENDIF.
*   fill different fields in new EABP
    PERFORM fill_eabp USING wa_eabp
                            p_act_date.
*   Conversion of all EABP fields
    PERFORM eabp_convert_curr USING p_act_date
                                    p_waers
                                    p_rwaer
                           CHANGING wa_eabp
                                    x_error.
    IF x_error = co_true.
      PERFORM f20_close_object USING p_obj.
*     error in conversion from &1 to &2 on date &3
      ROLLBACK WORK.
      mac_msg_putx co_msg_error '340' 'TU'
                   p_waers p_rwaer p_act_date space conversion_error.
      IF 1 = 2. MESSAGE e340(tu) WITH space space space. ENDIF.
    ENDIF.

    CALL FUNCTION 'ISU_INTERNAL_VERTRAG_TO_VTREF'
      EXPORTING
        i_vertrag = wa_eabp-vertrag
      IMPORTING
        e_vtref   = h_vtref.
*   Conversion of all IEABPS fields
    LOOP AT p_obj-ieabps INTO wa_eabps WHERE vtref = h_vtref.
*     delete all positions which remain active in old object
      IF wa_eabps-vorauszahl = 'L' AND
         f_vz_out = co_true.
        IF wa_eabps-solldat LT wa_eabp-begperiode OR
           wa_eabps-solldat GT wa_eabp-endperiode.
          DELETE p_obj-ieabps.
          CONTINUE.
        ENDIF.
      ELSE.
        IF <date> LT wa_eabp-begperiode OR
           <date> GT wa_eabp-endperiode.
          DELETE p_obj-ieabps.
          CONTINUE.
        ENDIF.
      ENDIF.

      IF wa_eabp-waers NE wa_eabps-waers.
        PERFORM f20_close_object USING p_obj.
*       different currencies in head and position (budbilplan &1)
        ROLLBACK WORK.
        mac_msg_putx co_msg_error '341' 'TU'
                     wa_eabp-opbel space space space conversion_error.
        IF 1 = 2. MESSAGE e341(tu) WITH space. ENDIF.
      ENDIF.
      PERFORM ieabps_convert_curr USING p_act_date
                                        p_waers
                                        p_rwaer
                               CHANGING wa_eabps
                                        x_error.
      IF x_error = co_true.
        PERFORM f20_close_object USING p_obj.
*       error in conversion from &1 to &2 on date &3
        ROLLBACK WORK.
        mac_msg_putx co_msg_error '340' 'TU'
                     p_waers p_rwaer p_act_date space conversion_error.
        IF 1 = 2. MESSAGE e340(tu) WITH space space space. ENDIF.
      ENDIF.
      wa_eabps-waers = p_rwaer.
      IF wa_eabp-kzabsver = co_absver_stat.
        MOVE-CORRESPONDING wa_eabps TO fkktaxexc.
        CALL FUNCTION 'ISU_S_BPP_TAX_CALCULATE'
          EXPORTING
            x_waers           = wa_eabps-waers
            x_bukrs           = wa_eabps-bukrs
            x_mwskz           = wa_eabps-mwskz
            x_kzabsver        = p_obj-eabp-kzabsver
            x_txjcd           = wa_eabps-txjcd
            x_txdat           = wa_eabps-txdat
            x_bldat           = wa_eabps-bldat
            x_fkktaxexc       = fkktaxexc
            x_betrw           = wa_eabps-betrw
            x_xnett           = space
          IMPORTING
            y_txamt           = wa_eabps-sbetw
          EXCEPTIONS
            calculation_error = 1
            OTHERS            = 2.
        IF sy-subrc <> 0.
          PERFORM f20_close_object USING p_obj.
*         Unexpected ELSE case: field &1 with value &2 (&3 &4)
          ROLLBACK WORK.
          mac_msg_putx co_msg_error '898' 'E9'
                       'SY-SUBRC' sy-subrc 'FKK_TAX_LINES_CREATE' space
                       conversion_error.
          IF 1 = 2. MESSAGE e898(e9) WITH space space space space. ENDIF.
        ENDIF.
      ENDIF.
      MODIFY p_obj-ieabps FROM wa_eabps.
    ENDLOOP.
    wa_eabp-waers = p_rwaer.
    MODIFY p_obj-inteabp FROM wa_eabp.

  ENDLOOP.

* fill EABP
  p_obj-eabp = wa_eabp.

ENDFORM.                    " f23_convert_bbp
*&---------------------------------------------------------------------*
*&      Form  EABP_CONVERT_CURR
*&---------------------------------------------------------------------*
*       Conversion of all amounts in head EABP
*----------------------------------------------------------------------*
FORM eabp_convert_curr USING p_act_date TYPE d
                             p_waers    LIKE tfk042c-waers
                             p_rwaer    LIKE tfk042c-rwaer
                    CHANGING p_eabp     LIKE eabp
                             x_error    TYPE c.

* EINZBETR  move in/out budget billing amount
  PERFORM convert_amount USING p_act_date
                               p_eabp-einzbetr
                               p_rwaer
                               p_waers
                      CHANGING p_eabp-einzbetr.
  IF sy-subrc NE 0.
*   error in conversion
    x_error = co_true.
    EXIT.
  ENDIF.

* TAGBETR   daily budget billing amount
  PERFORM convert_amount USING p_act_date
                               p_eabp-tagbetr
                               p_rwaer
                               p_waers
                      CHANGING p_eabp-tagbetr.
  IF sy-subrc NE 0.
*   error in conversion
    x_error = co_true.
    EXIT.
  ENDIF.

* D_BETRAG  always used budget billing amount
  PERFORM convert_amount USING p_act_date
                               p_eabp-d_betrag
                               p_rwaer
                               p_waers
                      CHANGING p_eabp-d_betrag.
  IF sy-subrc NE 0.
*   error in conversion
    x_error = co_true.
    EXIT.
  ENDIF.

* ABSBETRW  Budget billing amount arranged for each contract
  PERFORM convert_amount USING p_act_date
                               p_eabp-absbetrw
                               p_rwaer
                               p_waers
                      CHANGING p_eabp-absbetrw.
  IF sy-subrc NE 0.
*   error in conversion
    x_error = co_true.
    EXIT.
  ENDIF.

ENDFORM.                    " ITEMS_CONVERT_CURR
*&---------------------------------------------------------------------*
*&      Form  ieabps_convert_curr
*&---------------------------------------------------------------------*
*       Conversion of all amounts in positions IEABPS
*----------------------------------------------------------------------*
FORM ieabps_convert_curr USING p_act_date TYPE d
                               p_waers    LIKE tfk042c-waers
                               p_rwaer    LIKE tfk042c-rwaer
                      CHANGING p_ieabps   LIKE eabps
                               x_error    TYPE c.

* BETRW     Budget billing amount in transaction currency
  PERFORM convert_amount USING p_act_date
                               p_ieabps-betrw
                               p_rwaer
                               p_waers
                      CHANGING p_ieabps-betrw.
  IF sy-subrc NE 0.
*   error in conversion
    x_error = co_true.
    EXIT.
  ENDIF.

  IF NOT p_ieabps-fdgrp IS INITIAL.
    p_ieabps-fdwbt = p_ieabps-betrw.
  ELSE.
    p_ieabps-fdwbt = 0.
  ENDIF.
  p_ieabps-skfbt = p_ieabps-betrw.

ENDFORM.                    " ieabps_convert_curr
*---------------------------------------------------------------------*
*       FORM convert_amount                                           *
*---------------------------------------------------------------------*
*       Conversion of one single amount
*---------------------------------------------------------------------*
FORM convert_amount USING x_date  LIKE sy-datum
                          x_betrw LIKE fkkop-betrw
                          x_rwaer LIKE tfk042c-rwaer
                          x_waers LIKE tfk042c-waers
                 CHANGING y_betrw LIKE fkkop-betrw.

* sy-subrc gets handled by caller

  IF x_betrw = 0.
    CLEAR sy-subrc.
    EXIT.
  ENDIF.
  CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
    EXPORTING
      date             = x_date
      foreign_amount   = x_betrw
      foreign_currency = x_waers
      local_currency   = x_rwaer
    IMPORTING
      local_amount     = y_betrw
    EXCEPTIONS
      OTHERS           = 1.                                 "#EC *

ENDFORM.                    " convert_amount
*&---------------------------------------------------------------------*
*&      Form  fill_eabp
*&---------------------------------------------------------------------*
*       all interesting fields in eabp are set
*----------------------------------------------------------------------*
FORM fill_eabp USING p_eabp LIKE eabp
                     p_date TYPE d.

  p_eabp-begperiode = p_date + 1.
  CLEAR p_eabp-manuellvkz.
* take over vorauszdat and abschldat if necessary
  IF p_eabp-abschldat IS INITIAL.
    IF NOT p_eabp-vorauszdat IS INITIAL.
      IF NOT p_eabp-vorauszdat BETWEEN p_eabp-begperiode
                                   AND p_eabp-endperiode.
        p_eabp-vorauszdat = p_eabp-begperiode.
      ENDIF.
    ENDIF.
  ELSE.
    IF p_eabp-abschldat LE p_eabp-begperiode.
      CLEAR: p_eabp-vorauszdat,
             p_eabp-abschldat.
    ELSE.
      IF NOT p_eabp-vorauszdat BETWEEN p_eabp-begperiode
                                   AND p_eabp-endperiode.
        p_eabp-vorauszdat = p_eabp-begperiode.
      ENDIF.
    ENDIF.
  ENDIF.
* take over abstopdat and absperdat if they are in the new
* periode. Set the dates to the start of the new periode if
* they lay earlier.
  IF NOT p_eabp-abstopdat IS INITIAL AND
     p_eabp-abstopdat LT p_eabp-begperiode.
    p_eabp-abstopdat = p_eabp-begperiode.
  ENDIF.
  IF NOT p_eabp-absperdat IS INITIAL AND
     p_eabp-absperdat LT p_eabp-begperiode.
    p_eabp-absperdat = p_eabp-begperiode.
  ENDIF.
  CLEAR p_eabp-anpdat.
  CLEAR p_eabp-aedat.
  CLEAR p_eabp-aenam.
  CLEAR p_eabp-debid.

ENDFORM.                    " fill_eabp
*&---------------------------------------------------------------------*
*&      Form  F23_CREATE_OBJECT
*&---------------------------------------------------------------------*
*       creates new budget billing plan
*----------------------------------------------------------------------*
FORM f23_create_object USING p_new_obj TYPE isu25_budbilplan.

  DATA: wa_eabps  LIKE eabps,
        wa_eabp   LIKE eabp,
        l_vertrag LIKE ever-vertrag.

* master record has to be cleared for creation
  CLEAR p_new_obj-muster_op[].

* condense positions
  PERFORM f23_condense CHANGING p_new_obj.

* No creation of EITR for budget billing change document
  p_new_obj-print_control-print_poss = '0'.

* redistribute OPUPW and OPUPK
  CALL FUNCTION 'ISU_S_CREATE_LOGICAL_STRUCTURE'
    CHANGING
      xy_teabps = p_new_obj-ieabps.

* set different fields in ieabps
  LOOP AT p_new_obj-ieabps INTO wa_eabps.
    IF l_vertrag NE wa_eabp-vertrag.
      CALL FUNCTION 'ISU_INTERNAL_VTREF_TO_VERTRAG'
        EXPORTING
          i_vtref   = wa_eabps-vtref
          i_subap   = wa_eabps-subap
        IMPORTING
          e_vertrag = l_vertrag.
      READ TABLE p_new_obj-inteabp INTO wa_eabp
                 WITH KEY vertrag = l_vertrag.
    ENDIF.
    IF wa_eabp-begperiode GT sy-datum.
      wa_eabps-budat = wa_eabp-begperiode.
    ELSE.
      wa_eabps-budat = sy-datum.
    ENDIF.
    wa_eabps-bldat = sy-datum.
    wa_eabps-whgrp = co_whgrp_001.
    wa_eabps-whang = '000'.
    IF p_new_obj-eabp-kzabsver EQ co_absver_stat.
      wa_eabps-xanza = co_true.
    ENDIF.
    CLEAR wa_eabps-opbel.
    IF wa_eabps-augbl = '*'.
      CLEAR wa_eabps-augbl.
    ENDIF.
    IF wa_eabps-augbl = p_new_obj-eabp-opbel.
      wa_eabps-augbl = '*'.
    ENDIF.
    IF wa_eabps-betrw = 0 AND
       wa_eabps-augbl IS INITIAL.
      wa_eabps-augbl = '*'.
      wa_eabps-augrd = co_augrd_deact.
      wa_eabps-augst = co_augst_9.
      wa_eabps-augbd = sy-datum.
      wa_eabps-augdt = sy-datum.
    ENDIF.
    IF wa_eabps-augrd = co_augrd_jvl.
      CLEAR: wa_eabps-augrd,
             wa_eabps-augdt,
             wa_eabps-augbl,
             wa_eabps-augbd,
             wa_eabps-augrd,
             wa_eabps-augwa,
             wa_eabps-augbt,
             wa_eabps-augst.
    ENDIF.
    CLEAR: wa_eabps-xaugp,
           wa_eabps-xragl,
           wa_eabps-xtaus,
           wa_eabps-opsta,
           wa_eabps-xwhpo,
           wa_eabps-inkps,
           wa_eabps-augob.
    CLEAR: wa_eabps-betrh,
           wa_eabps-betr2,
           wa_eabps-betr3,
           wa_eabps-sbeth,
           wa_eabps-sbet2,
           wa_eabps-sbet3.
    IF wa_eabps-potyp NA ' V'.
      CLEAR wa_eabps-potyp.
    ENDIF.
    MODIFY p_new_obj-ieabps FROM wa_eabps.
  ENDLOOP.
  IF sy-subrc NE 0.
*   at least one position has to be left in new object
    PERFORM f20_close_object USING p_new_obj.
    ROLLBACK WORK.
*   conversion of budbilplan &1 not necessary
    mac_msg_putx co_msg_error '336' 'TU'
                p_new_obj-eabp-opbel space space space
                no_change_necessary.
    IF 1 = 2. MESSAGE e336(tu) WITH space. ENDIF.
  ENDIF.

* Update of new object
  mac_prot_log_off.
  CALL FUNCTION 'ISU_BBP_UPDATE_CREATE'
    EXPORTING
      x_mass            = space
    CHANGING
      xy_obj            = p_new_obj
    EXCEPTIONS
      update_incomplete = 1
      OTHERS            = 2.
  mac_prot_log_on.
  IF sy-subrc <> 0.
*   letzte Meldung holen
    mac_prot_msg_last.
*   letzte Meldung zwischenspeichern
    h_msg-msgno = last_msg-msgno.
    h_msg-msgid = last_msg-msgid.
    h_msg-msgv1 = last_msg-msgv1.
    h_msg-msgv2 = last_msg-msgv2.
    h_msg-msgv3 = last_msg-msgv3.
    h_msg-msgv4 = last_msg-msgv4.

    PERFORM f20_close_object USING p_new_obj.
    ROLLBACK WORK.
    mac_msg_putx co_msg_error h_msg-msgno h_msg-msgid h_msg-msgv1
                 h_msg-msgv2 h_msg-msgv3 h_msg-msgv4 update_error.
  ENDIF.

ENDFORM.                    " f23_create_object
*&---------------------------------------------------------------------*
*&      Form  f23_delete_jvl
*&---------------------------------------------------------------------*
*       all jvl-information gets deleted from the new object since
*       it's no longer active
*----------------------------------------------------------------------*
FORM f23_delete_jvl CHANGING p_obj TYPE isu25_budbilplan.

  CLEAR: p_obj-ejvl,
         p_obj-intejvl[],
         p_obj-intejvl_db[],
         p_obj-iejvls[],
         p_obj-db_iejvls[],
         p_obj-jvlte_changed.

ENDFORM.                    " f23_delete_jvl
*&---------------------------------------------------------------------*
*&      Form  f23_deactivate_jvl
*&---------------------------------------------------------------------*
*       deactivates old jvl-object
*----------------------------------------------------------------------*
FORM f23_deactivate_jvl USING p_l_obj TYPE isu25_budbilplan
                              p_augrd TYPE eabps-augrd.

  DATA: wa_eabps LIKE eabps.

* Positionen deaktivieren
  LOOP AT p_l_obj-iejvls INTO wa_eabps.
    wa_eabps-augdt = sy-datum.
    wa_eabps-augbl = wa_eabps-opbel.
    wa_eabps-augbd = wa_eabps-budat.
    wa_eabps-augrd = p_augrd.
    wa_eabps-augst = co_augst_9.
    MODIFY p_l_obj-iejvls FROM wa_eabps INDEX sy-tabix.
  ENDLOOP.

ENDFORM.                    " f23_deactivate_jvl
*&---------------------------------------------------------------------*
*&      Form  f23_condense
*&---------------------------------------------------------------------*
*       if two positions have been put together they are condensed
*       into a single position here
*----------------------------------------------------------------------*
FORM f23_condense CHANGING p_obj TYPE isu25_budbilplan.

  DATA: c_eabps   LIKE eabps,
        c_tabix   LIKE sy-tabix,
        h_tabix   LIKE sy-tabix,
        fkktaxexc TYPE fkktaxexc,
        l_exc_key TYPE txexk_kk,
        l_txdat   TYPE txdat_kk.

  SORT p_obj-ieabps BY logno vtref tvorg grbbp DESCENDING.

  LOOP AT p_obj-ieabps INTO wa_eabps.
    h_tabix = sy-tabix.
    IF wa_eabps-logno      = c_eabps-logno      AND
       wa_eabps-vtref      = c_eabps-vtref      AND
       wa_eabps-tvorg      = c_eabps-tvorg      AND
       wa_eabps-grbbp      = c_eabps-grbbp.
*     condense positions
      ADD c_eabps-betrw TO wa_eabps-betrw.
      MOVE-CORRESPONDING wa_eabps TO fkktaxexc.
*      CALL FUNCTION 'FKK_TAX_EXEMPT_KEY_DETERMINE'
*        EXPORTING
*          i_fkktaxexc   = fkktaxexc
*        IMPORTING
*          e_exc_key     = l_exc_key
*        EXCEPTIONS
*          error_message = 1.
*      IF sy-subrc <> 0.
*        mac_msg_putx co_msg_error sy-msgno sy-msgid
*                     sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 tax_error.
*      ENDIF.
*
*      IF wa_eabps-txdat IS INITIAL.
*        l_txdat = wa_eabps-bldat.
*      ELSE.
*        l_txdat = wa_eabps-txdat.
*      ENDIF.
*      CALL FUNCTION 'FKK_TAX_LINES_CREATE'
*        EXPORTING
*          i_waers   = wa_eabps-waers
*          i_bukrs   = wa_eabps-bukrs
*          i_betrw   = wa_eabps-betrw
*          i_mwskz   = wa_eabps-mwskz
*          i_txjcd   = wa_eabps-txjcd
*          i_txdat   = l_txdat
*          i_exc_key = l_exc_key
*        IMPORTING
*          e_txamt   = wa_eabps-sbetw
*        EXCEPTIONS
*          OTHERS    = 1.
      CALL FUNCTION 'ISU_S_BPP_TAX_CALCULATE'
        EXPORTING
          x_waers           = wa_eabps-waers
          x_bukrs           = wa_eabps-bukrs
          x_mwskz           = wa_eabps-mwskz
          x_kzabsver        = p_obj-eabp-kzabsver
          x_txjcd           = wa_eabps-txjcd
          x_txdat           = wa_eabps-txdat
          x_bldat           = wa_eabps-bldat
          x_fkktaxexc       = fkktaxexc
          x_betrw           = wa_eabps-betrw
          x_xnett           = space
        IMPORTING
          y_txamt           = wa_eabps-sbetw
        EXCEPTIONS
          calculation_error = 1
          OTHERS            = 2.
      IF sy-subrc <> 0.
        PERFORM f20_close_object USING p_obj.
*       Unexpected ELSE case: field &1 with value &2 (&3 &4)
        ROLLBACK WORK.
        mac_msg_putx co_msg_error '898' 'E9'
                     'SY-SUBRC' sy-subrc 'FKK_TAX_LINES_CREATE' space
                     conversion_error.
        IF 1 = 2. MESSAGE e898(e9) WITH space space space space. ENDIF.
      ENDIF.
      MODIFY p_obj-ieabps FROM wa_eabps.
      DELETE p_obj-ieabps INDEX c_tabix.
      SUBTRACT 1 FROM h_tabix.
    ENDIF.
    c_eabps = wa_eabps.
    c_tabix = h_tabix.
  ENDLOOP.

ENDFORM.                    " f23_condense
