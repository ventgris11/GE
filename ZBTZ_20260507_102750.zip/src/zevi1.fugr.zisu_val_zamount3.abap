FUNCTION zisu_val_zamount3 .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(X_TE328) LIKE  TE328 STRUCTURE  TE328
*"  CHANGING
*"     REFERENCE(XY_OBJ) TYPE  ISU21_INVOICE_UNIT
*"     REFERENCE(XY_OUTCNSO) LIKE  ERDO-OUTCNSO
*"  EXCEPTIONS
*"      GENERAL_FAULT
*"----------------------------------------------------------------------
  DATA: deviation   LIKE ercho-deviation,
        outsorted   TYPE c,
        amount      LIKE erdk-total_amnt,
*DEB-IBEN-20190902-GE-6451
        ls_bill_doc TYPE isu2a_bill_doc.
*FIN-IBEN-20190902-GE-6451

*DEB-IBEN-20190902-GE-6451
  LOOP AT xy_obj-t_bill_doc INTO ls_bill_doc WHERE erch-sc_belnr_h <> ''.
    EXIT.
  ENDLOOP.
*FIN-IBEN-20190902-GE-6451

  CHECK xy_obj-t_eabp IS NOT INITIAL
*DEB-IBEN-20190902-GE-6451
  OR ( xy_obj-t_eabp IS INITIAL AND xy_obj-print_doc-erdk-portion CS 'A' )
  OR ls_bill_doc IS NOT INITIAL.
*FIN-IBEN-20190902-GE-6451

  amount = xy_obj-print_doc-erdk-total_amnt.
  CALL FUNCTION 'ISU_E25M_BETRW_WAERS_CORRECT'
    EXPORTING
      x_amount          = amount
      x_currency        = xy_obj-print_doc-erdk-total_waer
    IMPORTING
      y_amount          = amount
    EXCEPTIONS
      too_many_decimals = 1
      OTHERS            = 2.
  IF sy-subrc NE 0.
    mac_msg_putx co_msg_error '274' 'AJ' x_te328-validat_in space
                           space space general_fault.
    IF 1 = 2. MESSAGE e274(aj) WITH space. ENDIF.
  ENDIF.

  IF amount >= 0.
    IF amount < x_te328-value1 OR
       amount > x_te328-value2.
      deviation = amount.
      outsorted = 'X'.
    ENDIF.
  ELSEIF amount < 0.
    IF amount < x_te328-value4 OR
       amount > x_te328-value3.
      deviation = amount.
      outsorted = 'X'.
    ENDIF.
  ENDIF.

  IF NOT outsorted IS INITIAL.
    CALL FUNCTION 'ISU_OUTSORT_IERDO_WRITE'
      EXPORTING
        x_validat_in = x_te328-validat_in
        x_deviation  = deviation
      CHANGING
        xy_ierdo     = xy_obj-print_doc-t_erdo
        xy_outcnso   = xy_outcnso.
  ENDIF.
ENDFUNCTION.
