class ZCL_IM_IBSSI_RECEIVE_TO_UL definition
  public
  final
  create public .

public section.

  interfaces IF_EX_IBSSI_RECEIVE_TO_UPL .

  methods ADD_FIELDS
    importing
      !IS_DATA type ANY
    changing
      !CT_CONTAINER type CCMCONT_T .
protected section.
private section.

  data:
    GT_DATA TYPE TABLE OF REF TO DATA .
ENDCLASS.



CLASS ZCL_IM_IBSSI_RECEIVE_TO_UL IMPLEMENTATION.


METHOD add_fields.
  DATA: ls_cont TYPE swcont.

  DATA(lr_structdescr) = CAST cl_abap_structdescr( cl_abap_typedescr=>describe_by_data( is_data ) ).
  DATA(lt_fields) = lr_structdescr->get_ddic_field_list( ).
  LOOP AT lt_fields INTO DATA(ls_field).
    ASSIGN COMPONENT ls_field-fieldname OF STRUCTURE is_data TO FIELD-SYMBOL(<field>).
    ls_cont-element = ls_field-fieldname.
    ls_cont-value = <field>.
    APPEND ls_cont TO ct_container.
  ENDLOOP.
ENDMETHOD.


method IF_EX_IBSSI_RECEIVE_TO_UPL~PREPARE_DATA_FOR_MDG.
  LOOP AT gt_data INTO DATA(lr_data).
    ASSIGN lr_data->* TO FIELD-SYMBOL(<data>).
    me->add_fields( EXPORTING is_data = <data>
                    CHANGING ct_container = container ).
  ENDLOOP.
endmethod.


METHOD if_ex_ibssi_receive_to_upl~read_and_delete_from_bapimtcs.
** BADI pour récupérer les champs spé envoyés de CRM vers ISU
  DATA: lr_data        TYPE REF TO data,
        lv_struct_name TYPE string,
        lv_regex       TYPE string,
        lv_regex_or    TYPE string.
  lv_regex = '^CI_EUIHEAD_.*$'.
  lv_regex_or = '^CI_IFLOT_.*$'.
  " Gestion des champs pour les PODs
  LOOP AT bapimtcs INTO DATA(ls_bapimtcs).
    CLEAr lv_struct_name.
    IF cl_abap_matcher=>matches( pattern = lv_regex    text = ls_bapimtcs-tabname ) IS NOT INITIAL.
      lv_struct_name = ls_bapimtcs-tabname+11.
    ENDIF.
    IF cl_abap_matcher=>matches( pattern = lv_regex_or text = ls_bapimtcs-tabname ) IS NOT INITIAL.
      lv_struct_name = ls_bapimtcs-tabname+9.
    ENDIF.

    CHECK lv_struct_name IS NOT INITIAL.
*
*    lv_struct_name = ls_bapimtcs-tabname+11.
    CREATE DATA lr_data TYPE (lv_struct_name).

    ASSIGN lr_data->* TO FIELD-SYMBOL(<data>).

    CALL METHOD cl_abap_container_utilities=>read_container_c
      EXPORTING
        im_container           = ls_bapimtcs-data
      IMPORTING
        ex_value               = <data>
      EXCEPTIONS
        illegal_parameter_type = 1
        OTHERS                 = 2.
    IF sy-subrc <> 0.
*     Implement suitable error handling here
    ENDIF.


*    <data> = ls_bapimtcs-data.
    APPEND lr_data TO gt_data.

    DELETE bapimtcs.
*    ENDIF.
  ENDLOOP.
ENDMETHOD.
ENDCLASS.
