*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 12.09.2019 at 11:03:16
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
