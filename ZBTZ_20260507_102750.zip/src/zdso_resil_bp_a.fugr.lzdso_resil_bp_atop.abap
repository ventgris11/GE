* regenerated at 21.04.2019 17:53:02
FUNCTION-POOL ZDSO_RESIL_BP_A            MESSAGE-ID SV.

* INCLUDE LZDSO_RESIL_BP_AD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDSO_RESIL_BP_AT00                     . "view rel. data dcl.
