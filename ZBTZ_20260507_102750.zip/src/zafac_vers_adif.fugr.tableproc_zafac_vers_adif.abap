*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZAFAC_VERS_ADIF
*   generation date: 20.02.2019 at 16:37:17
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZAFAC_VERS_ADIF     .

  PERFORM TABLEPROC.

ENDFUNCTION.
