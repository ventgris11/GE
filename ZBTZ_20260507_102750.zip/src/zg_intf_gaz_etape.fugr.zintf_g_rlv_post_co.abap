FUNCTION zintf_g_rlv_post_co .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
  TYPES : BEGIN OF ty_etrg,
            abrvorg  TYPE abrvorg,
            adatsoll TYPE adatsoll,
          END OF ty_etrg.
  TYPES : BEGIN OF ty_eabl,
            ablbelnr TYPE ablbelnr,
            adattats TYPE adattats,
            adatsoll TYPE adatsoll,
          END OF ty_eabl.

  DATA: lc_field_num_pce      TYPE fieldname VALUE 'NUM_PCE',
        lc_field_date_releve  TYPE fieldname VALUE 'DATE_RELEVE',
        lc_field_motif_releve TYPE fieldname VALUE 'MOTIF_RELEVE',
        lc_field_statut       TYPE fieldname VALUE 'STATUT',
        lv_field              TYPE string,
        lv_int_ui             TYPE int_ui,
        lv_anlage             TYPE anlage,
        ls_object             TYPE eedm_isu_objects,
        ls_canc_param         TYPE isu21_canc_param,
        lt_anlage             TYPE isu_t_eanlkey_h,
        lv_instdata           TYPE isu2a_instdata,
        lt_idispdata          TYPE isu_bi_inst_dispdata_tab,
        ls_idispdata          TYPE isu_bi_inst_dispdata,
        lt_ianl_bdoc          TYPE isu_bi_inst_billdoc_disp_tab,
        lv_ianl_bdoc          TYPE isu_bi_inst_billdoc_disp,
        ls_iabl               TYPE isu_bi_inst_eabl_disp,
        lt_insttab            TYPE isu17_meterdocu_insttab,
        ls_insttab            TYPE isu17_meterdocu_inst,
        ls_obj                TYPE isu17_meterread,
        ls_etrg               TYPE ty_etrg,
        lt_etrg               TYPE TABLE OF ty_etrg,
        lt_eabl               TYPE TABLE OF ty_eabl,
        ls_eabl               TYPE ty_eabl,
        lt_iabl               TYPE isu_bi_inst_eabl_disp_tab,
        lv_string             TYPE string,
        lv_message            TYPE char255,
        ls_bpem               TYPE zbpem_flux_struct,
        lv_interface          TYPE zisu_flxid.


  FIELD-SYMBOLS: <fs_num_pce>, <fs_date_releve>, <fs_motif_releve>, <fs_motif_statut>.

  FIELD-SYMBOLS: <lr_flux>     TYPE any,
                 <lr_struc>    TYPE any,
                 <lr_idenreg>  TYPE any,
                 <lr_emetteur> TYPE any.


  lv_string = 'FLUX-NUM_PCE'.
  ASSIGN (lv_string) TO <lr_struc>.
  lv_string = 'FLUX-IDENREG'.
  ASSIGN (lv_string) TO <lr_idenreg> .
  lv_string = 'FLUX-FLUX'.
  ASSIGN (lv_string) TO <lr_flux> .
  lv_string = 'FLUX-EMETTEUR'.
  ASSIGN (lv_string) TO <lr_emetteur> .


  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.
  IF <fs_num_pce> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_releve>.
  IF <fs_date_releve> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_motif_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_motif_releve>.
  IF <fs_motif_releve> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_statut INTO lv_field.
  ASSIGN (lv_field) TO <fs_motif_statut>.
  IF <fs_motif_statut> IS NOT ASSIGNED.
  ENDIF.

* Pour récupération de INT_UI
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).
  IF lv_int_ui IS INITIAL.
  ENDIF.

* Pour récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.
  IF ls_object-installation IS INITIAL.
  ENDIF.

  lv_anlage = ls_object-installation.

  INSERT lv_anlage INTO TABLE lt_anlage.

  " Recherche des informations nécessaires aux différentes annulations
  CALL FUNCTION 'ISU_INST_BIVIEW_SELECT'
    EXPORTING
      x_ab         = <fs_date_releve>
*     X_BIS        =
      x_ianlkey    = lt_anlage
*     X_ONLY_MR    =
    IMPORTING
      y_instdata   = lv_instdata
    CHANGING
      xy_idispdata = lt_idispdata.

  CLEAR ls_idispdata.
  READ TABLE lt_idispdata INTO ls_idispdata WITH KEY anlage = lv_anlage.

  lt_iabl = ls_idispdata-iabl.

  SELECT ablbelnr adattats adatsoll INTO TABLE lt_eabl
    FROM eabl
    FOR ALL ENTRIES IN lt_iabl
    WHERE ablbelnr = lt_iabl-ablbelnr
    "AND   anlage = lv_anlage
    AND   adatsoll GT <fs_date_releve>.
  IF sy-subrc NE 0 OR lt_iabl IS INITIAL.
    ev_etape = 1.
  ELSE.
    ev_etape = 2.
    MESSAGE e216(zintf_g_messages) WITH <lr_emetteur> <lr_flux> <lr_idenreg> INTO lv_message.

    CLEAR ls_bpem.
    ls_bpem-num_pce = <fs_num_pce>.
    CASE <lr_flux>.
      WHEN 'ADIF'.
        ls_bpem-date_effet_cont = <fs_date_releve>.
      WHEN 'RE6M' OR 'RE1M' OR 'REMM' OR 'REJJ' OR 'REJM'.
        ls_bpem-date_releve     = <fs_date_releve>.
      WHEN 'AFAC'.
        ls_bpem-date_fin_prest  = <fs_date_releve>.
    ENDCASE.

    lv_interface = <lr_flux> .
    ls_bpem-idenreg = <lr_idenreg>.
    CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
      EXPORTING
        iv_interface_name = lv_interface
        iv_sparte         = 'ZG'
        is_structure      = ls_bpem.

  ENDIF.
ENDFUNCTION.
