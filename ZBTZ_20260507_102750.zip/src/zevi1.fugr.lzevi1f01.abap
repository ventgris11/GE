*----------------------------------------------------------------------*
***INCLUDE LEVI1F01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  DETERMINE_MAIN_TRANSACTIONS
*&---------------------------------------------------------------------*
*       Calling the function for determination of main transactions
*       and adding them to the internal table
*----------------------------------------------------------------------*
*      -->X_IHVOR   text                                               *
*      <--XY_ITEIVV text                                               *
*----------------------------------------------------------------------*
FORM DETERMINE_MAIN_TRANSACTIONS USING X_IHVOR LIKE TEIVV-IHVOR
                              CHANGING XY_ITFKIVV TYPE VAL_ITFKIVV.
  DATA: ITFKIVV TYPE VAL_ITFKIVV.

  CALL FUNCTION 'ISU_DB_TEIVV_SELECT_IHVOR'
       EXPORTING
            X_IHVOR             = X_IHVOR
            X_APPLK             = 'R'
       TABLES
            T_TFKIVV             = ITFKIVV
       EXCEPTIONS
            NOT_FOUND           = 1
            INT_TRANS_NOT_VALID = 2
            TRANS_NOT_VALID     = 3
            OTHERS              = 4.
  IF SY-SUBRC <> 0.
    MAC_MSG_PUTX CO_MSG_ERROR SY-MSGNO SY-MSGID SY-MSGV1 SY-MSGV2
                    SY-MSGV3 SY-MSGV4 GENERAL_FAULT.
  ELSE.
    APPEND LINES OF ITFKIVV TO XY_ITFKIVV.
  ENDIF.

ENDFORM.                               " DETERMINE_MAIN_TRANSACTIONS
*&---------------------------------------------------------------------*
*&      Form  AGGREGATE_OPEN_ITEMS
*&---------------------------------------------------------------------*
*       Aggregate all amounts in open items to a given table of main
*       transactions.
*----------------------------------------------------------------------*
*      -->X_ITFIVV  text                                               *
*      -->X_IFKKOP  text                                               *
*      <--XY_AMOUNT  text                                              *
*----------------------------------------------------------------------*
FORM AGGREGATE_OPEN_ITEMS USING X_ITFKIVV TYPE VAL_ITFKIVV
                                X_IFKKOP TYPE ISU21_VKK_DOC-T_FKKOP
                       CHANGING XY_AMOUNT LIKE FKKOP-BETRW.
  DATA: WFKKOP LIKE FKKOP,
        WTFKIVV LIKE TFKIVV.
  DATA: SEL_TAB LIKE ISU_RANGES OCCURS 5 WITH HEADER LINE.

* for easier selection the table sel_tab has to be filled.
  SEL_TAB-SIGN = 'I'.
  SEL_TAB-OPTION = 'EQ'.

  LOOP AT X_ITFKIVV INTO WTFKIVV.
    SEL_TAB-LOW = WTFKIVV-HVORG.
    APPEND SEL_TAB.
  ENDLOOP.

  LOOP AT X_IFKKOP INTO WFKKOP
  WHERE HVORG IN SEL_TAB.
    ADD WFKKOP-BETRW TO XY_AMOUNT.
  ENDLOOP.
ENDFORM.                               " AGGREGATE_OPEN_ITEMS
