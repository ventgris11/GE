*----------------------------------------------------------------------*
*   INCLUDE LE25SF20                                                   *
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  f20_check_import_params
*&---------------------------------------------------------------------*
*   Prüfung der Übergabeparameter des Fubas
*----------------------------------------------------------------------*
*      -->P_X_DATE   Stichtag der Anpassung
*      -->P_X_OPBEL  Anzupassender Abschlagsplan
*----------------------------------------------------------------------*
FORM f20_check_import_params USING p_func_name TYPE string
                                   p_x_date    TYPE d
                                   p_x_opbel   TYPE eabp-opbel.

* Ist x_date gefüllt
  IF p_x_date IS INITIAL.
    mac_msg_putx co_msg_error  '215' 'TU'
                 'X_DATE' p_func_name
                 space space input_error.
    IF 1 = 2. MESSAGE e215(tu) WITH space space. ENDIF.
  ENDIF.

* Ist x_eabp gefüllt?
  IF p_x_opbel IS INITIAL.
    mac_msg_putx co_msg_error '215' 'TU'
                 'X_OPBEL' p_func_name
                 space space input_error.
    IF 1 = 2. MESSAGE e215(tu) WITH space space. ENDIF.
  ENDIF.

ENDFORM.                               " F20_CHECK_IMPORT_PARAMS
*&---------------------------------------------------------------------*
*&      Form  f20_read_object
*&---------------------------------------------------------------------*
*       Liest zu einem Abschlagsplan das Objekt Budbilplan
*----------------------------------------------------------------------*
*      -->p_x_date   Stichtag der Anpassung
*      -->p_x_opbel  Anzupassender Abschlagsplan
*      <--p_l_obj    gelesenes Objekt Budbilplan
*----------------------------------------------------------------------*
FORM f20_read_object USING p_x_opbel TYPE eabp-opbel
                           p_l_obj   TYPE isu25_budbilplan.

  CALL FUNCTION 'ISU_O_BUDBILPLAN_OPEN'
    EXPORTING
      x_opbel               = p_x_opbel
      x_upd_online          = co_true
      x_wmode               = '2'
    IMPORTING
      y_obj                 = p_l_obj
    EXCEPTIONS
      not_found             = 1
      existing              = 2
      foreign_lock          = 3
      invalid_key           = 4
      number_error          = 5
      system_error          = 6
      internal_error        = 7
      not_created_noduedate = 8
      billing_error         = 9
      not_authorized        = 10
      OTHERS                = 11.
  IF sy-subrc NE 0.
    PERFORM f20_close_object USING p_l_obj.
    mac_msg_putx_wp co_msg_error sy-msgno sy-msgid
                    sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 open_error.
  ENDIF.

ENDFORM.                               " f20_read_object
*&---------------------------------------------------------------------*
*&      Form  f20_check_object
*&---------------------------------------------------------------------*
FORM f20_check_object USING p_obj         TYPE isu25_budbilplan
                            p_take_amount TYPE rea64-take_amount.

  DATA:          h_opbel LIKE eabp-opbel.
  FIELD-SYMBOLS: <ever>  LIKE ever.

* Prüfung, ob der alte Abschlagsplan statistisches oder
* Sollstellungsverfahren hatte
  IF p_obj-eabp-kzabsver NE co_absver_stat AND
     p_obj-eabp-kzabsver NE co_absver_soll.
    PERFORM f20_close_object USING p_obj.
*   Abgrenzung des Abschlagsplans &1 nicht möglich
    mac_msg_putx co_msg_error '316' 'TU'
                p_obj-eabp-opbel space space space
                input_error.
    IF 1 = 2. MESSAGE e316(tu) WITH space. ENDIF.
  ENDIF.

* JVL-Objekt vorhanden, nichts anpassen
  IF NOT p_obj-intejvl[] IS INITIAL.
    PERFORM f20_close_object USING p_obj.
*   AbschlPlan &1 unterliegt Jahresvorausleistung;
*                 keine Abgrenzung möglich
    mac_msg_putx co_msg_error '325' 'TU'
                p_obj-eabp-opbel space space space
                input_error.
    IF 1 = 2. MESSAGE e325(tu) WITH space. ENDIF.
  ENDIF.

* Keine Abgrenzung, falls alle Abschlagspläne deaktiv:
  LOOP AT p_obj-inteabp TRANSPORTING NO FIELDS WHERE deaktiv IS INITIAL.
    EXIT.
  ENDLOOP.
  IF sy-subrc NE 0.
    PERFORM f20_close_object USING p_obj.
*   Abschlagsplan &1 deaktiviert; keine Abgrenzung möglich
    mac_msg_putx co_msg_error '334' 'TU'
                p_obj-eabp-opbel space space space
                input_error.
    IF 1 = 2. MESSAGE e334(tu) WITH space. ENDIF.
  ENDIF.

* Existiert bereits ein Nachfolgeabschlagsplan?
  LOOP AT p_obj-intever ASSIGNING <ever>.
    SELECT opbel FROM eabp
                 INTO h_opbel
                 WHERE vertrag    EQ <ever>-vertrag
                 AND   begperiode GT p_obj-eabp-endperiode.
      EXIT.
    ENDSELECT.
    IF sy-subrc EQ 0.
      PERFORM f20_close_object USING p_obj.
*     Zum Vertrag &1 existiert ein zukünftiger Abschlagsplan (&2)
      mac_msg_putx co_msg_error '349' 'TU'
                  <ever>-vertrag h_opbel space space
                  input_error.
      IF 1 = 2. MESSAGE e349(tu) WITH space space. ENDIF.
    ENDIF.
  ENDLOOP.

ENDFORM.                    " f20_check_object
*&---------------------------------------------------------------------*
*&      Form  f20_act_date_determine
*&---------------------------------------------------------------------*
*       Ermittlung des frühestmöglichen Änderungstermins
*----------------------------------------------------------------------*
*      -->P_X_DATE  text
*      -->P_L_OBJ  text
*      <--P_ACT_DATE  text
*----------------------------------------------------------------------*
FORM f20_act_date_determine USING    p_x_date   TYPE d
                                     p_l_obj    TYPE isu25_budbilplan
                            CHANGING p_act_date TYPE d
                                     p_active   TYPE kennzx.

  DATA: tab_count   LIKE sy-tabix,
        f_active(1) TYPE c VALUE co_true,
        wa_eabps    LIKE eabps.
  DATA: l_kz             TYPE c,
        wa_op            TYPE fkkop,
        lt_op            TYPE TABLE OF fkkop,
        herkf_string(50) TYPE c VALUE
                  '01/05/06/19/20/21/22/25/26/45/55/03/04',
        h_herkf          LIKE fkkko-herkf.

  DEFINE mac_position_check.
    if &1 gt p_l_obj-eabp-endperiode.
      subtract 1 from tab_count.
      continue.
    endif.
    if &1 lt p_x_date.              "vor Eingabedatum?
*     Abgrenzdatum auf Eingabedatum belassen
      p_act_date = p_x_date.
      f_active = co_false.
      exit.
    endif.
  END-OF-DEFINITION.

  CLEAR f_vz_out.
  LOOP AT p_l_obj-ieabps INTO wa_eabps WHERE vorauszahl = 'L'.
    IF wa_eabps-faedn   GT p_l_obj-eabp-endperiode AND
       wa_eabps-solldat LE p_l_obj-eabp-endperiode.
      f_vz_out = co_true.
    ENDIF.
  ENDLOOP.

* Fälligkeiten von hinten nach vorne lesen
  DESCRIBE TABLE p_l_obj-ieabps LINES tab_count.

  WHILE tab_count GT 0.
    READ TABLE p_l_obj-ieabps INTO wa_eabps INDEX tab_count.

*   check if position is out of period
    IF p_l_obj-eabp-kzabsver = co_absver_soll OR
       ( wa_eabps-vorauszahl = 'L' AND
         f_vz_out = co_true ).
*     remember position:
      p_act_date = wa_eabps-solldat.
      mac_position_check wa_eabps-solldat.
    ELSE.
*     remember position:
      p_act_date = wa_eabps-faedn.
      mac_position_check wa_eabps-faedn.
    ENDIF.

    IF wa_eabps-solldat LT p_l_obj-kar_datum OR         "vor AVB-Frist?
        NOT wa_eabps-studt IS INITIAL  OR                    "gestundet?
        NOT wa_eabps-xaesp IS INITIAL  OR                    "gedruckt?
        NOT wa_eabps-xpyor IS INITIAL  OR               "payment order?
      ( NOT wa_eabps-pdtyp  IS INITIAL AND               "payment specification?
            wa_eabps-pdtyp NE '1' ) OR
        NOT wa_eabps-abwbl IS INITIAL  OR  "in Ratenplan/Sammelrechnung?
        NOT wa_eabps-einmalanf IS INITIAL.
      f_active = co_false.
      EXIT.
    ELSEIF
     ( NOT wa_eabps-augbl IS INITIAL AND
      wa_eabps-augbl NE wa_eabps-opbel ) .    "(Teil-)gezahlt?
      IF wa_eabps-augbl = '*'.
        CALL FUNCTION 'ISU_GET_ALL_PART_FKKOP'
          EXPORTING
            i_fkkop     = wa_eabps
            i_obj       = p_l_obj-fkkwh
            i_keyselect = 'Y'
          TABLES
            o_fkkop     = lt_op.
        LOOP AT lt_op INTO wa_op WHERE NOT augbl IS INITIAL.
*             Prüfung ob 'echter' Ausgleich vorliegt
          SELECT SINGLE herkf FROM dfkkko INTO h_herkf
                              WHERE opbel = wa_op-augbl.
          IF herkf_string CS h_herkf.
            l_kz = co_true.
            EXIT.
          ENDIF.
        ENDLOOP.
        IF  l_kz = co_true.
          f_active = co_false.
          EXIT.
        ENDIF.
      ELSE.
        f_active = co_false.
        EXIT.
      ENDIF.
    ENDIF.
    SUBTRACT 1 FROM tab_count.
  ENDWHILE.

  IF f_active = co_true.
*   alle Fälligkeiten sind aktiv
    p_act_date = p_l_obj-eabp-begperiode + 1.
  ENDIF.

  p_active = f_active.

ENDFORM.                               " f20_act_date_determine
*&---------------------------------------------------------------------*
*&      Form  f20_read_termdat
*&---------------------------------------------------------------------*
*       Bisherige und neue Portionen lesen, inkl. Zusatzdaten
*----------------------------------------------------------------------*
*      -->P_DATE  Abgrenztermin
*      -->P_L_OBJ  Objekt (bisheriger) Budbilplan
*      <--P_TAB_EVERC  interne Tabelle mit Termindaten
*----------------------------------------------------------------------*
FORM f20_read_termdat USING p_x_change  TYPE rea64-change
                            p_l_obj     TYPE isu25_budbilplan
                            p_alt_date  TYPE d
                            p_active    TYPE kennzx
                   CHANGING p_tab_everc TYPE epc_ever_change_tab
                            p_date      TYPE d.

  DATA: wa_everc            TYPE epc_ever_change,
        l_eabp              TYPE eabp,
        l_ever              TYPE ever,
        lv_eanl             TYPE v_eanl,
        l_periodic_mr_suppr TYPE kennzx,
        l_date              TYPE d,
        l_sup_date          TYPE d,
        temp_date           TYPE d,
        l_te418             LIKE te418,
        t_te418             TYPE TABLE OF te418,
        l_te417             LIKE te417,
        l_te420             LIKE te420.
  DATA: alt_te420 TYPE te420,
        alt_eanl  TYPE v_eanl.

  REFRESH: p_tab_everc.

  LOOP AT p_l_obj-inteabp INTO l_eabp.
    MOVE-CORRESPONDING l_eabp TO wa_everc.
    wa_everc-old_portion = l_eabp-portion.

*   Vertrag und Terminstammsatz (Portion) lesen
    mac_prot_log_off.
    CALL FUNCTION 'ISU_P_SMR_DETERMINE'
      EXPORTING
        x_vertrag    = l_eabp-vertrag
        x_key_date   = p_date
      IMPORTING
        y_te420      = l_te420
        y_v_eanl     = lv_eanl
      CHANGING
        xy_ever      = l_ever
      EXCEPTIONS
        not_found    = 1
        system_error = 2
        OTHERS       = 3.
    mac_prot_log_on.
    IF sy-subrc <> 0.
      mac_close p_l_obj co_msg_error read_error.
    ENDIF.

    IF p_active   EQ co_true AND
       p_alt_date GT p_date.
*     Read if alternative portion exists for change date (p_alt_date)
      mac_prot_log_off.
      CALL FUNCTION 'ISU_P_SMR_DETERMINE'
        EXPORTING
          x_vertrag    = l_eabp-vertrag
          x_key_date   = p_alt_date
        IMPORTING
          y_te420      = alt_te420
          y_v_eanl     = alt_eanl
        CHANGING
          xy_ever      = l_ever
        EXCEPTIONS
          not_found    = 1
          system_error = 2
          OTHERS       = 3.
      mac_prot_log_on.
      IF sy-subrc <> 0.
        mac_close p_l_obj co_msg_error read_error.
      ENDIF.

*     Use alternative portion instead
      IF alt_te420-termschl NE l_te420-termschl.
        l_te420 = alt_te420.
        lv_eanl = alt_eanl.
        p_date  = p_alt_date.
      ENDIF.

    ENDIF.

*   Terminsatz (Portion) lesen
    mac_prot_log_off.
    CALL FUNCTION 'ISU_DB_TE417_SELECT_PERIOD'
      EXPORTING
        x_termschl    = l_te420-termschl
        x_datum       = p_date
        x_abrvorg     = co_turabr
      IMPORTING
        y_te417       = l_te417
      EXCEPTIONS
        not_found     = 01
        system_error  = 02
        not_qualified = 03.
    mac_prot_log_on.
    IF sy-subrc <> 0.
      mac_close p_l_obj co_msg_error read_error.
    ENDIF.

*   check if suppression due to move-in meter reading (if existing)
    mac_prot_log_off.
    CALL FUNCTION 'ISU_SUPPRESS_IN_FUTURE_CHECK'
      EXPORTING
        x_ableinh     = lv_eanl-ableinh
        x_anlage      = lv_eanl-anlage
        x_bukrs       = l_ever-bukrs
        x_sparte      = l_ever-sparte
        x_adat        = l_ever-einzdat
        x_ablesgr     = '06'        "meter reading for move-in
      IMPORTING
        y_suppression = l_periodic_mr_suppr
        y_sup_date    = l_sup_date
      EXCEPTIONS
        OTHERS        = 1.
    mac_prot_log_on.
    IF sy-subrc NE 0.
      mac_close p_l_obj co_msg_error read_error.
    ENDIF.
    IF NOT l_periodic_mr_suppr IS INITIAL.
      CALL FUNCTION 'ISU_DB_TE418_SINGLE'
        EXPORTING
          x_termschl   = lv_eanl-ableinh
          x_termtdat   = l_te417-termtdat
        IMPORTING
          y_te418      = l_te418
        EXCEPTIONS
          not_found    = 1
          system_error = 2
          OTHERS       = 3.
      IF sy-subrc <> 0.
        CALL FUNCTION 'ISU_DB_TE418_SELECT_TERMTDAT'
          EXPORTING
            x_termschl    = lv_eanl-ableinh
            x_termtdat    = l_te417-termtdat
          TABLES
            t_te418       = t_te418
          EXCEPTIONS
            not_found     = 1
            system_error  = 2
            not_qualified = 3
            OTHERS        = 4.
        IF sy-subrc <> 0.
          mac_close p_l_obj co_msg_error read_error.
        ENDIF.

        SORT t_te418 BY termtdat DESCENDING.
        READ TABLE t_te418 INTO l_te418 INDEX 1.
      ENDIF.
      IF l_te418-adatsoll = l_sup_date.
*       Wenn der unterdrückte Termin der bereits gelesen ist -->
*       Nächsten lesen
        l_date = l_te417-termtdat + 1.
*       Terminsatz (Portion) der Folgeperiode lesen
        mac_prot_log_off.
        CALL FUNCTION 'ISU_DB_TE417_SELECT_PERIOD'
          EXPORTING
            x_termschl    = l_te420-termschl
            x_datum       = l_date
            x_abrvorg     = co_turabr
          IMPORTING
            y_te417       = l_te417
          EXCEPTIONS
            not_found     = 01
            system_error  = 02
            not_qualified = 03.
        mac_prot_log_on.
        IF sy-subrc <> 0.
          mac_close p_l_obj co_msg_error read_error.
        ENDIF.
        IF p_x_change = co_false AND
           temp_date IS INITIAL.
*         Abgrenzdatum verschieben, aber nur wenn 'echter
*         Portionswechsel'
          temp_date = l_date - 1.
        ENDIF.
      ENDIF.
    ENDIF.

    wa_everc-new_portion = l_te420-termschl.
    wa_everc-gemfakt = l_ever-gemfakt.
    IF NOT l_ever-abszyk IS INITIAL.
      wa_everc-abszyk = l_ever-abszyk.
    ELSE.
      wa_everc-abszyk = l_te420-abszyk.
    ENDIF.
    wa_everc-termtdat = l_te417-termtdat.
    wa_everc-new_plan = co_true.
    APPEND wa_everc TO p_tab_everc.
  ENDLOOP.

  IF NOT temp_date IS INITIAL.
    p_date = temp_date.
  ENDIF.

ENDFORM.                               " f20_check_change
*&---------------------------------------------------------------------*
*&      Form  check_termdat
*&---------------------------------------------------------------------*
*       - Hat überhaupt ein Wechsel einer Portion stattgefunden?
*       - Ist dieser Wechsel innerhalb einer Muss-Gruppe konsistent?
*----------------------------------------------------------------------*
*      -->P_TAB_EVERC  Tabelle mit Termindaten
*----------------------------------------------------------------------*
FORM check_termdat USING p_x_change  TYPE rea64-change
                         p_tab_everc TYPE epc_ever_change_tab
                         p_l_obj     TYPE isu25_budbilplan.

  DATA: l_tab_everc TYPE epc_ever_change_tab,
        f_first     TYPE c VALUE co_true,
        h_termtdat  TYPE termtdat,
        h_portion1  TYPE eabp-portion,
        h_portion2  TYPE eabp-portion.
  FIELD-SYMBOLS: <everc> TYPE epc_ever_change.

* konsistenter Wechsel innerhalb Muss-Gruppe
  LOOP AT p_tab_everc ASSIGNING <everc>
                      WHERE gemfakt EQ co_invoice_must.
    IF f_first = co_true.
      h_portion1 = <everc>-old_portion.
      h_portion2 = <everc>-new_portion.
      h_termtdat = <everc>-termtdat.
      f_first = co_false.
      CONTINUE.
    ENDIF.
    IF h_portion1 NE <everc>-old_portion OR
       h_portion2 NE <everc>-new_portion.
      PERFORM f20_close_object USING p_l_obj.
*     Abgrenzung des Abschlagsplans &1 nicht möglich
      mac_msg_putx co_msg_error '315' 'TU'
                  p_l_obj-eabp-opbel space space space
                  input_error.
      IF 1 = 2. MESSAGE e315(tu) WITH space. ENDIF.
    ELSE.
*     In allen Einträgen bis auf einen wird das Kennzeichen zum
*     Anlegen eines neuen Abschlagsplans gelöscht
      CLEAR <everc>-new_plan.
*     Determine the youngest end of billing period
      IF <everc>-termtdat GT h_termtdat.
        h_termtdat = <everc>-termtdat.
      ENDIF.
    ENDIF.
  ENDLOOP.
* Take over the youngest end of billing period in all entries
  LOOP AT p_tab_everc ASSIGNING <everc>
                      WHERE gemfakt EQ co_invoice_must.
    <everc>-termtdat = h_termtdat.
  ENDLOOP.

* Prüfung, ob überhaupt irgendein Wechsel vorliegt.
* -> Löschen aller Einträge, die keine Veränderung erfuhren
  l_tab_everc[] = p_tab_everc[].
  IF p_x_change = co_false.
    LOOP AT l_tab_everc ASSIGNING <everc>.
      IF <everc>-old_portion EQ <everc>-new_portion.
        DELETE l_tab_everc.
      ENDIF.
    ENDLOOP.
  ENDIF.

  IF l_tab_everc[] IS INITIAL.
    PERFORM f20_close_object USING p_l_obj.
*   Keine Abgrenzung des Abschlagsplans &1 nötig
    mac_msg_putx co_msg_success '314' 'TU'
                p_l_obj-eabp-opbel space space space
                no_change_necessary.
    IF 1 = 2. MESSAGE e314(tu) WITH space. ENDIF.
  ENDIF.

ENDFORM.                               " check_portion_change
*&---------------------------------------------------------------------*
*&      Form  f20_deactivate_old_object
*&---------------------------------------------------------------------*
*       Alle Fälligkeiten nach Änderungsdatum werden deaktiviert
*----------------------------------------------------------------------*
*      -->P_DATE   Änderungsdatum
*      -->P_L_OBJ  BBP-Objekt
*----------------------------------------------------------------------*
FORM f20_deactivate_old_object USING p_date  TYPE d
                                     p_augrd TYPE eabps-augrd
                            CHANGING p_l_obj TYPE isu25_budbilplan.

  DATA: wa_eabps LIKE eabps,
        wa_eabp  LIKE eabp.
  FIELD-SYMBOLS: <date> TYPE d.

* Positionen deaktivieren
  IF p_l_obj-eabp-kzabsver = co_absver_soll.
    ASSIGN wa_eabps-solldat TO <date>.
  ELSE.
    ASSIGN wa_eabps-faedn TO <date>.
  ENDIF.
  LOOP AT p_l_obj-ieabps INTO wa_eabps.
    IF wa_eabps-vorauszahl = 'L' AND
       f_vz_out = co_true.
      CHECK wa_eabps-solldat GT p_date AND
            wa_eabps-solldat LE p_l_obj-eabp-endperiode.
    ELSE.
      CHECK <date> GT p_date AND
            <date> LE p_l_obj-eabp-endperiode.
    ENDIF.
    wa_eabps-augdt = sy-datum.
    wa_eabps-augbl = wa_eabps-opbel.
    wa_eabps-augbd = wa_eabps-budat.
    wa_eabps-augrd = p_augrd.
    wa_eabps-augst = co_augst_9.
    MODIFY p_l_obj-ieabps FROM wa_eabps INDEX sy-tabix.
  ENDLOOP.

* neues Ende der Periode im Abschlagsplan:
  LOOP AT p_l_obj-inteabp INTO wa_eabp.
    wa_eabp-vsperre = co_true.
    wa_eabp-endperiode = p_date.
    MODIFY p_l_obj-inteabp FROM wa_eabp INDEX sy-tabix.
  ENDLOOP.

* EABP neu füllen
  READ TABLE p_l_obj-inteabp INTO p_l_obj-eabp INDEX 1.

ENDFORM.                               " f20_deactivate_old_object
*&---------------------------------------------------------------------*
*&      Form  f20_update_object
*&---------------------------------------------------------------------*
*       Bisherigen Abschlagsplan wegschreiben
*----------------------------------------------------------------------*
*      -->P_L_OBJ  BBP-Objekt
*----------------------------------------------------------------------*
FORM f20_update_object USING p_l_obj TYPE isu25_budbilplan.

  mac_prot_log_off.
  CALL FUNCTION 'ISU_BBP_UPDATE_CHANGE'
    EXPORTING
      no_reprint        = co_true
      x_mass            = co_false
      x_upd_task        = co_false
    CHANGING
      xy_obj            = p_l_obj
    EXCEPTIONS
      update_incomplete = 1
      OTHERS            = 2.
  mac_prot_log_on.

  IF sy-subrc <> 0.
    mac_close p_l_obj co_msg_error update_error.
  ENDIF.

ENDFORM.                               " f20_update_object
*&---------------------------------------------------------------------*
*&      Form  f20_create_new_bbp
*&---------------------------------------------------------------------*
FORM f20_create_new_bbp USING p_date        TYPE d
                              p_tab_everc   TYPE epc_ever_change_tab
                              p_l_obj       TYPE isu25_budbilplan
                              p_t_newbbp    TYPE isu25_t_obj
                              p_no_dialog   TYPE regen-no_dialog
                              p_take_amount TYPE rea64-take_amount
                   pt_auto_pc TYPE isu25_auto_portion_change_tab.

  DATA: start_date    TYPE d,
        l_auto        TYPE isu25_budbilplan_auto,
        wa_everc      TYPE epc_ever_change,
        db_update     LIKE regen-db_update,
        new_obj       TYPE isu25_budbilplan,
        wa_eabp       TYPE eabp,
        wa_vorauszdat TYPE eabp-vorauszdat,
        wa_bbpkey     TYPE isu25_budbilplan_key.

  start_date = p_date + 1.

* Löschen aller Einträge, für die kein neuer Abschlagsplan angelegt wird
* 1. Da der Abschlagszyklus inzwischen gleich null ist
* 2. Da im Vertragskonto das Abschlagsverfahren umgestellt wurde
  LOOP AT p_tab_everc INTO wa_everc.
    IF wa_everc-abszyk           EQ '00' OR
       ( p_l_obj-vkonto-kzabsver NE co_absver_stat AND
         p_l_obj-vkonto-kzabsver NE co_absver_soll ).
      DELETE p_tab_everc.
    ENDIF.
  ENDLOOP.

  IF NOT p_no_dialog IS INITIAL.
*   Automationsdaten füllen, falls ohne Dialog gerufen
    l_auto-rea61_use    = co_true.
    l_auto-rea61-opbel  = space.
    l_auto-rea61_okcode = co_save.
  ENDIF.

  IF p_take_amount = co_true.
*   Nur bei Betragsübernahme Automationsdaten füllen
    l_auto-auto_pc = pt_auto_pc.
  ENDIF.

  LOOP AT p_tab_everc INTO wa_everc WHERE new_plan = co_true.
*   Aufbau aller Abschlagspläne

*   Vorauszahldatum setzen falls Vorauszahlung noch nicht deaktiviert
    CLEAR wa_vorauszdat.
    IF p_l_obj-eabp-abschldat IS INITIAL.
      wa_vorauszdat = p_l_obj-eabp-vorauszdat.
    ENDIF.

    mac_prot_log_off.
    CALL FUNCTION 'ISU_S_BUDBILPLAN_CREATE'
      EXPORTING
        x_vertrag             = wa_everc-vertrag
        x_edatum              = start_date
        x_upd_online          = co_true
        x_no_dialog           = p_no_dialog
        x_no_mass             = co_true
        x_auto                = l_auto
        x_vorauszdat          = wa_vorauszdat
        x_ep_period           = 'P'
      IMPORTING
        y_db_update           = db_update
        y_obj                 = new_obj
      EXCEPTIONS
        not_found             = 1
        existing              = 2
        foreign_lock          = 3
        number_error          = 4
        input_error           = 5
        system_error          = 6
        not_created_noduedate = 7
        billing_error         = 8
        not_authorized        = 9
        OTHERS                = 10.
    mac_prot_log_on.

    IF sy-subrc NE 0.
      IF sy-subrc EQ 2 OR
         sy-subrc EQ 7.
        mac_msg_putx_wp co_msg_information sy-msgno sy-msgid
                      sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 space.
      ELSE.
        ROLLBACK WORK.
        mac_msg_putx_wp co_msg_error sy-msgno sy-msgid
                       sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 update_error.
      ENDIF.
    ENDIF.
    IF NOT db_update IS INITIAL.
*     Tabelle der neu angelegten Abschlagspläne füllen
      APPEND new_obj TO p_t_newbbp.
    ENDIF.
  ENDLOOP.

ENDFORM.                               " f20_create_new_bbp
*&---------------------------------------------------------------------*
*&      Form  f20_change_act_date
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_L_OBJ  text
*      -->P_ACT_DATE  text
*      -->P_X_NO_NEW  text
*      -->P_TAB_EVERC  text
*----------------------------------------------------------------------*
FORM f20_change_act_date USING p_l_obj     TYPE isu25_budbilplan
                               p_act_date  TYPE d
                               p_x_no_new  TYPE rea64-no_new
                               p_tab_everc TYPE epc_ever_change_tab.

  DATA: wa_everc TYPE epc_ever_change.

* p_date mit dem ersten Eintrag füllen:
  READ TABLE p_tab_everc INDEX 1 INTO wa_everc .
  p_act_date = wa_everc-termtdat.

* Das früheste TERMTDAT bestimmt das Abgrenzdatum:
* (alle TERMTDAT liegen nach p_date, da mit diesem Datum Terminsätze
*  gelesen wurden!)
  LOOP AT p_tab_everc INTO wa_everc.
    IF wa_everc-termtdat LT p_act_date.
      p_act_date = wa_everc-termtdat.
    ENDIF.
  ENDLOOP.

  IF p_l_obj-eabp-endperiode EQ p_act_date.
*   conversion of budbilplan &1 not necessary
    PERFORM f20_close_object USING p_l_obj.
    mac_msg_putx co_msg_information '336' 'TU'
                p_l_obj-eabp-opbel space space space
                no_change_necessary.
    IF 1 = 2. MESSAGE e336(tu) WITH space. ENDIF.
  ELSEIF p_l_obj-eabp-endperiode LT p_act_date.
*   nur einen neuen ABP anlegen:
    p_act_date = p_l_obj-eabp-endperiode.
    p_x_no_new = co_false.
  ELSE.
*   nur den alten ABP abgrenzen:
    p_x_no_new = co_true.
  ENDIF.

ENDFORM.                    " f20_change_act_date

*---------------------------------------------------------------------*
*       FORM f20_close_object                                         *
*---------------------------------------------------------------------*
FORM f20_close_object USING p_obj TYPE isu25_budbilplan.

  CALL FUNCTION 'ISU_O_BUDBILPLAN_CLOSE'
    CHANGING
      xy_obj = p_obj.

ENDFORM.                    "f20_close_object
*&---------------------------------------------------------------------*
*&      Form  f20_take_over_amount
*&---------------------------------------------------------------------*
FORM f20_take_over_amount
               USING    p_obj       TYPE isu25_budbilplan
                        p_tab_everc TYPE epc_ever_change_tab
               CHANGING pt_auto_pc  TYPE isu25_auto_portion_change_tab.

  DATA: BEGIN OF wa_cdate,
          vorauszahl LIKE eabps-vorauszahl,
          faedn      LIKE eabps-faedn,
          logno      LIKE eabps-logno,
        END OF wa_cdate,
        BEGIN OF wa_vtref,
          vtref LIKE eabps-vtref,
        END OF wa_vtref.
  DATA: it_cdate  LIKE TABLE OF wa_cdate,
        it_vtref  LIKE TABLE OF wa_vtref,
        h_vtref   LIKE eabps-vtref,
        l_auto_pc TYPE isu25_auto_portion_change.
  FIELD-SYMBOLS: <eabps> LIKE eabps,
                 <eabp>  LIKE eabp,
                 <ever>  LIKE ever,
                 <everc> TYPE epc_ever_change.

  LOOP AT p_obj-intever ASSIGNING <ever>.
    CALL FUNCTION 'ISU_INTERNAL_VERTRAG_TO_VTREF'
      EXPORTING
        i_vertrag = <ever>-vertrag
      IMPORTING
        e_vtref   = h_vtref.

    CLEAR l_auto_pc.
*   Übernahme aller deaktivierter Positionen
    LOOP AT p_obj-ieabps ASSIGNING <eabps> WHERE vtref = h_vtref
                                           AND   augrd = co_augrd_pc.
      APPEND <eabps> TO l_auto_pc-ieabps.
    ENDLOOP.
    IF sy-subrc NE 0.
*     Es wurden keine Positionen deaktiviert; letzten Eintrag nehmen
      LOOP AT p_obj-ieabps ASSIGNING <eabps> WHERE vtref = h_vtref.
        wa_cdate-vorauszahl = <eabps>-vorauszahl.
        wa_cdate-faedn      = <eabps>-faedn.
        wa_cdate-logno      = <eabps>-logno.
        COLLECT wa_cdate INTO it_cdate.
      ENDLOOP.
      SORT it_cdate DESCENDING BY faedn vorauszahl.
      READ TABLE it_cdate INTO wa_cdate INDEX 1.
*     Jetzt steht die LOGNO der letzten Fälligkeit fest
      LOOP AT p_obj-ieabps ASSIGNING <eabps>
                           WHERE logno = wa_cdate-logno
                           AND   vtref = h_vtref.
        APPEND <eabps> TO l_auto_pc-ieabps.
      ENDLOOP.
    ENDIF.
    SORT l_auto_pc-ieabps BY faedn vorauszahl.

*   Neuen Abschlagszyklus füllen
    READ TABLE p_tab_everc ASSIGNING <everc>
                           WITH KEY vertrag = <ever>-vertrag.
    l_auto_pc-abszyk_new = <everc>-abszyk.

*   Zum Vertrag passenden EABP-Eintrag suchen
    READ TABLE p_obj-inteabp ASSIGNING <eabp>
                        WITH KEY vertrag = <ever>-vertrag.
*   Weitere Automationsdaten füllen. Bei Erweiterung der Struktur werden
*   die neuen Felder automatisch aus dem Kopf EABP übernommen
    MOVE-CORRESPONDING <eabp> TO l_auto_pc.
    APPEND l_auto_pc TO pt_auto_pc.
  ENDLOOP.

ENDFORM.                    " f20_take_over_amount
*&---------------------------------------------------------------------*
*&      Form  f20_check_move_out
*&---------------------------------------------------------------------*
*    Prüft, ob für einen der Verträge ein Auszug vorliegt und verschiebt
*    das Eingabedatum entsprechend. Die gestoppten Abschlagspläne
*    werden aus xy-obj entfernt und in y_obj geschrieben, um sie vor dem
*    Update wieder anzuhängen
*----------------------------------------------------------------------*
*      x_date Eingabedatum
*      xy_OBJ Abschlagspläne
*      y_OBJ  gestoppte Abschlagspläne
*      y_date geaendertes Eingabedatum
*----------------------------------------------------------------------*
FORM f20_check_move_out USING    x_date LIKE syst-datum
                        CHANGING xy_obj TYPE isu25_budbilplan
                                 y_date LIKE syst-datum.

  DATA: wa_eabp TYPE eabp,
        l_vtref TYPE fkkop-vtref,
        l_eabps TYPE eabps.

  y_date = x_date.

  LOOP AT xy_obj-inteabp INTO wa_eabp
        WHERE NOT abstopdat IS INITIAL
        OR    NOT absperdat IS INITIAL.
* Eingabedatum auf Stop/sperrdatum setzen wenn es zeitlich davor liegt
    IF NOT wa_eabp-abstopdat IS INITIAL.
      IF y_date LT wa_eabp-abstopdat.
        y_date = wa_eabp-abstopdat.
      ENDIF.
    ENDIF.
    IF NOT wa_eabp-absperdat IS INITIAL.
      IF y_date LT wa_eabp-absperdat.
        y_date = wa_eabp-absperdat.
      ENDIF.
    ENDIF.

  ENDLOOP.

ENDFORM.                    " f20_check_move_out
*DEB-IBENRAHHALI-20180715-GE-1554
*&---------------------------------------------------------------------*
*&      Form  f20_change_object_amount
*&---------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
*----------------------------------------------------------------------*
FORM f20_change_object_amount CHANGING p_l_obj TYPE isu25_budbilplan.

  FIELD-SYMBOLS: <ls_eabps> TYPE eabps.

  LOOP AT p_l_obj-ieabps ASSIGNING <ls_eabps> WHERE augst <> '9'.
*DEB-IBENRAHHALI-20180715-GE-1902
*    <ls_eabps>-betrw = 0.
    IF <ls_eabps>-potyp = 'T'.
      <ls_eabps>-betrw = <ls_eabps>-augbt.
    ELSE.
      <ls_eabps>-betrw = 0.
    ENDIF.
*FIN-IBENRAHHALI-20180715-GE-1902
  ENDLOOP.

ENDFORM.                               " f20_change_object_amount
*FIN-IBENRAHHALI-20180715-GE-1554
