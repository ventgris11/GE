FUNCTION ISU_ZINTFC01.
*"--------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(X_OP) TYPE  ISU2A_VARIANT_PARAMETERS
*"     REFERENCE(X_SS) TYPE  ISU2A_SS
*"  CHANGING
*"     REFERENCE(XY_OBJ) TYPE  ISU2A_BILLING_DATA
*"  EXCEPTIONS
*"      GENERAL_FAULT
*"      REGULAR_ERROR
*"--------------------------------------------------------------------
  INCLUDE IEVARBASIC.

*  MAC_CONTROL_CHECK 2.
*  MAC_BELZART_CHECK 1.
*
* preparing some data for the info invoice line
*  MOVE-CORRESPONDING X_SS TO WERCHZ.
*
*  MAC_INIT_OUTPUT X_SS-VARCONT2 X_OP-O1.

  LOOP AT X_OP-T1 INTO WPARA.
* doing the output processing
    MOVE-CORRESPONDING WPARA TO OUT_OPER.
    MAC_OUTPUT_IOPER X_OP-O1.
* writing the info line.
*    WERCHZ-AB = WPARA-AB.
*    WERCHZ-BIS = WPARA-BIS.
*    WERCHZ-I_ZAHL1 = OUT_OPER-QNT_NEW.
*    WERCHZ-MASS1 = X_OP-I1-MASS.
*
*    MAC_INVOICE_LINE_INFO X_SS-VARCONT1 CO_DLTYP01.

  ENDLOOP.                             "x_op-t1

check 1 = 2 .

* doing the same for the second operand.
"  LOOP AT X_OP-T2 INTO WPARA.
"* doing the output processing
"    MOVE-CORRESPONDING WPARA TO OUT_OPER.
"    MAC_OUTPUT_IOPER X_OP-O1.
"* writing the info line.
"    WERCHZ-AB = WPARA-AB.
"    WERCHZ-BIS = WPARA-BIS.
"    WERCHZ-I_ZAHL1 = OUT_OPER-QNT_NEW.
"    WERCHZ-MASS1 = X_OP-I2-MASS.

"    MAC_INVOICE_LINE_INFO X_SS-VARCONT1 CO_DLTYP01.

"  ENDLOOP.                             "x_op-t2
ENDFUNCTION.
