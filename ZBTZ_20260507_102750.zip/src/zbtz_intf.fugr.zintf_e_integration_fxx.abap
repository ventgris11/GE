FUNCTION zintf_e_integration_fxx .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_IDENREG) TYPE  ZIDENREG
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN DEFAULT ABAP_FALSE
*"     REFERENCE(IV_ID_FLUX) TYPE  ZID_FLUX
*"  EXPORTING
*"     REFERENCE(EV_ERROR) TYPE  CRMT_BOOLEAN
*"----------------------------------------------------------------------

  DATA: ls_id_enreg             TYPE zintf_g_donnees_generique,
        lv_log_handle           TYPE balloghndl,
        lv_art_sd_remise_grd    TYPE rvari_val_255,
        lt_fxx                  TYPE TABLE OF zintf_e_fxx,
        lt_fxx_temp             TYPE TABLE OF zintf_e_fxx,
        lv_num_dossier_affaire  TYPE string,
*        ls_fxx                 TYPE zintf_e_fxx,
        ls_temp_fxx             TYPE zintf_e_fxx,
        ls_fxx_temp             TYPE zintf_e_fxx,
        lv_int_ui               TYPE int_ui,
        lv_pourcent_rem_grd     TYPE wert,
        lv_taux_rem             TYPE betrw_kk,
        lv_ko                   TYPE flag,
        lv_bukrs                TYPE stdbk_kk,
        lv_blocage              TYPE flag,
        lv_sparte               TYPE sparte,
        lv_posnr                TYPE posnr,
*        lv_message              TYPE string,
        lr_switch_doc           TYPE REF TO cl_isu_ide_switchdoc,
        ls_switch_doc           TYPE eideswtdoc,
        ls_object               TYPE eedm_isu_objects,
        lt_mr_data              TYPE TABLE OF bapieabl,
        lt_mr_reason            TYPE TABLE OF bapieablg,
        lv_date                 TYPE datum,
        ls_sales_order_header   TYPE zisus_sales_order_header,
        lt_sales_order_header   TYPE TABLE OF zisus_sales_order_header,
        ls_sales_order_item     TYPE zisus_sales_order_item,
        lt_debit_note_item_tmp  TYPE zisut_sales_order_item,
        lt_credit_note_item_tmp TYPE zisut_sales_order_item,
        lt_debit_note_item      TYPE zisut_sales_order_item,
        lt_credit_note_item     TYPE zisut_sales_order_item,
        lv_vbeln                TYPE vbeln,
        lt_return               TYPE bapiret2_t,
        ls_return               TYPE bapiret2,
        lv_anlage               TYPE anlage,
        lv_temp_matnr           TYPE string,
        lv_emetteur             TYPE zemetteur_id,
        lv_idenreg              TYPE zintf_g_id_enreg,
        lv_id_evt               TYPE string,
        lv_fin                  TYPE string,
        v_date                  TYPE zdate_fin_frais,
        lv_compte_contrat       TYPE flag, "++GE-218
        ls_c01                  TYPE zintf_e_c01, "++GE-218
        lv_date_c01             TYPE dats, "++GE-218
        lv_date_max             TYPE dats, "++GE-218
        lv_date_min             TYPE dats. "++GE-218

*DEB-IBEN-20190116-GE-2300
  DATA: lv_guid_16           TYPE guid_16,
        lv_guid_22           TYPE sysuuid-c22,
        lv_date_retracted    TYPE dats,
        lv_is_retracted      TYPE abap_bool,
        lr_cl_crm            TYPE REF TO cl_crm_activities_util,
        lv_rfcdest           TYPE rfcdest,
        lv_result            TYPE crmt_boolean,
        lv_post_retractation TYPE abap_bool,
        lv_frais_sans_mes    TYPE abap_bool.
*FIN-IBEN-20190116-GE-2300

  CLEAR ev_error.

  lv_log_object    = lc_log_object_intf_elec.
  IF iv_id_flux = 'F03A'.
    lv_log_subobject = lc_log_subobject_f03.
  ELSEIF iv_id_flux = 'F15D'.
    lv_log_subobject = lc_log_subobject_f15.

  ENDIF.
  lv_msgid         = lc_msgid_intf_elec.

* Appel en mode &1 pour le flux &2
  IF 1 = 2. MESSAGE i018(zintf_e_messages). ENDIF.
  IF iv_mode_test IS INITIAL.
    macro_add_msg_to_log 'I' '018'
                         'REEL' iv_id_flux '' ''.
  ELSE.
    macro_add_msg_to_log 'I' '018'
                         'TEST' iv_id_flux '' ''.
  ENDIF.

  IF iv_id_flux = 'F03A'.
* Sélection des données à traiter
    SELECT * FROM zintf_e_f03a
    INTO TABLE lt_fxx
    WHERE idenreg EQ iv_idenreg.

    SORT lt_fxx BY num_dossier id_prm.

  ELSEIF iv_id_flux = 'F15D'.
* Sélection des données à traiter
    SELECT * FROM zintf_e_f15d
    APPENDING CORRESPONDING FIELDS OF TABLE lt_fxx
    WHERE idenreg EQ iv_idenreg.

    SORT lt_fxx BY id_affaire id_prm.


*+GE-18775 {
    SELECT *
      FROM zintf_param_f15
      INTO TABLE @DATA(lt_param_f15).
*+GE-18775 }
  ENDIF.


  LOOP AT lt_fxx INTO ls_fxx.

    CLEAR : lv_blocage, ls_sales_order_item, ls_sales_order_header,
lv_ko.
*DEB-IBEN-20190116-GE-2300
    CLEAR : lv_post_retractation, lv_frais_sans_mes.
*FIN-IBEN-20190116-GE-2300
    REFRESH :
    lt_sales_order_header,
    lt_debit_note_item,
    lt_credit_note_item.

    ls_temp_fxx = ls_fxx.
*   fxx : Traitement de l'enregistrement &1

    IF 1 = 2. MESSAGE i164(zintf_e_messages). ENDIF.

    macro_add_msg_to_log 'I' '164'
                             ls_fxx-idenreg '' '' ''.

**************************************************************
*******Etape n°1 : Vérifier si la ligne est pertinente *******
**************************************************************

    IF iv_id_flux = 'F03A'.



      IF ls_temp_fxx-groupe_article <> 'G2'.
        IF 1 = 2. MESSAGE i162(zintf_e_messages) INTO lv_message. ENDIF.

        macro_add_msg_to_log 'I' '162' '' '' '' ''.

        PERFORM update_ligne_fxx USING lc_statut_11_filtre iv_id_flux.


        CONTINUE.
      ENDIF.

      lv_num_dossier_affaire = ls_temp_fxx-num_dossier.
      lv_temp_matnr = ls_temp_fxx-id_article.

    ELSEIF iv_id_flux = 'F15D'.


*+GE-18775 {
      READ TABLE lt_param_f15 INTO DATA(ls_param_f15) WITH KEY id_ev = ls_temp_fxx-id_e_v BINARY SEARCH.
      IF sy-subrc EQ 0.
        IF ls_temp_fxx-nature_e_v <> '001'.
          IF 1 = 2. MESSAGE i162(zintf_e_messages) INTO lv_message. ENDIF.

          macro_add_msg_to_log 'I' '162' '' '' '' ''.

          PERFORM update_ligne_fxx USING lc_statut_11_filtre iv_id_flux.

          CONTINUE.
        ENDIF.
      ELSE.
*+GE-18775 }

* GLIC - GE-8151 - 2020/01/20 - Début - Ajout du 003
        IF ls_temp_fxx-nature_e_v <> '002'.
          IF ls_temp_fxx-nature_e_v <> '003'.


            IF 1 = 2. MESSAGE i162(zintf_e_messages) INTO lv_message. ENDIF.

            macro_add_msg_to_log 'I' '162' '' '' '' ''.

            PERFORM update_ligne_fxx USING lc_statut_11_filtre iv_id_flux.

            CONTINUE.
          ENDIF.
        ENDIF.
      ENDIF.
* GLIC - GE-8151 - 2020/01/20 - Fin

      lv_num_dossier_affaire = ls_temp_fxx-id_affaire.
      SPLIT ls_temp_fxx-id_e_v AT '-' INTO lv_id_evt lv_fin.
      lv_temp_matnr = lv_id_evt.
    ENDIF.


****************************************************
*******Etape n°2 : Vérifier l’existence du PCE*******
****************************************************
    lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num =
                                                  ls_temp_fxx-id_prm ).
    IF lv_int_ui IS INITIAL.

      MESSAGE e160(zintf_e_messages) WITH ls_temp_fxx-id_prm INTO lv_msg_bpem.

      lv_interface = ls_temp_fxx-id_flux .
      CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
        EXPORTING
          iv_interface_name = lv_interface
          iv_sparte         = 'ZE'
          is_structure      = ls_temp_fxx.

      macro_add_msg_to_log 'E' '160' ls_temp_fxx-id_prm '' '' ''.
      PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.
      CONTINUE.
    ENDIF.

*    IF ls_temp_fxx-DATE_FIN_FRAIS GE sy-datum.
    IF iv_id_flux = 'F15D'.
      IF ls_temp_fxx-date_effet_frais GE sy-datum.
        "Date fin frais devrait être antérieure à la date du jour
        IF 1 = 2. MESSAGE e412(zintf_e_messages). ENDIF.
        macro_add_msg_to_log 'E' '412' '' '' '' ''.
        PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.
        CONTINUE .
      ENDIF.
    ENDIF.

*++ STOU DEBUT GE-218
    IF ls_temp_fxx-compte_contrat IS NOT INITIAL.
      "Vérifier que le compte de contrats renseigné existe
      SELECT SINGLE vkont
        FROM fkkvk
        INTO @DATA(lv_vkont)
        WHERE vkont = @ls_temp_fxx-compte_contrat .
      IF sy-subrc NE 0.
        IF 1 = 2. MESSAGE e422(zintf_e_messages). ENDIF.
        macro_add_msg_to_log 'E' '422' ls_temp_fxx-compte_contrat
                                       '' '' ''.
        PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.
        RETURN.
      ENDIF.

      "Vérifier que le compte de contrats renseigné est lié au PRM du flux
      v_date = ls_temp_fxx-date_effet_frais.
*DEB-IBEN-20201027-GE-8158
      IF iv_id_flux = 'F03A'.
        lv_frais_sans_mes = abap_true.
      ELSE.
        "Récupération de l'installation
        SELECT SINGLE anlage
          FROM euiinstln
          INTO lv_anlage
          WHERE int_ui   EQ lv_int_ui
            AND datefrom LE v_date
            AND dateto   GE v_date.

        SELECT SINGLE anlage
          FROM ever
          INTO lv_anlage
          WHERE vkonto = ls_temp_fxx-compte_contrat
            AND anlage = lv_anlage.
*          AND einzdat LE v_date
*          AND auszdat GE v_date .
        IF sy-subrc NE 0.
          IF 1 = 2. MESSAGE e423(zintf_e_messages). ENDIF.
          macro_add_msg_to_log 'E' '423' ls_temp_fxx-compte_contrat
                                         ls_temp_fxx-id_prm
                                         '' ''.
          PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.
          RETURN.
        ENDIF.
      ENDIF.
*FIN-IBEN-20201027-GE-8158

      lv_compte_contrat = abap_true.

    ELSE.
*      Vérifier si l’article est listé dans ZF03A_RECH_C01
      SELECT SINGLE article
        FROM zf03a_rech_c01
        INTO @DATA(lv_article)
        WHERE article = @ls_temp_fxx-id_article .
      IF sy-subrc IS INITIAL. "Article trouvé
        "Recherche C01 de type S non filtré avec même numéro d'affaire

        SELECT SINGLE *
          FROM zintf_e_c01
          INTO ls_c01
          WHERE id_prm = ls_temp_fxx-id_prm
            AND statut NE '11'
            AND even_declencheur = 'S'
            AND num_dossier = ls_temp_fxx-num_dossier .
        IF sy-subrc IS INITIAL.
          "Le flux C01 trouvé est-il intégré ?
          IF ls_c01-statut NE '07' . "-->Non
            RETURN.
          ELSE. "--> Oui
            lv_date_c01 = ls_c01-date_abonnement .
          ENDIF.
        ELSE.
          "Recherche C01 de type S non filtré à +/- 30 jours


          lv_date_max = ls_temp_fxx-date_effet_frais + 30.
          lv_date_min = ls_temp_fxx-date_effet_frais - 30.

          CLEAR ls_c01 .
          SELECT SINGLE *
            FROM zintf_e_c01
            INTO ls_c01
            WHERE id_prm = ls_temp_fxx-id_prm
              AND statut NE '11'
              AND even_declencheur = 'S'
*              AND num_dossier = ls_temp_fxx-num_dossier
              AND date_abonnement BETWEEN lv_date_min AND lv_date_max .
          IF sy-subrc IS INITIAL.
            IF 1 = 2. MESSAGE e424(zintf_e_messages). ENDIF.
            macro_add_msg_to_log 'E' '424' ls_temp_fxx-num_dossier
                                           '' '' ''.
            MESSAGE e425(zintf_e_messages)
                             WITH ls_temp_fxx-id_article
                                  ls_temp_fxx-date_effet_frais
                                  ls_c01-num_dossier
                                  ls_c01-date_abonnement
                             INTO lv_msg_bpem.

            lv_interface = ls_temp_fxx-id_flux .
            CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
              EXPORTING
                iv_interface_name = lv_interface
                iv_sparte         = 'ZE'
                is_structure      = ls_temp_fxx.


            macro_add_msg_to_log 'E' '425' ls_temp_fxx-id_article
                                           ls_temp_fxx-date_effet_frais
                                           ls_c01-num_dossier
                                           ls_c01-date_abonnement.
            PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.

*DEB-IBEN-20190116-GE-2300
*          ENDIF.
*          RETURN.
            RETURN.
          ELSE.

            REFRESH : lt_ext_ui.

            ls_ext_ui-ext_ui = ls_temp_fxx-id_prm.
            APPEND ls_ext_ui TO lt_ext_ui .

            CALL METHOD zcl_tool=>get_ext_ui_type
              CHANGING
                ct_ext_ui = lt_ext_ui.

            READ TABLE lt_ext_ui INTO ls_ext_ui INDEX 1.
            IF ls_ext_ui-type = 'B2C' OR ls_ext_ui-bukrs = 'GDP2'.
              lv_b2c = 'X' .
            ENDIF.

            IF lv_b2c = 'X'.
              lv_zz_ref_externe = lv_num_dossier_affaire.

              CALL METHOD zcl_tool=>swd_search_mix
                EXPORTING
                  iv_pod            = lv_int_ui
                  iv_switch_type    = if_isu_ide_switch_constants=>co_swttype_enroll
                  iv_status         = cl_isu_ide_switchdoc=>co_stat_cancel
                  iv_mode           = cl_isu_wmode=>co_display
                  iv_date           = ls_temp_fxx-date_effet_frais
                  iv_zz_ref_externe = lv_zz_ref_externe
                RECEIVING
                  rr_switch_doc     = lr_switch_doc
                EXCEPTIONS
                  multiple_swt_doc  = 1
                  error             = 2
                  OTHERS            = 3.

              IF sy-subrc = 0 AND lr_switch_doc IS BOUND.
* Document trouvé
                ls_switch_doc = lr_switch_doc->get_all_properties( ).
                lv_guid_22 = ls_switch_doc-ext_reference.
                CALL FUNCTION 'GUID_CONVERT'
                  EXPORTING
                    iv_guid_c22 = lv_guid_22
                  IMPORTING
                    ev_guid_x16 = lv_guid_16.

                CREATE OBJECT lr_cl_crm.
                TRY.
                    CALL METHOD lr_cl_crm->if_crm_uiu_destinations~get_crm_destination
                      RECEIVING
                        rv_rfcdest = lv_rfcdest.

                  CATCH cx_crm_erp_activities.
* Accès à l'instance CRM/IS-U impossible => Vérifiez la connexion
                    IF 1 = 2. MESSAGE e085(zintf_e_messages). ENDIF.
                    macro_add_msg_to_log 'E' '085' '' ''
                                                   '' ''.
                    PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.
                    RETURN.
                ENDTRY.

                CALL FUNCTION 'ZISU_IS_CONTRACT_RETRACTED' DESTINATION lv_rfcdest
                  EXPORTING
                    iv_contract_guid  = lv_guid_16
                  IMPORTING
                    ev_is_retracted   = lv_is_retracted
                    ev_date_retracted = lv_date_retracted
                    ev_buag_id        = ls_temp_fxx-compte_contrat.

* Vérifier si le CC est repliqué
                SELECT SINGLE vkont
                  FROM fkkvk
                  INTO @DATA(lv_vkont_tmp)
                  WHERE vkont = @ls_temp_fxx-compte_contrat .
                IF sy-subrc <> 0.
* Le compte de contrat &1 n'est pas répliqué dans ISU
                  IF 1 = 2. MESSAGE e426(zintf_e_messages). ENDIF.
                  macro_add_msg_to_log 'E' '426' ls_temp_fxx-compte_contrat ''
                                                 '' ''.
                  PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.
                  RETURN.
                ENDIF.

                lv_sparte = 'ZE'.
                lv_frais_sans_mes = abap_true.
                lv_compte_contrat = abap_true.
                IF lv_date_retracted < ls_temp_fxx-date_effet_frais.
                  lv_post_retractation =  abap_true.
                ENDIF.
              ELSE.
* Si document non trouvé, sortir du processus d’intégration du flux F03A
* sans changer le statut du flux
                RETURN.
              ENDIF.
            ELSE.
* Si le cas traité est un B2B, sortir du processus d’intégration du flux F03A
* sans changer le statut du flux
              RETURN.
            ENDIF.
          ENDIF.
*FIN-IBEN-20190116-GE-2300
        ENDIF.
      ENDIF.
    ENDIF.

*++ STOU FIN   GE-218

****************************************************
*******Etape n°3.2 : Récupération des données pour commande SD  *******
****************************************************
    "    ON CHANGE OF ls_temp_fxx-id_demande_intern.
    CLEAR : ls_sales_order_header, lv_posnr.

** 2017.11.06 : LWAT (avec FGAL) : On veut la date d'effet
*    v_date = ls_temp_fxx-date_fin_frais. "AVANT
*    v_date = ls_temp_fxx-date_effet_frais."--GE-218
*++ DEBUT STOU GE-218
    IF lv_date_c01 IS NOT INITIAL.
      v_date = lv_date_c01.
    ELSE.
      v_date = ls_temp_fxx-date_effet_frais.
* DEBUT - GLIC - GE-8031 - 06/01/2020
      IF v_date IS INITIAL.
        v_date = ls_temp_fxx-date_fin_frais.
      ENDIF.
* FIN - GLIC - GE-8031
    ENDIF.
*++ FIN   STOU GE-218

* Récupération de l'installation
    SELECT SINGLE anlage
                  FROM euiinstln
                  INTO lv_anlage
                  WHERE int_ui EQ lv_int_ui
                  AND   datefrom LE v_date
                  AND   dateto GE v_date.

    IF sy-subrc EQ 0
*DEB-IBEN-20201117-GE-10663
         AND iv_id_flux <> 'F03A'.
*FIN-IBEN-20201117-GE-10663

      SELECT SINGLE sparte
        FROM eanl
        INTO lv_sparte
        WHERE anlage = lv_anlage.

* Récupération du partenaire, du compte de contrats et des conditions
*de paiement
*++ STOU DEBUT GE-218
      IF lv_compte_contrat = abap_true.
        SELECT SINGLE fkkvkp~gpart fkkvkp~vkont fkkvkp~stdbk
           INTO (ls_sales_order_header-partn_numb,
                 ls_sales_order_header-fkk_conacct, lv_bukrs )
           FROM ever AS ever
           INNER JOIN fkkvkp AS fkkvkp
              ON fkkvkp~vkont EQ ever~vkonto
           WHERE ever~anlage  EQ lv_anlage
             AND ever~vkonto  EQ ls_temp_fxx-compte_contrat .
      ELSE.
*++ STOU FIN   GE-218
        SELECT SINGLE fkkvkp~gpart fkkvkp~vkont fkkvkp~stdbk
          "fkkvkp~zahlkond
           INTO (ls_sales_order_header-partn_numb,
                 ls_sales_order_header-fkk_conacct, lv_bukrs )
          ",ls_sales_order_header-pmnttrms )
           FROM ever AS ever
           INNER JOIN fkkvkp AS fkkvkp
              ON fkkvkp~vkont EQ ever~vkonto
           WHERE ever~anlage  EQ lv_anlage
             AND ever~einzdat LE v_date
             AND ever~auszdat GE v_date.
      ENDIF. "++GE-218

      IF sy-subrc NE 0.
        lv_ko = 'X'.
      ENDIF.

*DEB-IBEN-20190116-GE-2300
    ELSEIF lv_frais_sans_mes IS NOT INITIAL.
* Cas facturation des frais sans MES
      SELECT SINGLE fkkvkp~gpart fkkvkp~vkont fkkvkp~stdbk
         INTO (ls_sales_order_header-partn_numb,
               ls_sales_order_header-fkk_conacct, lv_bukrs )
         FROM fkkvkp AS fkkvkp
         WHERE fkkvkp~vkont  EQ ls_temp_fxx-compte_contrat .
*FIN-IBEN-20190116-GE-2300
    ELSE.
      lv_ko = 'X'.
    ENDIF.



    IF lv_bukrs = 'GDP1'.
      lv_bukrs = 'ZGDP'.
    ENDIF.

* Récupération des dates de document et de prix en en-tête
    IF lv_ko IS INITIAL.

      ls_sales_order_header-doc_date = sy-datum.
      ls_sales_order_header-price_date = sy-datum.
      ls_sales_order_header-doc_type = 'ZDIS'.
      ls_sales_order_header-purch_no_c = ls_temp_fxx-id_prm.

      IF iv_id_flux = 'F15D'.
        ls_sales_order_header-req_date_h = ls_temp_fxx-date_effet_frais.
      ELSE.
*++ DEBUT STOU GE-218
        IF lv_date_c01 IS NOT INITIAL.
          ls_sales_order_header-req_date_h = lv_date_c01.
        ELSE.
          ls_sales_order_header-req_date_h = ls_temp_fxx-date_fin_frais.
        ENDIF.
*++ FIN   STOU GE-218
*        ls_sales_order_header-req_date_h = ls_temp_fxx-date_fin_frais. "--GE-218
      ENDIF.

      ls_sales_order_header-id_demande_intern =
                                           lv_num_dossier_affaire.
      ls_sales_order_header-bill_date = sy-datum.
*DEB-IBEN-20190116-GE-2300
      IF lv_post_retractation IS NOT INITIAL.
        ls_sales_order_header-bill_block = '10'.
      ENDIF.
*FIN-IBEN-20190116-GE-2300
      INSERT ls_sales_order_header INTO TABLE lt_sales_order_header.

    ELSE.

      MESSAGE e163(zintf_e_messages) WITH
                      ls_temp_fxx-id_prm INTO lv_message .

      lv_interface = ls_temp_fxx-id_flux .
      CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
        EXPORTING
          iv_interface_name = lv_interface
          iv_sparte         = 'ZE'
          is_structure      = ls_temp_fxx.

      macro_add_msg_to_log 'E' '163' '' '' '' ''.

      PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.

      CONTINUE.

    ENDIF.

    IF lv_ko IS INITIAL.
**************************************************************
******* Etape n°3.1 : Blocage des postes     *******
**************************************************************
      DATA ls_zparam_sd TYPE zparam_sd .

      SELECT SINGLE *
      FROM zparam_sd
      INTO ls_zparam_sd
      WHERE
      matnr = lv_temp_matnr
      AND
      bukrs = lv_bukrs.

      IF sy-subrc = 0.
        lv_blocage = 'X'.
      ENDIF.

*Gestion des items
      lv_posnr = lv_posnr + 10.
      ls_sales_order_item-posnr = lv_posnr.
      "          CONCATENATE 'D' ls_temp_fxx-id_art INTO lv_temp_matnr.

*+GE-18775 {
      READ TABLE lt_param_f15 INTO ls_param_f15 WITH KEY id_ev = ls_temp_fxx-id_e_v BINARY SEARCH.
      IF sy-subrc EQ 0.
        ls_sales_order_item-matnr = ls_param_f15-article.
      ELSE.
        ls_sales_order_item-matnr = lv_temp_matnr.
      ENDIF.
*+GE-18775 }

*      ls_sales_order_item-matnr = lv_temp_matnr.
*++ DEBUT STOU GE-218
      IF lv_date_c01 IS NOT INITIAL.
        ls_sales_order_item-bstdk = lv_date_c01.
      ELSE.
        ls_sales_order_item-bstdk = ls_temp_fxx-date_deb_frais.
      ENDIF.
*++ FIN   STOU GE-218
*        ls_sales_order_item-bstdk = ls_temp_fxx-date_deb_frais. "--GE-218

      IF lv_blocage IS NOT INITIAL.
        ls_sales_order_item-bill_block = '09'.
      ENDIF.

      IF iv_id_flux = 'F15D'.
        ls_sales_order_item-bstdk_e = ls_temp_fxx-date_effet_frais.
      ELSE.
*++ DEBUT STOU GE-218
        IF lv_date_c01 IS NOT INITIAL.
          ls_sales_order_item-bstdk_e = lv_date_c01.
        ELSE.
          ls_sales_order_item-bstdk_e = ls_temp_fxx-date_fin_frais.
        ENDIF.
*++ FIN   STOU GE-218
*          ls_sales_order_item-bstdk_e = ls_temp_fxx-date_fin_frais. "--GE-218
      ENDIF.


      ls_sales_order_item-ref_1 = lv_num_dossier_affaire.

      ls_sales_order_item-kbetr = ls_temp_fxx-mt_ht.
      ls_sales_order_item-waers = 'EUR'.

      ls_sales_order_item-id_demande_intern =
lv_num_dossier_affaire.
      ls_sales_order_item-emetteur = ls_temp_fxx-emetteur.
      ls_sales_order_item-idenreg = ls_temp_fxx-idenreg.

**Ajout de la gestion des dates :
      IF iv_id_flux = 'F03A'.
        IF ls_temp_fxx-code_debit_credit EQ 'Y'.
          " Poste des notes de débit
          ls_sales_order_item-kschl = 'ZPRE'.
          APPEND ls_sales_order_item TO lt_debit_note_item.

        ELSEIF ls_temp_fxx-code_debit_credit EQ 'Z'.
          "Poste des notes de crédit
          ls_sales_order_item-kschl = 'ZPRC'.
          APPEND ls_sales_order_item TO lt_credit_note_item.

        ENDIF.
      ELSEIF iv_id_flux = 'F15D'.
* GLIC - GE-8152 - 2020/01/20 - Début - Note de débit crédit est maintenant déterminé en fonction montant
*        IF ls_temp_fxx-id_e_v CS '-A'.
*          "Poste des notes de crédit
*          ls_sales_order_item-kschl = 'ZPRC'.
*          APPEND ls_sales_order_item TO lt_credit_note_item.
*        ELSE.
*          " Poste des notes de débit
*          ls_sales_order_item-kschl = 'ZPRE'.
*          APPEND ls_sales_order_item TO lt_debit_note_item.
*        ENDIF.
        IF ls_temp_fxx-mt_ht < 0.
          "Poste des notes de crédit
          ls_sales_order_item-kschl = 'ZPRC'.
          APPEND ls_sales_order_item TO lt_credit_note_item.
        ELSE.
          " Poste des notes de débit
          ls_sales_order_item-kschl = 'ZPRE'.
          APPEND ls_sales_order_item TO lt_debit_note_item.
        ENDIF.
* GLIC - GE-8151 - 2020/01/20 - Fin
      ENDIF.


      SELECT SINGLE string1
      INTO lv_art_sd_remise_grd
      FROM ettifn
      WHERE anlage = lv_anlage
      AND operand = 'EUDRPGRD'
      AND ab LE ls_temp_fxx-date_deb_frais
      AND bis GE ls_temp_fxx-date_deb_frais.
*<<<IBE-06/07/2017-Adaptation B2C
      IF sy-subrc = 0.
        SELECT SINGLE kondm INTO lv_art_sd_remise_grd FROM mvke WHERE matnr = ls_temp_fxx-id_article
        AND vkorg = 'GDP2'
        AND vtweg = 'Z1'
        AND kondm = lv_art_sd_remise_grd.
      ENDIF.
*IBE>>>
      IF sy-subrc = 0.
*<<<IBE-10/07/2017-Adaptation Interface Frais éligible au blocage
*  S'il y a la remise à appliquer, on met le statut en rejet l’enregistrement
* (message d'erreur: Remise appliquée sur l'article bloqué à la facturation SD ) sans créer la commande
        IF lv_blocage IS NOT INITIAL.
          IF 1 = 2. MESSAGE e120(zintf_e_messages). ENDIF.

          macro_add_msg_to_log 'E' '120' ls_temp_fxx-id_prm '' '' ''.

          PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.

          CONTINUE.
        ENDIF.
*IBE>>>
        SELECT SINGLE low
           INTO lv_art_sd_remise_grd
           FROM tvarvc
          WHERE name EQ 'ZINTF_E_ART_SD_REMISE_GRD'.

        SELECT SINGLE wert1
        INTO lv_pourcent_rem_grd
        FROM ettifn
        WHERE anlage = lv_anlage
        AND operand = 'EFCRPGRD'
        AND ab LE ls_temp_fxx-date_deb_frais
        AND bis GE ls_temp_fxx-date_deb_frais.

*<<<IBE-01/08/2017-Changement gestion des remises
*          lv_taux_rem =
*          lv_pourcent_rem_grd / 100.
        lv_taux_rem = lv_pourcent_rem_grd.
*IBE>>>

        IF sy-subrc = 0.

          "Gestion des items
          lv_posnr = lv_posnr + 10.
          ls_sales_order_item-posnr = lv_posnr.
          "          CONCATENATE 'D' ls_temp_fxx-id_art INTO lv_temp_matnr.
          lv_temp_matnr = lv_art_sd_remise_grd.
          ls_sales_order_item-matnr = lv_temp_matnr.
          ls_sales_order_item-bstdk = ls_temp_fxx-date_deb_frais.

          IF lv_blocage IS NOT INITIAL.
            ls_sales_order_item-bill_block = '09'.
          ENDIF.

          IF iv_id_flux = 'F15D'.
            ls_sales_order_item-bstdk_e = ls_temp_fxx-date_effet_frais.
          ELSE.
            ls_sales_order_item-bstdk_e = ls_temp_fxx-date_fin_frais.
          ENDIF.


          ls_sales_order_item-ref_1 = lv_num_dossier_affaire.

          ls_sales_order_item-kbetr = ls_temp_fxx-mt_ht
                                    *  lv_taux_rem * -1.
          IF  ls_sales_order_item-kschl = 'ZPRE'.
            ls_sales_order_item-kschl = 'ZPRC'.
          ELSEIF  ls_sales_order_item-kschl = 'ZPRC'.
            ls_sales_order_item-kschl = 'ZPRE'.
          ENDIF.
          ls_sales_order_item-waers = 'EUR'.

          ls_sales_order_item-id_demande_intern =
    lv_num_dossier_affaire.
          ls_sales_order_item-emetteur = ls_temp_fxx-emetteur.
          ls_sales_order_item-idenreg = ls_temp_fxx-idenreg.

          APPEND ls_sales_order_item TO lt_credit_note_item.
        ENDIF.

      ENDIF.
    ENDIF. "lv ko is intial
    "MFO  ENDLOOP.


*+GE-18775 {
    READ TABLE lt_param_f15 INTO ls_param_f15 WITH KEY id_ev = ls_temp_fxx-id_e_v BINARY SEARCH.
    IF sy-subrc EQ 0.
      CLEAR ls_sales_order_item.
      "Gestion des items
      lv_posnr                  = lv_posnr + 10.
      ls_sales_order_item-posnr = lv_posnr.
      ls_sales_order_item-matnr = 'GDP_E_CTA'.
      ls_sales_order_item-bstdk = ls_temp_fxx-date_deb_frais.

      IF lv_blocage IS NOT INITIAL.
        ls_sales_order_item-bill_block = '09'.
      ENDIF.

      ls_sales_order_item-bstdk_e = ls_temp_fxx-date_effet_frais.
      ls_sales_order_item-ref_1   = lv_num_dossier_affaire.

      SELECT SINGLE wert1
          INTO @DATA(lv_taux_cta)
      FROM ettaf
        INNER JOIN eanlh ON ettaf~tariftyp = eanlh~tariftyp
      WHERE anlage = @lv_anlage
          AND operand  = 'EFCTXCTA'
          AND eanlh~ab LE @ls_temp_fxx-date_effet_frais
          AND eanlh~bis GE @ls_temp_fxx-date_effet_frais
          AND ettaf~ab LE @ls_temp_fxx-date_effet_frais
          AND ettaf~bis GE @ls_temp_fxx-date_effet_frais.

      ls_sales_order_item-kbetr             = ls_temp_fxx-mt_ht * lv_taux_cta.
      ls_sales_order_item-waers             = 'EUR'.
      ls_sales_order_item-id_demande_intern = lv_num_dossier_affaire.
      ls_sales_order_item-emetteur          = ls_temp_fxx-emetteur.
      ls_sales_order_item-idenreg           = ls_temp_fxx-idenreg.

      IF ls_temp_fxx-mt_ht < 0.
        "Poste des notes de crédit
        ls_sales_order_item-kschl = 'ZPRC'.
        APPEND ls_sales_order_item TO lt_credit_note_item.
      ELSE.
        " Poste des notes de débit
        ls_sales_order_item-kschl = 'ZPRE'.
        APPEND ls_sales_order_item TO lt_debit_note_item.
      ENDIF.
    ENDIF.
*+GE-18775 }

*FPE-DEB-GE-6284 "étape vérification du taux de TVA
    IF iv_id_flux = 'F15D'.

*+GE-18775 {
      READ TABLE lt_param_f15 INTO ls_param_f15 WITH KEY id_ev = ls_temp_fxx-id_e_v BINARY SEARCH.
      IF sy-subrc EQ 0.
        ls_temp_fxx-id_e_v = ls_param_f15-article.
      ENDIF.
*+GE-18775 }

      DATA lv_class_fisc TYPE string.
      IF ls_fxx-taux_tva EQ '0'.
        SELECT SINGLE taxm1
          INTO lv_class_fisc
          FROM mlan
          WHERE matnr = ls_temp_fxx-id_e_v
          AND aland = 'FR'.
        IF lv_class_fisc = '1'. "Taxe-100%
          IF 1 = 2. MESSAGE e273(zintf_e_messages). ENDIF.
          macro_add_msg_to_log 'E' '273' ls_temp_fxx-id_prm ls_temp_fxx-taux_tva lv_class_fisc ''.
          PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.
          CONTINUE.
        ENDIF.
      ELSE. "taux tva différent de 0
        SELECT SINGLE taxm1
          INTO lv_class_fisc
          FROM mlan
          WHERE matnr = ls_temp_fxx-id_e_v
          AND aland = 'FR'.
        IF lv_class_fisc = '0'. "Sans taxe
          IF 1 = 2. MESSAGE e274(zintf_e_messages). ENDIF.
          macro_add_msg_to_log 'E' '274' ls_temp_fxx-id_prm lv_class_fisc '' ''.
          PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.
          CONTINUE.
        ENDIF.
      ENDIF.
    ENDIF.
*FPE-FIN-GE-6284
    SORT lt_sales_order_header BY id_demande_intern.
    SORT lt_debit_note_item BY id_demande_intern.

    LOOP AT lt_debit_note_item INTO ls_sales_order_item.
****************************************************
*******Etape n°4 : Création d’une note de débit  *******
****************************************************
      INSERT ls_sales_order_item INTO TABLE lt_debit_note_item_tmp.
      lv_emetteur = ls_sales_order_item-emetteur.
      lv_idenreg  = ls_sales_order_item-idenreg.
      READ TABLE lt_sales_order_header INTO ls_sales_order_header WITH
KEY id_demande_intern = ls_sales_order_item-id_demande_intern.
      AT END OF id_demande_intern.
        IF  ls_sales_order_header IS NOT INITIAL.
          CALL METHOD zcl_tool=>create_sales_order
            EXPORTING
              is_sales_order_header = ls_sales_order_header
              it_sales_order_item   = lt_debit_note_item_tmp
              iv_spart              = lv_sparte
              iv_societe_div        = lv_bukrs
            IMPORTING
              et_return             = lt_return
            RECEIVING
              ev_vbeln              = lv_vbeln.

          IF lv_vbeln IS NOT INITIAL.

            IF 1 = 2.
              MESSAGE i167(zintf_e_messages) WITH
       lv_vbeln
ls_sales_order_item-id_demande_intern INTO lv_message. ENDIF.

              macro_add_msg_to_log 'I' '167' lv_vbeln '' '' ''.

              PERFORM update_ligne_fxx USING lc_statut_07_integre iv_id_flux.

            ELSE.


              READ TABLE lt_return INTO ls_return WITH KEY type = 'E'.
              "fxx : &1 &2 &3 &4

              MESSAGE e158(zintf_e_messages) WITH
                                            ls_return-message INTO lv_message.

              lv_interface = ls_fxx-id_flux .
              CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
                EXPORTING
                  iv_interface_name = lv_interface
                  iv_sparte         = 'ZE'
                  is_structure      = ls_fxx.

              macro_add_msg_to_log 'E' '158' ls_return-message
               '' '' ''.

              PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.

              CONTINUE.

            ENDIF.

            CLEAR lt_debit_note_item_tmp.
          ENDIF.
        ENDAT.
      ENDLOOP.
****************************************************
*******Etape n°5 : Création d’une note de crédit*******
****************************************************
      SORT lt_credit_note_item BY id_demande_intern.
      LOOP AT lt_credit_note_item INTO ls_sales_order_item.
        INSERT ls_sales_order_item INTO TABLE lt_credit_note_item_tmp.
        lv_emetteur = ls_sales_order_item-emetteur.
        lv_idenreg  = ls_sales_order_item-idenreg.
        READ TABLE lt_sales_order_header INTO ls_sales_order_header WITH
  KEY id_demande_intern = ls_sales_order_item-id_demande_intern.
        AT END OF id_demande_intern.
          IF  ls_sales_order_header IS NOT INITIAL.
            CALL METHOD zcl_tool=>create_sales_order
              EXPORTING
                is_sales_order_header = ls_sales_order_header
                it_sales_order_item   = lt_credit_note_item_tmp
                iv_spart              = lv_sparte
                iv_societe_div        = lv_bukrs
              IMPORTING
                et_return             = lt_return
              RECEIVING
                ev_vbeln              = lv_vbeln.

            IF lv_vbeln IS NOT INITIAL.
              IF 1 = 2.
                MESSAGE i167(zintf_e_messages) WITH
   lv_vbeln
INTO lv_message. ENDIF.

                macro_add_msg_to_log 'I' '167'  lv_vbeln '' '' ''.

                PERFORM update_ligne_fxx USING lc_statut_07_integre iv_id_flux.

              ELSE.

                READ TABLE lt_return INTO ls_return WITH KEY type = 'E'.
                "fxx : &1 &2 &3 &4

                MESSAGE e158(zintf_e_messages) WITH
                                              ls_return-message INTO lv_message.

                lv_interface = ls_fxx-id_flux .
                CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
                  EXPORTING
                    iv_interface_name = lv_interface
                    iv_sparte         = 'ZE'
                    is_structure      = ls_fxx.


                macro_add_msg_to_log 'E' '158'
                ls_return-message '' '' ''.

                PERFORM update_ligne_fxx USING lc_statut_06_rejet iv_id_flux.

                CONTINUE.

              ENDIF.

              CLEAR lt_credit_note_item_tmp.
            ENDIF.

          ENDAT.
        ENDLOOP.
        IF iv_mode_test IS INITIAL.
          COMMIT WORK AND WAIT.
        ELSE.
          ROLLBACK WORK.
        ENDIF.

      ENDLOOP.

      IF iv_mode_test IS INITIAL.
        COMMIT WORK AND WAIT.
      ELSE.
        ROLLBACK WORK.
      ENDIF.

    ENDFUNCTION.
