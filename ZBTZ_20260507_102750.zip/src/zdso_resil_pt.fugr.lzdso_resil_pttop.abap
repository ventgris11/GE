* regenerated at 05.04.2019 12:51:31
FUNCTION-POOL ZDSO_RESIL_PT              MESSAGE-ID SV.

* INCLUDE LZDSO_RESIL_PTD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDSO_RESIL_PTT00                       . "view rel. data dcl.
