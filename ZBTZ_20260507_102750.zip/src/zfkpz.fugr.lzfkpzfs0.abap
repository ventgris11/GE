*---------------------------------------------------------------------*
*  INCLUDE LFKPZFS0                                                   *
*---------------------------------------------------------------------*

*---------------------------------------------------------------------*
*      Form  SCREEN_MODIF                                             *
*---------------------------------------------------------------------*
FORM SCREEN_MODIF.

  LOOP AT SCREEN.
    IF NOT XDISPLAY IS INITIAL.
      SCREEN-INPUT = 0.
      IF SCREEN-NAME EQ 'H_PRIOR'.
        IF H_PRIOR IS INITIAL.
          SCREEN-INVISIBLE = 1.
        ELSE.
          SCREEN-INVISIBLE = 0.
        ENDIF.
      ENDIF.
    ENDIF.
    IF NOT XSIGN IS INITIAL AND SCREEN-GROUP1 EQ '001'.
      SCREEN-INPUT = 0.
      SCREEN-INVISIBLE = 1.
    ENDIF.
    IF XPRIOR IS INITIAL AND SCREEN-GROUP1 EQ '002'.
      SCREEN-INPUT = 0.
      SCREEN-INVISIBLE = 1.
    ENDIF.
    IF SCREEN-GROUP1 EQ '003'.
      IF NOT H_PRIOR IS INITIAL.
        SCREEN-INTENSIFIED = 1.
      ELSE.
        SCREEN-INTENSIFIED = 0.
      ENDIF.
    ENDIF.
    MODIFY SCREEN.
  ENDLOOP.

ENDFORM.


*---------------------------------------------------------------------*
*      Form  SORT
*---------------------------------------------------------------------*
FORM SORT.

  DATA: L_LAST_PRIOR LIKE T_F4-PRIOR.
  SORT T_F4 BY XSELE DESCENDING
               PRIOR ASCENDING
               ZLSCH ASCENDING.
  LOOP AT T_F4.
    IF T_F4-XSELE IS INITIAL.
      EXIT.
    ENDIF.
    L_LAST_PRIOR = T_F4-PRIOR = SY-TABIX.
    MODIFY T_F4.
  ENDLOOP.
  SORT T_F4.
  T_F4-PRIOR = L_LAST_PRIOR.

ENDFORM.


*---------------------------------------------------------------------*
*      Form  STANDARD_F4
*---------------------------------------------------------------------*
FORM STANDARD_F4.

  DATA:
    L_FIELDS LIKE HELP_VALUE OCCURS 0 WITH HEADER LINE,
    L_VALUETAB(72) TYPE C    OCCURS 0 WITH HEADER LINE.

  L_FIELDS-TABNAME    = 'TFK042Z'.
  L_FIELDS-FIELDNAME  = 'ZLSCH'.
  L_FIELDS-SELECTFLAG = 'X'.   APPEND L_FIELDS.
  L_FIELDS-TABNAME    = 'TFK042ZT'.
  L_FIELDS-FIELDNAME  = 'TEXT1'.
  L_FIELDS-SELECTFLAG = SPACE. APPEND L_FIELDS.
  LOOP AT T_F4.
    CLEAR:
      T_F4-XSELE,
      T_F4-PRIOR.
    MODIFY T_F4.
    L_VALUETAB = T_F4-ZLSCH. APPEND L_VALUETAB.
    L_VALUETAB = T_F4-TEXT1. APPEND L_VALUETAB.
  ENDLOOP.
  describe table t_f4 lines sy-tfill.
  if xnopopup is initial
  or sy-tfill gt 1.
    CALL FUNCTION 'HELP_VALUES_GET_WITH_TABLE'         "#EC FB_OLDED
         EXPORTING
              FIELDNAME                     = 'ZLSCH'
              TABNAME                       = 'TFK042Z'
              DISPLAY                       = XDISPLAY
         IMPORTING
              SELECT_VALUE                  = T_F4-ZLSCH
         TABLES
              FIELDS                        = L_FIELDS
              VALUETAB                      = L_VALUETAB.
  else.
* T_F4-ZLSCH contains unique value, choose this one
  endif.
  IF T_F4-ZLSCH IS INITIAL.
    RAISE CANCELLED.
  ELSE.
    READ TABLE T_F4 WITH KEY ZLSCH = T_F4-ZLSCH.
    T_F4-XSELE = 'X'.
    T_F4-PRIOR = 1.
    MODIFY T_F4 INDEX SY-TABIX.
  ENDIF.

ENDFORM.


*---------------------------------------------------------------------*
*      Form  STANDARD_F4_MULTI
*---------------------------------------------------------------------*
FORM STANDARD_F4_MULTI.

  DATA:
    L_SUBRC  LIKE SY-SUBRC,
    L_FIELDS LIKE HELP_VALUE OCCURS 0 WITH HEADER LINE,
    L_SELTAB LIKE SHVALUE    OCCURS 0 WITH HEADER LINE,
    L_VALUEALL(72) TYPE C    OCCURS 0 WITH HEADER LINE,
    L_VALUESEL(72) TYPE C    OCCURS 0 WITH HEADER LINE.

data: lt_DFIES like DFIES occurs 0 with header line,
      lt_DDSHRETVAL like DDSHRETVAL occurs 0 with header line,
      lt_value_tab like TFK042ZT occurs 0 with header line.


* fill fieldstab: only show payment method and text
  lt_DFIES-tabname = 'TFK042ZT'.
  lt_DFIES-fieldname = 'ZLSCH'.
  append lt_dfies.
  lt_DFIES-tabname = 'TFK042ZT'.
  lt_DFIES-fieldname = 'TEXT1'.
  append lt_dfies.

* fill the value tab

  LOOP AT T_F4.
    move-corresponding t_f4 to lt_value_tab.
    append lt_value_tab.
  ENDLOOP.

  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
     EXPORTING
          RETFIELD         = 'ZLSCH'
*         WINDOW_TITLE     =
*         VALUE            = ' '
          VALUE_ORG        = 'S'
          MULTIPLE_CHOICE  = 'X'
          DISPLAY          = XDISPLAY
*         CALLBACK_PROGRAM = ' '
*         CALLBACK_FORM    = ' '
     TABLES
          VALUE_TAB        = lt_value_tab
          FIELD_TAB        = lt_dfies
          RETURN_TAB       = lt_DDSHRETVAL
*         DYNPFLD_MAPPING  =
     EXCEPTIONS
          PARAMETER_ERROR  = 1
          NO_VALUES_FOUND  = 2
          OTHERS           = 3
          .
  IF SY-SUBRC = 0.

    LOOP AT T_F4.
      READ TABLE lt_DDSHRETVAL WITH KEY FIELDVAL = T_F4-ZLSCH.
      IF SY-SUBRC EQ 0.
        T_F4-XSELE = 'X'.
      ELSE.
        CLEAR:
          T_F4-XSELE,
          T_F4-PRIOR.
      ENDIF.
      MODIFY T_F4.
    ENDLOOP.
    PERFORM SORT.
  endif.

*  L_FIELDS-TABNAME    = 'TFK042Z'.
*  L_FIELDS-FIELDNAME  = 'ZLSCH'.
*  L_FIELDS-SELECTFLAG = 'X'.   APPEND L_FIELDS.
*  L_FIELDS-TABNAME    = 'TFK042ZT'.
*  L_FIELDS-FIELDNAME  = 'TEXT1'.
*  L_FIELDS-SELECTFLAG = SPACE. APPEND L_FIELDS.
*
*  LOOP AT T_F4.
*    L_VALUEALL = T_F4(31).
*    APPEND L_VALUEALL.
*    IF T_F4-XSELE EQ 'X'.
*      L_VALUESEL = T_F4(31).
*      APPEND L_VALUESEL.
*    ENDIF.
*  ENDLOOP.
*
*  CALL FUNCTION 'HELP_VALUES_GET_AND_RETURN_TAB'
*       EXPORTING
*            DISPLAY                      = XDISPLAY
*            SELECTFIELD                  = 'ZLSCH'
*            TABLENAME                    = 'TFK042Z'
*            USE_USER_DEFINED_FIELDS      = 'X'
*            RETURN_PRESEL_VALUES         = 'X'
*       IMPORTING
*            RETURNCODE                   = L_SUBRC
*       TABLES
*            FULL_TABLE                   = L_VALUEALL
*            SELECTION_TAB                = L_SELTAB
*            USER_FIELDS                  = L_FIELDS
*            USER_MARKED_VALUES           = L_VALUESEL.


*  CHECK L_SUBRC EQ 0.
*  LOOP AT T_F4.
*    READ TABLE L_SELTAB WITH KEY LOW_VALUE = T_F4-ZLSCH.
*    IF SY-SUBRC EQ 0.
*      T_F4-XSELE = 'X'.
*    ELSE.
*      CLEAR:
*        T_F4-XSELE,
*        T_F4-PRIOR.
*    ENDIF.
*    MODIFY T_F4.
*  ENDLOOP.

*  PERFORM SORT.

ENDFORM.
