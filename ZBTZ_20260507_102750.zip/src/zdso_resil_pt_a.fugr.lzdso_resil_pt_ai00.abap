*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 14.04.2019 at 12:20:32
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
