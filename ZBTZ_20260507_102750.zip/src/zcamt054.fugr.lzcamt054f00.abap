*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 17.07.2018 at 19:01:50
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
