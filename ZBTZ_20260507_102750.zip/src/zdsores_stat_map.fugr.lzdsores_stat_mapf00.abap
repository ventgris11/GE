*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 03.04.2019 at 15:45:50
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
