FUNCTION zfm_create_so.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(IS_SALES_ORDER_HEADER) TYPE  ZISUS_SALES_ORDER_HEADER
*"     VALUE(IT_SALES_ORDER_ITEM) TYPE  ZISUT_SALES_ORDER_ITEM
*"     VALUE(IV_SOCIETE_DIV) TYPE  BUKRS_VF OPTIONAL
*"     VALUE(IV_SPART) TYPE  SPART OPTIONAL
*"  EXPORTING
*"     VALUE(EV_VBELN) TYPE  VBELN
*"     VALUE(ET_RETURN) TYPE  BAPIRET2_T
*"----------------------------------------------------------------------

  CALL METHOD zcl_tool=>create_sales_order
    EXPORTING
      is_sales_order_header = is_sales_order_header
      it_sales_order_item   = it_sales_order_item
      iv_societe_div        = iv_societe_div
      iv_spart              = iv_spart
    IMPORTING
      et_return             = et_return
    RECEIVING
      ev_vbeln              = ev_vbeln.

  IF ev_vbeln IS NOT INITIAL.
    COMMIT WORK AND WAIT.
  ENDIF.

ENDFUNCTION.
