* regenerated at 14.04.2019 12:20:32
FUNCTION-POOL ZDSO_RESIL_PT_A            MESSAGE-ID SV.

* INCLUDE LZDSO_RESIL_PT_AD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDSO_RESIL_PT_AT00                     . "view rel. data dcl.
