*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFPAYM00TOP.                       " Global Data
  INCLUDE LZFPAYM00UXX.                       " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LFPAYM00F...                       " Subprograms
* INCLUDE LFPAYM00O...                       " PBO-Modules
* INCLUDE LFPAYM00I...                       " PAI-Modules
