FUNCTION Z_FKK_SAMPLE_TFK126_EXCL_RA.
*"--------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(X_VERVAR) LIKE  TFK115-VERVAR
*"     VALUE(X_VERART) LIKE  TFK110-VERART OPTIONAL
*"     VALUE(X_BLDAT) LIKE  FKKKO-BLDAT DEFAULT SY-DATLO
*"     VALUE(X_IFNAM) LIKE  TFK116-IFNAM
*"     VALUE(X_XSORT) LIKE  BOOLE-BOOLE DEFAULT SPACE
*"  TABLES
*"      T_E516_FKKCL STRUCTURE  E516_FKKCL
*"      T_SELTAB STRUCTURE  ISELTAB OPTIONAL
*"--------------------------------------------------------------------


ENDFUNCTION.
