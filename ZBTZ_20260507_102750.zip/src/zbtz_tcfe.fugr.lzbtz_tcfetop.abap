* regenerated at 20.10.2018 17:29:03
FUNCTION-POOL ZBTZ_TCFE                  MESSAGE-ID SV.

* INCLUDE LZBTZ_TCFED...                     " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZBTZ_TCFET00                           . "view rel. data dcl.
