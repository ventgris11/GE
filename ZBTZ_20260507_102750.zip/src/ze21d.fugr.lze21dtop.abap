FUNCTION-POOL ZE21D.                    "MESSAGE-ID ..

tables: te500,
        te502,
        te529.


*------------------- Lokales Memory -----------------------------------

data: i_te502               like te502 occurs 10 with header line.
data: i_te503               like te503 occurs 1 with header line.
data: i_te503_tax           like te503_tax occurs 1 with header line.
data: i_te503_tax_access    like te503_tax occurs 1 with header line.
data: i_te503_tax_br        like te503_tax_br occurs 1 with header line.
data: i_te503_tax_br_access like te503_tax_br occurs 1 with header line.
data: i_te504               like te504 occurs 1 with header line.
data: i_te505               like te505 occurs 1 with header line.
data: i_te505_it            like te505_it occurs 1 with header line.
data: i_te514               like te514 occurs 1 with header line.
data: i_te529               like te529 occurs 10 with header line.
data: i_te508               like te508 occurs 1 with header line.
data: i_te509               like te509 occurs 1 with header line.
data: i_te2602              like te2602 occurs 1 with header line.
data: i_te2602a             like te2602a occurs 1 with header line.
data: i_te2608              like te2608 occurs 1 with header line.
data: k_te529               like te529 occurs 10 with header line.
data: i_te272               like te272 occurs 10.
data  ite506.

* --------------------------- Includes ---------------------------------

include emsg.
include IEKIVORG.
