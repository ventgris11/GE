*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 17.07.2018 at 19:01:50
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
