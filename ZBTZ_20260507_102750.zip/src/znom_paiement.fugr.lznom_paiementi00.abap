*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 22.07.2017 at 13:06:50
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
