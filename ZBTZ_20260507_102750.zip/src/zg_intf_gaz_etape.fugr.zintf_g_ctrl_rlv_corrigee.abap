FUNCTION zintf_g_ctrl_rlv_corrigee .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
* Modification   (GE-11713)                                            *
* DATE       : 14/10/2021                                              *                                                                                                                                                                      *
* USER       : HBENDHAFER                                              *
* TAG        : HBD                                                     *
* Description: adaptation condition 3 et 4 valides que pour REMM, RE6M *
*  et RE1M ne renvoient pas de PTA PCS dans le flux                    *
* OT         : DI1K928977                                              *
*"----------------------------------------------------------------------
  DATA:
    lv_field    TYPE string,
    lv_equnr    TYPE equnr,
    lt_eabl     TYPE TABLE OF eabl,
    ls_eabl     TYPE eabl,
    ls_date_min TYPE adat,
    ls_date_max TYPE adat,
    lv_ok       TYPE crmt_boolean,
    lv_message  TYPE char255,
    ls_bpem     TYPE zbpem_flux_struct.

*DEB-IBEN-20200115-GE-10867
  CONSTANTS:
    lc_pcs       TYPE e_operand VALUE 'GVFTPCS001',
    lc_pta       TYPE e_operand VALUE 'GVFTPTA001',
    lc_tolerance TYPE i VALUE 1.

  DATA: lv_cond_1        TYPE abap_bool,
        lv_cond_2        TYPE abap_bool,
        lv_cond_3        TYPE abap_bool,
        lv_cond_4        TYPE abap_bool,
        lv_cond_5        TYPE abap_bool, "HBD-GE-11713
        lt_ettifn        TYPE TABLE OF ettifn,
        lv_int_ui        TYPE int_ui,
        ls_object        TYPE eedm_isu_objects,
        lv_wert1_min     TYPE e_wert1,
        lv_wert1_max     TYPE e_wert1,
        lv_debut_periode TYPE sy-datum,
        lv_re6m_re1m     TYPE flag,
        lv_remm          TYPE flag.

  FIELD-SYMBOLS: <fs_fin_periode>,
                 <fs_index_brut_fin_periode>,
                 <fs_index_brut_debut_periode>,
                 <fs_pta>,
                 <fs_pcs>,
                 <fs_vol_brut_conso>,
                 <fs_volume_conv>,
                 <fs_energie_conso>.

*FIN-IBEN-20200115-GE-10867

  FIELD-SYMBOLS:
    <fs_emetteur>,
    <fs_flux>,
    <fs_idenreg>,
    <fs_num_pce>,
    <fs_date_releve>,
    <fs_debut_periode>,
    <fs_statut>,
    <fs_eabl>              TYPE eabl.

  DEFINE macro_add_message_to_log.
    MESSAGE &1(zintf_g_messages)
       WITH &2
            &3
            &4
       INTO lv_message.
    RETURN.
  END-OF-DEFINITION.

  ev_etape = 2.

  CLEAR lv_field.
  MOVE 'FLUX-EMETTEUR'                 TO lv_field.
  ASSIGN (lv_field)                    TO <fs_emetteur>.

  CLEAR lv_field.
  MOVE 'FLUX-FLUX'                     TO lv_field.
  ASSIGN (lv_field)                    TO <fs_flux>.

  CLEAR lv_field.
  MOVE 'FLUX-IDENREG'                  TO lv_field.
  ASSIGN (lv_field)                    TO <fs_idenreg>.

  CLEAR lv_field.
  MOVE 'FLUX-NUM_PCE'                  TO lv_field.
  ASSIGN (lv_field)                    TO <fs_num_pce>.

  CLEAR lv_field.
  MOVE 'FLUX-DATE_RELEVE'              TO lv_field.
  ASSIGN (lv_field)                    TO <fs_date_releve>.

  CLEAR lv_field.
  MOVE 'FLUX-DEBUT_PERIODE'            TO lv_field.
  ASSIGN (lv_field)                    TO <fs_debut_periode>.

*DEB-IBEN-20200115-GE-10867
  CLEAR lv_field.
  MOVE 'FLUX-FIN_PERIODE'              TO lv_field.
  ASSIGN (lv_field)                    TO <fs_fin_periode>.

  CLEAR lv_field.
  MOVE 'FLUX-INDEX_BRUT_FIN_PERIODE'   TO lv_field.
  ASSIGN (lv_field)                    TO <fs_index_brut_fin_periode>.

  CLEAR lv_field.
  MOVE 'FLUX-INDEX_BRUT_DEBUT_PERIODE' TO lv_field.
  ASSIGN (lv_field)                    TO <fs_index_brut_debut_periode>.

  CLEAR lv_field.
  MOVE 'FLUX-PTA'                      TO lv_field.
  ASSIGN (lv_field)                    TO <fs_pta>.

  CLEAR lv_field.
  MOVE 'FLUX-PCS'                      TO lv_field.
  ASSIGN (lv_field)                    TO <fs_pcs>.

  CLEAR lv_field.
  MOVE 'FLUX-VOL_BRUT_CONSO'           TO lv_field.
  ASSIGN (lv_field)                    TO <fs_vol_brut_conso>.

  CLEAR lv_field.
  MOVE 'FLUX-VOLUME_CONV'              TO lv_field.
  ASSIGN (lv_field)                    TO <fs_volume_conv>.

  CLEAR lv_field.
  MOVE 'FLUX-ENERGIE_CONSO'            TO lv_field.
  ASSIGN (lv_field)                    TO <fs_energie_conso>.



*&-<HBD-GE-11713-Début : kill switch
*Variables TVARVC controlant le lancement du processus d'integration des releves correctives
  CLEAR: lv_re6m_re1m,lv_remm.
  SELECT SINGLE low FROM tvarvc INTO lv_remm WHERE name EQ 'ZINTF_REMM_C'.
  SELECT SINGLE low FROM tvarvc INTO lv_re6m_re1m WHERE name EQ 'ZINTF_RE6M_RE1M_C'.

  IF <fs_flux> EQ 'REMM' AND lv_remm EQ abap_true.
    MESSAGE e107(zintf_g_messages) WITH <fs_num_pce>
                                    INTO DATA(lv_msge).
    RETURN.
  ENDIF.
  IF ( <fs_flux> EQ 'RE6M' OR <fs_flux> EQ 'RE1M' ) AND lv_re6m_re1m EQ abap_true.
    MESSAGE e107(zintf_g_messages) WITH <fs_num_pce>
                                    INTO DATA(lv_mess).
    RETURN.
  ENDIF.
*&- HBD-GE-11713-Fin   : Kill switch >




  CLEAR: lv_ok, lv_equnr.
  REFRESH lt_eabl.
  zcl_tool=>get_all_eabl_from_equipment(
    EXPORTING
      iv_ext_ui = <fs_num_pce>
      iv_date   = <fs_fin_periode>
    IMPORTING
      ev_ok     = lv_ok
      ev_equnr  = lv_equnr
      et_eabl   = lt_eabl ).



  IF lv_ok EQ abap_false OR lt_eabl IS INITIAL.

    MESSAGE e242(zintf_g_messages) WITH <fs_num_pce>
                                        <fs_debut_periode>
                                        INTO DATA(lv_msg).
    CLEAR ls_bpem.
    ls_bpem-num_pce = <fs_num_pce>.
    CASE <fs_flux>.
      WHEN 'ADIF'.
        ls_bpem-date_effet_cont = <fs_date_releve>.
      WHEN 'RE6M' OR 'RE1M' OR 'REMM' OR 'REJJ' OR 'REJM'.
        ls_bpem-date_releve     = <fs_date_releve>.
      WHEN 'AFAC'.
        ls_bpem-date_fin_prest  = <fs_date_releve>.
    ENDCASE.

    DATA : lv_interface TYPE zisu_flxid.
    lv_interface = <fs_flux> .
    ls_bpem-idenreg = <fs_idenreg>.
    CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
      EXPORTING
        iv_interface_name = lv_interface
        iv_sparte         = 'ZG'
        is_structure      = ls_bpem.

* Aucune relève pertinente pour le PCE &1 en date du &2
    macro_add_message_to_log e242
                             <fs_num_pce>
                             <fs_debut_periode>
                             ''.
  ENDIF.



* Condition 1
  READ TABLE lt_eabl TRANSPORTING NO FIELDS WITH KEY zzdate_fin = <fs_fin_periode>
                                                     v_zwstand = trunc( <fs_index_brut_fin_periode> ).
  IF sy-subrc = 0.
    lv_cond_1 = abap_true.
  ENDIF.


* Condition 2
  CLEAR: lv_ok, lv_equnr.
  REFRESH lt_eabl.
  zcl_tool=>get_all_eabl_from_equipment(
    EXPORTING
      iv_ext_ui = <fs_num_pce>
      iv_date   = <fs_debut_periode>
    IMPORTING
      ev_ok     = lv_ok
      ev_equnr  = lv_equnr
      et_eabl   = lt_eabl ).


  READ TABLE lt_eabl TRANSPORTING NO FIELDS WITH KEY zzdate_debut = <fs_debut_periode>
                                                     zzindex_brut_debut = trunc( <fs_index_brut_debut_periode> ).
  IF sy-subrc = 0.
    lv_cond_2 = abap_true.
  ENDIF.


* Récupération du point de comptage (PCE)
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).

* Récupération de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.


* Condition 3

  IF <fs_vol_brut_conso> = 0.
    lv_wert1_min = lv_wert1_max = <fs_pta>.
  ELSE.
    lv_wert1_min = ( <fs_volume_conv> / <fs_vol_brut_conso> ) * ( 1 - ( lc_tolerance / 100 ) ) .
    lv_wert1_max = ( <fs_volume_conv> / <fs_vol_brut_conso> ) * ( 1 + ( lc_tolerance / 100 ) ) .
  ENDIF.

  lv_debut_periode = <fs_debut_periode> + 1.

  SELECT *
    INTO TABLE lt_ettifn
    FROM ettifn
   WHERE anlage EQ ls_object-installation
   AND operand = lc_pta
   AND ab <= lv_debut_periode
   AND bis >= <fs_fin_periode>
   AND ( wert1 >= lv_wert1_min AND wert1 <= lv_wert1_max ).

  IF sy-subrc = 0.
    lv_cond_3 = abap_true.
  ENDIF.



* Condition 4
  IF <fs_volume_conv> = 0.
    lv_wert1_min = lv_wert1_max = <fs_pcs>.
  ELSE.
    lv_wert1_min = ( <fs_energie_conso> / <fs_volume_conv> ) * ( 1 - ( lc_tolerance / 100 ) ) .
    lv_wert1_max = ( <fs_energie_conso> / <fs_volume_conv> ) * ( 1 + ( lc_tolerance / 100 ) ) .
  ENDIF.

  SELECT *
    INTO TABLE lt_ettifn
    FROM ettifn
   WHERE anlage EQ ls_object-installation
   AND operand = lc_pcs
   AND ab <= lv_debut_periode
   AND bis >= <fs_fin_periode>
   AND ( wert1 >= lv_wert1_min AND wert1 <= lv_wert1_max ).

  IF sy-subrc = 0.
    lv_cond_4 = abap_true.
  ENDIF.

* Condition 5
  "HBD-GE-11713-RE1M/RE6M
  IF <fs_vol_brut_conso> = 0.
    lv_wert1_min = lv_wert1_max = <fs_pcs>.
  ELSE.
    lv_wert1_min = ( <fs_energie_conso> / <fs_vol_brut_conso> ) * ( 1 - ( lc_tolerance / 100 ) ) .
    lv_wert1_max = ( <fs_energie_conso> / <fs_vol_brut_conso> ) * ( 1 + ( lc_tolerance / 100 ) ) .
  ENDIF.

  SELECT *
     INTO TABLE lt_ettifn
     FROM ettifn
    WHERE anlage EQ ls_object-installation
    AND operand = lc_pcs
    AND ab <= lv_debut_periode
    AND bis >= <fs_fin_periode>
    AND ( wert1 >= lv_wert1_min AND wert1 <= lv_wert1_max ).

  IF sy-subrc = 0.
    lv_cond_5 = abap_true.
  ENDIF.

  "HBD-GE-11713-RE1M/RE6M
  CASE <fs_flux> .
    WHEN 'REMM'.
      IF lv_cond_1 = abap_true AND lv_cond_2 = abap_true
        AND lv_cond_3 = abap_true AND lv_cond_4 = abap_true.
        CLEAR lv_field.
        MOVE 'FLUX-STATUT'              TO lv_field.
        ASSIGN (lv_field)               TO <fs_statut>.
        <fs_statut> = zcl_tool=>gc_statut_filtre.

        ev_etape = 3.
* Flux filtré pour PCE &1
        macro_add_message_to_log i254
                                 <fs_num_pce>
                                 ''
                                 ''.
      ENDIF.
    WHEN 'RE6M' OR 'RE1M'.
      IF  lv_cond_1 = abap_true
        AND lv_cond_2 = abap_true
        AND lv_cond_5 = abap_true.

        CLEAR lv_field.
        MOVE 'FLUX-STATUT'              TO lv_field.
        ASSIGN (lv_field)               TO <fs_statut>.
        <fs_statut> = zcl_tool=>gc_statut_filtre.

        ev_etape = 3.
* Flux filtré pour PCE &1
        macro_add_message_to_log i254
                                 <fs_num_pce>
                                 ''
                                 ''.
      ENDIF.
    WHEN OTHERS.
  ENDCASE.
*FIN-IBEN-20200115-GE-10867
*&-<Début HBD-GE-11713 : commenter le bloc qui suit et déplacer le check 242 vers ligne 172
*  CLEAR:
*    lv_ok,
*    lv_equnr,
*    lt_eabl[].
*
*  CLEAR lv_ok.
*  zcl_tool=>get_all_eabl_from_equipment(
*    EXPORTING
*      iv_ext_ui = <fs_num_pce>
*      iv_date   = <fs_debut_periode>
*    IMPORTING
*      ev_ok     = lv_ok
*      ev_equnr  = lv_equnr
*      et_eabl   = lt_eabl ).
*
*  IF lv_ok EQ abap_false.
*    MESSAGE e242(zintf_g_messages) WITH <fs_num_pce>
*                                        <fs_debut_periode>
*                                        INTO DATA(lv_msg).
*
*    CLEAR ls_bpem.
*    ls_bpem-num_pce = <fs_num_pce>.
*    CASE <fs_flux>.
*      WHEN 'ADIF'.
*        ls_bpem-date_effet_cont = <fs_date_releve>.
*      WHEN 'RE6M' OR 'RE1M' OR 'REMM' OR 'REJJ' OR 'REJM'.
*        ls_bpem-date_releve     = <fs_date_releve>.
*      WHEN 'AFAC'.
*        ls_bpem-date_fin_prest  = <fs_date_releve>.
*    ENDCASE.
*
*    DATA : lv_interface TYPE zisu_flxid.
*    lv_interface = <fs_flux> .
*    ls_bpem-idenreg = <fs_idenreg>.
*    CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
*      EXPORTING
*        iv_interface_name = lv_interface
*        iv_sparte         = 'ZG'
*        is_structure      = ls_bpem.
*
** Aucune relève pertinente pour le PCE &1 en date du &2
*    macro_add_message_to_log e242
*                             <fs_num_pce>
*                             <fs_debut_periode>
*                             ''.
*  ENDIF.
*
** Recherche sur la date de relève à +/- 5 jours
*  ls_date_min = <fs_date_releve> - 5.
*  ls_date_max = <fs_date_releve> + 5.
*
** Suppression des relèves hors période de référence
*  DELETE lt_eabl WHERE adat LT ls_date_min.
*  DELETE lt_eabl WHERE adat GT ls_date_max.
*
*  IF lt_eabl[] IS INITIAL.
*    IF 1 = 2. MESSAGE i242(zintf_g_messages). ENDIF.
** Aucune relève pertinente pour le PCE &1 en date du &2 à +/- 5 jours
*    macro_add_message_to_log i242
*                             <fs_num_pce>
*                             <fs_date_releve>
*                             '(à +/- 5 jours)'.
*  ENDIF.
*&- Fin HBD-GE-11713 : commenter le bloc qui suit et déplacer le check 242 vers ligne 172>

  READ TABLE lt_eabl INTO ls_eabl INDEX 1.

  SET PARAMETER ID 'EAB' FIELD ls_eabl-ablbelnr.

  ev_etape = 1.

ENDFUNCTION.
