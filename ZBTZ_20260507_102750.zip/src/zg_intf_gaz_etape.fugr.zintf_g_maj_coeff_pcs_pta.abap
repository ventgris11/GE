FUNCTION zintf_g_maj_coeff_pcs_pta .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
  FIELD-SYMBOLS:
    <fs_emetteur>,
    <fs_flux>,
    <fs_idenreg>,
    <fs_num_pce>,
    <fs_date_releve>,
    <fs_debut_periode>,
    <fs_pcs>,
    <fs_pta>,
    <fs_vol_brut_conso>,
    <fs_vol_conv>,
    <fs_energie_conso>,
    <fs_type>, <fs_raison>. "++GE-2200

  CONSTANTS:
    lc_pcs TYPE e_operand VALUE 'GVFTPCS001',
    lc_pta TYPE e_operand VALUE 'GVFTPTA001'.

  DATA:
    lv_field          TYPE string,
    lv_message        TYPE char255,
    lv_subobj         TYPE balsubobj,
    lv_int_ui         TYPE int_ui,
    ls_object         TYPE eedm_isu_objects,
    lt_eablg          TYPE TABLE OF eablg,
    nb_releves_mes    TYPE i,
    nb_releves_pose   TYPE i,
    lt_ettifn         TYPE TABLE OF ettifn,
    lt_ettifn_pcs     TYPE TABLE OF ettifn,
    ls_ettifn_pcs     TYPE ettifn,
    ls_ettifn_pcs_new TYPE ettifn,
    lt_ettifn_pta     TYPE TABLE OF ettifn,
    ls_ettifn_pta     TYPE ettifn,
    ls_ettifn_pta_new TYPE ettifn,
    lt_ettifn_delete  TYPE isu_iettifn,
    lt_ettifn_update  TYPE isu_iettifn,
    lt_ettifn_insert  TYPE isu_iettifn, " Ajout AFR - GE-16916
    lv_wert1          TYPE e_wert1,
    lv_pcs            TYPE e_factor,
    lv_pta            TYPE e_factor,
    lv_energie        TYPE string,
    lv_vol_brut       TYPE string,
    lv_vol_conv       TYPE string,
    lv_pta_flux       TYPE string.


  CLEAR lv_field.
  MOVE 'FLUX-IDENREG'        TO lv_field.
  ASSIGN (lv_field)          TO <fs_idenreg>.

  CLEAR lv_field.
  MOVE 'FLUX-FLUX'           TO lv_field.
  ASSIGN (lv_field)          TO <fs_flux>.
  MOVE <fs_flux>             TO lv_subobj.

  CLEAR lv_field.
  MOVE 'FLUX-NUM_PCE'        TO lv_field.
  ASSIGN (lv_field)          TO <fs_num_pce>.

  CLEAR: lv_field.
  MOVE 'FLUX-TYPE_RELEVE'    TO lv_field.
  ASSIGN (lv_field)          TO <fs_type>.

*++ STOU DEBUT GE-2200
*  CLEAR: lv_field.
*  MOVE 'FLUX-RAISON_RELEVE' TO lv_field.
*  ASSIGN (lv_field) TO <fs_raison>.

*-- STOU DEBUT GE-2204
*  IF <fs_flux> = 'RE6M' AND <fs_raison> IS ASSIGNED AND <fs_type> IS ASSIGNED.
*    IF <fs_raison> = '87' AND <fs_type> = 'S'.
*      CLEAR: lv_field.
*      MOVE 'FLUX-FIN_PERIODE' TO lv_field.
*      ASSIGN (lv_field) TO <fs_date_releve>.
*    ELSE.
*      CLEAR: lv_field.
*      MOVE 'FLUX-DATE_RELEVE' TO lv_field.
*      ASSIGN (lv_field) TO <fs_date_releve>.
*    ENDIF.
*  ELSE.
*    CLEAR: lv_field.
*    MOVE 'FLUX-DATE_RELEVE' TO lv_field.
*    ASSIGN (lv_field) TO <fs_date_releve>.
*  ENDIF.
*-- STOU FIN   GE-2204

  CLEAR: lv_field.
  MOVE 'FLUX-DATE_RELEVE'                 TO lv_field.
  ASSIGN (lv_field)                       TO <fs_date_releve>.

*++ STOU FIN   GE-2200

  "MFO GE-6347 début
  CLEAR: lv_field.
  MOVE 'FLUX-EMETTEUR'                 TO lv_field.
  ASSIGN (lv_field)                       TO <fs_emetteur>.
  "MFO GE-6347 Fin

  CLEAR lv_field.
  MOVE 'FLUX-DEBUT_PERIODE'  TO lv_field.
  ASSIGN (lv_field)          TO <fs_debut_periode>.

  CLEAR lv_field.
  MOVE 'FLUX-PCS'            TO lv_field.
  ASSIGN (lv_field)          TO <fs_pcs>.
  IF sy-subrc IS NOT INITIAL.
    CLEAR lv_field.
    MOVE 'FLUX-COEF_THERMIQUE' TO lv_field.
    ASSIGN (lv_field)          TO <fs_pcs>.
  ENDIF.

  CLEAR lv_field.
  MOVE 'FLUX-PTA'            TO lv_field.
  ASSIGN (lv_field)          TO <fs_pta>.

  CLEAR lv_field.
  MOVE 'FLUX-VOL_BRUT_CONSO' TO lv_field.
  ASSIGN (lv_field)          TO <fs_vol_brut_conso>.

  CLEAR lv_field.
  MOVE 'FLUX-VOLUME_CONV'    TO lv_field.
  ASSIGN (lv_field)          TO <fs_vol_conv>.

  CLEAR lv_field.
  MOVE 'FLUX-ENERGIE_CONSO'  TO lv_field.
  ASSIGN (lv_field)          TO <fs_energie_conso>.

  ev_etape = 1.

* Si date début de période non renseignée,
* aucune mise à jour des valeurs fixes PCS et/ou PTA
  CHECK <fs_debut_periode> IS NOT INITIAL.

* Récupération du point de comptage (PCE)
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).

* Récupération de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.

  IF ls_object-installation IS INITIAL.
* (ID &1) PCE &2 non rattaché à une installation active à la date du &3
    MESSAGE e044(zintf_g_messages)
       WITH <fs_idenreg>
            <fs_num_pce>
            <fs_date_releve>
       INTO lv_message.
    ev_etape = 2.
    RETURN.
  ENDIF.

* Recherche d'une relève postérieure à la MES
  CLEAR: lt_eablg[], lt_eablg.
  SELECT *
    INTO TABLE lt_eablg
    FROM eablg
   WHERE anlage   EQ ls_object-installation
     AND adatsoll EQ <fs_debut_periode>
     AND ablesgr  EQ '06'.

  nb_releves_mes = lines( lt_eablg ).

  CLEAR: lt_eablg[], lt_eablg.
  SELECT *
    INTO TABLE lt_eablg
    FROM eablg
   WHERE anlage   EQ ls_object-installation
     AND adatsoll EQ <fs_debut_periode>
     AND ablesgr  EQ '21'.

  nb_releves_pose = lines( lt_eablg ).

* Récupération des valeurs fixes de l'installation
  CLEAR: lt_ettifn[], lt_ettifn.
  SELECT *
    INTO TABLE lt_ettifn
    FROM ettifn
   WHERE anlage EQ ls_object-installation.

*************** Mise à jour du PCS *******************************

  lt_ettifn_pcs[] = lt_ettifn[].
  DELETE lt_ettifn_pcs WHERE operand NE lc_pcs.

  IF lt_ettifn_pcs[] IS INITIAL.
    MESSAGE e209(zintf_g_messages)
       WITH <fs_emetteur>
            <fs_flux>
            <fs_idenreg>
            lc_pcs
       INTO lv_message.
    ev_etape = 2.
    RETURN.
  ENDIF.

* Si la donnée PCS est non renseignée, ne pas mettre à jour la valeur fixe PCS
  IF <fs_pcs> IS NOT INITIAL.
    SORT lt_ettifn_pcs BY bis DESCENDING.

* Suppression des entrées avec une date de début supérieure ou égale
* à la date de début de la tranche à insérer
    CLEAR: lt_ettifn_delete[], lt_ettifn_delete.
    LOOP AT lt_ettifn_pcs INTO ls_ettifn_pcs.
      IF ls_ettifn_pcs-ab GE <fs_debut_periode>.
        APPEND ls_ettifn_pcs TO lt_ettifn_delete.
        DELETE TABLE lt_ettifn_pcs FROM ls_ettifn_pcs.
      ENDIF.
    ENDLOOP.

    IF lt_ettifn_delete[] IS NOT INITIAL.
      CALL FUNCTION 'ISU_DB_ETTIFN_UPDATE'
        EXPORTING
          x_upd_mode = 'D'
          x_iettifn  = lt_ettifn_delete.
    ENDIF.

    IF lt_ettifn_pcs[] IS NOT INITIAL.
      READ TABLE lt_ettifn_pcs INTO ls_ettifn_pcs INDEX 1.
    ENDIF.

    ls_ettifn_pcs_new = ls_ettifn_pcs.

    IF nb_releves_mes EQ 0.
      IF nb_releves_pose GT 0.
        ls_ettifn_pcs_new-ab = <fs_debut_periode>.
      ELSE.
        ls_ettifn_pcs_new-ab = <fs_debut_periode> + 1.
      ENDIF.
    ELSE.
      ls_ettifn_pcs_new-ab   = <fs_debut_periode>.
    ENDIF.

    lv_energie  = <fs_energie_conso>.
    lv_vol_conv = <fs_vol_conv>.
    IF lv_vol_conv <> 0.
      lv_wert1 = lv_energie / lv_vol_conv.
    ELSE.
      lv_wert1 = <fs_pcs>.
    ENDIF.

    ls_ettifn_pcs_new-wert1 = lv_wert1.
    ls_ettifn_pcs_new-bis   = '99991231'.

* Modification pour prise en compte des MES
* en cours de vie d'une installation (RES plus MES)
    IF nb_releves_mes EQ 0.
      IF nb_releves_pose GT 0.
        ls_ettifn_pcs-bis = <fs_debut_periode> - 1.
      ELSE.
        ls_ettifn_pcs-bis = <fs_debut_periode>.
      ENDIF.
    ELSE.
      ls_ettifn_pcs-bis   = <fs_debut_periode> - 1.
    ENDIF.

* Si le coefficient PCS est le même, fusion des 2 tranches de temps
    IF ls_ettifn_pcs_new-wert1 = ls_ettifn_pcs-wert1.
      ls_ettifn_pcs_new-ab = ls_ettifn_pcs-ab.
    ENDIF.

    CLEAR: lt_ettifn_update[], lt_ettifn_update.

    APPEND ls_ettifn_pcs TO lt_ettifn_update.

    IF lt_ettifn_pcs[] IS NOT INITIAL.
      IF ls_ettifn_pcs_new-wert1 = ls_ettifn_pcs-wert1.
        CALL FUNCTION 'ISU_DB_ETTIFN_UPDATE'
          EXPORTING
            x_upd_mode = 'D'
            x_iettifn  = lt_ettifn_update.
      ELSE.
* Mise à jour de la date de la dernière tranche
        CALL FUNCTION 'ISU_DB_ETTIFN_UPDATE'
          EXPORTING
            x_upd_mode = 'U'
            x_iettifn  = lt_ettifn_update.
      ENDIF.
    ENDIF.

    CLEAR: lt_ettifn_update[], lt_ettifn_update.

    APPEND ls_ettifn_pcs_new TO lt_ettifn_update.

* Insertion de la nouvelle tranche
    CALL FUNCTION 'ISU_DB_ETTIFN_UPDATE'
      EXPORTING
        x_upd_mode = 'I'
        x_iettifn  = lt_ettifn_update.
  ENDIF.

  CHECK <fs_flux> EQ 'REMM'.

*************** Mise à jour du PTA *******************************

  lt_ettifn_pta[] = lt_ettifn[].
  DELETE lt_ettifn_pta WHERE operand NE lc_pta.

  IF lt_ettifn_pta[] IS INITIAL.
    MESSAGE e209(zintf_g_messages)
       WITH <fs_emetteur>
            <fs_flux>
            <fs_idenreg>
            lc_pta
       INTO lv_message.
    ev_etape = 2.
    RETURN.
  ENDIF.

  lv_vol_conv = <fs_vol_conv>.
  lv_vol_brut = <fs_vol_brut_conso>.

  "MFO GE-6347 début
* Si la donnée PTA est non renseignée, ne pas mettre à jour la valeur fixe PTA
  lv_pta = <fs_pta>.
  IF lv_pta IS INITIAL OR lv_pta = 0.
*+GE-16269 {
    IF <fs_flux> = 'REMM'.
      FIELD-SYMBOLS : <fs_index_deb>,
                      <fs_index_fin>.
      DATA : lv_index_deb TYPE string,
             lv_index_fin TYPE string.
      CLEAR lv_field.
      MOVE 'FLUX-INDEX_BRUT_DEBUT_PERIODE'  TO lv_field.
      ASSIGN (lv_field)          TO <fs_index_deb>.

      CLEAR lv_field.
      MOVE 'FLUX-INDEX_BRUT_FIN_PERIODE'  TO lv_field.
      ASSIGN (lv_field)          TO <fs_index_fin>.

      lv_index_deb = <fs_index_deb>.
      REPLACE '.' IN lv_index_deb WITH space.
      CONDENSE lv_index_deb NO-GAPS.
      lv_index_fin = <fs_index_fin>.
      REPLACE '.' IN lv_index_fin WITH space.
      CONDENSE lv_index_fin NO-GAPS.

      IF lv_index_deb <> lv_index_fin.
        MESSAGE e119(zintf_g_messages)
        WITH <fs_num_pce>
        INTO lv_message.
        ev_etape  = 2.
        RETURN.
      ENDIF.
*    ENDIF.
    ELSE.
*+GE-16269 }
      "Rejet « PCE &1 volume brut &2 et volume converti = 0 et PTA »
      MESSAGE e251(zintf_g_messages)
      WITH <fs_num_pce>
           lv_vol_brut
      INTO lv_message.
      ev_etape = 2.
      RETURN.
    ENDIF.
  ENDIF.



  IF lv_vol_brut <> 0 AND lv_vol_conv = 0 AND <fs_emetteur> = 'GDFD'.
    MESSAGE e252(zintf_g_messages)
WITH <fs_num_pce>
     lv_vol_brut
INTO lv_message.
    ev_etape = 2.
    RETURN.
  ENDIF.

  "MFO GE-6347 Fin

*  IF <fs_pta> IS NOT INITIAL.
  IF lv_pta IS NOT INITIAL AND lv_pta NE 0.
    SORT lt_ettifn_pta BY bis DESCENDING.

* Suppression des entrées avec une date de début supérieure ou égale
* à la date de début de la tranche à insérer
    CLEAR: lt_ettifn_delete[], lt_ettifn_delete.
    LOOP AT lt_ettifn_pta INTO ls_ettifn_pta.
      IF ls_ettifn_pta-ab GE <fs_debut_periode>.
        APPEND ls_ettifn_pta TO lt_ettifn_delete.
        DELETE TABLE lt_ettifn_pta FROM ls_ettifn_pta.
      ENDIF.
    ENDLOOP.

    IF lt_ettifn_delete[] IS NOT INITIAL.
      CALL FUNCTION 'ISU_DB_ETTIFN_UPDATE'
        EXPORTING
          x_upd_mode = 'D'
          x_iettifn  = lt_ettifn_delete.
    ENDIF.

    IF lt_ettifn_pta[] IS NOT INITIAL.
      READ TABLE lt_ettifn_pta INTO ls_ettifn_pta INDEX 1.
    ENDIF.

    ls_ettifn_pta_new = ls_ettifn_pta.

    IF nb_releves_mes EQ 0.
      IF nb_releves_pose GT 0.
        ls_ettifn_pta_new-ab = <fs_debut_periode>.
      ELSE.
        ls_ettifn_pta_new-ab = <fs_debut_periode> + 1.
      ENDIF.
    ELSE.
      ls_ettifn_pta_new-ab   = <fs_debut_periode>.
    ENDIF.
    "MFO GE-6347 début
*    lv_vol_conv = <fs_vol_conv>.
*    lv_vol_brut = <fs_vol_brut_conso>.

    IF lv_vol_brut <> 0.
      IF lv_vol_conv <> 0.
        lv_wert1 =  lv_vol_conv / lv_vol_brut.
      ELSE.
        "Si GRDF : Rejet « PRM &1 volume brut &2 et volume converti = 0 »
        IF <fs_emetteur> = 'GDFD'. "Rejet déjà catché plus haut
          MESSAGE e252(zintf_g_messages)
          WITH <fs_num_pce>
           lv_vol_brut
            INTO lv_message.
          ev_etape = 2.
          RETURN.
        ELSE.
          "Sinon utiliser le PTA du flux
          lv_wert1 = <fs_pta>.
        ENDIF.
      ENDIF.
    ELSE. "lv_vol_brut = 0
      lv_wert1 = <fs_pta>.
    ENDIF.

    "MFO GE-6347 Fin

    ls_ettifn_pta_new-wert1 = lv_wert1.
    ls_ettifn_pta_new-bis   = '99991231'.

* Modification pour prise en compte des MES
* en cours de vie d'une installation (RES plus MES)
    IF nb_releves_mes EQ 0.
      IF nb_releves_pose GT 0.
        ls_ettifn_pta-bis = <fs_debut_periode> - 1.
      ELSE.
        ls_ettifn_pta-bis = <fs_debut_periode>.
      ENDIF.
    ELSE.
      ls_ettifn_pta-bis   = <fs_debut_periode> - 1.
    ENDIF.

* Si le coefficient PTA est le même, fusion des 2 tranches de temps
    IF ls_ettifn_pta_new-wert1 = ls_ettifn_pta-wert1.
      ls_ettifn_pta_new-ab = ls_ettifn_pta-ab.
    ENDIF.

    CLEAR: lt_ettifn_update[], lt_ettifn_update.

    APPEND ls_ettifn_pta TO lt_ettifn_update.

    IF lt_ettifn_pta[] IS NOT INITIAL.
      IF ls_ettifn_pta_new-wert1 = ls_ettifn_pta-wert1.
        CALL FUNCTION 'ISU_DB_ETTIFN_UPDATE'
          EXPORTING
            x_upd_mode = 'D'
            x_iettifn  = lt_ettifn_update.
      ELSE.
* Mise à jour de la date de la dernière tranche
        CALL FUNCTION 'ISU_DB_ETTIFN_UPDATE'
          EXPORTING
            x_upd_mode = 'U'
            x_iettifn  = lt_ettifn_update.
      ENDIF.
    ENDIF.

    CLEAR: lt_ettifn_update[], lt_ettifn_update.

    APPEND ls_ettifn_pta_new TO lt_ettifn_update.

* Insertion de la nouvelle tranche
    CALL FUNCTION 'ISU_DB_ETTIFN_UPDATE'
      EXPORTING
        x_upd_mode = 'I'
        x_iettifn  = lt_ettifn_update.
  ENDIF.

ENDFUNCTION.
