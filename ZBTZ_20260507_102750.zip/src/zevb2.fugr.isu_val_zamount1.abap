FUNCTION isu_val_zamount1.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(X_TE327) LIKE  TE327 STRUCTURE  TE327
*"  CHANGING
*"     REFERENCE(XY_OBJ) TYPE  ISU2A_BILLING_DATA
*"     REFERENCE(XY_OUTCNSO) LIKE  ERCHO-OUTCNSO
*"  EXCEPTIONS
*"      GENERAL_FAULT
*"----------------------------------------------------------------------
  DATA: werchz    LIKE erchz,
        nettobtr  LIKE erchz-nettobtr,
        outsorted TYPE c,
        deviation LIKE ercho-deviation.


  READ TABLE xy_obj-iabrzeit TRANSPORTING NO FIELDS
                             WITH KEY pertyp = 'AS'.
  IF sy-subrc IS INITIAL.
    EXIT.
  ENDIF.

  LOOP AT xy_obj-bill-ierchz INTO werchz
          WHERE buchrel = 'X'.
    IF werchz-abslkz IS INITIAL.
      nettobtr = nettobtr + werchz-nettobtr.
    ENDIF.
  ENDLOOP.

  CALL FUNCTION 'ISU_E25M_BETRW_WAERS_CORRECT'
    EXPORTING
      x_amount          = nettobtr
      x_currency        = werchz-twaers
    IMPORTING
      y_amount          = nettobtr
    EXCEPTIONS
      too_many_decimals = 1
      OTHERS            = 2.
  IF sy-subrc NE 0.
    mac_msg_putx co_msg_error '274' 'AJ' x_te327-validation space
                           space space general_fault.
    IF 1 = 2. MESSAGE e274(aj) WITH space. ENDIF.
  ENDIF.

  IF nettobtr >= 0.
    IF nettobtr < x_te327-value1 OR
       nettobtr > x_te327-value2.
      deviation = nettobtr.
      outsorted = 'X'.
    ENDIF.
  ELSEIF nettobtr < 0.
    IF nettobtr < x_te327-value4 OR
       nettobtr > x_te327-value3.
      deviation = nettobtr.
      outsorted = 'X'.
    ENDIF.
  ENDIF.

  IF NOT outsorted IS INITIAL.
    CALL FUNCTION 'ISU_OUTSORT_IERCHO_WRITE'
      EXPORTING
        x_validation = x_te327-validation
        x_deviation  = deviation
      CHANGING
        xy_iercho    = xy_obj-bill-iercho
        xy_outcnso   = xy_outcnso.
  ENDIF.
ENDFUNCTION.
