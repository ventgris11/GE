* regenerated at 31.07.2017 13:02:14
FUNCTION-POOL ZBTZ_STOU                       MESSAGE-ID SV.

* INCLUDE LZBTZD...                          " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZBTZT00                                . "view rel. data dcl.
