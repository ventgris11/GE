*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZBTZ_F03
*   generation date: 16.10.2018 at 16:49:50
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZBTZ_F03            .

  PERFORM TABLEPROC.

ENDFUNCTION.
