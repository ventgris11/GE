*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 20.10.2018 at 19:32:23
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZTCFE_FACT_PARM.................................*
DATA:  BEGIN OF STATUS_ZTCFE_FACT_PARM               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTCFE_FACT_PARM               .
CONTROLS: TCTRL_ZTCFE_FACT_PARM
            TYPE TABLEVIEW USING SCREEN '0001'.
*...processing: ZTCFE_PS........................................*
DATA:  BEGIN OF STATUS_ZTCFE_PS                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTCFE_PS                      .
CONTROLS: TCTRL_ZTCFE_PS
            TYPE TABLEVIEW USING SCREEN '0002'.
*.........table declarations:.................................*
TABLES: *ZTCFE_FACT_PARM               .
TABLES: *ZTCFE_PS                      .
TABLES: ZTCFE_FACT_PARM                .
TABLES: ZTCFE_PS                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
