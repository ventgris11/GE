CLASS zcl_split_csv_eld_gaz_bord DEFINITION
  PUBLIC
  INHERITING FROM zcl_split_csv_eld_gaz
  CREATE PUBLIC .

  PUBLIC SECTION.

    METHODS constructor
      IMPORTING
        !i_emet       TYPE zemetteur_id
        !i_idflux     TYPE zconv_flux
        !i_rep_in     TYPE fileintern
        !i_rep_ar     TYPE fileintern
        !i_rep_refuse TYPE fileintern .

    METHODS create_files
         REDEFINITION .
    METHODS exec_python
         REDEFINITION .
    METHODS treat_file
         REDEFINITION .
  PROTECTED SECTION.

    TYPES:
      BEGIN OF ty_file_bordereaux,
        name_of_file  TYPE eps2filnam,
        nb_of_lines   TYPE i,
        lines_of_file TYPE table_of_strings,
      END OF ty_file_bordereaux .
    TYPES:
      tt_file_bordereaux TYPE STANDARD TABLE OF ty_file_bordereaux .

    DATA pt_bordereaux TYPE tt_file_bordereaux .
    DATA :
  p_num_seq_bordereaux(5) TYPE n.

  PRIVATE SECTION.
ENDCLASS.



CLASS ZCL_SPLIT_CSV_ELD_GAZ_BORD IMPLEMENTATION.


  METHOD constructor.

    super->constructor( i_emet = i_emet i_idflux = i_idflux i_rep_in = i_rep_in i_rep_ar = i_rep_ar i_rep_refuse = i_rep_refuse ).
    p_num_seq_bordereaux = 00001.

  ENDMETHOD.


  METHOD create_files.

    DATA :
      ls_longtext TYPE ty_longtext,
      lv_filename TYPE string.

    DATA :
          lt_file_name_parts TYPE TABLE OF string.

    LOOP AT pt_bordereaux ASSIGNING FIELD-SYMBOL(<ls_files>).

      CLEAR : lv_filename.

      ls_longtext = <ls_files>-name_of_file.

      " Récupération du chemin + nom de fichier
      CALL FUNCTION 'FILE_GET_NAME'
        EXPORTING
          logical_filename = 'ZISU_GAZ_ELD_A_TRANSFORMER'
          operating_system = 'VMS'
          parameter_1      = p_emet
          parameter_2      = 'AFAC'
          parameter_3      = <ls_files>-name_of_file
        IMPORTING
          file_name        = lv_filename
        EXCEPTIONS
          file_not_found   = 1
          OTHERS           = 2.

      " Open the file
      IF po_files_manager->open_dataset_output( lv_filename ) IS NOT INITIAL.

        TRY.

            LOOP AT <ls_files>-lines_of_file ASSIGNING FIELD-SYMBOL(<ls_line>).
              po_files_manager->transfer_to_dataset( x_file = lv_filename x_data = <ls_line> ).
            ENDLOOP.

            CLOSE DATASET lv_filename.

            " Fichier &1&2&3&4 créé avec succès
            MESSAGE s011(zsplit_csv_eld_gaz) WITH ls_longtext-msgv1 ls_longtext-msgv2 ls_longtext-msgv3 ls_longtext-msgv4 INTO DATA(lv_dummy).
            po_log->add_sy_msg( ).

          CATCH zcx_utils_file_error .

            " Erreur lors de l'écriture du fichier &1&2&3&4
            MESSAGE e005(zsplit_csv_eld_gaz) WITH ls_longtext-msgv1 ls_longtext-msgv2 ls_longtext-msgv3 ls_longtext-msgv4 INTO lv_dummy.
            po_log->add_sy_msg( ).

        ENDTRY.

      ENDIF.

    ENDLOOP.

  ENDMETHOD.


  METHOD exec_python.

    DATA :
      lv_parameter       TYPE btcxpgpar,
      lv_status          TYPE btcxpgstat,
      lv_exitcode        TYPE btcxpgexit,
      ls_longtext        TYPE ty_longtext,
      lt_exec_protocol   TYPE TABLE OF btcxpm,
      lt_file_name_parts TYPE TABLE OF string.

    lv_parameter = `--file ` && i_name && ` --flux bordereaux --emetteur ` && p_emet.


    CALL FUNCTION 'SXPG_COMMAND_EXECUTE'
      EXPORTING
        commandname                   = 'ZGENERATE_CSV_G'
        additional_parameters         = lv_parameter
      IMPORTING
        status                        = lv_status
        exitcode                      = lv_exitcode
      TABLES
        exec_protocol                 = lt_exec_protocol
      EXCEPTIONS
        no_permission                 = 1
        command_not_found             = 2
        parameters_too_long           = 3
        security_risk                 = 4
        wrong_check_call_interface    = 5
        program_start_error           = 6
        program_termination_error     = 7
        x_error                       = 8
        parameter_expected            = 9
        too_many_parameters           = 10
        illegal_command               = 11
        wrong_asynchronous_parameters = 12
        cant_enq_tbtco_entry          = 13
        jobcount_generation_error     = 14
        OTHERS                        = 15.

    IF sy-subrc  NE 0
    OR lv_status EQ 'E'.
      ls_longtext = i_name.
      " Fichier &1&2 : Erreur lors de l'appel du script python
      MESSAGE e004(zsplit_csv_eld_gaz) WITH ls_longtext-msgv1 ls_longtext-msgv2 INTO DATA(lv_dummy).
      po_log->add_sy_msg( ).
      " Raise the exception
      RAISE EXCEPTION TYPE zcx_split_eld_gaz_error.

    ENDIF.
  ENDMETHOD.


  METHOD treat_file.

    DATA :
      lv_num_cad         TYPE string,
      lv_date_releve     TYPE dats,
      lv_heure           TYPE string,
      lv_date            TYPE string,
      lv_pce             TYPE ext_ui,
      lt_data            TYPE table_of_strings,
      lt_file_name_parts TYPE table_of_strings,
      lt_entete_tech     TYPE table_of_strings,
      ls_add_bordereaux  TYPE ty_file_bordereaux,
      ls_header_tech     TYPE string,
      ls_entete_fonc     TYPE string,
      ls_pdp             TYPE string.

    REFRESH pt_bordereaux.

    LOOP AT i_lines ASSIGNING FIELD-SYMBOL(<ls_line>).

      " En tête technique
      IF sy-tabix EQ 1.

        ls_header_tech = <ls_line>.
        SPLIT ls_header_tech AT ';' INTO TABLE lt_data.
        READ TABLE lt_data ASSIGNING FIELD-SYMBOL(<ls_data>) INDEX 5.
        IF sy-subrc EQ 0.

          CASE p_emet.
            WHEN 'GRNB'.
              IF <ls_data> NE c_grnb_emet.
                " L'émetteur de l'entête &1 ne correspond pas à l'émetteur &2
                MESSAGE e012(zsplit_csv_eld_gaz) WITH <ls_data> p_emet INTO DATA(lv_dummy).
                po_log->add_sy_msg( ).
                RAISE EXCEPTION TYPE zcx_split_eld_gaz_error.
              ENDIF.
            WHEN 'DREU'.
              IF <ls_data> NE c_dreu_emet.
                " L'émetteur de l'entête &1 ne correspond pas à l'émetteur &2
                MESSAGE e012(zsplit_csv_eld_gaz) WITH <ls_data> p_emet INTO lv_dummy.
                po_log->add_sy_msg( ).
                RAISE EXCEPTION TYPE zcx_split_eld_gaz_error.
              ENDIF.
            WHEN OTHERS.
              " Aucun autre cas gérés pour le moment
          ENDCASE.

          <ls_data> = p_emet.

        ENDIF.

        CLEAR : ls_header_tech.
        LOOP AT lt_data ASSIGNING <ls_data>.
          IF ls_header_tech IS INITIAL.
            ls_header_tech = <ls_data>.
          ELSE.
            ls_header_tech = ls_header_tech && ';' && <ls_data>.
          ENDIF.
        ENDLOOP.

      ELSE.

        SPLIT <ls_line> AT ';' INTO TABLE lt_data.
        READ TABLE lt_data ASSIGNING <ls_data> INDEX 1.
        IF sy-subrc EQ 0 AND <ls_data> EQ 'header'.

          IF ls_add_bordereaux IS NOT INITIAL.
            " Création du pied de page
            ls_pdp =  sy-datlo && sy-timlo && ';' && ls_add_bordereaux-nb_of_lines && ';;' && 'EOF'.
            APPEND ls_pdp TO ls_add_bordereaux-lines_of_file.
            APPEND ls_add_bordereaux TO pt_bordereaux.
          ENDIF.

          CLEAR : ls_add_bordereaux, ls_entete_fonc.

          " Gestion de l'en tête technique
          APPEND ls_header_tech TO ls_add_bordereaux-lines_of_file.

          " Gestion de l'en tête fonctionnel
          LOOP AT lt_data ASSIGNING FIELD-SYMBOL(<ls_header>) FROM 2.
            IF ls_entete_fonc IS INITIAL.
              ls_entete_fonc = <ls_header>.
            ELSE.
              ls_entete_fonc = ls_entete_fonc && ';' && <ls_header>.
            ENDIF.
            IF sy-tabix EQ 2.
              lv_num_cad = <ls_header>.
              CONDENSE lv_num_cad NO-GAPS.
            ENDIF.
          ENDLOOP.

          APPEND ls_entete_fonc TO ls_add_bordereaux-lines_of_file.

          " Créer le nom de fichier
          " Récupération de la date et heure du fichier de base
          SPLIT i_name AT '_' INTO TABLE lt_file_name_parts.
          READ TABLE lt_file_name_parts ASSIGNING FIELD-SYMBOL(<ls_part>) INDEX 6.
          IF sy-subrc EQ 0.
            lv_date = <ls_part>.
          ENDIF.
          READ TABLE lt_file_name_parts ASSIGNING <ls_part> INDEX 6.
          IF sy-subrc EQ 0.
            lv_heure = <ls_part>.
          ENDIF.

          ls_add_bordereaux-name_of_file = 'AFAC_A_' && p_num_seq_bordereaux && '_1_' && p_emet && '_' && lv_num_cad && '_' && lv_date && lv_heure && '_00001.csv'.
          p_num_seq_bordereaux = p_num_seq_bordereaux + 1.

        ELSE.

          ls_add_bordereaux-nb_of_lines = ls_add_bordereaux-nb_of_lines + 1.
          APPEND <ls_line> TO ls_add_bordereaux-lines_of_file.

        ENDIF.

      ENDIF.

    ENDLOOP.

    " Gestion de la dernière ligne du tableau

    IF ls_add_bordereaux IS NOT INITIAL.
      " Création du pied de page
      ls_pdp =  sy-datlo && sy-timlo && ';' && ls_add_bordereaux-nb_of_lines && ';;' && 'EOF'.
      APPEND ls_pdp TO ls_add_bordereaux-lines_of_file.
      APPEND ls_add_bordereaux TO pt_bordereaux.
    ENDIF.

  ENDMETHOD.
ENDCLASS.
