*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 25.03.2019 at 09:29:54
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZCOEFF_A........................................*
DATA:  BEGIN OF STATUS_ZCOEFF_A                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCOEFF_A                      .
CONTROLS: TCTRL_ZCOEFF_A
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZCOEFF_A                      .
TABLES: ZCOEFF_A                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
