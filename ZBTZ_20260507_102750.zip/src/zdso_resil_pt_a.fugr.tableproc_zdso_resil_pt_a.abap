*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDSO_RESIL_PT_A
*   generation date: 14.04.2019 at 12:20:32
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDSO_RESIL_PT_A     .

  PERFORM TABLEPROC.

ENDFUNCTION.
