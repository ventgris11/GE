FUNCTION-POOL zfka5                      MESSAGE-ID sv.

* INCLUDE LZFKA5D...                         " Local class definition


INCLUDE lsvimdat.               "general data decl.
INCLUDE lfka5t00.               "view rel. data dcl.

INCLUDE finkscdt.
INCLUDE finkscdc.

TYPE-POOLS: shlp,
            fkkco.

TABLES: dfkkcoll, fkkmaze, rfka5.

*-----------------------------------------------------------------------
* Konstantendeklarationen
*-----------------------------------------------------------------------
CONSTANTS: const_marked                VALUE 'X',
           const_mode_all(5)           TYPE c VALUE 'IDUMS',
           const_mode_insert           VALUE 'I',
           const_mode_delete           VALUE 'D',
           const_mode_update           VALUE 'U',
           const_mode_modify           VALUE 'M',
           const_mode_simu             VALUE 'S',
           const_event_5059            LIKE tfkfbm-fbeve   VALUE '5059',
           const_event_5060            LIKE tfkfbm-fbeve   VALUE '5060',
           const_event_5061            LIKE tfkfbm-fbeve   VALUE '5061',
           const_event_5062            LIKE tfkfbm-fbeve   VALUE '5062',
           const_event_5063            LIKE tfkfbm-fbeve   VALUE '5063',
           const_event_5064            LIKE tfkfbm-fbeve   VALUE '5064',
           const_event_5065            LIKE tfkfbm-fbeve   VALUE '5065',
           const_event_6260            LIKE tfkfbm-fbeve   VALUE '6260',
           const_buber_1054            LIKE tfk033c-buber  VALUE '1054',
           const_aggrd_dunning         LIKE dfkkcoll-aggrd VALUE '04',
           const_agsta_freigegeben     LIKE dfkkcoll-agsta VALUE '01',
           const_agsta_abgegeben       LIKE dfkkcoll-agsta VALUE '02',
           const_agsta_bezahlt         LIKE dfkkcoll-agsta VALUE '03',
           const_agsta_teilbezahlt     LIKE dfkkcoll-agsta VALUE '04',
           const_agsta_storniert       LIKE dfkkcoll-agsta VALUE '05',
           const_agsta_erfolglos       LIKE dfkkcoll-agsta VALUE '06',
           const_agsta_cu_t_erfolglos  LIKE dfkkcoll-agsta VALUE '07',
           const_agsta_t_erfolglos     LIKE dfkkcoll-agsta VALUE '08',
           const_agsta_recall          LIKE dfkkcoll-agsta VALUE '09',
           const_agsta_cust_pay        LIKE dfkkcoll-agsta VALUE '10',
           const_agsta_cust_p_pay      LIKE dfkkcoll-agsta VALUE '11',
           const_agsta_paid            LIKE dfkkcoll-agsta VALUE '12',
           const_agsta_p_paid          LIKE dfkkcoll-agsta VALUE '13',
           const_agsta_rel_erfolglos   LIKE dfkkcoll-agsta VALUE '14',
           const_agsta_sub_erfolglos   LIKE dfkkcoll-agsta VALUE '15',
           const_agsta_rec_erfolglos   LIKE dfkkcoll-agsta VALUE '16',
           const_aggrd_einzelabgabe    LIKE dfkkcoll-aggrd VALUE '06',
           const_aggrd_ausbuchen       LIKE dfkkcoll-aggrd VALUE '02',
           const_aggrd_massenausbuchen LIKE dfkkcoll-aggrd VALUE '03',
           const_aggrd_mahnlauf        LIKE dfkkcoll-aggrd VALUE '04',
* process ID to determine currency
           const_proid                 LIKE tfk042c-proid VALUE '0008',
           const_objectclass           LIKE cdhdr-objectclas VALUE 'INKASSO_01',
           const_prcst_nosend          TYPE prcst_kk VALUE '03',
           const_collitem_lv_item      TYPE collitem_lv_kk VALUE '01',
           const_collitem_lv_group     TYPE collitem_lv_kk VALUE '02',
           const_collitem_lv_case      TYPE collitem_lv_kk VALUE '03'.
DATA: g_summe        TYPE betrw_kk.

DATA:   BEGIN OF table_colgpart,
          gpart LIKE fkkop-gpart,
          inkgp LIKE dfkkcoll-inkgp,
        END OF table_colgpart.
DATA: lm_table_colgpart LIKE table_colgpart OCCURS 0 WITH HEADER LINE.

DATA:   t_tfkfbc_5059 LIKE tfkfbc    OCCURS 0 WITH HEADER LINE,
        t_tfkfbc_5060 LIKE tfkfbc    OCCURS 0 WITH HEADER LINE,
        t_tfkfbc_5061 LIKE tfkfbc    OCCURS 0 WITH HEADER LINE.

DATA: h_tfk050d LIKE tfk050d OCCURS 0 WITH HEADER LINE.

TYPES: BEGIN OF pay_struc,
         opbel LIKE dfkkcoll-opbel,
         inkps LIKE dfkkcoll-inkps,
         betrz LIKE dfkkcoll-betrz,
         ninkb LIKE dfkkcoll-ninkb,
       END OF pay_struc.
TYPES: pay_tab_typ TYPE STANDARD TABLE OF pay_struc.

TYPES: BEGIN OF t_casestatus,
         inkgp       TYPE inkgp_kk,
         collitem_id TYPE collitem_id_kk,
         collitem_lv TYPE collitem_lv_kk,
         tspnr       TYPE tspnr_kk,
         collitem_st TYPE collitem_st_kk,
       END OF t_casestatus,
       tp_casestatus TYPE STANDARD TABLE OF t_casestatus.
DATA: gt_casestatus TYPE tp_casestatus,
      g_casestatus  TYPE t_casestatus.



DATA: mem_pfonc TYPE boole-boole.
DATA: h_man_sel TYPE c.   " manual selection of Collection Agency

DATA: it_fkkcoll         LIKE TABLE OF dfkkcoll,
      it_fkkcollh        LIKE TABLE OF dfkkcollh,
      it_fkkcollitem     LIKE TABLE OF dfkkcollitem,
      it_fkkcollpaymlink LIKE TABLE OF dfkkcollpaymlink,
      ut_dfkkop          LIKE dfkkop OCCURS 0 WITH HEADER LINE.

*DATA: rev_doc(1) TYPE c.
*------- table of documents to be reversed in DFKKCOLL ----------------*
DATA: BEGIN OF rev_doc OCCURS 0.    " table of reversed documents
        INCLUDE STRUCTURE fkkopbelinkps.
DATA:  END OF rev_doc.

CONSTANTS: co_pro_revers(1) TYPE c VALUE '1',
           co_pro_rescle(1) TYPE c VALUE '2',
           co_pro_return(1) TYPE c VALUE '3'.

* Contents of file that is to be displayed (dynpro 600)
DATA: BEGIN OF gt_lines OCCURS 0,
        text(500) TYPE c,
      END OF gt_lines.

*------- table of error messages --------------------------------------*
DATA: BEGIN OF errmsg OCCURS 0.    " table of error messages
        INCLUDE STRUCTURE fkkcollerr.
DATA:  END OF errmsg.

DATA: gv_file        TYPE trfile.
DATA: tabname        TYPE slis_tabname VALUE 'GT_LINES'.
DATA: gt_fieldcat    TYPE slis_t_fieldcat_alv.
DATA: gs_layout      TYPE slis_layout_alv.
DATA: gt_events      TYPE slis_t_event.
DATA: gt_top_of_page TYPE slis_t_listheader.
DATA: gt_status_set  TYPE slis_formname VALUE 'ALV_SET'.
DATA: g_user_command TYPE slis_formname VALUE 'USER_COMMAND'.

DATA: save_ok_code(4).

* Type definitions for FM FKK_SAMPLE_6263_EXAMPLE

TYPES: BEGIN OF gty_collitem_all,
         inkgp           TYPE inkgp_kk,
         gpart           TYPE gpart_kk,
         collitem_id     TYPE collitem_id_kk,
         collitem_lv     TYPE collitem_lv_kk,
         collitem_id_par TYPE collitem_id_par_kk,
         collitem_lv_par TYPE collitem_lv_par_kk,
         opbel           TYPE opbel_kk,
         opupw           TYPE opupw_kk,
         opupk           TYPE opupk_kk,
         opupz           TYPE opupz_kk,
       END OF gty_collitem_all.

TYPES: gty_collitem_all_tab TYPE STANDARD TABLE OF gty_collitem_all.

TYPES: BEGIN OF gty_opbel,
         opbel TYPE opbel_kk,
       END OF gty_opbel.

TYPES: BEGIN OF gty_inv_doc,
         opbel TYPE opbel_kk,
         docid TYPE docid_kk,
         docct TYPE docct_kk,
         txtkm TYPE txt80,
         cokey TYPE cokey_kk,
       END OF gty_inv_doc.
TYPES: gty_inv_doc_tab TYPE STANDARD TABLE OF gty_inv_doc.

TYPES: BEGIN OF gty_dun_doc,
         opbel TYPE opbel_kk,
         opupw TYPE opupw_kk,
         opupk TYPE opupk_kk,
         opupz TYPE opupz_kk,
         docid TYPE docid_kk,
         docct TYPE docct_kk,
         txtkm TYPE txt80,
         cokey TYPE cokey_kk,
       END OF gty_dun_doc.
TYPES: gty_dun_doc_tab TYPE STANDARD TABLE OF gty_dun_doc.

INCLUDE lfka5f01.
