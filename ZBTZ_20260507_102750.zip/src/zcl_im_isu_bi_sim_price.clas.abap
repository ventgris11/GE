class ZCL_IM_ISU_BI_SIM_PRICE definition
  public
  final
  create public .

public section.

  interfaces IF_EX_ISU_BI_SIM_PRICE .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_ISU_BI_SIM_PRICE IMPLEMENTATION.


METHOD if_ex_isu_bi_sim_price~change_iprei.
** Cette méthode permet d'étendre les clés de prix dans les parties manquantes pour la simulation (typiquement
** pour les remises qui ne sont pas sur toute la durée de la simu).

  " On ne veut pas utiliser ce code pour la facturation réelle (x_simulation vide)
  CHECK x_simulation IS NOT INITIAL.

  " On vérifie si la clé de prix à une date de fin
  DATA(lv_size) = lines( xy_iprei ).
  SORT xy_iprei BY bis ASCENDING.
  " On prend en modèle une des lignes de la clé de prix existante
  READ TABLE xy_iprei INTO DATA(ls_xy_iprei) INDEX 1.

* " Test pour essayer de conserver la meme valeur de prix sur toute la simulation
*  IF lines( xy_igap ) = 0.
*    REFRESH xy_iprei.
*    ls_xy_iprei-bis = '99992131'.
*    INSERT ls_xy_iprei INTO TABLE xy_iprei.
*  ENDIF.

  " On parcourt les tranches de temps manquantes (SAP a déja fait le job de les identifier !! :-))
  LOOP AT xy_igap INTO DATA(ls_xy_igap).

    ls_xy_iprei-ab = ls_xy_igap-ab.
    ls_xy_iprei-bis = ls_xy_igap-bis.
*+GE-15984 {
    IF x_price = 'GPIDPEG03'.
      IF xy_iprei[] IS INITIAL.
        DATA : lt_iepreih TYPE iepreih.

        lt_iepreih[] = x_iepreih[].
        SORT lt_iepreih BY bisdatum DESCENDING.
        READ TABLE lt_iepreih INTO DATA(ls_prix) INDEX 1.
        IF sy-subrc EQ 0.
          MOVE-CORRESPONDING ls_prix TO ls_xy_iprei.
          ls_xy_iprei-csno      = x_ss-csno.
          ls_xy_iprei-ab        = x_ss-ab.
          ls_xy_iprei-bis       = x_ss-bis.
          ls_xy_iprei-number    = '02'.
          ls_xy_iprei-preisart  = '0'.
          ls_xy_iprei-preis     = 'GPIDPEG03'.
          ls_xy_iprei-price_new = ls_prix-preisbtr.
          ls_xy_iprei-price_old = ls_prix-preisbtr.
          ls_xy_iprei-urpreis   = ls_prix-preisbtr.
        ENDIF.
      ENDIF.
    ELSE.
*+GE-15984 }
      " On positionne les prix à 0
      ls_xy_iprei-price_new = 0.
      ls_xy_iprei-price_old = 0.
      ls_xy_iprei-urpreis   = 0.
    ENDIF.

    INSERT ls_xy_iprei INTO TABLE xy_iprei.
  ENDLOOP.

  REFRESH xy_igap.
ENDMETHOD.
ENDCLASS.
