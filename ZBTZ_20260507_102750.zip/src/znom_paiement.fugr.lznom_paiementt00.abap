*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 22.07.2017 at 13:06:49
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZNOM_PAIEMENT...................................*
DATA:  BEGIN OF STATUS_ZNOM_PAIEMENT                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZNOM_PAIEMENT                 .
CONTROLS: TCTRL_ZNOM_PAIEMENT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZNOM_PAIEMENT                 .
TABLES: ZNOM_PAIEMENT                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
