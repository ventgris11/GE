*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 03.04.2019 at 15:45:50
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
