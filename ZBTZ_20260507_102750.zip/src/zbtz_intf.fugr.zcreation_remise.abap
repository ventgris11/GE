FUNCTION zcreation_remise .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_PCE_NUM) TYPE  EXT_UI
*"     REFERENCE(IV_ARTICLE) TYPE  MATNR
*"     REFERENCE(IV_DATE) TYPE  DATUM
*"  EXPORTING
*"     REFERENCE(EV_ERROR) TYPE  CRMT_BOOLEAN
*"     REFERENCE(EV_MESSAGE) TYPE  STRING
*"----------------------------------------------------------------------

  DATA: lv_ko                   TYPE flag,
        lv_bukrs                TYPE stdbk_kk,
        lv_blocage              TYPE flag,
        lv_sparte               TYPE sparte,
        lv_posnr                TYPE posnr,
*        lv_message              TYPE string,
        lv_date                 TYPE datum,
        ls_sales_order_header   TYPE zisus_sales_order_header,
        lt_sales_order_header   TYPE TABLE OF zisus_sales_order_header,
        ls_sales_order_item     TYPE zisus_sales_order_item,
        lt_debit_note_item_tmp  TYPE zisut_sales_order_item,
        lt_credit_note_item_tmp TYPE zisut_sales_order_item,
        lt_debit_note_item      TYPE zisut_sales_order_item,
        lt_credit_note_item     TYPE zisut_sales_order_item,
        lv_vbeln                TYPE vbeln,
        lt_return               TYPE bapiret2_t,
        ls_return               TYPE bapiret2,
        lv_anlage               TYPE anlage,
        lv_temp_matnr           TYPE string,
        lv_emetteur             TYPE zemetteur_id,
        lv_idenreg              TYPE zintf_g_id_enreg,
        lv_art_sd_remise_multi  TYPE rvari_val_255,
        v_date                  TYPE zdate_fin_frais.



  CLEAR : lv_blocage, ls_sales_order_item, ls_sales_order_header,
lv_ko.
  REFRESH :
  lt_sales_order_header,
  lt_debit_note_item,
  lt_credit_note_item.


  lv_art_sd_remise_multi = iv_article.
*  SELECT SINGLE low
*               INTO lv_art_sd_remise_multi
*               FROM tvarvc
*              WHERE name EQ 'ZINTF_E_ART_SD_REMISE_MULTI'.

****************************************************
*******Etape n°2 : Vérifier l’existence du PCE*******
****************************************************

  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num =
iv_pce_num ).

  IF lv_int_ui IS INITIAL.

    MESSAGE e160(zintf_e_messages)  WITH iv_pce_num INTO ev_message.

*    lv_interface = ls_fxx-id_flux .
*    CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
*      EXPORTING
*        iv_interface_name = lv_interface
*        iv_sparte         = 'ZE'
*        is_structure      = ls_fxx.

    ev_error = 'X'.
    EXIT.
  ENDIF.

****************************************************
*******Etape n°3.2 : Récupération des données pour commande SD  *******
****************************************************

  CLEAR : ls_sales_order_header, lv_posnr.

* Récupération de l'installation
  SELECT SINGLE anlage
                FROM euiinstln
                INTO lv_anlage
                WHERE int_ui EQ lv_int_ui
                AND   datefrom LE iv_date
                AND   dateto GE iv_date.

  IF sy-subrc EQ 0.

    SELECT SINGLE sparte
      FROM eanl
      INTO lv_sparte
      WHERE anlage = lv_anlage.

* Récupération du partenaire, du compte de contrats et des conditions
*de paiement
    SELECT SINGLE fkkvkp~gpart fkkvkp~vkont fkkvkp~stdbk
      "fkkvkp~zahlkond
INTO (ls_sales_order_header-partn_numb,
ls_sales_order_header-fkk_conacct, lv_bukrs )
      ",ls_sales_order_header-pmnttrms )
FROM ever AS ever
INNER JOIN fkkvkp AS fkkvkp
ON fkkvkp~vkont EQ ever~vkonto
WHERE ever~anlage  EQ lv_anlage
AND   ever~einzdat LE iv_date
AND   ever~auszdat GE iv_date.
    IF sy-subrc NE 0.
      ev_error = 'X'.
      EXIT.
    ENDIF.
  ELSE.
    ev_error = 'X'.
    EXIT.
  ENDIF.

* Récupération des dates de document et de prix en en-tête
  IF lv_ko IS INITIAL.
    ls_sales_order_header-doc_date = sy-datum.
    ls_sales_order_header-price_date = sy-datum.
    ls_sales_order_header-doc_type = 'ZPRE'.
    ls_sales_order_header-purch_no_c = iv_pce_num.
    ls_sales_order_header-req_date_h = iv_date.
    "ls_sales_order_header-id_demande_intern = ls_temp_fxx-num_dossier.
    ls_sales_order_header-bill_date = sy-datum.
    INSERT ls_sales_order_header INTO TABLE lt_sales_order_header.

  ENDIF.

  IF lv_ko IS INITIAL.


*Gestion des items
    lv_posnr = lv_posnr + 10.
    ls_sales_order_item-posnr = lv_posnr.
    "          CONCATENATE 'D' ls_temp_fxx-id_art INTO lv_temp_matnr.
    lv_temp_matnr = lv_art_sd_remise_multi.
    ls_sales_order_item-matnr = lv_temp_matnr.
    ls_sales_order_item-bstdk = iv_date.

    ls_sales_order_item-bstdk_e = iv_date.

    "  ls_sales_order_item-kbetr = ls_temp_fxx-montant_ht_frais .
    ls_sales_order_item-waers = 'EUR'.

**Ajout de la gestion des dates :

*        IF ls_temp_fxx-code_debit_credit EQ 'Y'.
*          " Poste des notes de débit
*          ls_sales_order_item-kschl = 'ZPRE'.
*          APPEND ls_sales_order_item TO lt_debit_note_item.
*
*        ELSEIF ls_temp_fxx-code_debit_credit EQ 'Z'.
    "Poste des notes de crédit

    "    ls_sales_order_item-kschl = 'ZPRC'.
    APPEND ls_sales_order_item TO lt_credit_note_item.

*        ENDIF.

  ENDIF. "lv ko is intial
  "MFO  ENDLOOP.

****************************************************
*******Etape n°5 : Création d’une note de crédit*******
****************************************************

  LOOP AT lt_credit_note_item INTO ls_sales_order_item.
    INSERT ls_sales_order_item INTO TABLE lt_credit_note_item_tmp.

    READ TABLE lt_sales_order_header INTO ls_sales_order_header WITH
KEY id_demande_intern = ls_sales_order_item-id_demande_intern.
    AT END OF id_demande_intern.
      IF  ls_sales_order_header IS NOT INITIAL.
        CALL METHOD zcl_tool=>create_sales_order
          EXPORTING
            is_sales_order_header = ls_sales_order_header
            it_sales_order_item   = lt_credit_note_item_tmp
            iv_spart              = lv_sparte
            iv_societe_div        = lv_bukrs
          IMPORTING
            et_return             = lt_return
          RECEIVING
            ev_vbeln              = lv_vbeln.

        IF lv_vbeln IS NOT INITIAL.

          MESSAGE i167(zintf_e_messages) WITH lv_vbeln
                                INTO ev_message.
        ELSE.

          READ TABLE lt_return INTO ls_return WITH KEY type = 'E'.
          "fxx : &1 &2 &3 &4

          MESSAGE ID ls_return-id
                  TYPE ls_return-type
                  NUMBER ls_return-number
                  INTO ev_message
                  WITH ls_return-message_v1
                       ls_return-message_v2
                       ls_return-message_v3
                       ls_return-message_v3.
*          MESSAGE e158(zintf_e_messages) WITH
*ls_return-message INTO ev_message.
          ev_error = 'X'.

          EXIT.

        ENDIF.

        CLEAR lt_credit_note_item_tmp.
      ENDIF.

    ENDAT.
  ENDLOOP.

  COMMIT WORK AND WAIT.

ENDFUNCTION.
