FUNCTION zintf_g_ctrl_rlv_post .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
  TYPES:
    BEGIN OF ty_annul,
      equnr    TYPE equnr,
      ablbelnr TYPE ablbelnr,
      adatsoll TYPE adatsoll,
      ablesgr  TYPE ablesgr,
    END OF ty_annul.

  DATA:
    lv_field            TYPE string,
    lv_int_ui           TYPE int_ui,
    lv_anlage           TYPE anlage,
    lv_anlage_processed TYPE anlage,
    ls_object           TYPE eedm_isu_objects,
    lt_anlage           TYPE isu_t_eanlkey_h,
    lv_instdata         TYPE isu2a_instdata,
    lt_idispdata        TYPE isu_bi_inst_dispdata_tab,
    ls_idispdata        TYPE isu_bi_inst_dispdata,
    lt_iabl             TYPE isu_bi_inst_eabl_disp_tab,
    ls_iabl             TYPE isu_bi_inst_eabl_disp,
    lt_insttab          TYPE isu17_meterdocu_insttab,
    ls_insttab          TYPE isu17_meterdocu_inst,
    ls_obj              TYPE isu17_meterread,
    ls_eabl             TYPE eabl,
    lt_annul            TYPE TABLE OF ty_annul,
    ls_annul            TYPE ty_annul,
    lv_message          TYPE char255.

  FIELD-SYMBOLS:
    <fs_emetteur>,
    <fs_flux>,
    <fs_idenreg>,
    <fs_num_pce>,
    <fs_date_releve>,
    <fs_type>, <fs_raison>. "++GE-2200

  DEFINE macro_add_message_to_log.
    ev_etape = 2.
    MESSAGE &1(zintf_g_messages)
       WITH <fs_emetteur>
            <fs_flux>
            <fs_idenreg>
            &2
       INTO lv_message.
    RETURN.
  END-OF-DEFINITION.

  ev_etape = 1.

  CLEAR: lv_field.
  MOVE 'FLUX-EMETTEUR'     TO lv_field.
  ASSIGN (lv_field)        TO <fs_emetteur>.

  CLEAR: lv_field.
  MOVE 'FLUX-FLUX'         TO lv_field.
  ASSIGN (lv_field)        TO <fs_flux>.

  CLEAR: lv_field.
  MOVE 'FLUX-IDENREG'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_idenreg>.

  CLEAR: lv_field.
  MOVE 'FLUX-NUM_PCE'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_num_pce>.

*++ STOU DEBUT GE-2200
  CLEAR: lv_field.
  MOVE 'FLUX-TYPE_RELEVE' TO lv_field.
  ASSIGN (lv_field) TO <fs_type>.

  CLEAR: lv_field.
  MOVE 'FLUX-RAISON_RELEVE' TO lv_field.
  ASSIGN (lv_field) TO <fs_raison>.

*-- STOU DEBUT GE-2204
*  IF <fs_flux> = 'RE6M' AND <fs_raison> IS ASSIGNED AND <fs_type> IS ASSIGNED .
*    IF <fs_raison> = '87' AND <fs_type> = 'S'.
*      CLEAR: lv_field.
*      MOVE 'FLUX-FIN_PERIODE' TO lv_field.
*      ASSIGN (lv_field) TO <fs_date_releve>.
*    ELSE.
*      CLEAR: lv_field.
*      MOVE 'FLUX-DATE_RELEVE' TO lv_field.
*      ASSIGN (lv_field) TO <fs_date_releve>.
*    ENDIF.
*  ELSE.
*    CLEAR: lv_field.
*    MOVE 'FLUX-DATE_RELEVE' TO lv_field.
*    ASSIGN (lv_field) TO <fs_date_releve>.
*  ENDIF.
*-- STOU FIN   GE-2204

  CLEAR: lv_field.
  MOVE 'FLUX-DATE_RELEVE'                 TO lv_field.
  ASSIGN (lv_field)                       TO <fs_date_releve>.

*++ STOU FIN   GE-2200


* Récupération du PCE
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).

  IF lv_int_ui IS INITIAL.
    IF 1 = 2. MESSAGE e240(zintf_g_messages). ENDIF.
*   &1 - &2 - &3 : PCE &4 inconnu
    macro_add_message_to_log e240 <fs_num_pce>.
  ENDIF.

* Récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.

  IF ls_object-installation IS INITIAL.
    IF 1 = 2. MESSAGE e241(zintf_g_messages). ENDIF.
*   &1 - &2 - &3 : Aucune installation trouvée pour le PCE &4
    macro_add_message_to_log e241 <fs_num_pce>.
  ENDIF.

  lv_anlage = ls_object-installation.

  CLEAR lv_anlage_processed.
  GET PARAMETER ID 'BILLPROCESS' FIELD lv_anlage_processed.

  IF lv_anlage_processed EQ lv_anlage.
* l'annulation avec ajustement des documents de facturation
* a été exécutée précédemment pour l'installation,
* il n'est donc pas nécessaire de poursuivre le traitement
    CLEAR lv_anlage_processed.
    SET PARAMETER ID 'BILLPROCESS' FIELD lv_anlage_processed.
    RETURN.
  ENDIF.

  INSERT lv_anlage INTO TABLE lt_anlage.

* Recherche des informations nécessaires aux différentes annulations
  CALL FUNCTION 'ISU_INST_BIVIEW_SELECT'
    EXPORTING
      x_ab         = <fs_date_releve>
      x_ianlkey    = lt_anlage
    IMPORTING
      y_instdata   = lv_instdata
    CHANGING
      xy_idispdata = lt_idispdata.

  CLEAR ls_idispdata.
  READ TABLE lt_idispdata
        INTO ls_idispdata WITH KEY anlage = lv_anlage.

* Contrôle s'il existe bien des documents de calcul de facturation
  CHECK ls_idispdata-iabl[] IS NOT INITIAL.

  LOOP AT ls_idispdata-iabl INTO ls_iabl.
    CLEAR ls_eabl.
    SELECT SINGLE *
      FROM eabl
      INTO ls_eabl
     WHERE ablbelnr EQ ls_iabl-ablbelnr.

*    IF ls_eabl-adatsoll GE <fs_date_releve>.
    IF ls_eabl-adattats GE <fs_date_releve>.
      CLEAR ls_annul.
      ls_annul-equnr    = ls_eabl-equnr.
      ls_annul-ablbelnr = ls_eabl-ablbelnr.
      ls_annul-adatsoll = ls_eabl-adatsoll.
      ls_annul-ablesgr  = ls_iabl-ablesgr.
      APPEND ls_annul TO lt_annul.
    ENDIF.
  ENDLOOP.

  CHECK lt_annul[] IS NOT INITIAL.

* Suppression des ordres de calcul de facturation et de relève
* en se basant sur la table EABL des documents de relevé pour cadrans à index
  LOOP AT lt_annul INTO ls_annul.
* Alimentation table interne pour appel module fonction
    CLEAR: lt_insttab[], ls_insttab.
    ls_insttab-anlage  = lv_anlage.
    ls_insttab-ablesgr = ls_annul-ablesgr.
    APPEND ls_insttab TO lt_insttab.

* Ouverture de l'objet relève
    CALL FUNCTION 'ISU_O_METERREAD_OPEN'
      EXPORTING
        x_anlage              = lv_anlage
        x_equnr               = ls_annul-equnr
        x_adatsoll            = ls_annul-adatsoll
        x_ablbelnr            = ls_annul-ablbelnr
        x_ablesgr             = ls_annul-ablesgr
        x_select2             = '5' "Ordres de relève et relevés
        x_wmode               = '6' "Annulation
        x_no_dialog           = 'X'
        x_upd_online          = 'X'
        x_no_enqueue          = 'X'
      IMPORTING
        y_obj                 = ls_obj
      TABLES
        xt_insttab            = lt_insttab
      EXCEPTIONS
        not_found             = 1
        foreign_lock          = 2
        internal_error        = 3
        input_error           = 4
        existing              = 5
        number_error          = 6
        general_fault         = 7
        system_error          = 8
        manual_abort          = 9
        gasdat_not_found      = 10
        no_mrrel_registers    = 11
        internal_warning      = 12
        not_authorized        = 13
        not_qualified         = 14
        anpstorno_not_allowed = 15
        already_billed        = 16
        OTHERS                = 99.

    IF NOT sy-subrc IS INITIAL.
      IF 1 = 2. MESSAGE e247(zintf_g_messages). ENDIF.
* &1 - &2 - &3 : Annulation document de relève &4 impossible
      macro_add_message_to_log e247 ls_annul-ablbelnr.
    ENDIF.

* Préparation de l'annulation des ordres de relevés et des documents de relèves
    CALL FUNCTION 'ISU_O_METERREAD_ACTION'
      EXPORTING
        x_okcode             = 'PSAV'
      CHANGING
        xy_obj               = ls_obj
      EXCEPTIONS
        cancelled            = 1
        failed               = 2
        action_not_supported = 3
        system_error         = 4
        input_error          = 5
        not_customized       = 6
        OTHERS               = 99.

    IF NOT sy-subrc IS INITIAL.
      IF 1 = 2. MESSAGE e247(zintf_g_messages). ENDIF.
* &1 - &2 - &3 : Annulation document de relève &4 impossible
      macro_add_message_to_log e247 ls_annul-ablbelnr.
    ENDIF.

* Suppression des ordres de relevés, ordres de calcul de facturation
* et des résultats de relevés
    CALL FUNCTION 'ISU_O_METERREAD_ACTION'
      EXPORTING
        x_okcode             = 'SAVE'
      CHANGING
        xy_obj               = ls_obj
      EXCEPTIONS
        cancelled            = 1
        failed               = 2
        action_not_supported = 3
        system_error         = 4
        input_error          = 5
        not_customized       = 6
        OTHERS               = 99.

    IF NOT sy-subrc IS INITIAL.
      IF 1 = 2. MESSAGE e247(zintf_g_messages). ENDIF.
* &1 - &2 - &3 : Annulation document de relève &4 impossible
      macro_add_message_to_log e247 ls_annul-ablbelnr.
    ELSE.
*      COMMIT WORK AND WAIT.
    ENDIF.
  ENDLOOP.
ENDFUNCTION.
