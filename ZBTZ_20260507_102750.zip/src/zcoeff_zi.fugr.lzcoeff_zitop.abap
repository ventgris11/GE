* regenerated at 25.03.2019 09:29:33
FUNCTION-POOL ZCOEFF_ZI                  MESSAGE-ID SV.

* INCLUDE LZCOEFF_ZID...                     " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCOEFF_ZIT00                           . "view rel. data dcl.
