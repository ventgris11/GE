*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 04.04.2019 at 10:47:44
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZCRMC_DEMAT.....................................*
DATA:  BEGIN OF STATUS_ZCRMC_DEMAT                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCRMC_DEMAT                   .
CONTROLS: TCTRL_ZCRMC_DEMAT
            TYPE TABLEVIEW USING SCREEN '0007'.
*.........table declarations:.................................*
TABLES: *ZCRMC_DEMAT                   .
TABLES: ZCRMC_DEMAT                    .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
