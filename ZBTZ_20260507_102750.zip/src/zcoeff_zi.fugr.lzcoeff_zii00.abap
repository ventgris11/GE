*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 25.03.2019 at 09:29:33
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
