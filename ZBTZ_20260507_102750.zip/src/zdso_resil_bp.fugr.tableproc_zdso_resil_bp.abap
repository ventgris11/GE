*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDSO_RESIL_BP
*   generation date: 21.04.2019 at 16:50:39
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDSO_RESIL_BP       .

  PERFORM TABLEPROC.

ENDFUNCTION.
