FUNCTION-POOL ZFKMB MESSAGE-ID >3.

* The following ABAP include contains the counters for
* the dunning proposal
INCLUDE fkk_dunning_counters.

TYPES:
  t_dfkkop         TYPE TABLE OF dfkkop,
  t_fkkmavs        TYPE TABLE OF fkkmavs.

*---------------------------------------------------------------------*
* Tabellen
*---------------------------------------------------------------------*
TABLES: fkkmako,                       "Mahnhistorie Kopf
        fkkmaze,                       "Mahnhistorie Zeilen
        fkkvkp,                        "Geschäftspartner im Konto
        dfkkmacfcsmk.                  "clarification controller Konto

* Steuertabellen
TABLES: t001,                          "Buchungskreis
        tfk047a,                       "Mahnverfahren
*        tfk047b,                       "Mahnstufen
*                       (umgestellt auf lokale Struktur)
        tfk047c,                       "Grenzbeträge
        tfk047f,                       "Mahngruppen
        tfk047s.                       "Mahnsperren

* Global table for all necessary PROIDs
DATA  gt_all_proid LIKE fkkr_proid OCCURS 4 WITH HEADER LINE.

INCLUDE lfklockcom.
INCLUDE lfkkaktiv2con.
INCLUDE lfkkaktiv2mac.

* tables for FKK_DETERMINE_DUNNING_DATA
DATA:
  i_fkkmako LIKE fkkmako OCCURS 0 WITH HEADER LINE,
  i_fkkmaze LIKE fkkmaze OCCURS 0 WITH HEADER LINE,
  i_fkkop   LIKE fkkop   OCCURS 0 WITH HEADER LINE,
  i_fkkvkp  LIKE fkkvkp  OCCURS 0 WITH HEADER LINE,
* for global memory
  n_fkkmako LIKE fkkmako OCCURS 0 WITH HEADER LINE,
  n_fkkmaze LIKE fkkmaze OCCURS 0 WITH HEADER LINE.

* offene Posten mit mahnrelevanten informationen
DATA i_fkkmavs LIKE fkkmavs OCCURS 100 WITH HEADER LINE.
* Mahngruppen
DATA i_fkkmagrp LIKE fkkmagrp OCCURS 5 WITH HEADER LINE.
* Mahnvorschlag
DATA mv_fkkmavs LIKE fkkmavs OCCURS 100 WITH HEADER LINE.
* In den offenen Posten enthaltenen Mahnstufen mit Mahnbetrag
* This table is used for checking the amount of a dunning level
* against then limit.
TYPES mahnst_tab_struc LIKE fkk_mahnst.
TYPES mahnst_tab_type TYPE mahnst_tab_struc OCCURS 10.

* Uebergabe der Meldungen fuer das Protokoll
DATA  t_fimsg LIKE fimsg OCCURS 1 WITH HEADER LINE.

DATA  akt_mahnd LIKE fkkmako-laufd.
DATA  akt_waers LIKE fkkmako-waers.
* tables for FKK_DETERMINE_DUNNING_HISTORY
DATA: gsber LIKE fkkmako-gsber,
      mahnv LIKE fkkmako-mahnv,
      mgrup LIKE fkkmako-mgrup,
      opbuk LIKE fkkmako-opbuk,
      abwma LIKE fkkmako-abwma,
      waers LIKE fkkmako-waers,
      vkont LIKE fkkmako-vkont,
      spart LIKE fkkmako-spart,
      vtref_subap type char21,
      stakz LIKE fkkmako-stakz,
      strat LIKE fkkmako-strat,            " Note 1497366
      first_entry.

* function module tables for events
DATA: t_fbstab_0303 LIKE tfkfbc OCCURS 0 WITH HEADER LINE,
      t_fbstab_0304 LIKE tfkfbc OCCURS 0 WITH HEADER LINE,
      t_fbstab_0305 LIKE tfkfbc OCCURS 0 WITH HEADER LINE,
      t_fbstab_0306 LIKE tfkfbc OCCURS 0 WITH HEADER LINE,
      t_fbstab_0307 LIKE tfkfbc OCCURS 0 WITH HEADER LINE,
      t_fbstab_0364 LIKE tfkfbc OCCURS 0 WITH HEADER LINE,
      t_fbstab_0365 LIKE tfkfbc OCCURS 0 WITH HEADER LINE,
      t_fbstab_0367 LIKE tfkfbc OCCURS 0 WITH HEADER LINE,
      t_fbstab_0368 LIKE tfkfbc OCCURS 0 WITH HEADER LINE.  "Note 1955232
DATA: t_fbstab_0312 TYPE TABLE OF tfkfbc WITH HEADER LINE,
      t_fbstab_0317 TYPE TABLE OF tfkfbc WITH HEADER LINE,
      t_fbstab_2851 TYPE TABLE OF tfkfbc WITH HEADER LINE.

* common structure for events 0300 - 0304
DATA gl_para_0300 TYPE fkkma_0300.
DATA  applk LIKE fkkma_para-applk.
* for clarification controller
DATA: i_fkkcfcslocks LIKE dfkkcfcslocks OCCURS 10 WITH HEADER LINE.
DATA  glob_tcode LIKE sy-tcode.

DATA  g_flex_dunn_active TYPE xfeld.

* Tabelle zum Merken der Mahnstatistik
DATA:
  BEGIN OF mahn_stat OCCURS 100,
    mahnv LIKE fkkmako-mahnv,
    mahns LIKE fkkmako-mahns,
    step  like fkkmako-step,
    waers LIKE fkkmako-waers,
    msalm LIKE fkkmako-msalm,
    mge1m LIKE fkkmako-mge1m,
    mge2m LIKE fkkmako-mge2m,
    mge3m LIKE fkkmako-mge3m,
    anzahl TYPE p,
  END OF mahn_stat.

DATA: g_local_waers LIKE t001-waers,
      g_local_bukrs LIKE t001-bukrs.
* Table which contains all HVORG/TVORG which have an "additional
* receivable rule":
DATA gt_tfktvo_rladdr LIKE tfktvo OCCURS 10 WITH HEADER LINE.
*
TYPES: BEGIN OF fkkop_struc,
        opbel LIKE fkkop-opbel,
        opupw LIKE fkkop-opupw,
        opupk LIKE fkkop-opupk,
        opupz LIKE fkkop-opupz,
        orupz LIKE fkkop-orupz,
        betrw LIKE fkkop-betrw,
        waers LIKE fkkop-waers,
        augbl LIKE fkkop-augbl,
   END OF fkkop_struc.
