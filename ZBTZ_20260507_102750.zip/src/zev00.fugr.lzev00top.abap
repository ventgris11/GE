FUNCTION-POOL ZEV00.                    "MESSAGE-ID ..

INCLUDE IEVARDAT.
INCLUDE IEAPRCCO.
INCLUDE IEAPERTYP.
* >>>>> note 913701
* additional type definition for changing of price category in
* QUANTI01, QUANTI11 and QUANTI21
  types: begin of pcat_ts,
           ab        type ABZEITSCH,
           bis       type BISZEITSCH,
           preisart  type E_PREISART,
           add_new   type ISU2A_PACK16,
           add_old   type ISU2A_PACK16,
           t_iprei   type ISU2A_IPREI,
         end of pcat_ts.
  types: ipcat_ts type table of pcat_ts.
* <<<<< note 913701
DATA l_badi_error TYPE REF TO cx_badi_initial_reference.    "n1566024
