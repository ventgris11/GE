*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 28.09.2020 at 18:53:35
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
