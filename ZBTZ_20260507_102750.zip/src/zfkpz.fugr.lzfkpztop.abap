FUNCTION-POOL ZFKPZ MESSAGE-ID >2.

*-----------------------------------------------------------------------
*        database tables
*-----------------------------------------------------------------------
TABLES: BNKA,
        CCARD,
        T001,
        T005,
        *T005,
        T012,
        T012K,
        TB035T,
        TFK001B,
        TFK042B,
        TFK042E,
        TFK042H,
        TFK042W,
        TFK042Z,
        TFK042ZA,
        TFK042ZT,
        T042P.

*-----------------------------------------------------------------------
*        structures from ddic
*-----------------------------------------------------------------------
TABLES: BUS000_EXT,
        BUS0BK,
        FIMSG,
        FKK001,
        FKK042Z,
        FKKPY_0650_PAYMENT_DATA,
        FKKPY_0650_RESULT, *FKKPY_0650_RESULT,
        X001.

*-----------------------------------------------------------------------
*        types
*-----------------------------------------------------------------------
TYPES:  BEGIN OF IMP,
          OPBUK       LIKE FKKVKP-OPBUK,
          PYBUK       TYPE PYBUK_KK,
          BUKRS       TYPE BUKRS,
          LAND1       TYPE LAND1,
          GPART       TYPE GPART_KK,
          VKONT       TYPE VKONT_KK,
          WAERS       LIKE FKKOP-WAERS,
          RWBTR       LIKE FKKCL-NAUGW,
          RBETR       LIKE FKKOP-BETRH,
          RPOST       LIKE PAYH-RPOST,
          RTEXT       LIKE PAYH-RTEXT,
          CHKAM       LIKE BOOLE-BOOLE,
          CHSIG       TYPE XFELD,
          CHKHB       LIKE BOOLE-BOOLE,
          BUDAT       LIKE FKKPY_PARA-BUDAT,
          APPLK       LIKE FKKPY_PARA-APPLK,
          EIGBV       LIKE FKKVKP-EIGBV,
          NOADR       LIKE BOOLE-BOOLE,
          CCINS       TYPE CCINS_KK,
          LFDNR       TYPE LFDNR_PAY,
          SRT1        TYPE FKKPY_SRT1,
          OPC         TYPE DFKKOPC,
          MNDID       TYPE SEPA_MNDID,
          XSIMU       TYPE XFELD,
        END   OF IMP.

TYPES:  ZWELS(30)     TYPE C.

TYPES:  BEGIN OF PBANK.
          INCLUDE STRUCTURE BUS0BK.
TYPES:    XPGRO       LIKE BNKA-XPGRO,
          BGRUP       LIKE BNKA-BGRUP,
          PSKTO       LIKE BNKA-PSKTO,
          BNKA        LIKE BNKA,
          TMPIBAN     TYPE IBAN,    "do not conflict with BUT0BK-IBAN
          SEPA_PMS    TYPE FKK_SEPA_PMS,
        END OF PBANK.

TYPES:  BEGIN OF HBANK,
          RANGF       LIKE TFK042A-RANGF,
          HBKID       LIKE T012K-HBKID,
          HKTID       LIKE T012K-HKTID,
          BGRUP       LIKE BNKA-BGRUP,
          BNKA        LIKE BNKA,
          T012        LIKE T012,
          T012K       LIKE T012K,
        END OF HBANK.

*-----------------------------------------------------------------------
*        internal tables with ddic reference
*-----------------------------------------------------------------------
DATA:   PYBTAB        LIKE FKKPYBUK    OCCURS 0 WITH HEADER LINE.

DATA:   T_0650IT      LIKE FKKPY_0650  OCCURS 0 WITH HEADER LINE,
                                       "cleared items (imported table)
        T_BUS0BK      LIKE BUS0BK      OCCURS 0 WITH HEADER LINE,
                                       "partner banks (imported table)
        T_BUSIBAN     LIKE TIBAN       OCCURS 0 WITH HEADER LINE,
                                       "IBAN of partner banks (imported table)
        T_BUS0CC      LIKE BUS0CC      OCCURS 0 WITH HEADER LINE,
                                       "card data     (imported table)
        T_HBANK       TYPE HBANK       OCCURS 0 WITH HEADER LINE,
                                       "house banks with master record
        T_HBANK_SAVE  TYPE HBANK       OCCURS 0 WITH HEADER LINE,
                                       "house banks with master record
        T_HBANK_0650  TYPE FKKPY_0650_HOUSE_BANK_DATA_T,
                                       "house banks
        T_ITEMS_0650  LIKE FKKPY_0650  OCCURS 0 WITH HEADER LINE,
                                       "cleared items (imported table)
        T_PBANK_ALL   TYPE PBANK       OCCURS 0 WITH HEADER LINE,
                                       "partner banks with master record
        T_PBANK       TYPE PBANK       OCCURS 0 WITH HEADER LINE,
                                       "partner banks, ok for paym.meth.
        T_PBANK_0650  TYPE FKKPY_0650_PARTNER_BANK_T,
                                       "partner banks, ok, for 0650
        T_TFKFBC      LIKE TFKFBC      OCCURS 0 WITH HEADER LINE,
                                       "function modules (in TFKFBM/S/C)
        T_TFK042A     LIKE TFK042A     OCCURS 0 WITH HEADER LINE,
                                       "bank selection
        T_TFK042E     LIKE TFK042E     OCCURS 0 WITH HEADER LINE,
                                       "memory for table TFK042E
        T_TFK042W     LIKE TFK042W     OCCURS 0 WITH HEADER LINE,
                                       "allowed currencies (actual)
        T_TFK042W_ALL LIKE TFK042W     OCCURS 0 WITH HEADER LINE,
                                       "allowed currencies (memory)
        T_FKK042Z     LIKE FKK042Z     OCCURS 0 WITH HEADER LINE,
                                       "memory for table TFK042Z
        T_FKK042Z_X   LIKE FKK042Z     OCCURS 0 WITH HEADER LINE,
                                       "memory for ebpp
        T_FKK042Z_R   LIKE FKK042Z     OCCURS 0 WITH HEADER LINE.
                                       "result of FKK_PAYMENT_METHOD_F4

*-----------------------------------------------------------------------
*        internal tables without ddic reference
*-----------------------------------------------------------------------
DATA:   BEGIN OF T_BNKA_BUF            OCCURS 0.
          INCLUDE STRUCTURE BNKA.
DATA:     COUNT(8) TYPE N.
DATA:   END   OF T_BNKA_BUF.

* payment methods with direct debit announcements (only GB)
DATA:   BEGIN OF T_DDAN_B OCCURS 2,
          BUKRS       LIKE FKKOP-BUKRS,
          PYMET       LIKE FKKOP-PYMET,
          XDDAN       LIKE BOOLE-BOOLE,
          DDATY       LIKE TFK042Z-DDATY,
        END   OF T_DDAN_B.
DATA:   BEGIN OF T_DDAN_L OCCURS 2,
          LAND1       LIKE TFK042Z-LAND1,
          PYMET       LIKE FKKOP-PYMET,
          XDDAN       LIKE BOOLE-BOOLE,
          DDATY       LIKE TFK042Z-DDATY,
        END   OF T_DDAN_L.

* RTP buffer
DATA:   BEGIN OF T_RTP OCCURS 2,
          LAND1       LIKE TFK042Z-LAND1,
          PYMET       LIKE FKKOP-PYMET,
          RTPTY       TYPE RTPTY_KK,
        END   OF T_RTP.

* payment methods for ebpp (billerdirect)
DATA:   BEGIN OF T_EBPP_B OCCURS 2,
          BUKRS       LIKE FKKOP-BUKRS,
          PYMET       LIKE FKKOP-PYMET,
          XEBPP       LIKE BOOLE-BOOLE,
        END   OF T_EBPP_B.
DATA:   BEGIN OF T_EBPP_L OCCURS 2,
          LAND1       LIKE TFK042Z-LAND1,
          PYMET       LIKE FKKOP-PYMET,
          XEBPP       LIKE BOOLE-BOOLE,
        END   OF T_EBPP_L.

* payment methods for esr (only CH)
DATA:   BEGIN OF T_ESR_B OCCURS 2,
          BUKRS       LIKE FKKOP-BUKRS,
          PYMET       LIKE FKKOP-PYMET,
          XESRD       LIKE BOOLE-BOOLE,
        END   OF T_ESR_B.
DATA:   BEGIN OF T_ESR_L OCCURS 2,
          LAND1       LIKE TFK042Z-LAND1,
          PYMET       LIKE FKKOP-PYMET,
          XESRD       LIKE BOOLE-BOOLE,
        END   OF T_ESR_L.

DATA:   BEGIN OF T_F4 OCCURS 0,        "help table for F4
          ZLSCH       LIKE FKK042Z-ZLSCH,
          TEXT1       LIKE FKK042Z-TEXT1,
          XEINZ       LIKE FKK042Z-XEINZ,
          XSELE       LIKE BOOLE-BOOLE,
          PRIOR       LIKE SY-INDEX,
        END OF T_F4.

*-----------------------------------------------------------------------
*        structures with ddic reference
*-----------------------------------------------------------------------
DATA:   BNKA_BUS      LIKE BNKA,       "bank data of partner bank
        BNKA_HB       LIKE BNKA,           "bank data of house bank
        MAD_BASICS    TYPE FKK_MAD_BASICS. "mass activity data

*-----------------------------------------------------------------------
*        structures without ddic reference
*-----------------------------------------------------------------------
DATA:   IMPORT        TYPE IMP,
        IMPORT_SAV    TYPE IMP.

*-----------------------------------------------------------------------
*        single fields
*-----------------------------------------------------------------------
DATA:   H_0650_ACTIVE LIKE BOOLE-BOOLE,          "event 0650 active?
        H_CALC(16)    TYPE P,
        H_INDEX       LIKE SY-INDEX,
        H_LENGTH      LIKE SY-FDPOS,
        H_MSGNO       LIKE SY-MSGNO,
        H_NUM04       LIKE FKKPY_0650_RESULT-STANDARD,
        H_OFFSET      LIKE SY-INDEX,
        H_PRIOR(2)    TYPE N,
        H_PSTLZ       LIKE BUS000_EXT-POST_CODE1,
        H_PYBUK       TYPE PYBUK_KK,
        H_ZLSCH       LIKE T042Z-ZLSCH,
        H_ZWELS_ACC   TYPE ZWELS,      "local memory of FKK..INTERSECT
        H_ZWELS_EXP   TYPE ZWELS,                           "
        H_ZWELS_PAR   LIKE FKKPY_PARA-ZWELS,                "
        H_ZWELS_RNG   TYPE ZWELS,      "local memory of FKK..RANGE
        H_42A_WAERS   LIKE T042A-WAERS,"local memory of READ_HOUSE_BANK
        H_42A_ZBUKR   LIKE T042A-ZBUKR,                     "
        H_42A_ZLSCH   LIKE T042A-ZLSCH.                     "

DATA:   MSGID         LIKE SY-MSGID,
        MSGV1         LIKE SY-MSGV1,
        MSGV2         LIKE SY-MSGV2,
        MSGV3         LIKE SY-MSGV3,
        MSGV4         LIKE SY-MSGV4.

DATA:   OK_CODE(4)    TYPE C.

DATA:   RCODE         LIKE SY-SUBRC.

DATA:   STEPL         LIKE SY-STEPL,
        SUBRC         LIKE SY-SUBRC.

DATA:   TFILL         LIKE SY-TFILL.

DATA:   XDISPLAY      LIKE BOOLE-BOOLE,
        XNOPOPUP      LIKE BOOLE-BOOLE,
        XPRIOR        LIKE BOOLE-BOOLE,
        XSIGN         LIKE BOOLE-BOOLE.

*-----------------------------------------------------------------------
*        ranges
*-----------------------------------------------------------------------
RANGES: R_ZLSCH       FOR  T042Z-ZLSCH.

*-----------------------------------------------------------------------
*        icons
*-----------------------------------------------------------------------

*-----------------------------------------------------------------------
*        field-symbols
*-----------------------------------------------------------------------

*-----------------------------------------------------------------------
*        includes
*-----------------------------------------------------------------------
INCLUDE LFKZ8COM.                   "direct debit announcements in GB
INCLUDE LFKIPCOM.                   "payment disposition

*-----------------------------------------------------------------------
*        controls / tabstrips / subscreens
*-----------------------------------------------------------------------
