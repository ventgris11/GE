*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 03.04.2019 at 18:10:39
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
