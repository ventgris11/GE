* regenerated at 17.04.2019 18:21:36
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZBTZTOP.                          " Global Data
  INCLUDE LZBTZUXX.                          " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZBTZF...                          " Subroutines
* INCLUDE LZBTZO...                          " PBO-Modules
* INCLUDE LZBTZI...                          " PAI-Modules
* INCLUDE LZBTZE...                          " Events
* INCLUDE LZBTZP...                          " Local class implement.
* INCLUDE LZBTZT99.                          " ABAP Unit tests
  INCLUDE LZBTZF00                                . " subprograms
  INCLUDE LZBTZI00                                . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
