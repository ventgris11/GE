FUNCTION ZINTF_G_CTRL_RLV_DEPOSE .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA: lc_field_raison_rlv TYPE fieldname VALUE 'RAISON_RELEVE',
        lv_field            TYPE string,
        lv_int_ui           TYPE int_ui
        .
  CONSTANTS:
    lc_raison_61 TYPE char2 VALUE '61', "Changement de compteur (dépose)
    lc_raison_62 TYPE char2 VALUE '62' "Changement de compteur (pose)
    .


  FIELD-SYMBOLS: <fs>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_raison_rlv INTO lv_field.
  ASSIGN (lv_field) TO <fs>.

  IF <fs> IS ASSIGNED.
    " On vérifie si la rélève est une relève de dépose
    IF  <fs> EQ lc_raison_61 .
      ev_etape = 1.
    ELSE.
      ev_etape = 2.
    ENDIF.
  ELSE.
    "Erreur technique
  ENDIF.

ENDFUNCTION.
