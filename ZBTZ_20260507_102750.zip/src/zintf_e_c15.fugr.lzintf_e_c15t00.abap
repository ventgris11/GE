*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 02.10.2020 at 14:54:39
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZINTF_E_C15.....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_C15                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_C15                   .
CONTROLS: TCTRL_ZINTF_E_C15
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZINTF_E_C15                   .
TABLES: ZINTF_E_C15                    .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
