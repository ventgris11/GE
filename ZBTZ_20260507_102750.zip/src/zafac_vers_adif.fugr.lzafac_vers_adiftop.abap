* regenerated at 20.02.2019 16:37:18
FUNCTION-POOL ZAFAC_VERS_ADIF            MESSAGE-ID SV.

* INCLUDE LZAFAC_VERS_ADIFD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZAFAC_VERS_ADIFT00                     . "view rel. data dcl.
