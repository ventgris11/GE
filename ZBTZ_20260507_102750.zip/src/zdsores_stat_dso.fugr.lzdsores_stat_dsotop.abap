* regenerated at 03.04.2019 15:42:03
FUNCTION-POOL ZDSORES_STAT_DSO           MESSAGE-ID SV.

* INCLUDE LZDSORES_STAT_DSOD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDSORES_STAT_DSOT00                    . "view rel. data dcl.
