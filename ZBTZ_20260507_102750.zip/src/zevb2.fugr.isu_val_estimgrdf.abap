FUNCTION isu_val_estimgrdf.
*"--------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(X_TE327) LIKE  TE327 STRUCTURE  TE327
*"  CHANGING
*"     REFERENCE(XY_OBJ) TYPE  ISU2A_BILLING_DATA
*"     REFERENCE(XY_OUTCNSO) LIKE  ERCHO-OUTCNSO
*"  EXCEPTIONS
*"      GENERAL_FAULT
*"--------------------------------------------------------------------
  DATA: werchz    LIKE erchz,
        nettobtr  LIKE erchz-nettobtr,
        outsorted TYPE c,
        deviation LIKE ercho-deviation.

  LOOP AT xy_obj-bill-ierchz INTO werchz
          WHERE ( belzart = 'XCM3' AND abslkz = ''
          AND ( ablesgr = '14' OR ablesgrv = '14' OR ablesgr = '09' )
          AND ( istablart = 'Z4' OR istablartva = 'Z4' )
          AND ablhinw = 'Z4' )

          OR

          ( belzart = 'XCM3' AND abslkz = '' AND  ablesgr = '14'
          AND ablesgrv = '14' AND ablhinw = 'Z4' ).
    EXIT.
  ENDLOOP.

  IF sy-subrc = 0.
    outsorted = 'X'.
  ENDIF.

  IF NOT outsorted IS INITIAL.
    CALL FUNCTION 'ISU_OUTSORT_IERCHO_WRITE'
      EXPORTING
        x_validation = x_te327-validation
        x_deviation  = deviation
      CHANGING
        xy_iercho    = xy_obj-bill-iercho
        xy_outcnso   = xy_outcnso.
  ENDIF.
ENDFUNCTION.
