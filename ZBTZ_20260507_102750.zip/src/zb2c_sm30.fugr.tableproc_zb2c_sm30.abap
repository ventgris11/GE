*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZB2C_SM30
*   generation date: 23.08.2017 at 07:55:14
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZB2C_SM30           .

  PERFORM TABLEPROC.

ENDFUNCTION.
