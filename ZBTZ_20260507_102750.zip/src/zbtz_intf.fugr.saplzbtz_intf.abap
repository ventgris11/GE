*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZBTZ_INTFTOP.                     " Global Data
  INCLUDE LZBTZ_INTFUXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZBTZ_INTFF...                     " Subroutines
* INCLUDE LZBTZ_INTFO...                     " PBO-Modules
* INCLUDE LZBTZ_INTFI...                     " PAI-Modules
* INCLUDE LZBTZ_INTFE...                     " Events
* INCLUDE LZBTZ_INTFP...                     " Local class implement.
* INCLUDE LZBTZ_INTFT99.                     " ABAP Unit tests

INCLUDE LZBTZ_INTFF01.
