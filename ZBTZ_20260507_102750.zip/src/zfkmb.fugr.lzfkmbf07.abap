*&---------------------------------------------------------------------*
*&  Include           LFKMBF07                                         *
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  GET_LOCAL_CURRENCY
*&---------------------------------------------------------------------*
FORM get_local_currency USING    p_bukrs       LIKE t001-bukrs
                        CHANGING p_local_waers LIKE t001-waers
                                 p_local_bukrs LIKE t001-bukrs.

  STATICS: s_bukrs LIKE t001-bukrs,
           s_waers LIKE t001-waers.

  IF p_bukrs = s_bukrs.
    p_local_waers = s_waers.
  ELSE.
    SELECT SINGLE waers INTO p_local_waers FROM t001
                        WHERE bukrs = p_bukrs.
    s_bukrs = p_bukrs.
    s_waers = p_local_waers.
  ENDIF.
* Merke den Buchungskreis, fuer den diese FORM gerufen wurde
  p_local_bukrs = p_bukrs.

ENDFORM.                               " GET_LOCAL_CURRENCY

*&---------------------------------------------------------------------*
*&      Form  get_range_mahnv_from_memory
*&---------------------------------------------------------------------*
FORM get_range_mahnv_from_memory CHANGING r_mahnv TYPE fkk_rt_mahnv.

  STATICS: gelesen.
  DATA: h_runkey TYPE fkk_mad_runkey.
  DATA: h_fkk_mad_mahn TYPE fkk_mad_mahn.

  IF gelesen IS INITIAL.
    CALL FUNCTION 'FKK_AKTIV2_RUN_KEY_CONSTRUCT'
      EXPORTING
        i_aktyp  = gl_para_0300-aktyp
        i_laufd  = gl_para_0300-laufd
        i_laufi  = gl_para_0300-laufi
      IMPORTING
        e_runkey = h_runkey.
    IMPORT addons TO h_fkk_mad_mahn FROM DATABASE rfdt(kk) ID h_runkey. "#EC ENHOK

    r_mahnv = h_fkk_mad_mahn-r_mahnv.
    gelesen = 'X'.
  ENDIF.

ENDFORM.                               " get_range_mahnv_from_memory

*&---------------------------------------------------------------------*
*&      Form  mahnstufen_tabelle_erweitern
*&---------------------------------------------------------------------*
FORM mahnstufen_tabelle_erweitern
                           TABLES p_mahnst_tab TYPE mahnst_tab_type
                           USING  p_mahnv LIKE tfk047b-mahnv.

  DATA l_tfk047b TYPE tfk047b.

  SORT p_mahnst_tab BY xlmst DESCENDING
                     mahns DESCENDING.
  READ TABLE p_mahnst_tab INDEX 1.

  SELECT * FROM tfk047b INTO l_tfk047b
    WHERE mahnv = p_mahnv
      AND mahns LE p_mahnst_tab-mahns.

    READ TABLE p_mahnst_tab WITH KEY mahns = l_tfk047b-mahns.
    IF sy-subrc NE 0.
      CLEAR p_mahnst_tab.
      p_mahnst_tab-mahns = l_tfk047b-mahns.
      APPEND p_mahnst_tab.
    ENDIF.

  ENDSELECT.

ENDFORM.                               " mahnstufen_tabelle_erweitern
