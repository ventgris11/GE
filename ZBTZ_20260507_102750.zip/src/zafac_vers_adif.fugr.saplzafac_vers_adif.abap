* regenerated at 20.02.2019 16:37:18
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZAFAC_VERS_ADIFTOP.               " Global Data
  INCLUDE LZAFAC_VERS_ADIFUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZAFAC_VERS_ADIFF...               " Subroutines
* INCLUDE LZAFAC_VERS_ADIFO...               " PBO-Modules
* INCLUDE LZAFAC_VERS_ADIFI...               " PAI-Modules
* INCLUDE LZAFAC_VERS_ADIFE...               " Events
* INCLUDE LZAFAC_VERS_ADIFP...               " Local class implement.
* INCLUDE LZAFAC_VERS_ADIFT99.               " ABAP Unit tests
  INCLUDE LZAFAC_VERS_ADIFF00                     . " subprograms
  INCLUDE LZAFAC_VERS_ADIFI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
