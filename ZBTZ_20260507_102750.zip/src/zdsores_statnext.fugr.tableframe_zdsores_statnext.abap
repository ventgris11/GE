*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZDSORES_STATNEXT
*   generation date: 07.04.2019 at 13:51:39
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZDSORES_STATNEXT   .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.
