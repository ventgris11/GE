FUNCTION zintf_g_ctrl_pta .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
  FIELD-SYMBOLS:
    <fs_idenreg>,
    <fs_num_pce>,
    <fs_date_releve>,
    <fs_debut_periode>,
    <fs_statut>,
    <fs_message>,
    <fs_pta>,
    <fs_index_deb>,
    <fs_index_fin>.

  DATA:
    lv_field     TYPE string,
    lv_index_deb TYPE string,
    lv_index_fin TYPE string,
*    lv_statut TYPE string,
*    lv_index_fin TYPE string,
    lv_message   TYPE char255,
    lv_pta       TYPE e_factor.


  CLEAR lv_field.
  MOVE 'FLUX-IDENREG'        TO lv_field.
  ASSIGN (lv_field)          TO <fs_idenreg>.

  CLEAR lv_field.
  MOVE 'FLUX-NUM_PCE'        TO lv_field.
  ASSIGN (lv_field)          TO <fs_num_pce>.

  CLEAR: lv_field.
  MOVE 'FLUX-DATE_RELEVE'                 TO lv_field.
  ASSIGN (lv_field)                       TO <fs_date_releve>.

  CLEAR lv_field.
  MOVE 'FLUX-DEBUT_PERIODE'  TO lv_field.
  ASSIGN (lv_field)          TO <fs_debut_periode>.

  CLEAR lv_field.
  MOVE 'FLUX-PTA'            TO lv_field.
  ASSIGN (lv_field)          TO <fs_pta>.

  ev_etape = 1.

* Si date début de période non renseignée,
* aucune mise à jour des valeurs fixes PCS et/ou PTA
  CHECK <fs_debut_periode> IS NOT INITIAL.


  lv_pta = <fs_pta>.
*************** Mise à jour du PTA *******************************
* Si la donnée PTA est non renseignée, ne pas mettre à jour la valeur fixe PTA
  IF lv_pta IS INITIAL OR lv_pta = 0.

    CLEAR lv_field.
    MOVE 'FLUX-INDEX_BRUT_DEBUT_PERIODE'  TO lv_field.
    ASSIGN (lv_field)          TO <fs_index_deb>.

    CLEAR lv_field.
    MOVE 'FLUX-INDEX_BRUT_FIN_PERIODE'  TO lv_field.
    ASSIGN (lv_field)          TO <fs_index_fin>.


    lv_index_deb = <fs_index_deb>.
    REPLACE '.' IN lv_index_deb WITH space.
    CONDENSE lv_index_deb NO-GAPS.
    lv_index_fin = <fs_index_fin>.
    REPLACE '.' IN lv_index_fin WITH space.
    CONDENSE lv_index_fin NO-GAPS.
    IF lv_index_deb = lv_index_fin.
      EXIT.
    ELSE.
      SELECT *
        FROM zintf_g_remm
        INTO TABLE @DATA(lt_flux)
        WHERE num_pce       = @<fs_num_pce> AND
              debut_periode = @<fs_debut_periode> AND
              statut NOT IN ('05', '07', '11', '13') AND
              idenreg <> @<fs_idenreg>.
      IF sy-subrc EQ 0.
*Si il existe un flux en statut non final sur le même PCE avec la même date de DEBUT_PERIODE :
*    filtrer le flux avec le message “PCE [X] : PTA nul avec index début <> index fin : filtré”
*    [note : cela veut dire que GRDF a corrigé le flux
        CLEAR lv_field.
        MOVE 'FLUX-STATUT'        TO lv_field.
        ASSIGN (lv_field)          TO <fs_statut>.
        <fs_statut> = '11'.

        MESSAGE w119(zintf_g_messages)
        WITH <fs_num_pce>
             ' : Filtré'
        INTO lv_message.

        CLEAR lv_field.
        MOVE 'FLUX-MSG'        TO lv_field.
        ASSIGN (lv_field)      TO <fs_message>.
        <fs_message> = lv_message.
        ev_etape  = 2.
      ENDIF.
    ENDIF.
  ENDIF.


ENDFUNCTION.
