*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 13.06.2019 at 19:00:32
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZINTFDSOINFRALOG................................*
DATA:  BEGIN OF STATUS_ZINTFDSOINFRALOG              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTFDSOINFRALOG              .
CONTROLS: TCTRL_ZINTFDSOINFRALOG
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZINTFDSOINFRALOG              .
TABLES: ZINTFDSOINFRALOG               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
