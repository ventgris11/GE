FUNCTION zintf_g_ctrl_rlv_mes_mhs .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA: lc_field_raison_rlv TYPE fieldname VALUE 'RAISON_RELEVE',
        lv_field            TYPE string,
        lv_int_ui           TYPE int_ui
        .
  CONSTANTS:
    lc_raison_11 TYPE char2 VALUE '11', "MES sur point libre avec auto relève
    lc_raison_12 TYPE char2 VALUE '12', "MES sur point libre avec reprise d’index de MHS
    lc_raison_13 TYPE char2 VALUE '13', "MES sur point libre
    lc_raison_32 TYPE char2 VALUE '32', "CHF avec index calculé (départ)
    lc_raison_34 TYPE char2 VALUE '34', "CHF avec index calculé fiabilisé (départ)
    lc_raison_36 TYPE char2 VALUE '36', "CHF (départ)
    lc_raison_38 TYPE char2 VALUE '38', "CHF avec déplacement (départ)
    lc_raison_40 TYPE char2 VALUE '40', "CHF sur index auto relevé (départ)
    lc_raison_42 TYPE char2 VALUE '42', "MES sur point non libre avec auto relève (départ)
    lc_raison_44 TYPE char2 VALUE '44', "MES sur point non libre (départ)
    lc_raison_46 TYPE char2 VALUE '46', "MES sur point non libre sur index calculé (Souscription)

    lc_raison_21 TYPE char2 VALUE '21', "MHS avec déplacement
    lc_raison_22 TYPE char2 VALUE '22', "MHS avec index auto relevé
    lc_raison_23 TYPE char2 VALUE '23', "MHS avec index calculé
    lc_raison_31 TYPE char2 VALUE '31', "CHF avec index calculé (résiliation)
    lc_raison_33 TYPE char2 VALUE '33', "CHF avec index calculé fiabilisé (résiliation)
    lc_raison_35 TYPE char2 VALUE '35', "CHF (résiliation)
    lc_raison_37 TYPE char2 VALUE '37', "CHF sur index auto relevé (résiliation)
    lc_raison_39 TYPE char2 VALUE '39', "CHF sur relève mesurée (résiliation)
    lc_raison_41 TYPE char2 VALUE '41', "MES sur point non libre avec auto relève (résiliation)
    lc_raison_43 TYPE char2 VALUE '43', "MES sur point non libre (résiliation)
    lc_raison_45 TYPE char2 VALUE '45'  "MES sur point non libre sur index calculé (Résiliation)
    .


  FIELD-SYMBOLS: <fs>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_raison_rlv INTO lv_field.
  ASSIGN (lv_field) TO <fs>.

  IF <fs> IS ASSIGNED.
    " SI la raison de relève a une des valeurs suivante alors on intégre le un rlv spéciale liée ADIF
    IF  <fs> EQ lc_raison_21 OR
        <fs> EQ lc_raison_22 OR
        <fs> EQ lc_raison_23 OR
        <fs> EQ lc_raison_31 OR
        <fs> EQ lc_raison_33 OR
        <fs> EQ lc_raison_35 OR
        <fs> EQ lc_raison_37 OR
        <fs> EQ lc_raison_39 OR
        <fs> EQ lc_raison_41 OR
        <fs> EQ lc_raison_43 OR
        <fs> EQ lc_raison_45 .
      ev_etape = 1.
    ELSEIF <fs> EQ lc_raison_11 OR
        <fs> EQ lc_raison_12 OR
        <fs> EQ lc_raison_13 OR
        <fs> EQ lc_raison_32 OR
        <fs> EQ lc_raison_34 OR
        <fs> EQ lc_raison_36 OR
        <fs> EQ lc_raison_38 OR
        <fs> EQ lc_raison_40 OR
        <fs> EQ lc_raison_42 OR
        <fs> EQ lc_raison_44 OR
        <fs> EQ lc_raison_46
        .
      ev_etape = 2.
    ELSE.
      "Gérer erreur fonctionnelle
    ENDIF.
  ELSE.
    "Erreur technique
  ENDIF.

ENDFUNCTION.
