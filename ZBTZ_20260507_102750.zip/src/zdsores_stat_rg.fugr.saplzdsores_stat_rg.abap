* regenerated at 07.04.2019 13:04:36
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDSORES_STAT_RGTOP.               " Global Data
  INCLUDE LZDSORES_STAT_RGUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDSORES_STAT_RGF...               " Subroutines
* INCLUDE LZDSORES_STAT_RGO...               " PBO-Modules
* INCLUDE LZDSORES_STAT_RGI...               " PAI-Modules
* INCLUDE LZDSORES_STAT_RGE...               " Events
* INCLUDE LZDSORES_STAT_RGP...               " Local class implement.
* INCLUDE LZDSORES_STAT_RGT99.               " ABAP Unit tests
  INCLUDE LZDSORES_STAT_RGF00                     . " subprograms
  INCLUDE LZDSORES_STAT_RGI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
