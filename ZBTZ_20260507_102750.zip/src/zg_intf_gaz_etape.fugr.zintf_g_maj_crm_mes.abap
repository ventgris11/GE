FUNCTION zintf_g_maj_crm_mes.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  TYPES : BEGIN OF ty_maj_crm,
            key   TYPE char40,
            value TYPE text132,
          END OF ty_maj_crm.

  DATA:
    lv_field   TYPE string,
    lv_message TYPE char255,
    lt_result  TYPE STANDARD TABLE OF efindres,
    ls_findpar TYPE efindpar,
    lt_maj_crm TYPE TABLE OF ty_maj_crm,
    ls_maj_crm TYPE ty_maj_crm,
    lv_ryt_rel TYPE string,
    lv_success TYPE crmt_boolean,
    lv_rfcdest TYPE rfcdest,
    lv_day     TYPE string,
    lv_month   TYPE string,
    lv_year    TYPE string,
    lv_dtr     TYPE dats.


  FIELD-SYMBOLS:
    <fs_flux>,
    <fs_num_pce>,
    <fs_date_releve>,
    <fs_date_periode>.


  CLEAR: lv_field.
  MOVE 'FLUX-FLUX'                       TO lv_field.
  ASSIGN (lv_field)                      TO <fs_flux>.

  CLEAR: lv_field.
  MOVE 'FLUX-NUM_PCE'                    TO lv_field.
  ASSIGN (lv_field)                      TO <fs_num_pce>.

  CLEAR: lv_field.
  MOVE 'FLUX-DATE_RELEVE'                TO lv_field.
  ASSIGN (lv_field)                      TO <fs_date_releve>.

  CLEAR: lv_field.
  MOVE 'FLUX-FIN_PERIODE'                TO lv_field.
  ASSIGN (lv_field)                      TO <fs_date_periode>.


  "Récupération destination pour appel MF CRM
  lv_rfcdest = zcl_tool=>get_rfc_for_crm( ).

  IF <fs_flux> = 'RE6M'. "zcl_tool=>gc_log_subobject_re6m
    lv_ryt_rel = '0001'.
  ELSEIF <fs_flux> = 'RE1M'. "zcl_tool=>gc_log_subobject_re1m
    lv_ryt_rel = '0006'.
  ENDIF.

*  lv_day = <fs_date_releve>+6(2).
*  lv_month = <fs_date_periode>+4(2).
*  lv_year = <fs_date_releve>(4).
*  CONCATENATE lv_year lv_month lv_day INTO lv_dtr.
  IF lv_ryt_rel IS NOT INITIAL.
*  IF lv_dtr IS NOT INITIAL.
*    ls_maj_crm-key = 'ZZ0011A0_'. "dtr
*    ls_maj_crm-value = lv_dtr.
*    APPEND ls_maj_crm TO lt_maj_crm.
    CLEAR ls_maj_crm.
    ls_maj_crm-key = 'PD_UITYPE'. "rythme relève
    ls_maj_crm-value = lv_ryt_rel.
    APPEND ls_maj_crm TO lt_maj_crm.

    "Appel MF CRM pour MAJ données PCE
    CALL FUNCTION 'ZREPL_TECHOBJ_UPDATE_V2' DESTINATION lv_rfcdest
      EXPORTING
        iv_ext_ui     = <fs_num_pce>
        it_parameters = lt_maj_crm
      IMPORTING
        ev_success    = lv_success
        ev_message    = lv_message.
    IF lv_success = abap_false.
      "Erreur MAJ CRM
      RETURN.
    ELSE.
      ev_etape = 1.
    ENDIF.
  ENDIF.

ENDFUNCTION.
