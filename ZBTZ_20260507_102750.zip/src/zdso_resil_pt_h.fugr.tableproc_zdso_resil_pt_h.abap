*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDSO_RESIL_PT_H
*   generation date: 21.04.2019 at 18:40:33
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDSO_RESIL_PT_H     .

  PERFORM TABLEPROC.

ENDFUNCTION.
