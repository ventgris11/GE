*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 13.06.2019 at 19:00:33
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
