FUNCTION zintf_g_ctrl_ordres_releve .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  FIELD-SYMBOLS:
    <fs_emetteur>,
    <fs_idenreg>,
    <fs_flux>,
    <fs_num_pce>,
    <fs_date_releve>,
    <fs_motif_releve>.

  DATA:
    lv_field            TYPE string,
    lv_message          TYPE char255,
    lv_int_ui           TYPE int_ui,
    ls_object           TYPE eedm_isu_objects,
    lv_date_releve_mini TYPE dats,
    lv_date_releve_maxi TYPE dats,
    lt_mr_data          TYPE TABLE OF bapieabl,
    ls_mr_data          TYPE bapieabl,
    lt_mr_reason        TYPE TABLE OF bapieablg,
    ls_mr_reason        TYPE bapieablg,
    lv_return           TYPE bapireturn1,
    ls_bpem             TYPE zbpem_flux_struct,
    lv_interface        TYPE zisu_flxid,
*<<<IBE-01/06/2017-Adaptation B2C
    lt_ext_ui           TYPE ztab_ext_ui_type,
    ls_ext_ui           TYPE zstr_ext_ui_type,
*IBE>>>.
* GLIC - 26/12/2019 - GE-7165 - Début
    ls_eanlh            TYPE eanlh,
    ls_te422            TYPE te422.
* GLIC - 26/12/2019 - GE-7165 - Fin

  ev_etape = 2.

  CLEAR lv_field.
  MOVE 'FLUX-EMETTEUR'     TO lv_field.
  ASSIGN (lv_field)        TO <fs_emetteur>.

  CLEAR lv_field.
  MOVE 'FLUX-IDENREG'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_idenreg>.

  CLEAR lv_field.
  MOVE 'FLUX-FLUX'         TO lv_field.
  ASSIGN (lv_field)        TO <fs_flux>.

  CLEAR lv_field.
  MOVE 'FLUX-NUM_PCE'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_num_pce>.

  CLEAR lv_field.
  MOVE 'FLUX-DATE_RELEVE'  TO lv_field.
  ASSIGN (lv_field)        TO <fs_date_releve>.

  CLEAR lv_field.
  MOVE 'FLUX-MOTIF_RELEVE' TO lv_field.
  ASSIGN (lv_field)        TO <fs_motif_releve>.

  CLEAR ls_bpem.
  ls_bpem-num_pce = <fs_num_pce>.
  CASE <fs_flux>.
    WHEN 'ADIF'.
      ls_bpem-date_effet_cont = <fs_date_releve>.
    WHEN 'RE6M' OR 'RE1M' OR 'REMM' OR 'REJJ' OR 'REJM'.
      ls_bpem-date_releve     = <fs_date_releve>.
    WHEN 'AFAC'.
      ls_bpem-date_fin_prest  = <fs_date_releve>.
  ENDCASE.

* Récupération du point de comptage
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).

  IF lv_int_ui IS INITIAL.
* &1 - &2 - &3 : PCE &4 inexistant
    MESSAGE e084(zintf_g_messages)
       WITH <fs_emetteur>
            <fs_flux>
            <fs_idenreg>
            <fs_num_pce>
       INTO lv_message.

    lv_interface    = <fs_flux> .
    ls_bpem-idenreg = <fs_idenreg>.
    CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
      EXPORTING
        iv_interface_name = lv_interface
        iv_sparte         = 'ZG'
        is_structure      = ls_bpem.

    RETURN.
  ENDIF.

* Récupération de l'installation à la date de relève
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.

  IF ls_object-installation IS INITIAL.
* (ID &1) PCE &2 non rattaché à une installation active à la date du &3
    MESSAGE e044(zintf_g_messages)
       WITH <fs_idenreg>
            <fs_num_pce>
            <fs_date_releve>
       INTO lv_message.
    RETURN.
  ENDIF.

* GLIC - 26/12/2019 - GE-7165 - Début

* Le -/+ 12 est laissé en dur comme avant la GE-7165 pour gèrer le cas où aucune UR n'est trouvée plus bas
  lv_date_releve_mini = <fs_date_releve> - 12 .
  lv_date_releve_maxi = <fs_date_releve> + 12.

  CLEAR ls_eanlh.

  SELECT SINGLE *
    FROM eanlh
    INTO ls_eanlh
    WHERE anlage = ls_object-installation
      AND ab  LE <fs_date_releve>
      AND bis GE <fs_date_releve>.

  IF ls_eanlh IS NOT INITIAL.

    CLEAR ls_te422.

    SELECT SINGLE *
      FROM te422
      INTO ls_te422
      WHERE termschl = ls_eanlh-ableinh.

    IF ls_te422 IS NOT INITIAL.
      lv_date_releve_mini = <fs_date_releve> - ls_te422-auf_abl.
      lv_date_releve_maxi = <fs_date_releve> + ls_te422-eper_abl.
    ENDIF.
  ENDIF.

* GLIC - 26/12/2019 - GE-7165 - Fin

* Vérification de l'existence d'un historique de relève sur le PCE
  REFRESH: lt_mr_data, lt_mr_reason.
  CALL FUNCTION 'BAPI_MTRREADDOC_GETLIST'
    EXPORTING
      installation      = ls_object-installation
      mrdocumenttype    = '1'  "Ordre de calcul de facturation
      mrreason          = '01' "Relevé périodique
      targetmrdatefrom  = lv_date_releve_mini
      targetmrdateto    = lv_date_releve_maxi
    IMPORTING
      return            = lv_return
    TABLES
      mrdocumentdata    = lt_mr_data
      mrdocumentreasons = lt_mr_reason.

* Vérification de l'existence ou non d'un ordre de relève
* à plus ou moins 12 jours de la date de relève en question

  <fs_motif_releve> = '02'.

  CLEAR ls_mr_data.
  LOOP AT lt_mr_data
     INTO ls_mr_data
    WHERE targetmrdate BETWEEN lv_date_releve_mini
                           AND lv_date_releve_maxi.
    <fs_motif_releve> = '01'.
    EXIT.
  ENDLOOP.

*<<<IBE-23/05/2017-Adaptation B2C
* Chercher le type PCE
  IF <fs_motif_releve> = '02'.
    REFRESH lt_ext_ui.
    ls_ext_ui-ext_ui = <fs_num_pce>.
    ls_ext_ui-date_validite = <fs_date_releve>.
    APPEND ls_ext_ui TO lt_ext_ui.
    CALL METHOD zcl_tool=>get_ext_ui_type
      CHANGING
        ct_ext_ui = lt_ext_ui.
    READ TABLE lt_ext_ui INTO ls_ext_ui INDEX 1.
    IF ls_ext_ui-type = 'B2C'.
      <fs_motif_releve> = '09'.
    ENDIF.
  ENDIF.
*IBE>>>

  ev_etape = 1.

ENDFUNCTION.
