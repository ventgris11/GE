*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCRM_SM30
*   generation date: 21.04.2017 at 14:28:03
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCRM_SM30           .

  PERFORM TABLEPROC.

ENDFUNCTION.
