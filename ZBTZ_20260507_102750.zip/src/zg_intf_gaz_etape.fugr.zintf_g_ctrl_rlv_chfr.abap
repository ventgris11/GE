FUNCTION ZINTF_G_CTRL_RLV_CHFR .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA: lc_field_raison_rlv TYPE fieldname VALUE 'RAISON_RELEVE',
        lv_field            TYPE string,
        lv_int_ui           TYPE int_ui
        .
  CONSTANTS:
    lc_raison_52 TYPE char2 VALUE '52', "Changement de fréquence de relève (départ)
    lc_raison_51 TYPE char2 VALUE '51' "Changement de fréquence de relève (résiliation)
    .


  FIELD-SYMBOLS: <fs>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_raison_rlv INTO lv_field.
  ASSIGN (lv_field) TO <fs>.

  IF <fs> IS ASSIGNED.
    " SI la raison de relève a une des valeurs suivante alors on intégre le un rlv spéciale liée ADIF
    IF  <fs> EQ lc_raison_51 OR
        <fs> EQ lc_raison_52.
      ev_etape = 1.
    ELSE.
      ev_etape = 2.
    ENDIF.
  ELSE.
    "Erreur technique
  ENDIF.

ENDFUNCTION.
