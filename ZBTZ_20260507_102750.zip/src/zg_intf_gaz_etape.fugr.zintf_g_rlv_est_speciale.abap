FUNCTION zintf_g_rlv_est_speciale .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA: lc_field_type_releve TYPE fieldname VALUE 'TYPE_RELEVE',
        lv_field             TYPE string
        .

  FIELD-SYMBOLS: <fs>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_type_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs>.

  IF <fs> IS ASSIGNED.
*GE-7209 - GLIC - 20/10/2019
*    IF <FS> = 'S' or <FS> = 'D'.
    IF <fs> = 'S'.
*GE-7209 - GLIC - 20/10/2019
      ev_etape = 1.
    ELSE.
      ev_etape = 2.
    ENDIF.
  ELSE.
    "Erreur technique
  ENDIF.

ENDFUNCTION.
