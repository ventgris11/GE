*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 04.04.2019 at 10:47:44
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
