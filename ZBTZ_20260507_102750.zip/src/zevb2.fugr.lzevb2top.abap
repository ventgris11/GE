FUNCTION-POOL ZEVB2.                         "MESSAGE-ID ..

TYPE-POOLS: isu2a.

*$*$ Fehlerbehandlung
INCLUDE emsg.

*global variants
CONSTANTS:
      co_sign_i       TYPE tvarv_sign VALUE 'I',
      co_option_eq    TYPE tvarv_opti VALUE 'EQ'.

DATA:
      gr_badi_mrochk  TYPE REF TO isu_bill_mrochk,
      gv_intcode      TYPE intcode,
      gv_dexbasicproc TYPE e_dexbasicproc,
      gt_service      TYPE eide_service_tab,
      gt_dexproc      TYPE idexproc.
