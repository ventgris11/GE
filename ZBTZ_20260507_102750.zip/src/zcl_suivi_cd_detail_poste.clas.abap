class ZCL_SUIVI_CD_DETAIL_POSTE definition
  public
  inheriting from ZCL_UTILS_BASE_ALV_GRID
  final
  create public .

public section.

  data PV_SELECT type ZSUIVI_CREANCES_DOUTEUSES_SEL .
  constants PC_SPARTE_GAZ type SPARTE value 'ZG' ##NO_TEXT.
  constants PC_SPARTE_ELEC type SPARTE value 'ZE' ##NO_TEXT.
  constants PC_BUKRS_GDP1 type BUKRS value 'GDP1' ##NO_TEXT.
  constants PC_BUKRS_GDP2 type BUKRS value 'GDP2' ##NO_TEXT.

  methods SET_CRITERIA
    importing
      !X_SELECT type ZSUIVI_CREANCES_DOUTEUSES_SEL .
protected section.

  data PT_DATA type ZSUIVI_TT_CD_DETAIL_POSTES .

  methods GET_LAYOUT
    redefinition .
  methods GRID_LOAD
    redefinition .
  PRIVATE SECTION.
ENDCLASS.



CLASS ZCL_SUIVI_CD_DETAIL_POSTE IMPLEMENTATION.


  METHOD GET_LAYOUT.

    FIELD-SYMBOLS:
     <fcat> TYPE lvc_s_fcat.

    " Call superior method
    CALL METHOD super->get_layout( ).

    " Have the grid fit with the actual size of the columns
    pv_layo-cwidth_opt = abap_true.

    " Display with zebra
    pv_layo-zebra = abap_true.

    " Change the field catalog
    LOOP AT pt_fcat ASSIGNING <fcat>.

      CASE <fcat>-fieldname.
        WHEN 'ECHU_INF_T1'.
          <fcat>-coltext = `Mtt pièce échue < à ` && pv_select-t1 && ' j.'.

        WHEN 'ECHU_RES_INF_T1'.
          <fcat>-coltext = `Mtt pièce échue cont. rés. < à ` && pv_select-t1 && ' j.'.

        WHEN 'ECHU_T1_T2'.
          <fcat>-coltext = `Mtt pièce échue entre ` && pv_select-t1 && ` et ` && pv_select-t2 && ' j.'.

        WHEN 'ECHU_RES_T1_T2'.
          <fcat>-coltext = `Mtt pièce cont. rés. entre ` && pv_select-t1 && ` et ` && pv_select-t2 && ' j.'.

        WHEN 'ECHU_T2_T3'.
          <fcat>-coltext = `Mtt pièce échue entre ` && pv_select-t2 && ` et ` && pv_select-t3 && ' j.'.

        WHEN 'ECHU_RES_T2_T3'.
          <fcat>-coltext = `Mtt pièce cont. rés. entre ` && pv_select-t2 && ` et ` && pv_select-t3 && ' j.'.

        WHEN 'ECHU_T3_T4'.
          <fcat>-coltext = `Mtt pièce échue entre ` && pv_select-t3 && ` et ` && pv_select-t4 && ' j.'.

        WHEN 'ECHU_RES_T3_T4'.
          <fcat>-coltext = `Mtt pièce cont. rés. entre ` && pv_select-t3 && ` et ` && pv_select-t4 && ' j.'.

        WHEN 'ECHU_T4_T5'.
          <fcat>-coltext = `Mtt pièce échue entre` && pv_select-t4 && ` et ` && pv_select-t5 && ' j.'.

        WHEN 'ECHU_RES_T4_T5'.
          <fcat>-coltext = `Mtt pièce cont. rés. entre ` && pv_select-t4 && ` et ` && pv_select-t5 && ' j.'.

        WHEN 'ECHU_T5_T6'.
          <fcat>-coltext = 'Mtt pièce échue entre' && ` ` && pv_select-t5 && ` et ` && pv_select-t6 && ' j.'.

        WHEN 'ECHU_RES_T5_T6'.
          <fcat>-coltext = `Mtt pièce cont. rés. entre ` && pv_select-t5 && ` et ` && pv_select-t6 && ' j.'.

        WHEN 'ECHU_T6_T7'.
          <fcat>-coltext = `Mtt pièce échue entre ` && pv_select-t6 && ` et ` && pv_select-t7 && ' j.'.

        WHEN 'ECHU_RES_T6_T7'.
          <fcat>-coltext = `Mtt pièce cont. rés. entre ` && pv_select-t6 && ` et ` && pv_select-t7 && ' j.'.

        WHEN 'ECHU_SUP_T7'.
          <fcat>-coltext = `Mtt pièce échue > à ` && pv_select-t7 && ' j.'.

        WHEN 'ECHU_RES_T7'.
          <fcat>-coltext = `Mtt pièce échue cont. rés. > à ` && pv_select-t7 && ' j.'.

      ENDCASE.

    ENDLOOP.

  ENDMETHOD.


  METHOD grid_load.

    TYPES :
      BEGIN OF lty_vertrag,
        vtref   TYPE vtref_kk,
        vertrag TYPE vertrag,
      END OF lty_vertrag,

      BEGIN OF lty_opbel,
        xblnr TYPE xblnr_kk,
        opbel TYPE opbel_kk,
      END OF lty_opbel.

    DATA :
      lv_vtref TYPE vtref_kk,
      lv_xblnr TYPE xblnr_kk.

    DATA :
      ls_data    TYPE zsuivi_cd_detail_postes,
      ls_vertrag TYPE lty_vertrag,
      ls_opbel   TYPE lty_opbel.

    DATA :
      lt_vertrag TYPE STANDARD TABLE OF lty_vertrag,
      lt_opbel   TYPE STANDARD TABLE OF lty_opbel.

    " Call superior method
    CALL METHOD super->grid_load( ).

    " Reset the output table
    REFRESH pt_data.

    SELECT * INTO TABLE @DATA(lt_tva)
      FROM ztaux_tva.

    IF pv_select-poste_stat IS INITIAL.
      SELECT opbel, bukrs, gpart, vkont, vtref, budat, spart, mwskz, xblnr, betrw, faedn INTO TABLE @DATA(lt_dfkkop)
        FROM dfkkop
       WHERE opbel  IN @pv_select-facture
         AND vkont  IN @pv_select-vkont
         AND gpart  IN @pv_select-partner
         AND bukrs  IN @pv_select-bukrs
         AND spart  IN @pv_select-sparte
         AND vtref  IN @pv_select-vertrag
         AND xblnr  IN @pv_select-piece
         AND budat  IN @pv_select-date_comptable
         AND faedn  IN @pv_select-echue
         AND augst  EQ @space.
    ELSE.
      SELECT opbel bukrs gpart vkont vtref budat spart mwskz xblnr betrw faedn INTO TABLE lt_dfkkop
      FROM dfkkop
       WHERE opbel  IN pv_select-facture
         AND vkont  IN pv_select-vkont
         AND gpart  IN pv_select-partner
         AND bukrs  IN pv_select-bukrs
         AND spart  IN pv_select-sparte
         AND vtref  IN pv_select-vertrag
         AND xblnr  IN pv_select-piece
         AND budat  IN pv_select-date_comptable
         AND faedn  IN pv_select-echue
         AND stakz  EQ space.
    ENDIF.

    " Table of contract ref
    DATA(lt_vtref) = lt_dfkkop.
    SORT lt_vtref BY vtref.
    DELETE ADJACENT DUPLICATES FROM lt_vtref COMPARING vtref.

    IF lt_vtref IS NOT INITIAL.

      " Conversion
      LOOP AT lt_vtref ASSIGNING FIELD-SYMBOL(<ls_vtref>).
        lv_vtref = ls_vertrag-vtref = <ls_vtref>-vtref.
        SHIFT lv_vtref LEFT DELETING LEADING '0'.
        ls_vertrag-vertrag = lv_vtref.
        APPEND ls_vertrag TO lt_vertrag.
      ENDLOOP.

      SELECT vertrag, auszdat INTO TABLE @DATA(lt_ever)
        FROM ever
        FOR ALL ENTRIES IN @lt_vertrag
        WHERE vertrag EQ @lt_vertrag-vertrag.

    ENDIF.

    " Table des pièces de référence
    DATA(lt_xblnr) = lt_dfkkop.
    SORT lt_xblnr BY xblnr.
    DELETE ADJACENT DUPLICATES FROM lt_xblnr COMPARING xblnr.

    IF lt_xblnr IS NOT INITIAL.

      " Conversion
      LOOP AT lt_xblnr ASSIGNING FIELD-SYMBOL(<ls_xblnr>).
        lv_xblnr = ls_opbel-xblnr = <ls_xblnr>-xblnr.
        SHIFT lv_xblnr LEFT DELETING LEADING '0'.
        ls_opbel-opbel = lv_xblnr.
        APPEND ls_opbel TO lt_opbel.
      ENDLOOP.

      SELECT opbel, begabrpe INTO TABLE @DATA(lt_erch)
        FROM erchc
        INNER JOIN erch ON erch~belnr EQ erchc~belnr
        FOR ALL ENTRIES IN @lt_opbel
        WHERE opbel = @lt_opbel-opbel.

    ENDIF.

    " Table des pièces
    DATA(lt_pieces) = lt_dfkkop.
    SORT lt_pieces BY opbel.
    DELETE ADJACENT DUPLICATES FROM lt_pieces COMPARING opbel.

    IF lt_pieces IS NOT INITIAL.

      SELECT opbel, budat, xblnr INTO TABLE @DATA(lt_dfkkko)
        FROM dfkkko
        FOR ALL ENTRIES IN @lt_pieces
        WHERE opbel EQ @lt_pieces-opbel.

    ENDIF.

    " Récupération des taux de TVA
    "- Tableau de code TVA
    DATA(lt_code_tva) = lt_dfkkop.
    SORT lt_code_tva BY mwskz.
    DELETE ADJACENT DUPLICATES FROM lt_code_tva COMPARING mwskz.

    IF lt_code_tva IS NOT INITIAL.
      SELECT mwskz, kbetr INTO TABLE @DATA(lt_taux)
        FROM a003
        INNER JOIN konp ON konp~knumh EQ a003~knumh
        FOR ALL ENTRIES IN @lt_code_tva
        WHERE aland EQ 'FR'
          AND mwskz EQ @lt_code_tva-mwskz.
    ENDIF.

    SORT lt_ever    BY vertrag.
    SORT lt_dfkkko  BY opbel.
    SORT lt_erch    BY opbel.
    SORT lt_taux    BY mwskz.
    SORT lt_vertrag BY vtref.
    SORT lt_opbel   BY xblnr.

    LOOP AT lt_dfkkop ASSIGNING FIELD-SYMBOL(<ls_dfkkop>).

      ls_data-societe         = <ls_dfkkop>-bukrs.
      ls_data-bp              = <ls_dfkkop>-gpart.
      ls_data-compte_contrat  = <ls_dfkkop>-vkont.
      ls_data-contrat         = <ls_dfkkop>-vtref.
      ls_data-date_cpt_poste  = <ls_dfkkop>-budat.
      ls_data-secteur         = <ls_dfkkop>-spart.
      ls_data-code_tva        = <ls_dfkkop>-mwskz.

      READ TABLE lt_vertrag ASSIGNING FIELD-SYMBOL(<ls_vertrag>) WITH KEY vtref = <ls_dfkkop>-vtref BINARY SEARCH.
      IF sy-subrc EQ 0.
        READ TABLE lt_ever ASSIGNING FIELD-SYMBOL(<ls_ever>) WITH KEY vertrag = <ls_vertrag>-vertrag BINARY SEARCH.
        IF sy-subrc EQ 0.
          ls_data-date_dem = <ls_ever>-auszdat.
        ENDIF.
      ENDIF.

      IF ls_data-date_dem NE '99991231'.
        ls_data-resilie = abap_true.
      ENDIF.

      ls_data-num_piece = <ls_dfkkop>-opbel.

      READ TABLE lt_dfkkko ASSIGNING FIELD-SYMBOL(<ls_dfkkko>) WITH KEY opbel = <ls_dfkkop>-opbel BINARY SEARCH.
      IF sy-subrc EQ 0.
        ls_data-date_cpt  = <ls_dfkkko>-budat.
        ls_data-ref_doc   = <ls_dfkkko>-xblnr.
      ENDIF.

      READ TABLE lt_opbel ASSIGNING FIELD-SYMBOL(<ls_opbel>) WITH KEY xblnr = <ls_dfkkop>-xblnr BINARY SEARCH.
      IF sy-subrc EQ 0.
        READ TABLE lt_erch ASSIGNING FIELD-SYMBOL(<ls_erch>) WITH KEY opbel = <ls_opbel>-opbel BINARY SEARCH.
        IF sy-subrc EQ 0.
          ls_data-deb_periode = <ls_erch>-begabrpe.
        ENDIF.
      ENDIF.

      READ TABLE lt_taux ASSIGNING FIELD-SYMBOL(<ls_tva>) WITH KEY mwskz = <ls_dfkkop>-mwskz BINARY SEARCH.
      IF sy-subrc EQ 0.
        ls_data-mtt_creance_ht = <ls_dfkkop>-betrw / ( 1 + ( <ls_tva>-kbetr / 1000 ) ).

        IF <ls_tva>-kbetr EQ 200.
          ls_data-tva_20 = <ls_dfkkop>-betrw.
        ELSE.
          ls_data-tva_5 = <ls_dfkkop>-betrw.
        ENDIF.
      ENDIF.


      IF <ls_dfkkop>-betrw GE 0.

        DATA(lv_diff) = sy-datum - <ls_dfkkop>-faedn.
        IF ls_data-resilie IS NOT INITIAL.

          IF lv_diff LT pv_select-t1.
            ls_data-echu_inf_t1 = <ls_dfkkop>-betrw.
          ELSEIF lv_diff GE pv_select-t1 AND lv_diff LT pv_select-t2.
            ls_data-echu_t1_t2 = <ls_dfkkop>-betrw.
          ELSEIF lv_diff GE pv_select-t2 AND lv_diff LT pv_select-t3.
            ls_data-echu_t2_t3 = <ls_dfkkop>-betrw.
          ELSEIF lv_diff GE pv_select-t3 AND lv_diff LT pv_select-t4.
            ls_data-echu_t3_t4 = <ls_dfkkop>-betrw.
          ELSEIF lv_diff GE pv_select-t4 AND lv_diff LT pv_select-t5.
            ls_data-echu_t4_t5 = <ls_dfkkop>-betrw.
          ELSEIF lv_diff GE pv_select-t5 AND lv_diff LT pv_select-t6.
            ls_data-echu_t5_t6 = <ls_dfkkop>-betrw.
          ELSEIF lv_diff GE pv_select-t6 AND lv_diff LT pv_select-t7.
            ls_data-echu_t6_t7 = <ls_dfkkop>-betrw.
          ELSEIF lv_diff GE pv_select-t7 .
            ls_data-echu_sup_t7 = <ls_dfkkop>-betrw.
          ENDIF.

        ELSE.

          IF lv_diff LT pv_select-t1.
            ls_data-echu_res_inf_t1 = <ls_dfkkop>-betrw.
          ELSEIF lv_diff GE pv_select-t1 AND lv_diff LT pv_select-t2.
            ls_data-echu_res_t1_t2 = <ls_dfkkop>-betrw.
          ELSEIF lv_diff GE pv_select-t2 AND lv_diff LT pv_select-t3.
            ls_data-echu_res_t2_t3 = <ls_dfkkop>-betrw.
          ELSEIF lv_diff GE pv_select-t3 AND lv_diff LT pv_select-t4.
            ls_data-echu_res_t3_t4 = <ls_dfkkop>-betrw.
          ELSEIF lv_diff GE pv_select-t4 AND lv_diff LT pv_select-t5.
            ls_data-echu_res_t4_t5 = <ls_dfkkop>-betrw.
          ELSEIF lv_diff GE pv_select-t5 AND lv_diff LT pv_select-t6.
            ls_data-echu_res_t5_t6 = <ls_dfkkop>-betrw.
          ELSEIF lv_diff GE pv_select-t6 AND lv_diff LT pv_select-t7.
            ls_data-echu_res_t6_t7 = <ls_dfkkop>-betrw.
          ELSEIF lv_diff GE pv_select-t7 .
            ls_data-echu_res_t7 = <ls_dfkkop>-betrw.
          ENDIF.

        ENDIF.

      ENDIF.

      IF <ls_dfkkop>-betrw LT 0.
        ls_data-mtt_cred = <ls_dfkkop>-betrw.
      ENDIF.

      ls_data-solde = <ls_dfkkop>-betrw.

      APPEND ls_data TO pt_data.
      CLEAR ls_data.

    ENDLOOP.

    " Reference the data
    GET REFERENCE OF pt_data INTO pr_data.

  ENDMETHOD.


  METHOD SET_CRITERIA.

    " Save the new criteria
    pv_select = x_select.

    " Refresh the display
    CALL METHOD me->display( ).

  ENDMETHOD.
ENDCLASS.
