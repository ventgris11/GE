*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 07.04.2019 at 13:51:40
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
