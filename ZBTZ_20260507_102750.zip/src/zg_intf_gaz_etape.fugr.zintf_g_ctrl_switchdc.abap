FUNCTION zintf_g_ctrl_switchdc .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA: lc_field_num_pce      TYPE fieldname VALUE 'NUM_PCE',
        lc_field_nb_roue      TYPE fieldname VALUE 'NB_ROUE_COMPTEUR',
        lc_field_index        TYPE fieldname VALUE 'INDEX_BRUT_FIN_PERIODE',
        lc_field_flux         TYPE fieldname VALUE 'FLUX',
        lc_field_emetteur     TYPE fieldname VALUE 'EMETTEUR',
        lc_field_idenreg      TYPE fieldname VALUE 'IDENREG',
        lc_field_type_rel     TYPE fieldname VALUE 'RAISON_RELEVE',
        lc_field_date_rel     TYPE fieldname VALUE 'DATE_RELEVE',
*<<<IBE-23/05/2017-Adaptation B2C
        lc_field_demande      TYPE fieldname VALUE 'NUM_DEMANDE',
*IBE>>>

*FPE-GE-523
        lc_field_num_compteur TYPE fieldname VALUE 'NUM_SERIE_COMPTEUR',
*FPE-GE-523

        lv_field              TYPE string,
        lv_int_ui             TYPE int_ui,
        ls_switch_doc         TYPE eideswtdoc,
        lv_message            TYPE string,
        lv_subobj             TYPE balsubobj,
        lv_type_pce           TYPE char2,
        lv_date_releve        TYPE datum,
        lr_switch_doc         TYPE REF TO cl_isu_ide_switchdoc,
*<<<IBE-23/05/2017-Adaptation B2C
        lv_ref_externe        TYPE zzintf_ref_externe,
        lt_ext_ui             TYPE ztab_ext_ui_type,
        ls_ext_ui             TYPE zstr_ext_ui_type,
*IBE>>>
        ls_g_mes              TYPE zintf_g_mes.
                                                                                                                              "FPE-GE-523
  FIELD-SYMBOLS: <fs>, <fs_nb_roue>, <fs_index>, <fs_flux>, <fs_emetteur>, <fs_idenreg>, <fs_type_releve>, <fs_date_releve>, <fs_num_compteur>,
*<<<IBE-23/05/2017-Adaptation B2C
                 <fs_num_demande>.
*IBE>>>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_flux INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.
  IF <fs_flux> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_nb_roue INTO lv_field.
  ASSIGN (lv_field) TO <fs_nb_roue>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_index INTO lv_field.
  ASSIGN (lv_field) TO <fs_index>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_emetteur INTO lv_field.
  ASSIGN (lv_field) TO <fs_emetteur>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_flux INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_idenreg INTO lv_field.
  ASSIGN (lv_field) TO <fs_idenreg>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_type_rel INTO lv_field.
  ASSIGN (lv_field) TO <fs_type_releve>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_rel INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_releve>.

*<<<IBE-23/05/2017-Adaptation B2C
  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_demande INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_demande>.
*IBE>>>.

*FPE-GE-523- Numéro de série compteur RE6M et RE1M
  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_compteur INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_compteur>.
*FPE-GE-523

* FPE Début GE-83 - implémentation RE1M
  IF <fs_flux> = 'RE6M'.
    lv_subobj = zcl_tool=>gc_log_subobject_re6m.
  ELSEIF <fs_flux> = 'RE1M'.
    lv_subobj = zcl_tool=>gc_log_subobject_re1m.
  ELSE.
    lv_subobj = zcl_tool=>gc_log_subobject_remm.
  ENDIF.
* FPE GE-83 fin

  CLEAR: lv_int_ui .
  IF <fs> IS ASSIGNED.
    lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs> ).
  ENDIF.

  IF  lv_int_ui IS NOT INITIAL.
** Modif AliA Consulting (LWAT) 2016.07.18 : Modification de la recherche du switch doc
** car il faut également rechercher sur le type de switch doc (emménagement / déménagement)
    DATA: lv_switch_type TYPE eideswttype.
    IF zcl_tool=>rlv_is_mes( <fs_type_releve> ). "Mise en service
      lv_switch_type = if_isu_ide_switch_constants=>co_swttype_enroll. " Emménagement
    ELSEIF zcl_tool=>rlv_is_mhs( <fs_type_releve> ). " Mise Hors Service
      lv_switch_type = if_isu_ide_switch_constants=>co_swttype_drop. " Déménagement
    ELSE. "Type autre que MES / RES ? Pourquoi recherche-t-on un switch doc ?
      MESSAGE e000(zintf_g_messages) WITH <fs_emetteur> <fs_flux> <fs_idenreg> ' : Raison de relève non MHS / MES (ZINTF_G_CTRL_SWITCHDC)'
      INTO lv_message.
      zcl_tool=>log_add_msg( EXPORTING iv_log_object = zcl_tool=>gc_log_object_intf_gaz
      iv_log_subobject = lv_subobj
      iv_test_mode = iv_mode_test
      CHANGING  cv_log_handle = cv_log_handle ).
      ev_etape = 1.
      EXIT. " On quitte
    ENDIF.


** >> GE-2429 (LWAT) 28.09.2018 : La recherche est désormais d'abord basée sur le numéro
**    d'affaire puis date de mise en service
    " On récupère le numéro de référence de la demande (si présent)
    CLEAR lv_ref_externe.
    IF <fs_num_demande> IS ASSIGNED.
      lv_ref_externe = <fs_num_demande>.
    ENDIF.

    " Recherche du switchdoc
    CALL METHOD zcl_tool=>swd_search_mix
      EXPORTING
        iv_pod            = lv_int_ui
        iv_switch_type    = lv_switch_type
        iv_status         = cl_isu_ide_switchdoc=>co_stat_active " Actif
        iv_date           = <fs_date_releve>
        iv_zz_ref_externe = lv_ref_externe
      RECEIVING
        rr_switch_doc     = lr_switch_doc
      EXCEPTIONS
        multiple_swt_doc  = 1
        error             = 2
        OTHERS            = 3.

**<<<IBE-23/05/2017-Adaptation B2C
** Chercher le type PCE
*    REFRESH lt_ext_ui.
*    ls_ext_ui-ext_ui = <fs>.
*    ls_ext_ui-date_validite = <fs_date_releve>.
*    APPEND ls_ext_ui TO lt_ext_ui.
*    CALL METHOD zcl_tool=>get_ext_ui_type
*      CHANGING
*        ct_ext_ui = lt_ext_ui.
*    READ TABLE lt_ext_ui INTO ls_ext_ui INDEX 1.
*    IF ls_ext_ui-type = 'B2C' AND <fs_num_demande> IS ASSIGNED.
*      lv_ref_externe = <fs_num_demande>.
*    ELSE.
*      CLEAR lv_ref_externe.
*    ENDIF.
**IBE>>>
*
*    CALL METHOD zcl_tool=>swd_search
*      EXPORTING
*        iv_pod            = lv_int_ui
*        iv_switch_type    = lv_switch_type
*        iv_status         = cl_isu_ide_switchdoc=>co_stat_active " Actif
*** Ajout AliA Consulting (LWAT) 2016.10.22 : On recherche par rapport à une date
*        iv_date           = <fs_date_releve>
*** Fin Ajout AliA Consulting (LWAT) 2016.10.22
**<<<IBE-23/05/2017-Adaptation B2C
*        iv_zz_ref_externe = lv_ref_externe
**IBE>>>
*      RECEIVING
*        rr_switch_doc     = lr_switch_doc
*      EXCEPTIONS
*        multiple_swt_doc  = 1
**       no_swt_doc        = 2
*        error             = 2
*        OTHERS            = 3.
**      CALL METHOD cl_isu_ide_switchdoc=>select
**        EXPORTING
**         x_pod           = lv_int_ui
***         x_status        = '03' "actif (attente réponse GRDF)
**          x_wmode         = cl_isu_wmode=>co_change
**        RECEIVING
**          y_switchdoc     = lr_switch_doc
**        EXCEPTIONS
**          not_found       = 1
**          parameter_error = 2
**          not_unique      = 3
**          general_fault   = 4
**          foreign_lock    = 5
**          not_authorized  = 6
**          OTHERS          = 7.
** Fin Modif AliA Consulting (LWAT) 2016.07.18
** << GE-2429 (LWAT) 28.09.2018
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
      INTO lv_message
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      zcl_tool=>log_add_msg( EXPORTING iv_log_object = zcl_tool=>gc_log_object_intf_gaz
      iv_log_subobject = lv_subobj
      iv_test_mode = iv_mode_test
      CHANGING  cv_log_handle = cv_log_handle ).
      ev_etape = 1.
    ELSE.
      IF lr_switch_doc IS NOT BOUND.
*   ADIF : Pas de switch doc associé au PCE &1. Passage statut "Action CRM"
        MESSAGE e054(zintf_g_messages) WITH <fs> INTO lv_message.
        zcl_tool=>log_add_msg( EXPORTING iv_log_object = zcl_tool=>gc_log_object_intf_gaz
        iv_log_subobject = lv_subobj
        iv_test_mode = iv_mode_test
        CHANGING  cv_log_handle = cv_log_handle ).
        ev_etape = 1.
      ELSE.
        "on test si le flag ADIF est OK
        ls_switch_doc = lr_switch_doc->get_all_properties( ).
        IF ls_switch_doc-zzg_adif_ok = 'X'.
          lr_switch_doc->set_property( x_property = 'ZZG_NB_ROUES' x_value = <fs_nb_roue> ).
          lr_switch_doc->set_property( x_property = 'ZZG_REL_EMMENAGEMENT' x_value = <fs_index> ).
*FPE-DEB-GE-523 - Num série compteur
          IF <fs_flux> = 'RE6M' OR <fs_flux> = 'RE1M'.
            lr_switch_doc->set_property( x_property = 'ZZE_MAT_COMPTEUR' x_value = <fs_num_compteur> ).
          ENDIF.
*FPE-FIN-GE-523 - Num série compteur

*          IF <fs_emetteur> = 'GDFD'.
          CASE <fs_flux>.
            WHEN 'RE6M'.
              lv_type_pce = '6M'.
* FPE GE-83 ++ RE1M
            WHEN 'RE1M'.
              lv_type_pce = '1M'.
* FPE GE-83 fin
            WHEN 'REMM'.
              lv_type_pce = 'MM'.
            WHEN 'REJM'.
              lv_type_pce = 'JM'.
            WHEN 'REJJ'.
              lv_type_pce = 'JJ'.
          ENDCASE.
*          ELSE.
*            lv_type_pce = 'GR'.
*          ENDIF.

          lr_switch_doc->set_property( x_property = 'ZZG_TYPE_PCE' x_value = lv_type_pce ).

          IF iv_mode_test IS INITIAL.
            lr_switch_doc->save( ).
            lr_switch_doc->close( ). " On close car le switch doc sera modifié par l'event juste après !

            IF <fs_flux> = 'RE6M' OR <fs_flux> = 'RE1M'.
              ls_g_mes-flux        = <fs_flux>.
              ls_g_mes-emetteur    = <fs_emetteur>.
              ls_g_mes-num_pce     = <fs>.
              ls_g_mes-statut      = '01'.
              ls_g_mes-idenreg     = <fs_idenreg>.
              ls_g_mes-date_releve = <fs_date_releve>.

              MODIFY zintf_g_mes FROM ls_g_mes.

            ENDIF.
***** Déplacer dans la 1ère relève de mise en service
*      " Génération de l'évènement pour confirmer le switch document
            zcl_tool=>swd_event_generate( iv_event = zcl_tool=>gc_swd_accept_enrollment iv_switchdoc_num = ls_switch_doc-switchnum ).
          ENDIF.
          ev_etape = 2.
        ELSE.
          MESSAGE w214(zintf_g_messages) WITH <fs_emetteur> <fs_flux> <fs_idenreg> INTO lv_message.
          ev_etape = 1.
        ENDIF.
      ENDIF.
    ENDIF.
  ELSE.
    "Erreur technique
    MESSAGE e160(zintf_g_messages) WITH <fs> INTO lv_message.
    ev_etape = 1.
  ENDIF.

ENDFUNCTION.
