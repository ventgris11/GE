*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZINTF_E_R15
*   generation date: 16.11.2020 at 16:51:49
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZINTF_E_R15         .

  PERFORM TABLEPROC.

ENDFUNCTION.
