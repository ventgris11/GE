FUNCTION z_isu_event_1211 .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(I_WITH_SIMULATED_ITEMS) LIKE  BOOLE-BOOLE
*"     VALUE(I_FKKEPOSC) LIKE  FKKEPOSC STRUCTURE  FKKEPOSC OPTIONAL
*"  EXPORTING
*"     VALUE(E_NDTXT_DEACTIVATE) LIKE  FKKL1-NDTXT
*"     VALUE(E_NDTXT_ACTIVATE) LIKE  FKKL1-NDTXT
*"     VALUE(E_SNDSP) LIKE  FKKL1-SNDSP
*"     VALUE(E_FTEXT_1117) LIKE  FKKL1-NDTXT
*"     VALUE(E_FCODE_1117) LIKE  SY-UCOMM
*"  TABLES
*"      T_POSTAB STRUCTURE  FKKEPOS
*"      T_SEL_VALUES STRUCTURE  FKKL1
*"      T_TOTALS STRUCTURE  FKKEPOS_TOT OPTIONAL
*"      T_NEW_ITEMS STRUCTURE  FKKEPOS OPTIONAL
*"----------------------------------------------------------------------

  FIELD-SYMBOLS: <ls_postab> TYPE fkkepos.
  FIELD-SYMBOLS: <fs_fkkko> TYPE fkkko.
  DATA :
    ld_numfact  TYPE e_printdoc,
    lv_typefact TYPE ztypefact,

    BEGIN OF lt_type_facture OCCURS 0,
      domvalue_l TYPE domvalue_h,
      ddtext     TYPE ddtext,
    END OF lt_type_facture.

  SELECT *
    FROM dd07v
    APPENDING CORRESPONDING FIELDS OF TABLE lt_type_facture
      WHERE domname = 'ZTYPEFACT'.

  "On garde le fonctionnement du standard actif
  CALL FUNCTION 'ISU_EVENT_1211'
    EXPORTING
      i_with_simulated_items = i_with_simulated_items
      i_fkkeposc             = i_fkkeposc
    IMPORTING
      e_ndtxt_deactivate     = e_ndtxt_deactivate
      e_ndtxt_activate       = e_ndtxt_activate
      e_sndsp                = e_sndsp
      e_ftext_1117           = e_ftext_1117
      e_fcode_1117           = e_fcode_1117
    TABLES
      t_postab               = t_postab
      t_sel_values           = t_sel_values
      t_totals               = t_totals
      t_new_items            = t_new_items.

  LOOP AT t_postab ASSIGNING <ls_postab> WHERE xblnr IS NOT INITIAL and bukrs = 'GDP2'.
    IF <ls_postab>-blart = 'FA' OR <ls_postab>-blart = 'AF'.

      clear ld_numfact.
      ld_numfact = <ls_postab>-xblnr+4(12).
      SELECT SINGLE zztypefact
        FROM erdk
        INTO lv_typefact
        WHERE opbel EQ ld_numfact.

      IF sy-subrc = 0.
        READ TABLE lt_type_facture
      WITH KEY domvalue_l = lv_typefact.
        IF sy-subrc = 0.
          <ls_postab>-type_facture = lt_type_facture-ddtext.
        ENDIF.
      ENDIF.

    ENDIF.

  ENDLOOP.

ENDFUNCTION.
