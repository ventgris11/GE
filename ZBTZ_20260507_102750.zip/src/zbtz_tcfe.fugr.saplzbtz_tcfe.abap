* regenerated at 20.10.2018 17:29:03
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZBTZ_TCFETOP.                     " Global Data
  INCLUDE LZBTZ_TCFEUXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZBTZ_TCFEF...                     " Subroutines
* INCLUDE LZBTZ_TCFEO...                     " PBO-Modules
* INCLUDE LZBTZ_TCFEI...                     " PAI-Modules
* INCLUDE LZBTZ_TCFEE...                     " Events
* INCLUDE LZBTZ_TCFEP...                     " Local class implement.
* INCLUDE LZBTZ_TCFET99.                     " ABAP Unit tests
  INCLUDE LZBTZ_TCFEF00                           . " subprograms
  INCLUDE LZBTZ_TCFEI00                           . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
