FUNCTION zintf_e_integration_rxx .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_IDENREG) TYPE  ZIDENREG
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN DEFAULT ABAP_FALSE
*"     REFERENCE(IV_ID_FLUX) TYPE  ZID_FLUX
*"  EXPORTING
*"     REFERENCE(EV_ERROR) TYPE  CRMT_BOOLEAN
*"----------------------------------------------------------------------

  CLEAR ev_error.
  lv_log_object    = lc_log_object_intf_elec.
  lv_msgid         = lc_msgid_intf_elec.

  CLEAR lv_log_handle.

  CASE iv_id_flux.
    WHEN 'R04'.
      lv_log_subobject = lc_log_subobject_r04.
    WHEN 'R15'.
      lv_log_subobject = lc_log_subobject_r15.
    WHEN 'R16'.
      lv_log_subobject = lc_log_subobject_r16.
    WHEN 'R17'.
      lv_log_subobject = lc_log_subobject_r17.
    WHEN OTHERS.
  ENDCASE.
* Appel en mode &1 pour le flux &2
  IF 1 = 2. MESSAGE i018(zintf_e_messages). ENDIF.
  IF iv_mode_test IS INITIAL.
    macro_add_msg_to_log 'I' '018'
                         'REEL' iv_id_flux '' ''.
  ELSE.
    macro_add_msg_to_log 'I' '018'
                         'TEST' iv_id_flux '' ''.
  ENDIF.

  EXPORT : lv_log_subobject TO MEMORY ID 'LOG_SUBOBJECT',
           lv_log_handle    TO MEMORY ID 'LOG_HANDLE'   .  "++GE-81

* Sélection des données à traiter
  CASE iv_id_flux.
    WHEN 'R04'.
      CLEAR ls_rxx.
      SELECT SINGLE *
        INTO CORRESPONDING FIELDS OF ls_rxx
        FROM zintf_e_r04
       WHERE idenreg EQ iv_idenreg.

      lv_statut_flux = ls_rxx-statut.

      REFRESH lt_rxx_3.
      SELECT *
        INTO CORRESPONDING FIELDS OF TABLE lt_rxx_3
        FROM zintf_e_r04_3
       WHERE idenreg EQ iv_idenreg
       ORDER BY idenreg
                id_periode
                rang_cadran.
    WHEN 'R15'.
      CLEAR ls_rxx.
      SELECT SINGLE *
        INTO CORRESPONDING FIELDS OF ls_rxx
        FROM zintf_e_r15
       WHERE idenreg EQ iv_idenreg.

      lv_statut_flux = ls_rxx-statut.

*** --> GE-2462 - GLIC - 04/02/2019 - On ne prend plus que les FOURNI
*      IF ls_cxx-niv_service = '0' .
*        lv_type_class = 'FOURNI'.
*      ELSE.
*        lv_type_class = 'DISTRI'.
*      ENDIF.
      lv_type_class = 'FOURNI'.
*** <-- GE-2462 - GLIC - 04/02/2019

      REFRESH lt_rxx_3.
      SELECT *
        INTO CORRESPONDING FIELDS OF TABLE lt_rxx_3
        FROM zintf_e_r15_3
       WHERE idenreg           EQ iv_idenreg
         AND type_classe_tempo EQ lv_type_class
       ORDER BY idenreg
                type_classe_tempo
                rang_cadran.

    WHEN 'R16'.
      CLEAR ls_rxx.
      SELECT SINGLE *
        INTO CORRESPONDING FIELDS OF ls_rxx
        FROM zintf_e_r16
       WHERE idenreg EQ iv_idenreg.

      lv_statut_flux = ls_rxx-statut.

      REFRESH lt_rxx_3.
      SELECT *
        INTO CORRESPONDING FIELDS OF TABLE lt_rxx_3
        FROM zintf_e_r16_3
       WHERE idenreg           EQ iv_idenreg
         AND type_classe_tempo EQ 'FOURNI'
       ORDER BY idenreg
                type_classe_tempo
                rang_cadran.
    WHEN 'R17'.

      CLEAR ls_rxx.
      SELECT SINGLE *
        INTO CORRESPONDING FIELDS OF ls_rxx
        FROM zintf_e_r17
       WHERE idenreg EQ iv_idenreg.


      lv_statut_flux = ls_rxx-statut.

      REFRESH lt_rxx_3.
      SELECT *
        INTO CORRESPONDING FIELDS OF TABLE lt_rxx_3
        FROM zintf_e_r17_3
       WHERE idenreg           EQ iv_idenreg
       ORDER BY idenreg
                id_classe_tempo.

      SELECT *
        INTO CORRESPONDING FIELDS OF TABLE lt_r17_3b
        FROM zintf_e_r17_3b
       WHERE idenreg           EQ iv_idenreg
       ORDER BY idenreg
                id_classe_tempo.

** >> GE-2520 (LWAT) 21.01.2019 : Il faut faire une recherche avec regexp
      DATA: lv_found TYPE crmt_boolean.
      zcl_tool_flux=>rxx_find_motif( EXPORTING iv_motif = ls_rxx-motif_releve_new
                                     IMPORTING es_transco_rlv = ls_trnsco_rlv
                                               ev_found       = lv_found ).

      IF lv_found EQ abap_false.
*      SELECT SINGLE *                                        " -- GE-2520
*        FROM zintf_trnsco_rlv                                " -- GE-2520
*        INTO ls_trnsco_rlv                                   " -- GE-2520
*        WHERE motif_releve_new = ls_rxx-motif_releve_new .   " -- GE-2520
*      IF sy-subrc NE 0.                                      " -- GE-2520
** << GE-2520 (LWAT) 21.01.2019
        "Motif de relève &1 inconnu
        IF 1 = 2. MESSAGE e405(zintf_e_messages). ENDIF.
        macro_add_msg_to_log 'E' '405'
                             ls_rxx-motif_releve_new
                             space space space.
        PERFORM update_ligne_releve USING lc_statut_06_rejet.
        RETURN.
      ENDIF.
*      IF ls_rxx-motif_releve_new = 'F130'.
      IF ls_rxx-motif_releve_new   CP 'F130*'
        OR ls_rxx-motif_releve_new CP 'F800*'
        OR ls_rxx-motif_releve_new CP 'F820*'. "GE-6280: [F.R17] MEA Synchro des R17 à J-1 du C12 de RES
        "Vérifier l’existence du PRM
        lv_int_ui
          = zcl_tool=>pod_check_exist( iv_pce_num = ls_rxx-id_prm ).
        IF lv_int_ui IS INITIAL.
* PRM &1 non trouvé => passage au statut "Attention Action CRM"
          IF 1 = 2. MESSAGE e052(zintf_e_messages). ENDIF.
          macro_add_msg_to_log 'E' '052'
                               ls_rxx-id_prm '' '' ''.
          lv_statut_flux = lc_statut_10_action_crm.
          PERFORM update_ligne_releve USING  lc_statut_10_action_crm.
          RETURN.
        ENDIF.

        CLEAR ls_object .
        CALL METHOD zcl_tool=>pod_get_related_object
          EXPORTING
            iv_int_ui = lv_int_ui
            iv_date   = ls_rxx-date_fin_conso
          IMPORTING
            es_detail = ls_object
            ev_equnr  = lv_equnr
            ev_sernr  = lv_sernr.

        IF NOT ls_object-contract IS INITIAL
          AND ( ls_rxx-date_deb_conso NE ls_rxx-date_fin_conso ).
          ls_trnsco_rlv-type_event = 'RES' .
        ENDIF.
      ENDIF.

      lv_anlage = ls_object-installation.

  ENDCASE.

*++ STOU DEBUT GE-4501
  SELECT SINGLE * FROM zintf_bypass_ctr
    INTO ls_bypass_ctr
    WHERE idenreg = ls_rxx-idenreg .
*++ STOU FIN   GE-4501

  IF ls_rxx-id_flux EQ 'R15'.
    IF ls_rxx-origine_evenement = '1'.
* Le flux R concerne le contrat d'injection
      IF 1 = 2. MESSAGE e189(zintf_e_messages). ENDIF.
      macro_add_msg_to_log 'E' '189'
                           '' '' '' ''.
      ev_error = abap_true.
      RETURN.
    ENDIF.
  ENDIF.

  lv_int_ui
      = zcl_tool=>pod_check_exist( iv_pce_num = ls_rxx-id_prm ).
  IF lv_int_ui IS INITIAL.
* PRM &1 non trouvé => passage au statut 06 "REJET"
    IF 1 = 2. MESSAGE e150(zintf_e_messages). ENDIF.
    macro_add_msg_to_log 'E' '150'
                         ls_rxx-id_prm '' '' ''.
    lv_statut_flux = lc_statut_06_rejet.
    PERFORM update_ligne_releve USING  lc_statut_06_rejet.
    RETURN.
  ENDIF.

  CLEAR ls_object .
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = ls_rxx-date_fin_conso
    IMPORTING
      es_detail = ls_object
      ev_equnr  = lv_equnr
      ev_sernr  = lv_sernr.

  lv_anlage = ls_object-installation.

  SELECT *
    FROM zintf_e_mesure
    INTO TABLE lt_mesure .

  REFRESH lt_ext_ui . "++GE-1938

  CLEAR lv_b2c .
  ls_ext_ui-ext_ui = ls_rxx-id_prm  .
  APPEND ls_ext_ui TO lt_ext_ui .
  CALL METHOD zcl_tool=>get_ext_ui_type
    CHANGING
      ct_ext_ui = lt_ext_ui.

  READ TABLE lt_ext_ui INTO ls_ext_ui INDEX 1.
  IF ls_ext_ui-type = 'B2C' OR ls_ext_ui-bukrs = 'GDP2'.
    lv_b2c = 'X' .
  ENDIF.

*++ STOU DEBUT GE-477
  DATA lv_date_mes TYPE dats.

  lv_date_mes = ls_rxx-date_fin_conso .

  IF ls_rxx-id_flux EQ 'R04' OR
     ls_rxx-id_flux EQ 'R15'.

* Récupération du numéro de l'installation
*    "Vérifier s’il existe une relève au motif « 06 - Relevé avant emménagement ».
    IF ls_rxx-id_flux EQ 'R04' .
      lv_dat_pls_1 = ls_rxx-date_deb_conso + 1.
    ELSE.
      lv_dat_pls_1 = ls_rxx-date_fin_conso + 1.
    ENDIF.

    REFRESH: lt_mr_data, lt_mr_reason.
    CALL FUNCTION 'BAPI_MTRREADDOC_GETLIST'
      EXPORTING
        mrdatefrom        = lv_dat_pls_1
        mrdateto          = lv_dat_pls_1
        installation      = lv_anlage
        mrdocumenttype    = '2' "Résultat relevé
        mrreason          = '06'
      TABLES
        mrdocumentdata    = lt_mr_data
        mrdocumentreasons = lt_mr_reason.
    READ TABLE lt_mr_data INDEX 1 INTO ls_mr_data.
    IF sy-subrc = 0 .
      lv_date_mes = ls_rxx-date_fin_conso + 1.
    ENDIF.
  ENDIF.

  CLEAR lv_bim.
  SELECT SINGLE *
    FROM eanlh
    INTO ls_eanlh
    WHERE anlage = lv_anlage
      AND ableinh LIKE '%BM%'
      AND ab  LE lv_date_mes
      AND bis GE lv_date_mes.

*  CLEAR lv_bim.
*  SELECT SINGLE *
*    FROM eanlh
*    INTO ls_eanlh
*    WHERE anlage = lv_anlage
*      AND ableinh LIKE '%BM%'
*      AND ab  LE ls_rxx-date_fin_conso
*      AND bis GE ls_rxx-date_fin_conso.

*++ STOU FIN   GE-477
  IF sy-subrc IS INITIAL.
    lv_bim = abap_true.
  ENDIF.

  lv_int_ui = zcl_tool=>pod_check_exist(
                           iv_pce_num = ls_rxx-id_prm ).

* Récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = ls_rxx-date_fin_conso
    IMPORTING
      es_detail = ls_object
      ev_equnr  = lv_equnr
      ev_sernr  = lv_sernr.

*+GE-11728 {
  IF ls_rxx-motif_releve = 'MCT' OR ls_rxx-motif_releve = 'MCF'.
    PERFORM check_mct_mcf CHANGING ev_error.
    IF ev_error EQ abap_true.
      IF lv_statut_flux IS NOT INITIAL.
        PERFORM update_ligne_releve USING lv_statut_flux.
      ENDIF.
      RETURN.
    ENDIF.
  ENDIF.
*+GE-11728 }

  CLEAR ls_egerr.
  SELECT * FROM egerr
           INTO ls_egerr UP TO 1 ROWS
          WHERE equnr EQ lv_equnr
            AND bis   GE ls_rxx-date_fin_conso
            AND ab    LE ls_rxx-date_fin_conso.
  ENDSELECT.

  PERFORM controles_ligne_releve CHANGING ev_error.

  IF ev_error EQ abap_true.
    IF lv_statut_flux IS NOT INITIAL. "++GE-1709
      PERFORM update_ligne_releve USING lv_statut_flux.
    ENDIF. "++GE-1709
    RETURN.
  ENDIF.

*DEB-IBEN-20210107-GE-11157
  PERFORM f_ctrl_classe_temporelle CHANGING ev_error.
  IF ev_error IS NOT INITIAL.
    PERFORM update_ligne_releve USING lc_statut_06_rejet.
    RETURN.
  ENDIF.
*FIN-IBEN-20210107-GE-11157

************************************************************************
* Détermination du sous-processus de gestion d'une relève
* en fonction de la donnée "Evénement déclencheur" (flux R04)
* ou des données "Statut" ou "Motif" de relève     (flux R15/R16/R17)
************************************************************************
  lv_date_deb = ls_rxx-date_deb_conso . "GE-95

  CLEAR lv_recreation . "++GE-2318
  IF ls_rxx-id_flux EQ 'R04'.
* Détermination du processus en fonction de l'événement déclencheur
    CASE ls_rxx-even_declencheur.
      WHEN '0'.  "Facture de mise en service
        PERFORM processus_releve_emmenagement   CHANGING ev_error. "--GE-648
*DEB-IBEN
*      WHEN '1'.  "Facture sur relevé
      WHEN '1'  "Facture sur relevé
        OR '2'.  "Facture acompte intermédiaire
*FIN-IBEN
        PERFORM processus_releve_cyclique         CHANGING ev_error.
*DEB-IBEN
*      WHEN '2'   "Facture acompte intermédiaire
*        OR '4'.  "Facture de résiliation
      WHEN '4'.  "Facture de résiliation
*FIN-IBEN
        PERFORM processus_releve_a_filtrer        CHANGING ev_error.

      WHEN '3'.  "Facture événementielle
*++ STOU DEBUT GE-1491
        CLEAR ls_rxx_3 .
        READ TABLE lt_rxx_3 INTO ls_rxx_3 INDEX 1.
        IF ls_rxx_3-origine_index_a_f = 'X'.
          PERFORM processus_releve_cyclique  CHANGING ev_error.
        ELSE.
*++ STOU FIN   GE-1491
          IF ls_rxx-date_deb_conso EQ ls_rxx-date_fin_conso.
            PERFORM processus_releve_a_filtrer      CHANGING ev_error.
          ELSE.
            PERFORM processus_releve_evenement   USING iv_mode_test
                                                 CHANGING ev_error.
          ENDIF.
        ENDIF. "++GE-1491

      WHEN '9'.  "Redressement
        IF ls_rxx-mode_redressement EQ 'A'.
          PERFORM processus_releve_a_filtrer      CHANGING ev_error.
        ELSE.
          PERFORM processus_releve_redressement   CHANGING ev_error.
        ENDIF.
      WHEN OTHERS.
        PERFORM processus_releve_a_filtrer        CHANGING ev_error.
    ENDCASE.

  ELSEIF ls_rxx-id_flux EQ 'R15'.

* Détermination du processus en fonction
* ou du statut de relève ou du motif de relève
    IF ls_rxx-statut_releve EQ 'RECTIFICATIF'.
      PERFORM processus_releve_redressement       CHANGING ev_error.
    ELSE.
      CASE ls_rxx-motif_releve.
        WHEN 'CYCL' "Relevé cyclique
          OR 'FIAB'"Index réel utilisé pour fiabiliser une estimation
          OR 'AUTRE'. "++GE-1663
          PERFORM processus_releve_cyclique       CHANGING ev_error.
        WHEN 'CFNS' "Changement de fournisseur sortant
          OR 'RES'. "Résiliation
          PERFORM processus_releve_a_filtrer      CHANGING ev_error.
        WHEN 'CFNE' "Changement de fournisseur entrant
          OR 'MES'. "Mise en service
          IF lv_b2c = 'X' AND lv_bim = 'X'.
            PERFORM processus_releve_emmenagement   CHANGING ev_error.
          ELSE.
            PERFORM processus_releve_a_filtrer      CHANGING ev_error.
          ENDIF.
        WHEN 'MCT' "Modification de la formule tarifaire acheminement
          OR 'MCF'.                                         "+GE-11728
*-GE-11728 {
*          PERFORM processus_releve_evenement   USING iv_mode_test
*                                               CHANGING ev_error.
*-GE-11728 }
*+GE-11728 {
          PERFORM processus_releve_cyclique CHANGING ev_error.
*+GE-11728 }
        WHEN OTHERS.
*   DEB-GLIC-20200302-GE-8624 - On rejéte au lieu de filter
*          PERFORM processus_releve_a_filtrer      CHANGING ev_error.
*         PRM &1 : Motif &2 non géré
          IF 1 = 2. MESSAGE e277(zintf_e_messages). ENDIF.
          macro_add_msg_to_log 'E' '277'
                               ls_rxx-id_prm
                               ls_rxx-motif_releve
                               space
                               space.
          lv_statut_flux = lc_statut_06_rejet.
          ev_error = abap_true.
          PERFORM update_ligne_releve USING lv_statut_flux.
          RETURN.
*   FIN-GLIC-20200302-GE-8624
      ENDCASE.
    ENDIF.
  ELSEIF ls_rxx-id_flux EQ 'R16'.
*   A définir
  ELSEIF ls_rxx-id_flux EQ 'R17'.
    IF ls_rxx-statut_releve EQ 'RECTIFICATIF'.
      PERFORM processus_releve_redressement   CHANGING ev_error.
    ELSE. "INITIAL
*      IF ls_trnsco_rlv-type_event  = 'MES' .
      CASE ls_trnsco_rlv-transco_motif_rlv.
        WHEN 'CYCL'. "Relevé cyclique
          PERFORM processus_releve_cyclique    CHANGING ev_error.
        WHEN 'EVNT'.
          CLEAR : gv_r17_mea.
          PERFORM processus_releve_evenement   USING iv_mode_test
                                               CHANGING ev_error.
*DEB-IBEN-20190515-GE-5228
*          EXIT.
*FIN-IBEN-20190515-GE-5228
          "GE-6280:Début: [F.R17] MEA Synchro des R17 à J-1 du C12 de RES
          IF  gv_r17_mea EQ abap_true.
            EXIT.
          ENDIF.
          "GE-6280:Fin: [F.R17] MEA Synchro des R17 à J-1 du C12 de RES
        WHEN OTHERS.
          PERFORM processus_releve_a_filtrer   CHANGING ev_error.
      ENDCASE.
*      ENDIF.
    ENDIF.
  ENDIF.

  ls_rxx-date_deb_conso = lv_date_deb  . "GE-95

** les erreurs d'annulation (factures, doc et relèves) sont catchées avec un retour à 'R'
  IF ev_error EQ abap_true OR ev_error EQ 'R'.
    PERFORM update_ligne_releve USING lc_statut_06_rejet.
  ELSE.
    IF ls_rxx-id_flux EQ 'R04' AND ls_rxx-even_declencheur = '0'
       AND lv_filtre = abap_true.
      PERFORM update_ligne_releve USING lc_statut_11_filtre.
    ELSE.
*DEB-IBEN-20190515-GE-5228
*      IF ls_rxx-id_flux <> 'R17'.
*FIN-IBEN-20190515-GE-5228
      PERFORM update_ligne_releve USING lc_statut_07_integre.
*DEB-IBEN-20190515-GE-5228
*      ENDIF.
*FIN-IBEN-20190515-GE-5228
*++ STOU DEBUT GE-2318
      IF lv_recreation = abap_true.
        lv_prm_flux = ls_rxx-id_prm && | | && ls_rxx-id_flux .
        PERFORM f_processus_recreation USING ls_data_cycl
                                             ls_object
                                             lv_prm_flux.
      ENDIF.
*++ STOU FIN   GE-2318
    ENDIF.
  ENDIF.

  COMMIT WORK AND WAIT . "STOU OPE-658

ENDFUNCTION.
