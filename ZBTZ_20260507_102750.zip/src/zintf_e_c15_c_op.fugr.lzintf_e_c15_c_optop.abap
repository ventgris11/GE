* regenerated at 12.09.2019 11:03:16
FUNCTION-POOL ZINTF_E_C15_C_OP           MESSAGE-ID SV.

* INCLUDE LZINTF_E_C15_C_OPD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZINTF_E_C15_C_OPT00                    . "view rel. data dcl.
