*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZINTF_DSO_LOG
*   generation date: 11.06.2019 at 17:56:47
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZINTF_DSO_LOG       .

  PERFORM TABLEPROC.

ENDFUNCTION.
