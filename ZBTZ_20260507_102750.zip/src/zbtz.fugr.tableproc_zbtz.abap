*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZBTZ
*   generation date: 29.06.2021 at 14:47:43
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZBTZ                .

  PERFORM TABLEPROC.

ENDFUNCTION.
