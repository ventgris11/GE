FUNCTION zintf_g_ctrl_continuite_rlv .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
* Modification   (GE-11713)                                            *
* DATE       : 13/10/2021                                              *                                                                                                                                                                      *
* USER       : HBENDHAFER                                              *
* TAG        : HBD                                                     *
* Description: Controle de continuité pour les flux C existe déja dans *
* ZINTF_G_CTRL_INDEX_RLV  et   ZINTF_G_CTRL_DATE_RLV                   *
* OT         : DI1K928971                                              *
*"----------------------------------------------------------------------
* Modification   (GE-13361)                                            *
* DATE       : 29/04/2022                                              *                                                                                                                                                                      *
* USER       : HBENDHAFER                                              *
* TAG        : HBD                                                     *
* Description: Controle sur le champ zz* suite à la pose du compteur   *
* OT         : DI1K929448                                              *
*"----------------------------------------------------------------------
**
** Une fois extraites les relèves pertinentes déjà intégrées,
** et antérieures à celle à intégrer,
** un contrôle de cohérence s'effectue sur la date de la dernière relève
**
** La date de début de période doit être égale à la date de la dernière relève
**
** A l'exception de la relève faisant suite
** à une MES (Mise en Service) ou à un CHF (Changement de Fournisseur),
** et pour laquelle un décalage de plus ou moins N jours est toléré
** avec la date de MES ou de CHF
**
** Ce traitement particulier est dû à la relève qui est quasiment toujours en décalage
** avec l'ADIF
**
** Par défaut, la tolérance acceptable est de 5 jours
** mais elle peut être définie en paramètre
**
  DATA:
    lv_field     TYPE string,
    lv_equnr     TYPE equnr,
    lt_eabl      TYPE TABLE OF eabl,
    ls_eabl      TYPE eabl,
    ls_eablg     TYPE eablg,
    lv_ok        TYPE crmt_boolean,
    lv_message   TYPE char255,
    lv_low       TYPE rvari_val_255,
    lv_tolerance TYPE i,
    lv_date_min  TYPE dats,
    lv_date_max  TYPE dats,

    ls_bpem      TYPE zbpem_flux_struct,
    lv_msg       TYPE string,
    lv_interface TYPE zisu_flxid,

    lr_cx_root   TYPE REF TO cx_root.

  FIELD-SYMBOLS:
    <fs_emetteur>,
    <fs_flux>,
    <fs_idenreg>,
    <fs_num_pce>,
    <fs_date_releve>,
    <fs_debut_periode>,
    <fs_index_brut_debut>,
    <fs_index_brut_fin>,
    <fs_qual_index_brut_fin>,
    <fs_vol_brut_conso>,
    <fs_ind_pass_zero>,
    <fs_type>, <fs_raison>. "++GE-2200

  DEFINE macro_add_message_to_log.
    MESSAGE &1(zintf_g_messages)
       WITH &2
            &3
            &4
            &5
       INTO lv_message.
    RETURN.
  END-OF-DEFINITION.

  CLEAR: lv_field.
  MOVE 'FLUX-EMETTEUR'                    TO lv_field.
  ASSIGN (lv_field)                       TO <fs_emetteur>.

  CLEAR: lv_field.
  MOVE 'FLUX-FLUX'                        TO lv_field.
  ASSIGN (lv_field)                       TO <fs_flux>.

  CLEAR: lv_field.
  MOVE 'FLUX-IDENREG'                     TO lv_field.
  ASSIGN (lv_field)                       TO <fs_idenreg>.

  CLEAR: lv_field.
  MOVE 'FLUX-NUM_PCE'                     TO lv_field.
  ASSIGN (lv_field)                       TO <fs_num_pce>.

*++ STOU DEBUT GE-2200
  CLEAR: lv_field.
  MOVE 'FLUX-TYPE_RELEVE' TO lv_field.
  ASSIGN (lv_field) TO <fs_type>.

  CLEAR: lv_field.
  MOVE 'FLUX-RAISON_RELEVE' TO lv_field.
  ASSIGN (lv_field) TO <fs_raison>.

*-- STOU DEBUT GE-2204
*  IF <fs_flux> = 'RE6M' AND <fs_raison> IS ASSIGNED AND <fs_type> IS ASSIGNED .
*    IF <fs_raison> = '87' AND <fs_type> = 'S'.
*      CLEAR: lv_field.
*      MOVE 'FLUX-FIN_PERIODE' TO lv_field.
*      ASSIGN (lv_field) TO <fs_date_releve>.
*    ELSE.
*      CLEAR: lv_field.
*      MOVE 'FLUX-DATE_RELEVE' TO lv_field.
*      ASSIGN (lv_field) TO <fs_date_releve>.
*    ENDIF.
*  ELSE.
*    CLEAR: lv_field.
*    MOVE 'FLUX-DATE_RELEVE' TO lv_field.
*    ASSIGN (lv_field) TO <fs_date_releve>.
*  ENDIF.
*-- STOU FIN   GE-2204

  CLEAR: lv_field.
  MOVE 'FLUX-DATE_RELEVE'                 TO lv_field.
  ASSIGN (lv_field)                       TO <fs_date_releve>.

*++ STOU FIN   GE-2200

  CLEAR: lv_field.
  MOVE 'FLUX-DEBUT_PERIODE'               TO lv_field.
  ASSIGN (lv_field)                       TO <fs_debut_periode>.

  CLEAR lv_field.
  MOVE 'FLUX-INDEX_BRUT_DEBUT_PERIODE'    TO lv_field.
  ASSIGN (lv_field)                       TO <fs_index_brut_debut>.

  CLEAR lv_field.
  MOVE 'FLUX-INDEX_BRUT_FIN_PERIODE'      TO lv_field.
  ASSIGN (lv_field)                       TO <fs_index_brut_fin>.

  CLEAR lv_field.
  MOVE 'FLUX-QUAL_INDEX_BRUT_FIN_PERIODE' TO lv_field.
  ASSIGN (lv_field)                       TO <fs_qual_index_brut_fin>.

  CLEAR lv_field.
  MOVE 'FLUX-VOL_BRUT_CONSO'              TO lv_field.
  ASSIGN (lv_field)                       TO <fs_vol_brut_conso>.

  CLEAR lv_field.
  MOVE 'FLUX-IND_PASSAGE_ZERO_INDEX_BRUT' TO lv_field.
  ASSIGN (lv_field)                       TO <fs_ind_pass_zero>.

  IF sy-subrc NE 0.
    CLEAR lv_field.
    MOVE 'ABAP_FALSE'                     TO lv_field.
    ASSIGN (lv_field)                     TO <fs_ind_pass_zero>.
  ENDIF.

  ev_etape = 2.

  "&-<Début HBD-GE-11713
  IF <fs_type> = 'C'.
    ev_etape = 1.
    RETURN.
  ENDIF.
  "&-Fin HBD-GE-11713>



  CLEAR ls_bpem.
  ls_bpem-num_pce = <fs_num_pce>.
  CASE <fs_flux>.
    WHEN 'ADIF'.
      ls_bpem-date_effet_cont = <fs_date_releve>.
    WHEN 'RE6M' OR 'RE1M' OR 'REMM' OR 'REJJ' OR 'REJM'.
      ls_bpem-date_releve     = <fs_date_releve>.
    WHEN 'AFAC'.
      ls_bpem-date_fin_prest  = <fs_date_releve>.
  ENDCASE.

  CLEAR:
    lv_ok,
    lv_equnr,
    lt_eabl[].

**MFO 09/03/2017
* Vérification si la relève est comprise à +/- N jours
* en fonction de la tolérance définie ou non
* Si aucune valeur n'est définie, par défaut la tolérance est fixée à 5 jours
  lv_tolerance = 5.

* Récupération de la tolérance autorisée pour les premières relèves après MES / CHF
  SELECT SINGLE low
           INTO lv_low
           FROM tvarvc
          WHERE name EQ 'ZINTF_G_1ERE_RELEVE_TOLERANCE'.

  IF sy-subrc EQ 0.
    TRY.
        lv_tolerance = lv_low.
      CATCH cx_root INTO lr_cx_root.
        lv_tolerance = 5.
    ENDTRY.
  ENDIF.

  lv_date_min = <fs_debut_periode> - lv_tolerance.
  lv_date_max = <fs_debut_periode> + lv_tolerance.

*** Fin modif 09/03/2017
  CLEAR lv_ok.
  zcl_tool=>get_all_eabl_from_equipment(
    EXPORTING
      iv_ext_ui = <fs_num_pce>
"      iv_date   = <fs_debut_periode>
      iv_date   = lv_date_max
    IMPORTING
      ev_ok     = lv_ok
      ev_equnr  = lv_equnr
      et_eabl   = lt_eabl ).

  IF lv_ok EQ abap_false.
* Aucune relève pertinente pour le PCE &1 en date du &2
    MESSAGE e242(zintf_g_messages) WITH <fs_num_pce>
                                        <fs_debut_periode>
                                   INTO lv_msg.

    lv_interface = <fs_flux> .
    ls_bpem-idenreg = <fs_idenreg>.
    CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
      EXPORTING
        iv_interface_name = lv_interface
        iv_sparte         = 'ZG'
        is_structure      = ls_bpem.

    macro_add_message_to_log e242
                             <fs_num_pce>
                             <fs_debut_periode>
                             ' '
                             ' '.
  ENDIF.

*  SET PARAMETER ID 'EQN' FIELD lv_equnr.

* Suppression des relèves pertinentes postérieures ou égales
* à la date de la relève
  DELETE lt_eabl WHERE adat GE <fs_date_releve>.

  IF lt_eabl[] IS INITIAL.
* Aucune relève pertinente pour le PCE &1 en date du &2
    MESSAGE e242(zintf_g_messages) WITH <fs_num_pce>
                                        <fs_debut_periode>
                                   INTO lv_msg.

    lv_interface = <fs_flux> .
    ls_bpem-idenreg = <fs_idenreg>.
    CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
      EXPORTING
        iv_interface_name = lv_interface
        iv_sparte         = 'ZG'
        is_structure      = ls_bpem.

    macro_add_message_to_log e242
                             <fs_num_pce>
                             <fs_debut_periode>
                             ' '
                             ' '.
  ENDIF.

* Les relèves retenues sont triées par date de relève
* de la plus récente à la plus éloignée
* L'accès en lecture de la première permet donc de pointer
* sur la dernière relève intégrée
*++ STOU DEBUT GE-2204
*  DELETE lt_eabl WHERE zzidenreg IS INITIAL .
*++ GLIC - GE-3731 - suppression du tri car un tri existe déjà en amont dans la méthode "get_all_eabl_from_equipment"
*  SORT lt_eabl BY zzidenreg DESCENDING .
*++ GLIC - GE-3731 - Fin
*++ STOU FIN   GE-2204

  CLEAR ls_eabl.
  READ TABLE lt_eabl
        INTO ls_eabl INDEX 1.

* Vérification de la cohérence de continuité
*  IF ls_eabl-zzdate_fin EQ <fs_debut_periode>. "++GE-2204
*  IF ls_eabl-adat EQ <fs_debut_periode>.      "--GE-2204
  IF ls_eabl-zzdate_fin EQ <fs_debut_periode> OR gv_pose_225 EQ abap_true. "HBD-GE-13361: Erreur 225 - Nombre de roues incorrect

* Relève OK: cohérence de continuité de date
  ELSE.
* Vérification s'il s'agit d'une relève de MES ou de CHF
    CLEAR ls_eablg.
    SELECT SINGLE *
             FROM eablg
             INTO ls_eablg
            WHERE ablbelnr EQ ls_eabl-ablbelnr
              AND ablesgr  EQ '06'.

    IF sy-subrc NE 0.
*++ STOU DEBUT GE-2204
      DELETE lt_eabl WHERE zzidenreg IS INITIAL .
      IF ls_eabl-zzdate_fin NE <fs_debut_periode>.
        IF 1 = 2. MESSAGE e245(zintf_g_messages). ENDIF.
        MESSAGE e245(zintf_g_messages) WITH lv_equnr
                                            <fs_debut_periode>
                                            ls_eabl-adat
                                       INTO lv_msg.
        ls_bpem-idenreg = <fs_idenreg>.
        lv_interface = <fs_flux> .
        CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
          EXPORTING
            iv_interface_name = lv_interface
            iv_sparte         = 'ZG'
            is_structure      = ls_bpem.

* Equipement &1: Date début période &2 incohérente ( Relève du &3 )
        macro_add_message_to_log e245
                                 lv_equnr
                                 <fs_debut_periode>
                                 ls_eabl-adat
                                 ' '.

*      IF 1 = 2. MESSAGE e245(zintf_g_messages). ENDIF.
** Equipement &1: Date début période &2 incohérente ( Relève du &3 )
*      macro_add_message_to_log e245
*                               lv_equnr
*                               <fs_debut_periode>
*                               ls_eabl-adat
*                               ' '.
      ENDIF.
*++ STOU FIN   GE-2204
    ENDIF.

** Vérification si la relève est comprise à +/- N jours
** en fonction de la tolérance définie ou non
** Si aucune valeur n'est définie, par défaut la tolérance est fixée à 5 jours
*    lv_tolerance = 5.
*
** Récupération de la tolérance autorisée pour les premières relèves après MES / CHF
*    SELECT SINGLE low
*             INTO lv_low
*             FROM tvarvc
*            WHERE name EQ 'ZINTF_G_1ERE_RELEVE_TOLERANCE'.
*
*    IF sy-subrc EQ 0.
*      TRY.
*          lv_tolerance = lv_low.
*        CATCH cx_root INTO lr_cx_root.
*          lv_tolerance = 5.
*      ENDTRY.
*    ENDIF.
*
*    lv_date_min = <fs_debut_periode> - lv_tolerance.
*    lv_date_max = <fs_debut_periode> + lv_tolerance.

    IF ls_eabl-adat BETWEEN lv_date_min AND lv_date_max.
* Relève OK: cohérence de continuité de date
    ELSE.

      MESSAGE e245(zintf_g_messages) WITH lv_equnr
                                          <fs_debut_periode>
                                          ls_eabl-adat
                                     INTO lv_msg.
      ls_bpem-idenreg = <fs_idenreg>.
      lv_interface = <fs_flux> .
      CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
        EXPORTING
          iv_interface_name = lv_interface
          iv_sparte         = 'ZG'
          is_structure      = ls_bpem.

* Equipement &1: Date début période &2 incohérente ( Relève du &3 )
      macro_add_message_to_log e245
                               lv_equnr
                               <fs_debut_periode>
                               ls_eabl-adat
                               ' '.
    ENDIF.
  ENDIF.

* Contrôle de continuité des index
  IF <fs_index_brut_debut> NE ls_eabl-v_zwstand.
* Equipement &1: Index &2 du &3 incohérent avec Index &4
    IF 1 = 2. MESSAGE e238(zintf_g_messages). ENDIF.
    macro_add_message_to_log e238
                             lv_equnr
                             ls_eabl-v_zwstand
                             ls_eabl-adat
                             <fs_index_brut_debut>.
  ENDIF.

  IF  <fs_index_brut_fin> LT ls_eabl-v_zwstand
  AND <fs_vol_brut_conso> GT 0
  AND <fs_ind_pass_zero>  EQ 'N'.
    IF ( ls_eabl-ablestyp EQ '01'
         AND <fs_qual_index_brut_fin> CA 'CEM' )
    OR ( ls_eabl-ablestyp EQ '03'
         AND <fs_qual_index_brut_fin> EQ 'E' ).
* Equipement &1: Index &2 inférieur à Index &3 du &4 => A TRAITER
      IF 1 = 2. MESSAGE e239(zintf_g_messages). ENDIF.
      macro_add_message_to_log e239
                               lv_equnr
                               ls_eabl-v_zwstand
                               <fs_index_brut_fin>
                               ls_eabl-adat.
      RETURN.
    ENDIF.
  ENDIF.

  SET PARAMETER ID 'EAB' FIELD ls_eabl-ablbelnr.
  ev_etape = 1.

ENDFUNCTION.
