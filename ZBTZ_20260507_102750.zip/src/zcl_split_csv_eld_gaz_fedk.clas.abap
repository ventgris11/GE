CLASS zcl_split_csv_eld_gaz_fedk DEFINITION
  PUBLIC
  INHERITING FROM zcl_split_csv_eld_gaz_bord
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.
    METHODS exec_python REDEFINITION.
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.



CLASS ZCL_SPLIT_CSV_ELD_GAZ_FEDK IMPLEMENTATION.


  METHOD exec_python.
    DATA :
      lv_parameter       TYPE btcxpgpar,
      lv_status          TYPE btcxpgstat,
      lv_exitcode        TYPE btcxpgexit,
      ls_longtext        TYPE ty_longtext,
      lt_exec_protocol   TYPE TABLE OF btcxpm,
      lt_file_name_parts TYPE TABLE OF string.

    lv_parameter = `--file ` && i_name && ` --flux FEDK --emetteur ` && p_emet.


    CALL FUNCTION 'SXPG_COMMAND_EXECUTE'
      EXPORTING
        commandname                   = 'ZGENERATE_CSV_G'
        additional_parameters         = lv_parameter
      IMPORTING
        status                        = lv_status
        exitcode                      = lv_exitcode
      TABLES
        exec_protocol                 = lt_exec_protocol
      EXCEPTIONS
        no_permission                 = 1
        command_not_found             = 2
        parameters_too_long           = 3
        security_risk                 = 4
        wrong_check_call_interface    = 5
        program_start_error           = 6
        program_termination_error     = 7
        x_error                       = 8
        parameter_expected            = 9
        too_many_parameters           = 10
        illegal_command               = 11
        wrong_asynchronous_parameters = 12
        cant_enq_tbtco_entry          = 13
        jobcount_generation_error     = 14
        OTHERS                        = 15.

    IF sy-subrc  NE 0
    OR lv_status EQ 'E'.
      ls_longtext = i_name.
      " Fichier &1&2 : Erreur lors de l'appel du script python
      MESSAGE e004(zsplit_csv_eld_gaz) WITH ls_longtext-msgv1 ls_longtext-msgv2 INTO DATA(lv_dummy).
      po_log->add_sy_msg( ).
      " Raise the exception
      RAISE EXCEPTION TYPE zcx_split_eld_gaz_error.

    ENDIF.
  ENDMETHOD.
ENDCLASS.
