*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 22.04.2019 at 02:53:37
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
