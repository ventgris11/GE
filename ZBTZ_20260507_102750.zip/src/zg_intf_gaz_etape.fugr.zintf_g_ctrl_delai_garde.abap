FUNCTION zintf_g_ctrl_delai_garde .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
  DATA: lc_field_num_pce       TYPE fieldname VALUE 'NUM_PCE',
* DEB GE-3823 - FPE
        lc_field_date_creation TYPE fieldname VALUE 'DATE_CREATION',
* FIN GE-3823 - FPE
        lc_field_date_releve   TYPE fieldname VALUE 'DATE_RELEVE',
        lc_field_motif_releve  TYPE fieldname VALUE 'MOTIF_RELEVE',
        lc_field_statut        TYPE fieldname VALUE 'STATUT',
        lc_field_flux          TYPE fieldname VALUE 'FLUX',
        lc_field_idenreg       TYPE fieldname VALUE 'IDENREG',
        lc_field_emetteur      TYPE fieldname VALUE 'EMETTEUR',
        lv_field               TYPE string,
        lv_message             TYPE char255,
        lv_subobj              TYPE balsubobj,
        lv_date_garde          TYPE dats,
        ls_bpem                TYPE zbpem_flux_struct,
        lv_interface           TYPE zisu_flxid,
        lv_low                 TYPE char255.

  FIELD-SYMBOLS: <fs_num_pce>, <fs_date_creation>, <fs_date_releve>, <fs_motif_releve>, <fs_motif_statut>, <fs_flux>, <fs_idenreg>, <fs_emetteur>.
  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_flux INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.
  IF <fs_flux> IS NOT ASSIGNED.
  ENDIF.


  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.
  IF <fs_num_pce> IS NOT ASSIGNED.
  ENDIF.

* ++ GE-3823 - FPE - Prise en compte de la date de création pour délai de garde
  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_creation INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_creation>.
  IF <fs_date_creation> IS NOT ASSIGNED.
  ENDIF.
* GE-3823

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_releve>.
  IF <fs_date_releve> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_motif_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_motif_releve>.
  IF <fs_motif_releve> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_statut INTO lv_field.
  ASSIGN (lv_field) TO <fs_motif_statut>.
  IF <fs_motif_statut> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_idenreg INTO lv_field.
  ASSIGN (lv_field) TO <fs_idenreg>.
  IF <fs_idenreg> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_emetteur INTO lv_field.
  ASSIGN (lv_field) TO <fs_emetteur>.

* FPE GE-83 - implémentation RE1M
  IF <fs_flux> = 'RE6M'.
    lv_subobj = zcl_tool=>gc_log_subobject_re6m.
  ELSEIF <fs_flux> = 'RE1M'.
    lv_subobj = zcl_tool=>gc_log_subobject_re1m.
  ELSE.
    lv_subobj = zcl_tool=>gc_log_subobject_remm.
  ENDIF.
* FPE GE-83 Fin

* DEB - GLIC - 20190711 - GE-3823 - Lecture de ZINTF_G_DELAI_DE_GARDE dans TVARVC

  SELECT SINGLE low
         INTO lv_low
         FROM tvarvc
        WHERE name = 'ZINTF_G_DELAI_DE_GARDE'.

  IF sy-subrc <> 0.
    " Valeur par défaut de 5 jours si variable non trouvé
    lv_low = 5.
  ELSE.
*++ GE-3823
    lv_date_garde = <fs_date_creation> + lv_low.
*    lv_date_garde = <fs_date_releve> + lv_low.
* FIN GE-3823
  ENDIF.

*  lv_date_garde = <fs_date_releve> + 5.

* FIN - GLIC - 20190711 - GE-3823

  IF lv_date_garde GT sy-datum .
    ev_etape              = 1.
  ELSE.
    ev_etape              = 2.

    MESSAGE e215(zintf_g_messages) WITH <fs_emetteur> <fs_flux> <fs_idenreg> INTO lv_message.

    CLEAR ls_bpem.
    ls_bpem-num_pce = <fs_num_pce>.
    CASE <fs_flux>.
      WHEN 'ADIF'.
        ls_bpem-date_effet_cont = <fs_date_releve>.
      WHEN 'RE6M' OR 'RE1M' OR 'REMM' OR 'REJJ' OR 'REJM'.
        ls_bpem-date_releve     = <fs_date_releve>.
      WHEN 'AFAC'.
        ls_bpem-date_fin_prest  = <fs_date_releve>.
    ENDCASE.

    lv_interface    = <fs_flux>.
    IF <fs_idenreg> IS ASSIGNED .
      ls_bpem-idenreg = <fs_idenreg>.
    ENDIF.

    CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
      EXPORTING
        iv_interface_name = lv_interface
        iv_sparte         = 'ZG'
        is_structure      = ls_bpem.


  ENDIF.


ENDFUNCTION.
