*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 03.04.2019 at 18:10:39
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
