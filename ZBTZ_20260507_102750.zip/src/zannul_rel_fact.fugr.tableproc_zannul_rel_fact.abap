*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZANNUL_REL_FACT
*   generation date: 29.11.2021 at 15:56:23
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZANNUL_REL_FACT     .

  PERFORM TABLEPROC.

ENDFUNCTION.
