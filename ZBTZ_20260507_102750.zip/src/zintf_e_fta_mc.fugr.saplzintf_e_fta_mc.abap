* regenerated at 05.07.2024 10:17:08
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZINTF_E_FTA_MCTOP.                " Global Data
  INCLUDE LZINTF_E_FTA_MCUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZINTF_E_FTA_MCF...                " Subroutines
* INCLUDE LZINTF_E_FTA_MCO...                " PBO-Modules
* INCLUDE LZINTF_E_FTA_MCI...                " PAI-Modules
* INCLUDE LZINTF_E_FTA_MCE...                " Events
* INCLUDE LZINTF_E_FTA_MCP...                " Local class implement.
* INCLUDE LZINTF_E_FTA_MCT99.                " ABAP Unit tests
  INCLUDE LZINTF_E_FTA_MCF00                      . " subprograms
  INCLUDE LZINTF_E_FTA_MCI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
