FUNCTION z_fkk_sample_0650.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(I_RESULT) LIKE  FKKPY_0650_RESULT STRUCTURE
*"        FKKPY_0650_RESULT
*"     VALUE(I_PAYMENT_DATA) LIKE  FKKPY_0650_PAYMENT_DATA STRUCTURE
*"        FKKPY_0650_PAYMENT_DATA
*"  EXPORTING
*"     VALUE(E_RESULT) LIKE  FKKPY_0650_RESULT STRUCTURE
*"        FKKPY_0650_RESULT
*"  TABLES
*"      T_HOUSE_BANKS TYPE  FKKPY_0650_HOUSE_BANK_DATA_T
*"      T_PARTNER_BANKS TYPE  FKKPY_0650_PARTNER_BANK_T
*"      T_ITEMS STRUCTURE  FKKPY_0650 OPTIONAL
*"----------------------------------------------------------------------
  e_result = i_result.
  e_result-newchoice = i_result-standard.
  DATA : v_plafond TYPE rvari_val_255,
        v_plafond_neg TYPE rvari_val_255,
        w_house_banks TYPE fkkpy_0650_house_bank_data,
        v_hktid_new TYPE hktid.

  IF i_payment_data-opbuk = 'GDP2'.

    SELECT SINGLE low
    FROM tvarvc
    INTO v_plafond
    WHERE name = 'Z_PLAFOND_PREL_B2C'.

  ELSEIF i_payment_data-opbuk = 'GDP1'.
*DEB-IBEN-20210907-GE-12832

 "DEBUT-16: GE-16344
        "  OR i_payment_data-opbuk = 'GDP3'.
*FIN-16: GE-16344

*FIN-IBEN-20210907-GE-12832

    SELECT SINGLE low
    FROM tvarvc
    INTO v_plafond
    WHERE name = 'Z_PLAFOND_PREL_B2B'.

* Debut-16: GE-16344
    ELSEIF i_payment_data-opbuk = 'GDP3'.
    SELECT SINGLE low
    FROM tvarvc
    INTO v_plafond
    WHERE name = 'Z_PLAFOND_PREL_EKV'.
* Fin-16: GE-16344

  ENDIF.

  IF v_plafond IS INITIAL.
    e_result-newchoice = 00.
  ELSE.
    v_plafond_neg = v_plafond * -1.
"Juste pour les virements
    IF i_payment_data-rwbtr LT v_plafond_neg.
*    IF i_payment_data-rwbtr GT v_plafond
*      OR i_payment_data-rwbtr LT v_plafond_neg.

      READ TABLE t_house_banks
      INTO w_house_banks
      INDEX i_result-standard.

      SELECT SINGLE hktid_new
      FROM zparam_banque
      INTO v_hktid_new
      WHERE
      hbkid = w_house_banks-hbkid
      AND
      hktid = w_house_banks-hktid.

      READ TABLE t_house_banks
      WITH KEY
      hbkid = w_house_banks-hbkid
      hktid = v_hktid_new.
      IF sy-subrc = 0.
        e_result-newchoice = sy-tabix.
      ELSE.
        e_result-newchoice = 00.
      ENDIF.
    ELSE.
      e_result-newchoice = i_result-standard.
    ENDIF.
  ENDIF.
  "ENDIF.
* if special_logic_is_active.
*   e_result-newchoice = '02'.
* endif.
ENDFUNCTION.
