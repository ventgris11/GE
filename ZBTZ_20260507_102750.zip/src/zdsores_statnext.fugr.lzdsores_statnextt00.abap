*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 07.04.2019 at 13:51:40
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZDSORES_STATNEXT................................*
DATA:  BEGIN OF STATUS_ZDSORES_STATNEXT              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDSORES_STATNEXT              .
CONTROLS: TCTRL_ZDSORES_STATNEXT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDSORES_STATNEXT              .
TABLES: ZDSORES_STATNEXT               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
