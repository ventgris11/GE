FUNCTION-POOL ZFKCI                      . "MESSAGE-ID ...

INCLUDE lfkkaktiv2con.
INCLUDE lfkkaktiv2mac.

*-----------------------------------------------------------------------
* Declaration of constants
*-----------------------------------------------------------------------
CONSTANTS: c_header                 TYPE satztyp_i_kk VALUE '1'.
CONSTANTS: c_position               TYPE satztyp_i_kk VALUE '2'.
CONSTANTS: c_trailer                TYPE satztyp_i_kk VALUE '9'.
CONSTANTS: c_payment                TYPE postyp_kk    VALUE '1'.
CONSTANTS: c_recall                 TYPE postyp_kk    VALUE '2'.
CONSTANTS: c_master_data_changes    TYPE postyp_kk    VALUE '3'.
CONSTANTS: c_storno                 TYPE postyp_kk    VALUE '4'.
CONSTANTS: c_clearing               TYPE postyp_kk    VALUE '5'.
CONSTANTS: c_coll_ag_paid           TYPE postyp_kk    VALUE '6'.
CONSTANTS: c_cancelled_receivable   TYPE postyp_kk    VALUE '7'.
CONSTANTS: c_write_off              TYPE postyp_kk    VALUE '8'.
CONSTANTS: c_released               TYPE agsta_kk     VALUE '01'.
CONSTANTS: c_receivable_submitted   TYPE agsta_kk     VALUE '02'.
CONSTANTS: c_receivable_paid        TYPE agsta_kk     VALUE '03'.
CONSTANTS: c_receivable_part_paid   TYPE agsta_kk     VALUE '04'.
CONSTANTS: c_receivable_cancelled   TYPE agsta_kk     VALUE '05'.
CONSTANTS: c_receivable_write_off   TYPE agsta_kk     VALUE '06'.
CONSTANTS: c_agsta_cu_t-erfolglos   TYPE agsta_kk     VALUE '07'.
CONSTANTS: c_agsta_t-erfolglos      TYPE agsta_kk     VALUE '08'.
CONSTANTS: c_receivable_recalled    TYPE agsta_kk     VALUE '09'.
CONSTANTS: c_costumer_directly_paid TYPE agsta_kk     VALUE '10'.
CONSTANTS: c_costumer_partally_paid TYPE agsta_kk     VALUE '11'.
CONSTANTS: c_full_clearing          TYPE agsta_kk     VALUE '12'.
CONSTANTS: c_partial_clearing       TYPE agsta_kk     VALUE '13'.
CONSTANTS: c_receivable_part_write_off TYPE agsta_kk  VALUE '15'.
CONSTANTS: c_rec_recall_part_write_off TYPE agsta_kk  VALUE '16'.
CONSTANTS: c_sum_no                 TYPE sumknz_kk    VALUE ''.
CONSTANTS: c_sum_gpart              TYPE sumknz_kk    VALUE '1'.
CONSTANTS: c_sum_nrzas              TYPE sumknz_kk    VALUE '2'.
CONSTANTS: c_sum_vkont              TYPE sumknz_kk    VALUE '3'.
CONSTANTS: c_event_5051             LIKE tfkfbm-fbeve VALUE '5051'.
CONSTANTS: c_event_5052             LIKE tfkfbm-fbeve VALUE '5052'.
CONSTANTS: c_event_5053             LIKE tfkfbm-fbeve VALUE '5053'.
CONSTANTS: c_subname(04)            TYPE c            VALUE 'COLI'.
CONSTANTS: c_msgprio_high           LIKE fimsg-msgpr  VALUE '1'.
CONSTANTS: c_msgprio_medium         LIKE fimsg-msgpr  VALUE '2'.
CONSTANTS: c_msgprio_low            LIKE fimsg-msgpr  VALUE '3'.
CONSTANTS: c_msgprio_info           LIKE fimsg-msgpr  VALUE '4'.
CONSTANTS: c_inkgp(05)              TYPE c            VALUE 'INKGP'.
CONSTANTS: c_marked                 TYPE c            VALUE 'X'.
CONSTANTS: c_hstorno                TYPE herkf_kk     VALUE '02'.
CONSTANTS: c_hrueckl                TYPE herkf_kk     VALUE '08'.
CONSTANTS: c_hrausgl                TYPE herkf_kk     VALUE '09'.
CONSTANTS: c_htrausgl               TYPE herkf_kk     VALUE '39'.
CONSTANTS: c_buber_1059             TYPE buber_kk     VALUE '1059'.
CONSTANTS: c_only_log               TYPE c            VALUE 'X'.
CONSTANTS: true                     TYPE c            VALUE 'X'.
CONSTANTS: false                    TYPE c            VALUE space.
CONSTANTS: c_no_msg_per_service          TYPE i            VALUE '10'.

*-------------------- new appl. log for mass activity -----------------*
CONSTANTS: const_aktyp_wo   TYPE aktyp_kk   VALUE '0097',
           const_objtype_gp TYPE swo_objtyp VALUE 'CA_BUS1006',
           const_objtype_vk TYPE swo_typeid VALUE 'CA_CONTACC',
           error_id         LIKE fkk_mass_act_count-countid VALUE '1',
           success_id       LIKE fkk_mass_act_count-countid VALUE '2',
           test_id          LIKE fkk_mass_act_count-countid VALUE '3'.

*----------------------------------------------------------------------*
* Database tables
*----------------------------------------------------------------------*
TABLES:
  dfkkcoll,
  tfk050b.                                                  "0403ins.

*----------------------------------------------------------------------*
* Internal tables
*----------------------------------------------------------------------*
DATA: t_fkkcollh_i_w LIKE dfkkcollh_i_w OCCURS 0 WITH HEADER LINE.
DATA: ht_agsta_range LIKE fkkr_agsta    OCCURS 0 WITH HEADER LINE.
DATA: ht_gpart_range LIKE fkkr_gpart    OCCURS 0 WITH HEADER LINE.
DATA: gt_inkgp       TYPE inkgp_kk      OCCURS 0 WITH HEADER LINE.
DATA: gt_fall        TYPE gpart_kk      OCCURS 0 WITH HEADER LINE.
DATA  gt_dd07v       LIKE dd07v         OCCURS 0 WITH HEADER LINE.
DATA  w_basics       TYPE fkk_mad_basics.
DATA: BEGIN OF t_gpart_inkgp OCCURS 0,
        gpart LIKE dfkkcoll-gpart,
        inkgp LIKE dfkkcoll-inkgp,
      END OF t_gpart_inkgp.
DATA: BEGIN OF t_inkgp_gpart OCCURS 0,
        inkgp LIKE dfkkcoll-inkgp,
        gpart LIKE dfkkcoll-gpart,
      END OF t_inkgp_gpart.
DATA: BEGIN OF t_gpart_datum OCCURS 0,
        gpart LIKE dfkkcoll-gpart,
        datum LIKE dfkkcoli_log-udate,
        uzeit LIKE dfkkcoli_log-utime,                      "260402ins
      END OF t_gpart_datum.
DATA: BEGIN OF t_stor OCCURS 0,
        storb LIKE dfkkcollh-storb,
      END OF t_stor.

*----------------------------------------------------------------------*
* structure additional fields for mass interest run
*----------------------------------------------------------------------*
DATA: gr_inkgp      TYPE fkkinkgp,
      g_fkkcollinfo TYPE fkkcollinfo.

*----------------------------------------------------------------------*
* Data definitions
*----------------------------------------------------------------------*
DATA: g_xcpart       TYPE xcpart_kk,
      g_xausg        TYPE xausg_kk,
      g_xback        TYPE xback_kk,
      g_xrever       TYPE xrever_kk,
      g_xreclr       TYPE xreclr_kk,
      g_xretrn       TYPE xretrn_kk,
      g_xstorno      TYPE xstorno_kk,
      g_xwroff       TYPE xwroff_kk,
      g_param        TYPE c,
      h_applk        LIKE tfkfbc-applk,
      h_runkey       TYPE fkk_mad_runkey,
      w_runkey       TYPE fkk_mad_runkey,
      w_inkkey(25),
      h_file_name(128),
      t_fkkcollh_i   LIKE fkkcollh_i,
      t_fkkcollt_i   LIKE fkkcollt_i,
      rc             LIKE sy-subrc.
DATA: g_dcpfm        TYPE xudcpfm.


TYPES BEGIN OF gty_fkkcoli_log_ext.
TYPES inkgp  TYPE inkgp_kk.
TYPES gpart  TYPE gpart_kk.
TYPES coli_log_tab     TYPE fkkcoli_log_tab.
TYPES postyp_sum_tab   TYPE fkkcol_postyp_sum_tab.
TYPES END OF gty_fkkcoli_log_ext.

DATA  gv_flg_coll_esoa_active  TYPE xfeld.
DATA  gt_collections_hash  TYPE HASHED TABLE OF fkkcollections WITH UNIQUE KEY inkgp gpart.
DATA  gt_collections       TYPE TABLE OF fkkcollections.
DATA  gt_coli_log_ext_hash TYPE HASHED TABLE OF gty_fkkcoli_log_ext WITH UNIQUE KEY inkgp gpart.

*>>>>> HANA
DATA: gt_fkkcollp_ip_w LIKE dfkkcollp_ip_w OCCURS 0 WITH HEADER LINE,
      gt_fkkcoli_log   LIKE dfkkcoli_log   OCCURS 0 WITH HEADER LINE.
*<<<<<< HANA
*----------------------------------------------------------------------*
* function modules for application exit
*----------------------------------------------------------------------*
DATA: t_fbstab       LIKE tfkfbc OCCURS 1 WITH HEADER LINE,
      t_tfkfbc_5051  LIKE tfkfbc OCCURS 0 WITH HEADER LINE,
      t_tfkfbc_5052  LIKE tfkfbc OCCURS 0 WITH HEADER LINE,
      t_tfkfbc_5053  LIKE tfkfbc OCCURS 0 WITH HEADER LINE.

*----------------------------------------------------------------------*
* include for selection screen
*----------------------------------------------------------------------*
*include lfkcieve.
