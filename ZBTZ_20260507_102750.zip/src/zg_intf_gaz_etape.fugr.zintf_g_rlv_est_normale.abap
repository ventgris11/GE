FUNCTION ZINTF_G_RLV_EST_NORMALE .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

DATA: lc_field_type_releve TYPE FIELDNAME value 'TYPE_RELEVE',
      lv_field        type STRING
      .

FIELD-SYMBOLS: <FS>.

  clear: lv_field.
  CONCATENATE 'FLUX-' lc_field_type_releve INTO lv_field.
  assign (lv_field) TO <fs>.

  IF <FS> IS ASSIGNED.
    IF <FS> = 'N'.
      EV_ETAPE = 1.
    ELSE.
      EV_ETAPE = 2.
    ENDIF.
  ELSE.
  "Erreur technique
  ENDIF.

ENDFUNCTION.
