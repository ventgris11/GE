* regenerated at 13.06.2019 19:00:33
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZINTFDSOINFRALOGTOP.              " Global Data
  INCLUDE LZINTFDSOINFRALOGUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZINTFDSOINFRALOGF...              " Subroutines
* INCLUDE LZINTFDSOINFRALOGO...              " PBO-Modules
* INCLUDE LZINTFDSOINFRALOGI...              " PAI-Modules
* INCLUDE LZINTFDSOINFRALOGE...              " Events
* INCLUDE LZINTFDSOINFRALOGP...              " Local class implement.
* INCLUDE LZINTFDSOINFRALOGT99.              " ABAP Unit tests
  INCLUDE LZINTFDSOINFRALOGF00                    . " subprograms
  INCLUDE LZINTFDSOINFRALOGI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
