*----------------------------------------------------------------------*
***INCLUDE LE31CF02 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  check_no_display_1205
*&---------------------------------------------------------------------*
FORM check_no_display_1205  USING    p_postab  TYPE fkkepos
                            CHANGING p_do_not_display_line.

*Dont display budget billing payments already transferred
  IF  p_postab-astkz CA 'PZ'
  AND p_postab-augbl NE space
  AND p_postab-xanza EQ 'X'
  AND p_postab-augrd EQ '07'.
    p_do_not_display_line = 1.
    EXIT.
  ENDIF.

* don't display cleared collective bill documents with amount zero
* from the reversal of the invoicing
  IF p_postab-stakz = co_stakz_coll_bill_req
    AND p_postab-betrw = 0
    AND NOT p_postab-augst IS INITIAL
    AND p_postab-opbel = p_postab-augbl.
    p_do_not_display_line = 1.
    EXIT.
  ENDIF.

  DATA: h_count TYPE i.
* don't display collective bill documents which
* have amount equal zero and
* don't contain any items.
  IF p_postab-stakz = co_stakz_coll_bill_req
   AND p_postab-betrw = 0.

    CALL FUNCTION 'FKK_BP_LINE_ITEMS_SELECT'
      EXPORTING
        i_abwbl      = p_postab-opbel
        i_linecount  = 1
        i_count_flag = 'X'
      IMPORTING
        e_count      = h_count.
    IF h_count IS INITIAL.
      CALL FUNCTION 'FKK_REPEAT_LINE_ITEMS_SELECT'
        EXPORTING
          i_abwbl      = p_postab-opbel
          i_linecount  = 1
          i_count_flag = 'X'
        IMPORTING
          e_count      = h_count.
    ENDIF.
    IF h_count IS INITIAL.
      p_do_not_display_line = 1.
      EXIT.
    ENDIF.
  ENDIF.

* the following checks are not necessary for IS-T
  IF p_postab-applk <> co_applk_ist.
* JVL und ABS Zeilen mit AUGRD nicht beachten
    IF p_postab-augrd = co_augrd_jvl.
      p_do_not_display_line = 1.
      EXIT.
    ENDIF.
* Barzahler JVL-Zeile bei Ablauf der Zahlfrist nicht beachten
*  ermittle HVORG/TVORG des Barzahlerbelegs
    IF p_postab-stakz = co_stakz_bbp_req OR p_postab-stakz = 'Z'.
      DATA:  p_hvo  LIKE teivv-hvorg,
             p_tvo  LIKE teivv-tvorg,
             l_ejvl LIKE ejvl.

      CALL FUNCTION 'ISU_DB_TEIVV_SELECT'
        EXPORTING
          i_ihvor             = '0045'
          i_itvor             = '0030'
          i_applk             = 'R'
        IMPORTING
          e_hvorg             = p_hvo
          e_tvorg             = p_tvo
        EXCEPTIONS
          not_found           = 1
          int_trans_not_valid = 2
          trans_not_valid     = 3
          OTHERS              = 4.

      IF sy-subrc <> 0.
        EXIT.
      ENDIF.
* Posten finden
      IF p_postab-hvorg = p_hvo
      AND p_postab-tvorg = p_tvo.
* wenn bezahlt, dann immer berücksichtigen
        IF NOT p_postab-augbl IS INITIAL.
          IF  p_postab-augbl <> p_postab-opbel
          AND p_postab-augrd <> '06'.
            EXIT.
          ENDIF.
        ENDIF.
* wenn Posten nicht mehr bezahlt werden kann, dann nicht mehr beachten
        CALL FUNCTION 'ISU_DB_EJVL_SINGLE'
          EXPORTING
            x_opbel      = p_postab-opbel
            x_vertrag    = p_postab-vtref
          IMPORTING
            y_ejvl       = l_ejvl
          EXCEPTIONS
            not_found    = 1
            system_error = 2
            OTHERS       = 3.
        IF sy-subrc <> 0.
          EXIT.
        ENDIF.
* Posten nicht anzeigen, wenn Sy-Datum größer als Sperrdatum ist
        IF l_ejvl-fdate < sy-datum.
          p_do_not_display_line = 1.
          EXIT.
        ENDIF.
      ENDIF.
    ENDIF.
* Abschlagsanforderungen mit Betrag 0 nicht anzeigen
    IF p_postab-stakz = co_stakz_bbp_req
      AND p_postab-betrw = 0.
      p_do_not_display_line = 1.
      EXIT.
    ENDIF.

* umgebuchte Abschlagsanforderungen nicht anzeigen
    IF p_postab-stakz CA 'PZ' AND p_postab-augrd = '06'.
      p_do_not_display_line = 1.
      EXIT.
    ENDIF.


* gestoppte Abschlagspositionen nicht anzeigen
    IF ( p_postab-stakz CA 'PZ' OR p_postab-ori_stakz CA 'PZ' )
     AND p_postab-opbel = p_postab-augbl
     AND ( p_postab-augrd = co_augrd_stopped
      OR   p_postab-augrd = co_augrd_deact
      OR   p_postab-augrd = co_augrd_pc
      OR   p_postab-augrd = co_augrd_euro ).
      p_do_not_display_line = 1.
      EXIT.
    ENDIF.

  ENDIF. " not IS-T

* Deaktivierten Ratenplan nicht anzeigen
  IF (  p_postab-stakz = co_stakz_installments
     OR  p_postab-ori_stakz = co_stakz_installments )
     AND p_postab-opbel = p_postab-augbl
     AND p_postab-augrd = co_augrd_deact.
    p_do_not_display_line = 1.
    EXIT.
  ENDIF.

ENDFORM.                    " check_no_display_1205
*&---------------------------------------------------------------------*
*&      Form  fill_add_fields_1205
*&---------------------------------------------------------------------*
FORM fill_add_fields_1205  USING    p_langu      LIKE sy-langu
                                    p_header_arc TYPE fkkko
                           CHANGING p_postab     TYPE fkkepos.

  DATA:
        h_tfktvot LIKE tfktvot,
        h_tfkhvot LIKE tfkhvot,
        h_fkkvk   LIKE fkkvk,
        h_fkkko   LIKE fkkko,
        h_tfk033d LIKE tfk033d.

* local buffer for origin text
  DATA: BEGIN OF L_HTEXT OCCURS 5,
          HERKF TYPE HERKF_KK,
          HTEXT TYPE HTEXT_KK,
        END   OF L_HTEXT.

* fill physical existing items (FKKOP)
  IF p_postab-xzahl IS INITIAL.

    wa_hvtxt_buftab-hvorg = p_postab-hvorg.
    READ TABLE hvtxt_buftab FROM  wa_hvtxt_buftab
                             INTO wa_hvtxt_buftab.

    IF sy-subrc EQ 0.
      p_postab-hvtxt = wa_hvtxt_buftab-hvtxt.
    ELSE.
      CALL FUNCTION 'ISU_GET_ENTRY_FROM_TFKHVOT'
        EXPORTING
          x_spras   = p_langu
          x_applk   = p_postab-applk
          x_hvorg   = p_postab-hvorg
        IMPORTING
          y_tfkhvot = h_tfkhvot
        EXCEPTIONS
          not_found = 1
          OTHERS    = 2.

      IF sy-subrc = 0.
*        pi_postab-hvtxt = h_tfkhvot-txt30.
        p_postab-hvtxt = h_tfkhvot-txt30.
        wa_hvtxt_buftab-applk = p_postab-gpart.
        wa_hvtxt_buftab-hvorg = p_postab-hvorg.
        wa_hvtxt_buftab-hvtxt = p_postab-hvtxt.
        INSERT wa_hvtxt_buftab INTO TABLE hvtxt_buftab.
      ENDIF.
    ENDIF.
    CALL FUNCTION 'ISU_GET_TRANSACTION_TEXT'
      EXPORTING
        x_applk  = p_postab-applk
        x_spras  = p_langu
        x_bukrs  = p_postab-bukrs
        x_sparte = p_postab-spart
        x_hvorg  = p_postab-hvorg
        x_tvorg  = p_postab-tvorg
      IMPORTING
        h_votxt  = p_postab-votxt.
  ENDIF.

  IF p_postab-xzahl = 'X' .
    h_tfk033d-applk = p_postab-applk.
    IF p_postab-applk = co_applk_isu.
      h_tfk033d-buber = co_buber_r010.
    ELSEIF p_postab-applk = co_applk_ist.
      h_tfk033d-buber = co_buber_t010.
    ELSE.
      mac_msg_putx_wp co_msg_programming_error 898 'E9' 'APPLK'
                      p_postab-applk 'ISU_ACC_DISP_BASIC_LIST'
                                                          space space.
      IF 1 = 2.
* nur wegen Verwendungsnachweis
        MESSAGE a898(e9) WITH 'APPLK' p_postab-applk
                              'ISU_ACC_DISP_BASIC_LIST'.
      ENDIF.
    ENDIF.

* Get chart of accounts
    IF bufktopl IS INITIAL.
      CALL FUNCTION 'ISU_GET_CHART_OF_ACCOUNTS'
        EXPORTING
          x_bukrs      = p_postab-bukrs
        IMPORTING
          y_ktopl      = bufktopl
        EXCEPTIONS
          not_found    = 1
          system_error = 2
          OTHERS       = 3.
      IF sy-subrc = 1.
        mac_msg_putx co_msg_error sy-msgno sy-msgid
          sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 not_found.
      ELSEIF sy-subrc = 2.
        mac_msg_putx co_msg_error sy-msgno sy-msgid
          sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 not_found.
      ELSEIF sy-subrc <> 0.
        mac_msg_putx_wp co_msg_programming_error 898 'E9' 'sy-subrc'
                       sy-subrc 'ISU_ACC_DISP_BASIC_LIST_1205'
                                                     space space.
        IF 1 = 2.
* nur wegen Verwendungsnachweis
          MESSAGE a898(e9) WITH space space space space.
        ENDIF.
      ENDIF.
      h_tfk033d-ktopl = bufktopl.
    ELSE.
      h_tfk033d-ktopl = bufktopl.
    ENDIF.
    MOVE: p_postab-augrd  TO h_tfk033d-key01.


    CALL FUNCTION 'FKK_ACCOUNT_DETERMINE'
      EXPORTING
        i_tfk033d           = h_tfk033d
      IMPORTING
        e_tfk033d           = h_tfk033d
      EXCEPTIONS
        error_in_input_data = 1
        nothing_found       = 2
        OTHERS              = 3.

    IF sy-subrc = 0.
      p_postab-hvorg = h_tfk033d-fun01.
      p_postab-tvorg = h_tfk033d-fun02.
    ENDIF.

    CALL FUNCTION 'ISU_GET_ENTRY_FROM_TFKHVOT'
      EXPORTING
        x_spras   = p_langu
        x_applk   = p_postab-applk
        x_hvorg   = p_postab-hvorg
      IMPORTING
        y_tfkhvot = h_tfkhvot
      EXCEPTIONS
        not_found = 1
        OTHERS    = 2.

    IF sy-subrc = 0.
      p_postab-hvtxt = h_tfkhvot-txt30.
    ENDIF.

    CALL FUNCTION 'ISU_GET_ENTRY_FROM_TFKTVOT'
      EXPORTING
        x_spras   = p_langu
        x_applk   = p_postab-applk
        x_hvorg   = p_postab-hvorg
        x_tvorg   = p_postab-tvorg
      IMPORTING
        y_tfktvot = h_tfktvot
      EXCEPTIONS
        OTHERS    = 1.

    IF sy-subrc NE 0.
      CLEAR p_postab-votxt.
    ELSE.
      p_postab-votxt = h_tfktvot-txt30.
    ENDIF.
  ENDIF.

  IF p_postab-abwkt IS INITIAL AND
     p_postab-gpart NE g_gpart.
    CLEAR: vkont_buftab.
    REFRESH: vkont_buftab.
    g_gpart = p_postab-gpart.
  ENDIF.

  wa_vkont_buftab-gpart = p_postab-gpart.
  wa_vkont_buftab-vkont = p_postab-vkont.

  READ TABLE vkont_buftab INTO wa_vkont_buftab
                          WITH KEY gpart = p_postab-gpart
                                   vkont = p_postab-vkont
                             BINARY SEARCH.

  IF sy-subrc EQ 0.
    p_postab-vkbez = wa_vkont_buftab-vkbez.
  ELSE.
    CALL FUNCTION 'FKK_ACCOUNT_READ'
      EXPORTING
        i_vkont      = p_postab-vkont
      IMPORTING
        e_fkkvk      = h_fkkvk
      EXCEPTIONS
        not_found    = 1
        foreign_lock = 2
        OTHERS       = 3.

    IF sy-subrc EQ 0.
      p_postab-vkbez = h_fkkvk-vkbez.
      wa_vkont_buftab-gpart = p_postab-gpart.
      wa_vkont_buftab-vkont = p_postab-vkont.
      wa_vkont_buftab-vkbez = h_fkkvk-vkbez.
      INSERT wa_vkont_buftab INTO TABLE vkont_buftab.
    ENDIF.
  ENDIF.

* check optimizing setting (HANA)
  STATICS: LV_OPT_DET TYPE XFELD,            "optimizing determined?
           LV_OPT_ACT TYPE XFELD.            "optimizing active?
  DATA: lo_opt_settings TYPE REF TO if_fkk_optimization_settings.
  if lv_opt_det is initial.
    lo_opt_settings = cl_fkk_optimization_settings=>get_instance( ).
    case p_postab-applk.
      when 'R'.
        lv_opt_act = lo_opt_settings->is_active( cl_fkk_optimization_settings=>CC_ISU_ACCBAL_HEAD_MASS_FETCH ).
      when 'T'.
        lv_opt_act = lo_opt_settings->is_active( cl_fkk_optimization_settings=>CC_IST_ACCBAL_HEAD_MASS_FETCH ).
    endcase.
    lv_opt_det = 'X'.
  endif.

  IF wa_head_buftab-opbel NE p_postab-opbel.
    CLEAR wa_head_buftab. "new opbel=>new wa_head_buftab,cf.note 901895
    wa_head_buftab-opbel = p_postab-opbel.

*   for archived documents header data provided by framework
    CLEAR: h_fkkko.
    IF p_postab-xarch = 'X'.
      h_fkkko = p_header_arc.
    ELSE.
*   with optimization, DFKKKO is mass-read in event 1211 for all items
      if lv_opt_act is initial.
        CALL FUNCTION 'FKK_DOC_HEADER_SELECT_BY_OPBEL'
          EXPORTING
            i_opbel = p_postab-opbel
          IMPORTING
            e_fkkko = h_fkkko
          EXCEPTIONS
            OTHERS  = 1.
        IF sy-subrc <> 0.
          CLEAR h_fkkko.
        ENDIF.
*   do not read DFKKKO single mode, H_FKKKO stays initial for non-archived items
      ELSE.
      ENDIF.
    ENDIF.
    IF h_fkkko IS NOT INITIAL.
      wa_head_buftab-herkf = h_fkkko-herkf.
      IF wa_head_buftab-herkf = 'R4'
      OR wa_head_buftab-herkf = 'R5'
      OR wa_head_buftab-herkf = 'R6'.
        wa_head_buftab-xblnr = h_fkkko-xblnr.
      ENDIF.
      wa_head_buftab-cpudt = h_fkkko-cpudt.
      wa_head_buftab-cputm = h_fkkko-cputm.
      wa_head_buftab-ernam = h_fkkko-ernam.

      CLEAR wa_head_buftab-htext.

      IF LV_opt_act NE SPACE.
        READ TABLE L_HTEXT WITH KEY HERKF = H_FKKKO-HERKF.
        IF SY-SUBRC = 0.
          WA_HEAD_BUFTAB-HTEXT = L_HTEXT-HTEXT.
        ELSE.
          SELECT  SINGLE htext FROM  tfk001t INTO WA_HEAD_BUFTAB-HTEXT
            WHERE spras = sy-langu
            AND   herkf = H_FKKKO-HERKF.
          IF SY-SUBRC = 0.
            L_HTEXT-HERKF = H_FKKKO-HERKF.
            L_HTEXT-HTEXT = WA_HEAD_BUFTAB-HTEXT.
            APPEND L_HTEXT.
          ENDIF.
        ENDIF.
      ELSE.
        SELECT SINGLE htext FROM  tfk001t INTO wa_head_buftab-htext
         WHERE  spras       = p_langu
         AND    herkf       = wa_head_buftab-herkf.
      ENDIF.
    ENDIF.
  ENDIF.

  if lv_opt_act eq space
  or (     lv_opt_act ne space
       and p_postab-xarch ne space ).
    IF    wa_head_buftab-herkf = 'R4'
       OR wa_head_buftab-herkf = 'R5'
       OR wa_head_buftab-herkf = 'R6'.
      p_postab-xblnr = wa_head_buftab-xblnr.
    ELSE.
      p_postab-xblnr = p_postab-xblnr.
    ENDIF.
    p_postab-herkf = wa_head_buftab-herkf.
    p_postab-htext = wa_head_buftab-htext.
    p_postab-cpudt = wa_head_buftab-cpudt.
    p_postab-cputm = wa_head_buftab-cputm.
    p_postab-ernam_std = wa_head_buftab-ernam.
  endif.
*-----------------------------------------------------------------------
* don't display any payment if i_fkkl1-szahl is initial.
  IF wa_augrd_vorg_buffer IS INITIAL.
    CLEAR: h_tfk033d.
    h_tfk033d-key01 = '01'.
    h_tfk033d-applk = p_postab-applk.
    h_tfk033d-buber = '1091'.
    IF bufktopl IS INITIAL.
      CALL FUNCTION 'ISU_GET_CHART_OF_ACCOUNTS'
        EXPORTING
          x_bukrs      = p_postab-bukrs
        IMPORTING
          y_ktopl      = bufktopl
        EXCEPTIONS
          not_found    = 1
          system_error = 2
          OTHERS       = 3.
      IF sy-subrc = 1.
        mac_msg_putx co_msg_error sy-msgno sy-msgid
          sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 not_found.
      ELSEIF sy-subrc = 2.
        mac_msg_putx co_msg_error sy-msgno sy-msgid
          sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 not_found.
      ELSEIF sy-subrc <> 0.
        mac_msg_putx_wp co_msg_programming_error 898 'E9' 'sy-subrc'
                       sy-subrc 'ISU_ACC_DISP_BASIC_LIST_1205'
                                                     space space.
        IF 1 = 2.
* nur wegen Verwendungsnachweis
          MESSAGE a898(e9) WITH space space space space.
        ENDIF.
      ENDIF.
      h_tfk033d-ktopl = bufktopl.
    ELSE.
      h_tfk033d-ktopl = bufktopl.
    ENDIF.

    CALL FUNCTION 'FKK_ACCOUNT_DETERMINE'
      EXPORTING
        i_tfk033d           = h_tfk033d
      IMPORTING
        e_tfk033d           = h_tfk033d
      EXCEPTIONS
        error_in_input_data = 1
        nothing_found       = 2
        OTHERS              = 3.

    IF sy-subrc = 0.
      wa_augrd_vorg_buffer-hvorg = h_tfk033d-fun01.
      wa_augrd_vorg_buffer-tvorg = h_tfk033d-fun02.
    ENDIF.

  ENDIF.

ENDFORM.                    " fill_add_fields_1205
*&---------------------------------------------------------------------*
*&      Form  check_only_payment_list
*&---------------------------------------------------------------------*
*       check which items should only be displayed on payment list
*       but not on the receivables list
*----------------------------------------------------------------------*
FORM check_only_payment_list USING p_fkkl1        STRUCTURE fkkl1
                                   p_postab       STRUCTURE fkkepos
                                   p_payment_list TYPE boole-boole.

* Hide BBPlans and BBPayments which are invoiced already
  PERFORM check_old_bbp USING p_postab
                              p_payment_list.

* Cleared statistical positions
  PERFORM hide_cleared_stat_items USING p_fkkl1
                                        p_postab
                                        p_payment_list.

ENDFORM.                    " check_only_payment_list

*&---------------------------------------------------------------------*
*&     Form check_xeanz
*&---------------------------------------------------------------------*
*      unmark down payment (POSTAB-XEANZ) for main transaction 0270
*----------------------------------------------------------------------*
FORM check_xeanz  USING     p_postab       STRUCTURE fkkepos
                  CHANGING  e_postab       STRUCTURE fkkepos.

  DATA: wa_buffer_trans_list LIKE wa_invoice_trans.

  READ TABLE gt_buffer_trans_list INTO wa_buffer_trans_list
                                  WITH KEY applk = p_postab-applk
                                           hvorg = p_postab-hvorg
                                           tvorg = p_postab-tvorg
                                  BINARY SEARCH.

  IF sy-subrc <> 0.
    SELECT SINGLE * FROM tfkivv
    INTO wa_buffer_trans_list
    WHERE  applk = p_postab-applk
       AND hvorg = p_postab-hvorg
       AND tvorg = p_postab-tvorg.
    IF sy-subrc EQ 0.
      APPEND wa_buffer_trans_list TO gt_buffer_trans_list.
      SORT gt_buffer_trans_list BY applk hvorg tvorg.
    ENDIF.
  ENDIF.

  IF wa_buffer_trans_list-ihvor = co_ihv_umbufakt_cran.
    CLEAR e_postab-xeanz.
  ENDIF.


ENDFORM.                    "check_xeanz
*&---------------------------------------------------------------------*
*&      Form  DEREG_FIELDS
*&---------------------------------------------------------------------*
* INVOICING_PARTY füllen, falls ursprünglich ausgeglichene Positionen  *
* auch eine hatten. Ausgleich über mehrere Posten mit unterschied-     *
* licher Invoicing Party sollte nicht möglich sein. Ist die Invoicing  *
* Party gefüllt, so muss auch der Vertrag ergänzt werden.              *
*----------------------------------------------------------------------*
FORM dereg_fields USING pt_fkkop_ag TYPE fkkop_t
                        i_fkkop     TYPE fkkop
                        i_fkkko     TYPE fkkko
               CHANGING e_fkkopzf   TYPE fkkopzf
                        e_fkkopsf   TYPE fkkopsf.

  DATA: wa_fkkop_ag          TYPE fkkop,
        lv_inbound           TYPE xfeld,
        lv_outbound          TYPE xfeld,
        lv_agreement_inactiv TYPE xfeld,
        lv_initiator         TYPE e_deregsppartner,
        ls_param_inv_out     TYPE inv_param_inv_outbound,
        ls_pay_param         TYPE inv_param_inv_outbound_pay,
        ls_ever              TYPE ever.

  READ TABLE pt_fkkop_ag INTO wa_fkkop_ag INDEX 1.

  e_fkkopzf-invoicing_party = wa_fkkop_ag-invoicing_party.
  e_fkkopzf-ethppm          = wa_fkkop_ag-ethppm.
  e_fkkopzf-payfreqid       = wa_fkkop_ag-payfreqid.

  IF wa_fkkop_ag-invoicing_party IS INITIAL.
    EXIT.
  ENDIF.

  IF wa_fkkop_ag-vtref IS INITIAL.
    mac_msg_putx_we co_msg_error '061' 'EDER'
                                  wa_fkkop_ag-opbel
                                  wa_fkkop_ag-opupk
                                  wa_fkkop_ag-opupz
                                  wa_fkkop_ag-invoicing_party.
    IF 1 EQ 2. MESSAGE e061(eder) WITH space space space space. ENDIF.
  ENDIF.

  e_fkkopsf-vbund = i_fkkop-vbund.
  e_fkkopsf-vtref = i_fkkop-vtref.
  e_fkkopsf-spart = i_fkkop-spart.
  e_fkkopsf-kofiz = i_fkkop-kofiz.

  CLEAR ls_ever.
  CALL FUNCTION 'ISU_INTERNAL_VTREF_TO_VERTRAG'
    EXPORTING
      i_vtref   = wa_fkkop_ag-vtref
    IMPORTING
      e_vertrag = ls_ever-vertrag.
  CALL FUNCTION 'ISU_DB_EVER_SINGLE'
    EXPORTING
      x_vertrag = ls_ever-vertrag
    IMPORTING
      y_ever    = ls_ever.

  CALL FUNCTION 'ISU_DEREG_PARAM_INV_REM'
    EXPORTING
      x_process           = co_process_par_invoice_cust
      x_keydate           = i_fkkko-bldat
      x_ever_key          = ls_ever-vertrag
    IMPORTING
      y_param_inv_out     = ls_param_inv_out
      y_agreement_inactiv = lv_agreement_inactiv
    CHANGING
      xy_initiator        = lv_initiator
      xy_ever             = ls_ever
    EXCEPTIONS
      general_fault       = 1
      no_parameter_found  = 2
      internal_error      = 3
      OTHERS              = 4.
  IF sy-subrc NE 0.
    mac_msg_repeat_we co_msg_error.
  ENDIF.

  IF lv_agreement_inactiv EQ abap_false.
    READ TABLE ls_param_inv_out-pay_param INTO ls_pay_param
         WITH KEY servprov_pay = ls_ever-servprov_pay.
    IF sy-subrc NE 0.
      MESSAGE e610(edereg_inv) WITH ls_ever-servprov_pay
                                    lv_initiator.
    ENDIF.

    e_fkkopzf-ethppm    = ls_pay_param-thppm.
    e_fkkopzf-payfreqid = ls_pay_param-payfreqid.
  ENDIF.

ENDFORM.                    " DEREG_FIELDS
