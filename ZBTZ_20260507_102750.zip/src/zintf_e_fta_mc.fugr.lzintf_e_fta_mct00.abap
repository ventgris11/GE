*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 05.07.2024 at 10:17:08
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZINTF_E_FTA_MC..................................*
DATA:  BEGIN OF STATUS_ZINTF_E_FTA_MC                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_FTA_MC                .
CONTROLS: TCTRL_ZINTF_E_FTA_MC
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZINTF_E_FTA_MC                .
TABLES: ZINTF_E_FTA_MC                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
