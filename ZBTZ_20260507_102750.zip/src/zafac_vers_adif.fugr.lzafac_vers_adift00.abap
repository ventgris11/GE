*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 20.02.2019 at 16:37:18
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZAFAC_VERS_ADIF.................................*
DATA:  BEGIN OF STATUS_ZAFAC_VERS_ADIF               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZAFAC_VERS_ADIF               .
CONTROLS: TCTRL_ZAFAC_VERS_ADIF
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZAFAC_VERS_ADIF               .
TABLES: ZAFAC_VERS_ADIF                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
