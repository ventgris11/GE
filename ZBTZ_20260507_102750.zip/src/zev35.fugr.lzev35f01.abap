*----------------------------------------------------------------------*
***INCLUDE LEV35F01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  MULTIPLY_BLOCKS
*&---------------------------------------------------------------------*
*       Multiply price blocks for all following schema steps
*----------------------------------------------------------------------*
*      -->X_OPERAND1  Operand name factor (for error message)          *
*      -->X_OPERAND2  Operand name price                               *
*      -->X_FACTOR    Factor for multiplying the blocks                *
*      -->X_SS        actual schema step                               *
*      -->X_IOUTSTEPS table of schema steps for output processing      *
*      <--XY_IPREI    price table to  be changed                       *
*----------------------------------------------------------------------*
FORM MULTIPLY_BLOCKS USING    X_OPERAND1  LIKE TE221-OPERAND
                              X_OPERAND2  LIKE TE221-OPERAND
                              X_FACTOR    TYPE ISU2A_PACK16
                              X_SS        TYPE ISU2A_SS
                              X_IOUTSTEPS TYPE ISU2A_IOUTPUT_STEPS
                     CHANGING XY_IPREI    TYPE ISU2A_IPREI.

  INCLUDE IEAPRCCO.

  DATA: WPREI  TYPE ISU2A_PREI,
        WOUTSTEPS TYPE ISU2A_OUTPUT_STEPS,
        MAX_ZONE LIKE EPREIH-BISZONE.

  IF X_FACTOR = 0.
    MAC_ERR '143' 'AJ' X_OPERAND1 SPACE SPACE SPACE GENERAL_FAULT.
    IF 1 = 2. MESSAGE E143(AJ). ENDIF.
  ENDIF.
* calculate the maximal possible block value to avoid a data
* overflow
  IF X_FACTOR > 1.
    MAX_ZONE = CO_BLOCK_INFINITE / X_FACTOR.
  ELSE.
    MAX_ZONE = CO_BLOCK_INFINITE.
  ENDIF.

* Multiply the blocks of the qprice for all following schemasteps in
* the same logical schema with the output operand of this variant
* as an input operand.
  LOOP AT X_IOUTSTEPS INTO WOUTSTEPS
  WHERE CSNO_FROM = X_SS-CSNO
  AND   OPERAND   = X_OPERAND2.
    READ TABLE XY_IPREI WITH KEY CSNO = WOUTSTEPS-CSNO_INTO
                             TRANSPORTING NO FIELDS BINARY SEARCH.
    CHECK SY-SUBRC = 0.
    LOOP AT XY_IPREI FROM SY-TABIX INTO WPREI.
      IF WPREI-CSNO <> WOUTSTEPS-CSNO_INTO.
        EXIT.
      ENDIF.
      MULTIPLY WPREI-VONZONE BY X_FACTOR.
      IF WPREI-BISZONE > MAX_ZONE OR
         WPREI-BISZONE = CO_BLOCK_INFINITE.
*       If last block has the maximum value: This exemption is allowed
*       and no changes are necessary.
        IF WPREI-BISZONE < CO_BLOCK_INFINITE.
          MAC_ERR '145' 'AJ' X_FACTOR WPREI-PREIS SPACE
                                  SPACE GENERAL_FAULT.
          IF 1 = 2. MESSAGE E145(AJ). ENDIF.
        ENDIF.
      ELSE.
        MULTIPLY WPREI-BISZONE BY X_FACTOR.
      ENDIF.
      MODIFY XY_IPREI FROM WPREI.
    ENDLOOP.                           "xy_iprei
    MAC_ERR_READ 'xy_prei' X_SS-PROGRAMM SPACE.

  ENDLOOP.                             "x_ioutsteps
ENDFORM.                               " MULTIPLY_BLOCKS

*&---------------------------------------------------------------------*
*&      Form  MULTIPLY_BLOCKS_prorate
*&---------------------------------------------------------------------*

FORM MULTIPLY_BLOCKS_PRORATE
                     USING    X_OPERAND1  LIKE TE221-OPERAND
                              X_OPERAND2  LIKE TE221-OPERAND
                              X_FACTOR    TYPE ISU2A_PACK16
                              X_AB        TYPE ABZEITSCH
                              X_BIS       TYPE BISZEITSCH
                              X_SS        TYPE ISU2A_SS
                              X_IOUTSTEPS TYPE ISU2A_IOUTPUT_STEPS
                     CHANGING XY_IPREI    TYPE ISU2A_IPREI.

  INCLUDE IEAPRCCO.

  DATA: WPREI  TYPE ISU2A_PREI,
        WOUTSTEPS TYPE ISU2A_OUTPUT_STEPS,
        MAX_ZONE LIKE EPREIH-BISZONE.

  IF X_FACTOR = 0.
    MAC_ERR '143' 'AJ' X_OPERAND1 SPACE SPACE SPACE GENERAL_FAULT.
    IF 1 = 2. MESSAGE E143(AJ). ENDIF.
  ENDIF.
* calculate the maximal possible block value to avoid a data
* overflow
  IF X_FACTOR > 1.
    MAX_ZONE = CO_BLOCK_INFINITE / X_FACTOR.
  ELSE.
    MAX_ZONE = CO_BLOCK_INFINITE.
  ENDIF.

* Take proration into account
* Multiply the blocks of the qprice for all following schemasteps in
* the same logical schema with the output operand of this variant
* as an input operand.
  LOOP AT X_IOUTSTEPS INTO WOUTSTEPS
  WHERE CSNO_FROM = X_SS-CSNO
  AND   OPERAND   = X_OPERAND2.
    READ TABLE XY_IPREI WITH KEY CSNO = WOUTSTEPS-CSNO_INTO
                                 AB   = X_AB
                                 BIS  = X_BIS
                             TRANSPORTING NO FIELDS BINARY SEARCH.
    CHECK SY-SUBRC = 0.
    LOOP AT XY_IPREI FROM SY-TABIX INTO WPREI
    WHERE AB  = X_AB
    AND   BIS = X_BIS.
      IF WPREI-CSNO <> WOUTSTEPS-CSNO_INTO.
        EXIT.
      ENDIF.
      MULTIPLY WPREI-VONZONE BY X_FACTOR.
      IF WPREI-BISZONE > MAX_ZONE OR
         WPREI-BISZONE = CO_BLOCK_INFINITE.
*       If last block has the maximum value: This exeption is allowed
*       and no changes are necessary.
        IF WPREI-BISZONE < CO_BLOCK_INFINITE.
          MAC_ERR '145' 'AJ' X_FACTOR WPREI-PREIS SPACE
                                  SPACE GENERAL_FAULT.
          IF 1 = 2. MESSAGE E145(AJ). ENDIF.
        ENDIF.
      ELSE.
        MULTIPLY WPREI-BISZONE BY X_FACTOR.
      ENDIF.
      MODIFY XY_IPREI FROM WPREI.
    ENDLOOP.                           "xy_iprei
    MAC_ERR_READ 'xy_prei' X_SS-PROGRAMM SPACE.

  ENDLOOP.                             "x_ioutsteps

ENDFORM.                    " MULTIPLY_BLOCKS_prorate


*---------------------------------------------------------------------*
*       FORM get_unit_price                                           *
*---------------------------------------------------------------------*
FORM GET_UNIT_PRICE  USING  X_ICENTRAL       TYPE  ICENTRAL_TYPE
                            X_PROCESS_TRANS  TYPE  CHAR5
                            X_I1_I2_OPERAND  TYPE  E_OPERAND
                            X_I3_I4_OPERAND  TYPE  E_OPERAND
                            X_ID_ACT         TYPE  ISU2A_PACK16
                            X_PRICE1         TYPE  ISU2A_PREI-PRICE_NEW
                            X_PRICE2         TYPE  ISU2A_PREI-PRICE_NEW
                            X_OP_I1_OPERAND  TYPE  E_OPERAND" 581361
                  CHANGING  XY_U_PRICE       TYPE  ISU2A_PACK16
                            XY_AAD_CT        TYPE  I
                            XY_P_PEAK        TYPE  ISU2A_PACK16
                            XY_ADW_LOAD      TYPE  ISU2A_PACK16
                            XY_AAD_LOAD      TYPE  ISU2A_PACK16
                            XY_IINFO         TYPE  IINFO.



  DATA: WCENTRAL     TYPE   WCENTRAL_TYPE.
  DATA: WCENTRAL2    LIKE   WCENTRAL.

  DATA: S_QNT        TYPE   ISU2A_PACK16.
  DATA: TP_LOAD      TYPE  ISU2A_PACK16.
  DATA: NL_LOAD      TYPE  ISU2A_PACK16.

  DATA: NOV_LOAD     TYPE  ISU2A_PACK16.
  DATA: DEC_LOAD     TYPE  ISU2A_PACK16.
  DATA: JAN_LOAD     TYPE  ISU2A_PACK16.
  DATA: FEB_LOAD     TYPE  ISU2A_PACK16.
  DATA: MAR_LOAD     TYPE  ISU2A_PACK16.
  DATA: APR_LOAD     TYPE  ISU2A_PACK16.
  DATA: MAY_LOAD     TYPE  ISU2A_PACK16.
  DATA: JUN_LOAD     TYPE  ISU2A_PACK16.
  DATA: JUL_LOAD     TYPE  ISU2A_PACK16.
  DATA: AUG_LOAD     TYPE  ISU2A_PACK16.
  DATA: SEP_LOAD     TYPE  ISU2A_PACK16.
  DATA: OCT_LOAD     TYPE  ISU2A_PACK16.

  DATA: TP_NOV_LOAD  TYPE  ISU2A_PACK16.
  DATA: TP_DEC_LOAD  TYPE  ISU2A_PACK16.
  DATA: TP_JAN_LOAD  TYPE  ISU2A_PACK16.
  DATA: TP_FEB_LOAD  TYPE  ISU2A_PACK16.
  DATA: TP_MAR_LOAD  TYPE  ISU2A_PACK16.
  DATA: TP_APR_LOAD  TYPE  ISU2A_PACK16.
  DATA: TP_MAY_LOAD  TYPE  ISU2A_PACK16.
  DATA: TP_JUN_LOAD  TYPE  ISU2A_PACK16.
  DATA: TP_JUL_LOAD  TYPE  ISU2A_PACK16.
  DATA: TP_AUG_LOAD  TYPE  ISU2A_PACK16.
  DATA: TP_SEP_LOAD  TYPE  ISU2A_PACK16.
  DATA: TP_OCT_LOAD  TYPE  ISU2A_PACK16.

  DATA: NL_NOV_LOAD  TYPE  ISU2A_PACK16.
  DATA: NL_DEC_LOAD  TYPE  ISU2A_PACK16.
  DATA: NL_JAN_LOAD  TYPE  ISU2A_PACK16.
  DATA: NL_FEB_LOAD  TYPE  ISU2A_PACK16.
  DATA: NL_MAR_LOAD  TYPE  ISU2A_PACK16.
  DATA: NL_APR_LOAD  TYPE  ISU2A_PACK16.
  DATA: NL_MAY_LOAD  TYPE  ISU2A_PACK16.
  DATA: NL_JUN_LOAD  TYPE  ISU2A_PACK16.
  DATA: NL_JUL_LOAD  TYPE  ISU2A_PACK16.
  DATA: NL_AUG_LOAD  TYPE  ISU2A_PACK16.
  DATA: NL_SEP_LOAD  TYPE  ISU2A_PACK16.
  DATA: NL_OCT_LOAD  TYPE  ISU2A_PACK16.

  DATA: AAD_LOAD     TYPE  ISU2A_PACK16.
  DATA: ADW_LOAD     TYPE  ISU2A_PACK16.

  DATA: SWI_LOAD     TYPE  ISU2A_PACK16.
  DATA: MXW_LOAD     TYPE  ISU2A_PACK16.
  DATA: MXW_NL_LOAD  TYPE  ISU2A_PACK16.  "+++++

  DATA: MWI_LOAD     TYPE  ISU2A_PACK16.
  DATA: TP_MWI_LOAD  TYPE  ISU2A_PACK16.
  DATA: NL_MWI_LOAD  TYPE  ISU2A_PACK16.

  DATA: NOV_CT       TYPE  I.
  DATA: DEC_CT       TYPE  I.
  DATA: JAN_CT       TYPE  I.
  DATA: FEB_CT       TYPE  I.
  DATA: MAR_CT       TYPE  I.
  DATA: APR_CT       TYPE  I.
  DATA: MAY_CT       TYPE  I.
  DATA: JUN_CT       TYPE  I.
  DATA: JUL_CT       TYPE  I.
  DATA: AUG_CT       TYPE  I.
  DATA: SEP_CT       TYPE  I.
  DATA: OCT_CT       TYPE  I.

  DATA: AAD_CT       TYPE  I.
  DATA: ADW_CT       TYPE  I.


  DATA: NOV_DCV     TYPE  ISU2A_PACK16.
  DATA: DEC_DCV     TYPE  ISU2A_PACK16.
  DATA: JAN_DCV     TYPE  ISU2A_PACK16.
  DATA: FEB_DCV     TYPE  ISU2A_PACK16.
  DATA: MAR_DCV     TYPE  ISU2A_PACK16.
  DATA: APR_DCV     TYPE  ISU2A_PACK16.
  DATA: MAY_DCV     TYPE  ISU2A_PACK16.
  DATA: JUN_DCV     TYPE  ISU2A_PACK16.
  DATA: JUL_DCV     TYPE  ISU2A_PACK16.
  DATA: AUG_DCV     TYPE  ISU2A_PACK16.
  DATA: SEP_DCV     TYPE  ISU2A_PACK16.
  DATA: OCT_DCV     TYPE  ISU2A_PACK16.
  DATA: NOV_AB      LIKE  SY-DATUM VALUE '99991231'.
  DATA: DEC_AB      LIKE  SY-DATUM VALUE '99991231'.
  DATA: JAN_AB      LIKE  SY-DATUM VALUE '99991231'.
  DATA: FEB_AB      LIKE  SY-DATUM VALUE '99991231'.
  DATA: MAR_AB      LIKE  SY-DATUM VALUE '99991231'.
  DATA: APR_AB      LIKE  SY-DATUM VALUE '99991231'.
  DATA: MAY_AB      LIKE  SY-DATUM VALUE '99991231'.
  DATA: JUN_AB      LIKE  SY-DATUM VALUE '99991231'.
  DATA: JUL_AB      LIKE  SY-DATUM VALUE '99991231'.
  DATA: AUG_AB      LIKE  SY-DATUM VALUE '99991231'.
  DATA: SEP_AB      LIKE  SY-DATUM VALUE '99991231'.
  DATA: OCT_AB      LIKE  SY-DATUM VALUE '99991231'.
  DATA: NOV_BIS     LIKE  SY-DATUM.
  DATA: DEC_BIS     LIKE  SY-DATUM.
  DATA: JAN_BIS     LIKE  SY-DATUM.
  DATA: FEB_BIS     LIKE  SY-DATUM.
  DATA: MAR_BIS     LIKE  SY-DATUM.
  DATA: APR_BIS     LIKE  SY-DATUM.
  DATA: MAY_BIS     LIKE  SY-DATUM.
  DATA: JUN_BIS     LIKE  SY-DATUM.
  DATA: JUL_BIS     LIKE  SY-DATUM.
  DATA: AUG_BIS     LIKE  SY-DATUM.
  DATA: SEP_BIS     LIKE  SY-DATUM.
  DATA: OCT_BIS     LIKE  SY-DATUM.


  DATA: WINFO TYPE WINFO.
* DATA: Y_IINFO TYPE IINFO.

  DATA: CHAR_AB         TYPE CHAR3   VALUE '_AB'.
  DATA: CHAR_BIS        TYPE CHAR4   VALUE '_BIS'.
  DATA: CHAR_CT         TYPE CHAR3   VALUE '_CT'.
  DATA: CHAR_CONS       TYPE CHAR10  VALUE '_LOAD'.
  DATA: CHAR_TRANS      TYPE CHAR10  VALUE '_LOAD'.
  DATA: FELDNAME_TRANS  TYPE CHAR12.
  DATA: FELDNAME_CONS   TYPE CHAR12.
  DATA: FELDNAME        TYPE CHAR12.
  FIELD-SYMBOLS <STRUKTURFELD> TYPE ANY.


  DATA: U_PRICE      TYPE  ISU2A_PACK16.

  DATA: P_PEAK       TYPE  ISU2A_PACK16.
  DATA: C_PEAK       TYPE  ISU2A_PACK16.
  DATA: C_2_1        TYPE  ISU2A_PACK16.
  DATA: C_1_1        TYPE  ISU2A_PACK16.


* Macro determining maximum
  DEFINE: MAC_MAX_LOAD.
*   &1 First parameter to be maximized
*   &2 Second parameter for comparison
    IF &1 < &2.
      &1 = &2.
    ENDIF.
  END-OF-DEFINITION.
  DEFINE: MAC_PREP_FILL_IINFO.
    CASE SY-INDEX.
      WHEN 1.
        FELDNAME = 'JAN'.
        FELDNAME_TRANS = 'TP_JAN'.
        FELDNAME_CONS  = 'NL_JAN'.
      WHEN 2.
        FELDNAME = 'FEB'.
        FELDNAME_TRANS = 'TP_FEB'.
        FELDNAME_CONS  = 'NL_FEB'.
      WHEN 3.
        FELDNAME = 'MAR'.
        FELDNAME_TRANS = 'TP_MAR'.
        FELDNAME_CONS  = 'NL_MAR'.
      WHEN 4.
        FELDNAME = 'APR'.
        FELDNAME_TRANS = 'TP_APR'.
        FELDNAME_CONS  = 'NL_APR'.
      WHEN 5.
        FELDNAME = 'MAY'.
        FELDNAME_TRANS = 'TP_MAY'.
        FELDNAME_CONS  = 'NL_MAY'.
      WHEN 6.
        FELDNAME = 'JUN'.
        FELDNAME_TRANS = 'TP_JUN'.
        FELDNAME_CONS  = 'NL_JUN'.
      WHEN 7.
        FELDNAME = 'JUL'.
        FELDNAME_TRANS = 'TP_JUL'.
        FELDNAME_CONS  = 'NL_JUL'.
      WHEN 8.
        FELDNAME = 'AUG'.
        FELDNAME_TRANS = 'TP_AUG'.
        FELDNAME_CONS  = 'NL_AUG'.
      WHEN 9.
        FELDNAME = 'SEP'.
        FELDNAME_TRANS = 'TP_SEP'.
        FELDNAME_CONS  = 'NL_SEP'.
      WHEN 10.
        FELDNAME = 'OCT'.
        FELDNAME_TRANS = 'TP_OCT'.
        FELDNAME_CONS  = 'NL_OCT'.
      WHEN 11.
        FELDNAME = 'NOV'.
        FELDNAME_TRANS = 'TP_NOV'.
        FELDNAME_CONS  = 'NL_NOV'.
      WHEN 12.
        FELDNAME = 'DEC'.
        FELDNAME_TRANS = 'TP_DEC'.
        FELDNAME_CONS  = 'NL_DEC'.
    ENDCASE.

  END-OF-DEFINITION.


  C_2_1   =   21 / 10.
  C_1_1   =   11 / 10.

  CLEAR: XY_U_PRICE,
         XY_AAD_CT.

* Regarding all non-transposed and transposed volumes
  LOOP AT X_ICENTRAL INTO WCENTRAL
    WHERE ( PROCESS = 'SPLIT'  OR
            PROCESS = 'REBLT'   )
    AND OPERAND = X_I1_I2_OPERAND.
*   ---------------------------------------------------------
*   Accessing table section with actually transposed volumes
    LOOP AT X_ICENTRAL INTO WCENTRAL2
      WHERE PROCESS = X_PROCESS_TRANS
      AND   DATE    = WCENTRAL-DATE
      AND   OPERAND = X_I1_I2_OPERAND.
      EXIT.
    ENDLOOP.
*   ------------------------------------------------------------
*   Get final priority value for S_QNT.But get NL_LOAD resp.
*   TP_LOAD as well-defined non-transposed volume resp. trans-
*   posed volume
    IF SY-SUBRC = 0.
      S_QNT   =  WCENTRAL2-QNT_NEW.
      TP_LOAD =  WCENTRAL2-QNT_NEW.
    ELSE.
      S_QNT   = WCENTRAL-QNT_NEW.
      TP_LOAD = WCENTRAL-QNT_NEW.
    ENDIF.
    NL_LOAD = WCENTRAL-QNT_NEW.
*   ---------------------------------------------------------------
*   Summation for Average Annual Daily Load AAD_LOAD
    ADD S_QNT TO AAD_LOAD.
    ADD 1 TO AAD_CT.
*   --------------------------------------------------------------
*   Maximizing daily peak load MWX_LOAD for customers with
*   daily readings
    CASE WCENTRAL-DATE+4(2).
      WHEN '11' OR '12' OR '01' OR '02' OR '03'.
        MAC_MAX_LOAD MXW_LOAD S_QNT.
        MAC_MAX_LOAD MXW_NL_LOAD NL_LOAD. "+++++
    ENDCASE.
*   ----------------------------------------------------------------
*   Preparing peak determination for monthly case and interruptible
*   case. Regarding all winter months NOV,DEC,JAN,FEB,MAR
    CASE WCENTRAL-DATE+4(2).
      WHEN '11'.
        ADD  S_QNT    TO  NOV_LOAD.
        ADD  NL_LOAD  TO  NL_NOV_LOAD.
        ADD  TP_LOAD  TO  TP_NOV_LOAD.
        ADD  1        TO  NOV_CT.
        IF WCENTRAL-DATE < NOV_AB.
          NOV_AB = WCENTRAL-DATE.
        ENDIF.
        IF WCENTRAL-DATE > NOV_BIS.
          NOV_BIS = WCENTRAL-DATE.
        ENDIF.
      WHEN '12'.
        ADD  S_QNT    TO  DEC_LOAD.
        ADD  NL_LOAD  TO  NL_DEC_LOAD.
        ADD  TP_LOAD  TO  TP_DEC_LOAD.
        ADD  1        TO  DEC_CT.
        IF WCENTRAL-DATE < DEC_AB.
          DEC_AB = WCENTRAL-DATE.
        ENDIF.
        IF WCENTRAL-DATE > DEC_BIS.
          DEC_BIS = WCENTRAL-DATE.
        ENDIF.
      WHEN '01'.
        ADD  S_QNT    TO  JAN_LOAD.
        ADD  NL_LOAD  TO  NL_JAN_LOAD.
        ADD  TP_LOAD  TO  TP_JAN_LOAD.
        ADD  1        TO  JAN_CT.
        IF WCENTRAL-DATE < JAN_AB.
          JAN_AB = WCENTRAL-DATE.
        ENDIF.
        IF WCENTRAL-DATE > JAN_BIS.
          JAN_BIS = WCENTRAL-DATE.
        ENDIF.
      WHEN '02'.
        ADD  S_QNT    TO  FEB_LOAD.
        ADD  NL_LOAD  TO  NL_FEB_LOAD.
        ADD  TP_LOAD  TO  TP_FEB_LOAD.
        ADD  1        TO  FEB_CT.
        IF WCENTRAL-DATE < FEB_AB.
          FEB_AB = WCENTRAL-DATE.
        ENDIF.
        IF WCENTRAL-DATE > FEB_BIS.
          FEB_BIS = WCENTRAL-DATE.
        ENDIF.
      WHEN '03'.
        ADD  S_QNT    TO  MAR_LOAD.
        ADD  NL_LOAD  TO  NL_MAR_LOAD.
        ADD  TP_LOAD  TO  TP_MAR_LOAD.
        ADD  1        TO  MAR_CT.
        IF WCENTRAL-DATE < MAR_AB.
          MAR_AB = WCENTRAL-DATE.
        ENDIF.
        IF WCENTRAL-DATE > MAR_BIS.
          MAR_BIS = WCENTRAL-DATE.
        ENDIF.
      WHEN '04'.
        ADD  NL_LOAD  TO  NL_APR_LOAD.
        ADD  TP_LOAD  TO  TP_APR_LOAD.
        ADD  1        TO  APR_CT.
        IF WCENTRAL-DATE < APR_AB.
          APR_AB = WCENTRAL-DATE.
        ENDIF.
        IF WCENTRAL-DATE > APR_BIS.
          APR_BIS = WCENTRAL-DATE.
        ENDIF.
      WHEN '05'.
        ADD  NL_LOAD  TO  NL_MAY_LOAD.
        ADD  TP_LOAD  TO  TP_MAY_LOAD.
        ADD  1        TO  MAY_CT.
        IF WCENTRAL-DATE < MAY_AB.
          MAY_AB = WCENTRAL-DATE.
        ENDIF.
        IF WCENTRAL-DATE > MAY_BIS.
          MAY_BIS = WCENTRAL-DATE.
        ENDIF.
      WHEN '06'.
        ADD  NL_LOAD  TO  NL_JUN_LOAD.
        ADD  TP_LOAD  TO  TP_JUN_LOAD.
        ADD  1        TO  JUN_CT.
        IF WCENTRAL-DATE < JUN_AB.
          JUN_AB = WCENTRAL-DATE.
        ENDIF.
        IF WCENTRAL-DATE > JUN_BIS.
          JUN_BIS = WCENTRAL-DATE.
        ENDIF.
      WHEN '07'.
        ADD  NL_LOAD  TO  NL_JUL_LOAD.
        ADD  TP_LOAD  TO  TP_JUL_LOAD.
        ADD  1        TO  JUL_CT.
        IF WCENTRAL-DATE < JUL_AB.
          JUL_AB = WCENTRAL-DATE.
        ENDIF.
        IF WCENTRAL-DATE > JUL_BIS.
          JUL_BIS = WCENTRAL-DATE.
        ENDIF.
      WHEN '08'.
        ADD  NL_LOAD  TO  NL_AUG_LOAD.
        ADD  TP_LOAD  TO  TP_AUG_LOAD.
        ADD  1        TO  AUG_CT.
        IF WCENTRAL-DATE < AUG_AB.
          AUG_AB = WCENTRAL-DATE.
        ENDIF.
        IF WCENTRAL-DATE > AUG_BIS.
          AUG_BIS = WCENTRAL-DATE.
        ENDIF.
      WHEN '09'.
        ADD  NL_LOAD  TO  NL_SEP_LOAD.
        ADD  TP_LOAD  TO  TP_SEP_LOAD.
        ADD  1        TO  SEP_CT.
        IF WCENTRAL-DATE < SEP_AB.
          SEP_AB = WCENTRAL-DATE.
        ENDIF.
        IF WCENTRAL-DATE > SEP_BIS.
          SEP_BIS = WCENTRAL-DATE.
        ENDIF.
      WHEN '10'.
        ADD  NL_LOAD  TO  NL_OCT_LOAD.
        ADD  TP_LOAD  TO  TP_OCT_LOAD.
        ADD  1        TO  OCT_CT.
        IF WCENTRAL-DATE < OCT_AB.
          OCT_AB = WCENTRAL-DATE.
        ENDIF.
        IF WCENTRAL-DATE > OCT_BIS.
          OCT_BIS = WCENTRAL-DATE.
        ENDIF.
    ENDCASE.
*   ----------------------------------------------------------
  ENDLOOP.

* Filling of table IINFO
  DO 12 TIMES.

    MAC_PREP_FILL_IINFO.

    FELDNAME+3 = CHAR_AB.
    ASSIGN (FELDNAME) TO <STRUKTURFELD>.
    WINFO-FROM =  <STRUKTURFELD>.
    FELDNAME+3 = CHAR_BIS.
    ASSIGN (FELDNAME) TO <STRUKTURFELD>.
    WINFO-TO   =  <STRUKTURFELD>.
    FELDNAME+3 = CHAR_CT.
    ASSIGN (FELDNAME) TO <STRUKTURFELD>.
    WINFO-ZEITANT   =  <STRUKTURFELD>.
    FELDNAME_CONS+6 = CHAR_CONS.
    ASSIGN (FELDNAME_CONS) TO <STRUKTURFELD>.
    WINFO-VOL_CONS =  <STRUKTURFELD>.
    FELDNAME_TRANS+6 = CHAR_TRANS.
    ASSIGN (FELDNAME_TRANS) TO <STRUKTURFELD>.
    WINFO-VOL_TRANS =  <STRUKTURFELD>.

    APPEND WINFO TO XY_IINFO.


  ENDDO.

* Getting final value for Average Annual Daily Load AAD_LOAD
  AAD_LOAD  = AAD_LOAD / AAD_CT.
  XY_AAD_CT = AAD_CT.

* Getting final value for Average Daily Winter Load ADW_LOAD
  ADW_LOAD =
     ( NOV_LOAD + DEC_LOAD + JAN_LOAD + FEB_LOAD + MAR_LOAD ) /
     ( NOV_CT   + DEC_CT   + JAN_CT   + FEB_CT   + MAR_CT   ).

* November: Getting final values NOV_LOAD, NL_NOV_LOAD, TP_NOV_LOAD
  NOV_LOAD    = NOV_LOAD    / NOV_CT.
  NL_NOV_LOAD = NL_NOV_LOAD / NOV_CT.
  TP_NOV_LOAD = TP_NOV_LOAD / NOV_CT.
  MAC_MAX_LOAD  MWI_LOAD     NOV_LOAD.
  MAC_MAX_LOAD  NL_MWI_LOAD  NL_NOV_LOAD.
  MAC_MAX_LOAD  TP_MWI_LOAD  TP_NOV_LOAD.

* December: Getting final values DEC_LOAD, NL_DEC_LOAD, TP_DEC_LOAD
  DEC_LOAD    = DEC_LOAD    / DEC_CT.
  NL_DEC_LOAD = NL_DEC_LOAD / DEC_CT.
  TP_DEC_LOAD = TP_DEC_LOAD / DEC_CT.
  MAC_MAX_LOAD  MWI_LOAD     DEC_LOAD.
  MAC_MAX_LOAD  NL_MWI_LOAD  NL_DEC_LOAD.
  MAC_MAX_LOAD  TP_MWI_LOAD  TP_DEC_LOAD.

* January: Getting final values JAN_LOAD, NL_JAN_LOAD, TP_JAN_LOAD
  JAN_LOAD    = JAN_LOAD    / JAN_CT.
  NL_JAN_LOAD = NL_JAN_LOAD / JAN_CT.
  TP_JAN_LOAD = TP_JAN_LOAD / JAN_CT.
  MAC_MAX_LOAD  MWI_LOAD     JAN_LOAD.
  MAC_MAX_LOAD  NL_MWI_LOAD  NL_JAN_LOAD.
  MAC_MAX_LOAD  TP_MWI_LOAD  TP_JAN_LOAD.

* February: Getting final values FEB_LOAD, NL_FEB_LOAD, TP_FEB_LOAD
  FEB_LOAD    = FEB_LOAD    / FEB_CT.
  NL_FEB_LOAD = NL_FEB_LOAD / FEB_CT.
  TP_FEB_LOAD = TP_FEB_LOAD / FEB_CT.
  MAC_MAX_LOAD  MWI_LOAD     FEB_LOAD.
  MAC_MAX_LOAD  NL_MWI_LOAD  NL_FEB_LOAD.
  MAC_MAX_LOAD  TP_MWI_LOAD  TP_FEB_LOAD.

* March: Getting final values MAR_LOAD, NL_MAR_LOAD, TP_MAR_LOAD
  MAR_LOAD    = MAR_LOAD    / MAR_CT.
  NL_MAR_LOAD = NL_MAR_LOAD / MAR_CT.
  TP_MAR_LOAD = TP_MAR_LOAD / MAR_CT.
  MAC_MAX_LOAD  MWI_LOAD     MAR_LOAD.
  MAC_MAX_LOAD  NL_MWI_LOAD  NL_MAR_LOAD.
  MAC_MAX_LOAD  TP_MWI_LOAD  TP_MAR_LOAD.

* Determine C_PEAK for monthly case. Please note C_PEAK >= 1.
  IF MWI_LOAD <= 0.
    C_PEAK = 1.
  ELSE.
    C_PEAK = C_2_1 - ( C_1_1 * AAD_LOAD / MWI_LOAD ).
    IF C_PEAK < 1.
      C_PEAK = 1.
    ENDIF.
  ENDIF.

* Final peak determination:
  IF X_ID_ACT = '1'.
*   Monthly case: Maximum of monthly loads * multiplier C_PEAK
    P_PEAK = MWI_LOAD * C_PEAK.
  ELSEIF X_ID_ACT = '2'.
*   Daily case: Maximum daily winter load
    P_PEAK = MXW_LOAD.
  ELSEIF X_ID_ACT = '3'.
*  Interruptible case: Maximum transposed - Maximum non transposed
    IF X_I1_I2_OPERAND = X_OP_I1_OPERAND.
*   Daily case, stable volume: Maximum daily winter load
      P_PEAK = MXW_LOAD.
    ELSE.
*   Daily case, interuptible volume
*      P_PEAK = TP_MWI_LOAD - NL_MWI_LOAD.  "+++++++
      P_PEAK =  MXW_LOAD - MXW_NL_LOAD.   "+++++++
    ENDIF.  " note 581361
  ENDIF.

  IF AAD_LOAD <> 0.
* Final determination of gas load balancing unit price
    U_PRICE =
     (  X_PRICE1  *  (  P_PEAK    -  ADW_LOAD  )  +
        X_PRICE2  *  (  ADW_LOAD  -  AAD_LOAD  )     ) /
     (  AAD_LOAD *     AAD_CT ).
  ELSE.
    U_PRICE = 0.
  ENDIF.

  XY_U_PRICE = U_PRICE.

  XY_P_PEAK   = P_PEAK.
  XY_ADW_LOAD = ADW_LOAD.
  XY_AAD_LOAD = AAD_LOAD.
*>>> Fill the values for the winter load table IINFO
  LOOP AT XY_IINFO INTO WINFO.
    CASE WINFO-FROM+4(2).
      WHEN 11.
        WINFO-WINTER_LOAD = NOV_LOAD.
      WHEN 12.
        WINFO-WINTER_LOAD = DEC_LOAD.
      WHEN 01.
        WINFO-WINTER_LOAD = JAN_LOAD.
      WHEN 02.
        WINFO-WINTER_LOAD = FEB_LOAD.
      WHEN 03.
        WINFO-WINTER_LOAD = MAR_LOAD.
    ENDCASE.
    MODIFY XY_IINFO FROM WINFO.
  ENDLOOP.

ENDFORM. " get_unit_price
*&---------------------------------------------------------------------*
*&      Form  IINFO_FILL_COMPLETE
*&---------------------------------------------------------------------*
FORM IINFO_FILL_COMPLETE USING X_SPLIT    LIKE REGEN-KENNZX
                               X_OP       TYPE ISU2A_VARIANT_PARAMETERS
                               X_OPERAND  TYPE E_OPERAND
                               X_ICENTRAL TYPE ICENTRAL_TYPE
                               X_TUD1     TYPE ISU2A_PACK16
                               X_TUD2_S   TYPE ISU2A_PACK16
                               X_TUD2_I   TYPE ISU2A_PACK16
                      CHANGING XY_IINFO   TYPE IINFO.


  DATA WINFO     TYPE WINFO.
  DATA WCENTRAL  TYPE WCENTRAL_TYPE.
  DATA DCV       TYPE ISU2A_PACK16.
  DATA TUD       TYPE ISU2A_PACK16.
  DATA S_TUD     TYPE ISU2A_PACK16.
  DATA S_OPERAND TYPE E_OPERAND.

  IF X_SPLIT = 1.
    LOOP AT XY_IINFO INTO WINFO.
      CLEAR DCV.
      CLEAR TUD.
      LOOP AT X_ICENTRAL INTO WCENTRAL
        WHERE PROCESS = 'DCV1'
        AND   DATE >= WINFO-FROM
        AND   DATE <= WINFO-TO.
        ADD WCENTRAL-QNT_PD_NEW TO DCV.
        ADD X_TUD1 TO TUD.
      ENDLOOP.
      WINFO-DCV = DCV.
      WINFO-TUD = TUD.
      MODIFY XY_IINFO FROM WINFO.
    ENDLOOP.

  ELSE.
    IF X_OP-I1-OPERAND = X_OPERAND.
      S_OPERAND = X_OP-I3-OPERAND.
      S_TUD = X_TUD2_S.
    ELSE.
      S_OPERAND = X_OP-I4-OPERAND.
      S_TUD = X_TUD2_I.
    ENDIF.
    LOOP AT XY_IINFO INTO WINFO.
      CLEAR DCV.
      CLEAR TUD.
      LOOP AT X_ICENTRAL INTO WCENTRAL
        WHERE PROCESS = 'DCV2'
        AND   OPERAND = S_OPERAND
        AND   DATE >= WINFO-FROM
        AND   DATE <= WINFO-TO.
        ADD WCENTRAL-QNT_PD_NEW TO DCV.
        ADD S_TUD TO TUD.
      ENDLOOP.
      WINFO-DCV = DCV.
      WINFO-TUD = TUD.
      MODIFY XY_IINFO FROM WINFO.
    ENDLOOP.



  ENDIF.  " x_split

ENDFORM.                    " IINFO_FILL_COMPLETE

*&---------------------------------------------------------------------*
*&      Form  CALC_AVG_PRICE
*&---------------------------------------------------------------------*
FORM CALC_AVG_PRICE USING X_IPREI       TYPE ISU2A_IPREI
                          X_CSNO        LIKE ERCHZ-CSNO
                          X_NUMBER      LIKE ISU2A_OPER-NUMBER
                          X_PREIS       TYPE E_PREIS
                          X_AB          TYPE ABZEITSCH
                          X_BIS         TYPE BISZEITSCH
                          X_OPERAND     TYPE E_OPERAND
                 CHANGING Y_PREISBTR    LIKE ERCHZ-PREISBTR
                          Y_TIMPORT     LIKE ERCHZ-ZEITANT
                          Y_TIMTYP      LIKE ERCHZ-TIMTYP.

  INCLUDE IEAPRCCO.

  DATA:    V_TIMPORT     LIKE   ERCHZ-ZEITANT.
  DATA:    WPREI         TYPE   ISU2A_PREI.
  DATA:    V_MNGBASIS    LIKE   EPREIH-MNGBASIS.
  DATA:    C1(25)        TYPE   C.
  DATA:    C2(25)        TYPE   C.
  DATA:    CHECK_DATE    LIKE   WPREI-BIS.
  DATA:    S_TIMBASIS    LIKE   EDSC-TIMBASIS.


  LOOP AT X_IPREI INTO WPREI
       WHERE  CSNO     =  X_CSNO
       AND    NUMBER   =  X_NUMBER
       AND    PREIS    =  X_PREIS
       AND    BIS     >=  X_AB
       AND    AB      <=  X_BIS.
*   Store the information of the timtyp for
*   FORM GET_TIMBASIS
    IF WPREI-PREISTYP = CO_PTYP_TIME_DEP.
      IF Y_TIMTYP <> WPREI-TIMTYP
      AND NOT Y_TIMTYP IS INITIAL.
        MAC_MSG_PUT 'E910(AH)' X_OPERAND
                     SPACE SPACE SPACE GENERAL_FAULT.
        IF 1 = 2. MESSAGE E910(AH) WITH SPACE. ENDIF.
      ENDIF.
      Y_TIMTYP = WPREI-TIMTYP.
    ENDIF.

* In case of an time dependent price the time base has
* to be considered for the caluclation of the avergage
* price
    IF WPREI-PREISTYP = CO_PTYP_TIME_DEP.
      S_TIMBASIS = WPREI-TIMBASIS.
    ELSE.
      S_TIMBASIS = 1.
    ENDIF.
*   Check if there is any gap in definition of price operand
    IF NOT CHECK_DATE IS INITIAL.
      IF WPREI-AB <> CHECK_DATE.
        CHECK_DATE = CHECK_DATE - 1.
        CONCATENATE CHECK_DATE '<>' WPREI-AB INTO C1
                    SEPARATED BY SPACE.
        MAC_MSG_PUT 'E908(AH)' X_PREIS  SPACE SPACE SPACE GENERAL_FAULT.
        IF 1 = 2. MESSAGE E908(AH) WITH SPACE. ENDIF.
*        MAC_ERR '899' 'E9'
*           'Simulation period not covered by price operand'
*            X_OP_I1_OPERAND  C1 Space  GENERAL_FAULT.
*        IF 1 = 2. MESSAGE E899(E9) WITH SPACE SPACE SPACE SPACE. ENDIF.
      ENDIF.
    ENDIF.
    CHECK_DATE = WPREI-BIS + 1.
*   Please note that it is important to have precondition NORMAL PRICE
*   here. In case of block/scale prices and price zone adjustment
*   inside the variants ( QUANTI01 ) there are local temporary  price
*   tables. Only for normal prices OBJ-IPREI is well-defined everywhere.
    IF WPREI-PREISART <> CO_PART_NORMAL.
      MAC_MSG_PUT 'E909(AH)' SPACE SPACE SPACE SPACE GENERAL_FAULT.
      IF 1 = 2. MESSAGE E909(AH). ENDIF.
*        MAC_ERR '899' 'E9'
*            'ISU_COMPUT25'  'WPREI-PREISART <> CO_PART_NORMAL'
*            WPREI-PREISART  '0' GENERAL_FAULT.
*      IF 1 = 2. MESSAGE E899(E9) WITH SPACE SPACE SPACE SPACE. ENDIF.
    ENDIF.
    IF WPREI-MNGBASIS <> 0.
      V_MNGBASIS = WPREI-MNGBASIS.
    ELSE.
      V_MNGBASIS = 1.
    ENDIF.

    V_TIMPORT   =  WPREI-BIS - WPREI-AB + 1.

    Y_PREISBTR  =  Y_PREISBTR +
                 ( ( WPREI-PRICE_NEW * V_TIMPORT ) / V_MNGBASIS /
                     S_TIMBASIS ).

    Y_TIMPORT   =  Y_TIMPORT  + V_TIMPORT.

  ENDLOOP. " obj-iprei









ENDFORM.                    " CALC_AVG_PRICE
*&---------------------------------------------------------------------*
*&      Form  GET_TIMBASIS
*&---------------------------------------------------------------------*

FORM GET_TIMBASIS USING    X_CSNO           TYPE ISU2A_SS-CSNO
                           X_OP             TYPE ISU2A_OPER_NON_HIST
                           X_IOUTSTEPS      TYPE ISU2A_IOUTPUT_STEPS
                           X_IPREI          TYPE ISU2A_IPREI
                           X_TIMTYP         LIKE ERCHZ-TIMTYP
                  CHANGING XY_TIMBASIS      LIKE EDSC-TIMBASIS.

  DATA FIRST_CSNO TYPE CSNO.
  DATA FIRST_OPNUMBER TYPE OPCSNO.
  DATA FIRST TYPE KENNZX VALUE 'X'.

* to find the quantity base, a entry in X_IOUTSTEPS for the
* corresponding CSNO and OPERAND is read and used to find
* TIMBASIS in table IPREI.

  DATA: WOUTSTEPS TYPE ISU2A_OUTPUT_STEPS,
        WPREI     TYPE ISU2A_PREI.
  DATA  WSS       TYPE ISU2A_SS.

  LOOP AT X_IOUTSTEPS INTO WOUTSTEPS WHERE
          CSNO_FROM = X_CSNO AND
          OPERAND   = X_OP-OPERAND.
    IF NOT FIRST IS INITIAL.
      FIRST_CSNO     = WOUTSTEPS-CSNO_INTO.
      FIRST_OPNUMBER = WOUTSTEPS-NUMBER_OPERAND_INTO.
      CLEAR FIRST.
    ENDIF.
* Check, whether the timetyp in all target steps are the
* same as the timetyp of the source step.
    LOOP AT X_IPREI INTO WPREI WHERE
            CSNO = WOUTSTEPS-CSNO_INTO AND
            NUMBER = WOUTSTEPS-NUMBER_OPERAND_INTO.
      IF X_TIMTYP <> WPREI-TIMTYP.
        MAC_MSG_PUT 'E911(AH)' X_CSNO WOUTSTEPS-CSNO_INTO
                     SPACE SPACE GENERAL_FAULT.
        IF 1 = 2. MESSAGE E911(AH) WITH SPACE SPACE. ENDIF.
      ENDIF.
    ENDLOOP.
  ENDLOOP.
* Determination of the time base from the
* first target step
  LOOP AT X_IPREI INTO WPREI WHERE
          CSNO = FIRST_CSNO AND
          NUMBER = FIRST_OPNUMBER.
    XY_TIMBASIS = WPREI-TIMBASIS.
    EXIT.
  ENDLOOP.
  IF SY-SUBRC <> 0 OR XY_TIMBASIS IS INITIAL.
    XY_TIMBASIS = 1.
  ENDIF.
ENDFORM.                    " GET_TIMBASIS
*&---------------------------------------------------------------------*
*&      Form  calc_avg_price_new
*&---------------------------------------------------------------------*

FORM CALC_AVG_PRICE_NEW   USING X_IPREI       TYPE ISU2A_IPREI
                                X_CSNO        LIKE ERCHZ-CSNO
                                X_NUMBER      LIKE ISU2A_OPER-NUMBER
                                X_OPERAND     TYPE E_OPERAND
                       CHANGING Y_OUT_IPREI   TYPE ISU2A_OUT_IPREI
                                Y_TIMTYP      LIKE ERCHZ-TIMTYP.


  INCLUDE IEAPRCCO.

  DATA:        V_TIMPORT     LIKE ERCHZ-ZEITANT.
  DATA:        WPREI         TYPE ISU2A_PREI.
  DATA:        V_MNGBASIS    LIKE EPREIH-MNGBASIS.
  DATA:        C1(25)        TYPE C.
  DATA:        C2(25)        TYPE C.
  DATA:        CHECK_DATE    LIKE WPREI-BIS.
  DATA:        S_TIMBASIS    LIKE EDSC-TIMBASIS.
  DATA:        OUT_PREI      TYPE ISU2A_OUT_PREI.
  DATA:        S_DATE        LIKE WPREI-BIS.
  DATA:        FIRST         TYPE C VALUE 'X'.
  DATA:        FIRST_TIME_SLICE TYPE C VALUE 'X'.
  FIELD-SYMBOLS <OUT_PREI>    TYPE ISU2A_OUT_PREI.


  LOOP AT X_IPREI INTO WPREI
       WHERE  CSNO     =  X_CSNO
       AND    NUMBER   =  X_NUMBER.
    IF FIRST IS INITIAL.
      IF S_DATE <> WPREI-AB.
        CLEAR FIRST_TIME_SLICE.
      ENDIF.
    ELSE.
      S_DATE = WPREI-AB.
      CLEAR FIRST.
    ENDIF.
*   Store the information of the timtyp for
*   FORM GET_TIMBASIS
    IF WPREI-PREISTYP = CO_PTYP_TIME_DEP.
      IF Y_TIMTYP <> WPREI-TIMTYP
      AND NOT Y_TIMTYP IS INITIAL.
        MAC_MSG_PUT 'E910(AH)' X_OPERAND
                     SPACE SPACE SPACE GENERAL_FAULT.
        IF 1 = 2. MESSAGE E910(AH) WITH SPACE. ENDIF.
      ENDIF.
      Y_TIMTYP = WPREI-TIMTYP.
    ENDIF.

    IF NOT WPREI-PRCZONAJ IS INITIAL.
*   Pricezoneadjust to the billing period is active.
*    --> terminate billing
     MAC_MSG_PUT 'E827(AJ)' WPREI-PREIS SPACE SPACE SPACE GENERAL_FAULT.
      IF 1 = 2. MESSAGE E827(AJ) WITH WPREI-PREIS. ENDIF.
    ENDIF.

* In case of an time dependent price the time base has
* to be considered for the caluclation of the avergage
* price
    IF WPREI-PREISTYP = CO_PTYP_TIME_DEP.
      S_TIMBASIS = WPREI-TIMBASIS.
    ELSE.
      S_TIMBASIS = 1.
    ENDIF.
*   The first time slices are append to table OUT_IPREI
    IF NOT FIRST_TIME_SLICE IS INITIAL.
      IF WPREI-MNGBASIS <> 0.
        OUT_PREI-MNGBASIS = WPREI-MNGBASIS.
      ELSE.
        OUT_PREI-MNGBASIS = 1.
      ENDIF.
*     Fill fields of OUTPREI
      OUT_PREI-AB        = WPREI-AB.
      OUT_PREI-BIS       = WPREI-BIS.
      OUT_PREI-PREISART  = WPREI-PREISART.
      OUT_PREI-VONZONE   = WPREI-VONZONE.
      OUT_PREI-BISZONE   = WPREI-BISZONE.
      OUT_PREI-ZONENNR   = WPREI-ZONENNR.

      V_TIMPORT   =  WPREI-BIS - WPREI-AB + 1.

      OUT_PREI-PRICE_NEW = ( WPREI-PRICE_NEW * V_TIMPORT ) /
                             OUT_PREI-MNGBASIS / S_TIMBASIS.
      APPEND OUT_PREI TO Y_OUT_IPREI.

    ELSE.      " first_time
      LOOP AT Y_OUT_IPREI ASSIGNING <OUT_PREI>
           WHERE VONZONE = WPREI-VONZONE
           AND   BISZONE = WPREI-BISZONE
           AND   ZONENNR = WPREI-ZONENNR.
        IF WPREI-BIS > <OUT_PREI>-BIS.
          <OUT_PREI>-BIS = WPREI-BIS.
        ENDIF.

        V_TIMPORT   =  WPREI-BIS - WPREI-AB + 1.

        <OUT_PREI>-PRICE_NEW = <OUT_PREI>-PRICE_NEW +
                            ( ( WPREI-PRICE_NEW * V_TIMPORT )  /
                                <OUT_PREI>-MNGBASIS / S_TIMBASIS ).
      ENDLOOP.
      IF SY-SUBRC = 4.
*     Number and/or values of the price zones don't match
        MAC_MSG_PUT 'E828(AJ)' SPACE SPACE SPACE SPACE GENERAL_FAULT.
        IF 1 = 2. MESSAGE E828(AJ) WITH WPREI-PREIS. ENDIF.
      ENDIF.
    ENDIF.     " first_time
  ENDLOOP. " obj-iprei

ENDFORM.                    " calc_avg_price_new

*&---------------------------------------------------------------------*
*&      Form  MULTIPLY_BLOCKS_det_quant
*&---------------------------------------------------------------------*
FORM MULTIPLY_BLOCKS_DET_QUANT
                     USING    X_OPERAND1  LIKE TE221-OPERAND
                              X_OPERAND3  LIKE TE221-OPERAND
                              X_OPERAND2  LIKE TE221-OPERAND
                              X_QNT       TYPE ISU2A_PACK16
                              X_FACTOR    TYPE ISU2A_PACK16
                              X_SS        TYPE ISU2A_SS
                              X_IOUTSTEPS TYPE ISU2A_IOUTPUT_STEPS
                     CHANGING XY_IPREI    TYPE ISU2A_IPREI.

  INCLUDE IEAPRCCO.

  DATA: WPREI     TYPE ISU2A_PREI,
        WOUTSTEPS TYPE ISU2A_OUTPUT_STEPS,
        BLOCK_DEC TYPE ISU2A_PACK16,
        BLOCK     TYPE BISZONE,
        MAX_ZONE  TYPE BISZONE.

  IF X_FACTOR = 0.
    MAC_ERR '143' 'AJ' X_OPERAND1 SPACE SPACE SPACE GENERAL_FAULT.
    IF 1 = 2. MESSAGE E143(AJ). ENDIF.
  ENDIF.
* calculate the maximal possible block value to avoid a data
* overflow
  IF X_FACTOR > 1.
    MAX_ZONE = CO_BLOCK_INFINITE / X_FACTOR.
  ELSE.
    MAX_ZONE = CO_BLOCK_INFINITE.
  ENDIF.

* Multiply the blocks of the qprice for all following schemasteps in
* the same logical schema with the output operand of this variant
* as an input operand.
  LOOP AT X_IOUTSTEPS INTO WOUTSTEPS
  WHERE CSNO_FROM = X_SS-CSNO
  AND   OPERAND   = X_OPERAND2.
    READ TABLE XY_IPREI WITH KEY CSNO = WOUTSTEPS-CSNO_INTO
                             TRANSPORTING NO FIELDS BINARY SEARCH.
    CHECK SY-SUBRC = 0.
    LOOP AT XY_IPREI FROM SY-TABIX INTO WPREI.
      IF WPREI-CSNO <> WOUTSTEPS-CSNO_INTO.
        EXIT.
      ENDIF.
*     Calculate block with decimals
      BLOCK_DEC = WPREI-VONZONE * X_FACTOR.
*     Calculate block without decimals
      BLOCK = WPREI-VONZONE * X_FACTOR.
      IF BLOCK_DEC > BLOCK
      AND X_QNT <= BLOCK_DEC
      AND X_QNT >  BLOCK.
*       Round down => add 1 to VONZONE if price determination quantity
*       is between rounded value and value with decimals
        WPREI-VONZONE = BLOCK + 1.
      ELSEIF BLOCK > BLOCK_DEC
      AND X_QNT >  BLOCK_DEC
      AND X_QNT <= BLOCK.
*       Round up => subtract 1 from VONZONE if price determination
*       quantity is between rounded value and value with decimals
        WPREI-VONZONE = BLOCK - 1.
      ELSE.                                                 "n1439565
        wprei-vonzone = block.                              "n1439565
      ENDIF.
      IF WPREI-BISZONE > MAX_ZONE OR
         WPREI-BISZONE = CO_BLOCK_INFINITE.
*       If last block has the maximum value: This exemption is allowed
*       and no changes are necessary.
        IF WPREI-BISZONE < CO_BLOCK_INFINITE.
          MAC_ERR '145' 'AJ' X_FACTOR WPREI-PREIS SPACE
                                  SPACE GENERAL_FAULT.
          IF 1 = 2. MESSAGE E145(AJ). ENDIF.
        ENDIF.
      ELSE.
*       Calculate block with decimals
        BLOCK_DEC = WPREI-BISZONE * X_FACTOR.
*       Calculate block without decimals
        BLOCK = WPREI-BISZONE * X_FACTOR.
        IF BLOCK_DEC > BLOCK
        AND X_QNT <= BLOCK_DEC
        AND X_QNT >  BLOCK.
*         Round down => add 1 to BISZONE if price determination quantity
*         is between rounded value and value with decimals
          WPREI-BISZONE = BLOCK + 1.
        ELSEIF BLOCK_DEC < BLOCK
        AND X_QNT >  BLOCK_DEC
        AND X_QNT <= BLOCK.
*         Round up => subtract 1 from BISZONE if price determination
*         quantity is between rounded value and value with decimals
          WPREI-BISZONE = BLOCK - 1.
        ELSE.                                               "n1439565
          wprei-biszone = block.                            "n1439565
        ENDIF.
      ENDIF.
      MODIFY XY_IPREI FROM WPREI.
    ENDLOOP.                           "xy_iprei
    MAC_ERR_READ 'xy_prei' X_SS-PROGRAMM SPACE.

  ENDLOOP.                             "x_ioutsteps
ENDFORM.                    " MULTIPLY_BLOCKS_det_quant

*&---------------------------------------------------------------------*
*&      Form  multiply_block_difference
*&---------------------------------------------------------------------*
FORM MULTIPLY_BLOCK_DIFFERENCE
                     USING    X_OPERAND1  LIKE TE221-OPERAND
                              X_OPERAND3  LIKE TE221-OPERAND
                              X_OPERAND2  LIKE TE221-OPERAND
                              X_QNT       TYPE ISU2A_PACK16
                              X_FACTOR    TYPE ISU2A_PACK16
                              X_SS        TYPE ISU2A_SS
                              X_IOUTSTEPS TYPE ISU2A_IOUTPUT_STEPS
                     CHANGING XY_IPREI    TYPE ISU2A_IPREI.
  INCLUDE IEAPRCCO.

  DATA: WPREI     TYPE ISU2A_PREI,
        WOUTSTEPS TYPE ISU2A_OUTPUT_STEPS,
        BLOCK_DEC TYPE ISU2A_PACK16,
        BLOCK     TYPE BISZONE,
        DIFF      TYPE ISU2A_PACK16,
        BISZONE_ALT TYPE BISZONE,
        DATE      TYPE ABZEITSCH,
        MAX_ZONE  TYPE BISZONE.

  IF X_FACTOR = 0.
    MAC_ERR '143' 'AJ' X_OPERAND1 SPACE SPACE SPACE GENERAL_FAULT.
    IF 1 = 2. MESSAGE E143(AJ). ENDIF.
  ENDIF.
* calculate the maximal possible block value to avoid a data
* overflow
  IF X_FACTOR > 1.
    MAX_ZONE = CO_BLOCK_INFINITE / X_FACTOR.
  ELSE.
    MAX_ZONE = CO_BLOCK_INFINITE.
  ENDIF.

* Multiply the blocks of the qprice for all following schemasteps in
* the same logical schema with the output operand of this variant
* as an input operand.
  LOOP AT X_IOUTSTEPS INTO WOUTSTEPS
  WHERE CSNO_FROM = X_SS-CSNO
  AND   OPERAND   = X_OPERAND2.
    CLEAR biszone_alt.                                      "n1439565
    READ TABLE xy_iprei WITH KEY csno = woutsteps-csno_into
                             TRANSPORTING NO FIELDS BINARY SEARCH.
    CHECK SY-SUBRC = 0.
    LOOP AT XY_IPREI FROM SY-TABIX INTO WPREI.
      IF WPREI-CSNO <> WOUTSTEPS-CSNO_INTO.
        EXIT.
      ENDIF.
      IF WPREI-AB <> DATE.
*       Date change -> start with initial BISZONE_ALT
        CLEAR BISZONE_ALT.
        DATE = WPREI-AB.
      ENDIF.
      IF WPREI-BISZONE < CO_BLOCK_INFINITE.
*       Only for blocks < Infinity
        DIFF = WPREI-BISZONE - WPREI-VONZONE.
        IF NOT BISZONE_ALT IS INITIAL.
*         Adjust from block
          WPREI-VONZONE = BISZONE_ALT.
        ENDIF.
*       Calculate to block with decimals -> block_dec
        BLOCK_DEC = WPREI-VONZONE + DIFF * X_FACTOR.
*       Calculate to block without decimals -> block
        BLOCK = WPREI-VONZONE + DIFF * X_FACTOR.
*       Adjust block if the price determination quantity is
*       between the rounded block and the block with decimals
        IF BLOCK_DEC > BLOCK
        AND X_QNT <= BLOCK_DEC
        AND X_QNT >  BLOCK.
          WPREI-BISZONE = BLOCK + 1.
        ELSEIF BLOCK  > BLOCK_DEC
        AND X_QNT <= BLOCK
        AND X_QNT >  BLOCK_DEC.
          WPREI-BISZONE = BLOCK - 1.
        ELSE.
          WPREI-BISZONE = BLOCK.
        ENDIF.
      ELSE.
        IF NOT BISZONE_ALT IS INITIAL.
*         Adjust from block
          WPREI-VONZONE = BISZONE_ALT.
        ENDIF.
      ENDIF.
*     Store to block for the next step
      BISZONE_ALT = WPREI-BISZONE.
      IF WPREI-BISZONE > MAX_ZONE OR
          WPREI-BISZONE = CO_BLOCK_INFINITE.
*       If last block has the maximum value: This exemption is allowed
*       and no changes are necessary.
        IF WPREI-BISZONE < CO_BLOCK_INFINITE.
          MAC_ERR '145' 'AJ' X_FACTOR WPREI-PREIS SPACE
                                  SPACE GENERAL_FAULT.
          IF 1 = 2. MESSAGE E145(AJ). ENDIF.
        ENDIF.
      ENDIF.
      MODIFY XY_IPREI FROM WPREI.
    ENDLOOP.
    MAC_ERR_READ 'xy_prei' X_SS-PROGRAMM SPACE.
  ENDLOOP.
ENDFORM.                    " multiply_block_difference

*&---------------------------------------------------------------------*
*&      Form  MULTIPLY_BLOCKS_DET_QUANT_PR
*&---------------------------------------------------------------------*

FORM MULTIPLY_BLOCKS_DET_QUANT_PR
                     USING    X_OPERAND1  LIKE TE221-OPERAND
                              X_OPERAND3  LIKE TE221-OPERAND
                              X_OPERAND2  LIKE TE221-OPERAND
                              X_QNT       TYPE ISU2A_PACK16
                              X_FACTOR    TYPE ISU2A_PACK16
                              X_AB        TYPE ABZEITSCH
                              X_BIS       TYPE BISZEITSCH
                              X_SS        TYPE ISU2A_SS
                              X_IOUTSTEPS TYPE ISU2A_IOUTPUT_STEPS
                     CHANGING XY_IPREI    TYPE ISU2A_IPREI.
  INCLUDE IEAPRCCO.

  DATA: WPREI     TYPE ISU2A_PREI,
        WOUTSTEPS TYPE ISU2A_OUTPUT_STEPS,
        BLOCK_DEC TYPE ISU2A_PACK16,
        BLOCK     TYPE BISZONE,
        MAX_ZONE  TYPE BISZONE.

  IF X_FACTOR = 0.
    MAC_ERR '143' 'AJ' X_OPERAND1 SPACE SPACE SPACE GENERAL_FAULT.
    IF 1 = 2. MESSAGE E143(AJ). ENDIF.
  ENDIF.
* calculate the maximal possible block value to avoid a data
* overflow
  IF X_FACTOR > 1.
    MAX_ZONE = CO_BLOCK_INFINITE / X_FACTOR.
  ELSE.
    MAX_ZONE = CO_BLOCK_INFINITE.
  ENDIF.

* Multiply the blocks of the qprice for all following schemasteps in
* the same logical schema with the output operand of this variant
* as an input operand.
  LOOP AT X_IOUTSTEPS INTO WOUTSTEPS
  WHERE CSNO_FROM = X_SS-CSNO
  AND   OPERAND   = X_OPERAND2.
    READ TABLE XY_IPREI WITH KEY CSNO = WOUTSTEPS-CSNO_INTO
                             TRANSPORTING NO FIELDS BINARY SEARCH.
    CHECK SY-SUBRC = 0.
    LOOP AT XY_IPREI FROM SY-TABIX INTO WPREI
    WHERE AB  = X_AB
    AND   BIS = X_BIS.
      IF WPREI-CSNO <> WOUTSTEPS-CSNO_INTO.
        EXIT.
      ENDIF.
*     Calculate block with decimals
      BLOCK_DEC = WPREI-VONZONE * X_FACTOR.
*     Calculate block without decimals
      BLOCK = WPREI-VONZONE * X_FACTOR.
      IF BLOCK_DEC > BLOCK
      AND X_QNT < BLOCK_DEC
      AND X_QNT > BLOCK.
*       Round down => add 1 to VONZONE if price determination quantity
*       is between rounded value and value with decimals
        WPREI-VONZONE = BLOCK + 1.
      ELSEIF BLOCK > BLOCK_DEC
      AND X_QNT > BLOCK_DEC
      AND X_QNT < BLOCK.
*       Round up => subtract 1 from VONZONE if price determination
*       quantity is between rounded value and value with decimals
        WPREI-VONZONE = BLOCK - 1.
      ELSE.                                                 "n1439565
        wprei-vonzone = block.                              "n1439565
      ENDIF.
      IF WPREI-BISZONE > MAX_ZONE OR
         WPREI-BISZONE = CO_BLOCK_INFINITE.
*       If last block has the maximum value: This exemption is allowed
*       and no changes are necessary.
        IF WPREI-BISZONE < CO_BLOCK_INFINITE.
          MAC_ERR '145' 'AJ' X_FACTOR WPREI-PREIS SPACE
                                  SPACE GENERAL_FAULT.
          IF 1 = 2. MESSAGE E145(AJ). ENDIF.
        ENDIF.
      ELSE.
*       Calculate block with decimals
        BLOCK_DEC = WPREI-BISZONE * X_FACTOR.
*       Calculate block without decimals
        BLOCK = WPREI-BISZONE * X_FACTOR.
        IF BLOCK_DEC > BLOCK
        AND X_QNT < BLOCK_DEC
        AND X_QNT > BLOCK.
*         Round down => add 1 to BISZONE if price determination quantity
*         is between rounded value and value with decimals
          WPREI-BISZONE = BLOCK + 1.
        ELSEIF BLOCK_DEC > BLOCK
        AND X_QNT > BLOCK_DEC
        AND X_QNT < BLOCK.
*         Round up => subtract 1 from BISZONE if price determination
*         quantity is between rounded value and value with decimals
          WPREI-BISZONE = BLOCK + 1.
        ELSE.                                               "n1439565
          wprei-biszone = block.                            "n1439565
        ENDIF.
      ENDIF.
      MODIFY XY_IPREI FROM WPREI.
    ENDLOOP.                           "xy_iprei
    MAC_ERR_READ 'xy_prei' X_SS-PROGRAMM SPACE.

  ENDLOOP.                             "x_ioutsteps

ENDFORM.                    " MULTIPLY_BLOCKS_DET_QUANT_PR

*&---------------------------------------------------------------------*
*&      Form  MULTIPLY_BLOCK_DIFFERENCE_PR
*&---------------------------------------------------------------------*
FORM MULTIPLY_BLOCK_DIFFERENCE_PR
                     USING    X_OPERAND1  LIKE TE221-OPERAND
                              X_OPERAND3  LIKE TE221-OPERAND
                              X_OPERAND2  LIKE TE221-OPERAND
                              X_QNT       TYPE ISU2A_PACK16
                              X_FACTOR    TYPE ISU2A_PACK16
                              X_AB        TYPE ABZEITSCH
                              X_BIS       TYPE BISZEITSCH
                              X_SS        TYPE ISU2A_SS
                              X_IOUTSTEPS TYPE ISU2A_IOUTPUT_STEPS
                     CHANGING XY_IPREI    TYPE ISU2A_IPREI.
  INCLUDE IEAPRCCO.

  DATA: WPREI     TYPE ISU2A_PREI,
        WOUTSTEPS TYPE ISU2A_OUTPUT_STEPS,
        BLOCK_DEC TYPE ISU2A_PACK16,
        BLOCK     TYPE BISZONE,
        DIFF      TYPE ISU2A_PACK16,
        BISZONE_ALT TYPE BISZONE,
        DATE      TYPE ABZEITSCH,
        MAX_ZONE  TYPE BISZONE.

  IF X_FACTOR = 0.
    MAC_ERR '143' 'AJ' X_OPERAND1 SPACE SPACE SPACE GENERAL_FAULT.
    IF 1 = 2. MESSAGE E143(AJ). ENDIF.
  ENDIF.
* calculate the maximal possible block value to avoid a data
* overflow
  IF X_FACTOR > 1.
    MAX_ZONE = CO_BLOCK_INFINITE / X_FACTOR.
  ELSE.
    MAX_ZONE = CO_BLOCK_INFINITE.
  ENDIF.

* Multiply the blocks of the qprice for all following schemasteps in
* the same logical schema with the output operand of this variant
* as an input operand.
  LOOP AT X_IOUTSTEPS INTO WOUTSTEPS
  WHERE CSNO_FROM = X_SS-CSNO
  AND   OPERAND   = X_OPERAND2.
    CLEAR biszone_alt.                                      "n1439565
    READ TABLE xy_iprei WITH KEY csno = woutsteps-csno_into
                             TRANSPORTING NO FIELDS BINARY SEARCH.
    CHECK SY-SUBRC = 0.
    LOOP AT XY_IPREI FROM SY-TABIX INTO WPREI
    WHERE AB  = X_AB
    AND   BIS = X_BIS.
      IF WPREI-CSNO <> WOUTSTEPS-CSNO_INTO.
        EXIT.
      ENDIF.
      IF WPREI-AB <> DATE.
*       Date change -> start with initial BISZONE_ALT
        CLEAR BISZONE_ALT.
        DATE = WPREI-AB.
      ENDIF.
      IF WPREI-BISZONE < CO_BLOCK_INFINITE.
*       Only for blocks < Infinity
        DIFF = WPREI-BISZONE - WPREI-VONZONE.
*       Calculate to block with decimals -> block_dec
        BLOCK_DEC = WPREI-VONZONE + DIFF * X_FACTOR.
*       Calculate to block without decimals -> block
        BLOCK = WPREI-VONZONE + DIFF * X_FACTOR.
*       Adjust block if the price determination quantity is
*       between the rounded block and the block with decimals
        IF BLOCK_DEC > BLOCK
        AND X_QNT < BLOCK_DEC
        AND X_QNT > BLOCK.
          WPREI-BISZONE = BLOCK + 1.
        ELSEIF BLOCK  > BLOCK_DEC
        AND X_QNT < BLOCK
        AND X_QNT > BLOCK_DEC.
          WPREI-BISZONE = BLOCK - 1.
        ELSE.
          WPREI-BISZONE = BLOCK.
        ENDIF.
      ENDIF.
      IF NOT BISZONE_ALT IS INITIAL.
*       Adjust from block
        WPREI-VONZONE = BISZONE_ALT.
      ENDIF.
*     Store to block for the next step
      BISZONE_ALT = WPREI-BISZONE.
      IF WPREI-BISZONE > MAX_ZONE OR
         WPREI-BISZONE = CO_BLOCK_INFINITE.
*       If last block has the maximum value: This exemption is allowed
*       and no changes are necessary.
        IF WPREI-BISZONE < CO_BLOCK_INFINITE.
          MAC_ERR '145' 'AJ' X_FACTOR WPREI-PREIS SPACE
                                  SPACE GENERAL_FAULT.
          IF 1 = 2. MESSAGE E145(AJ). ENDIF.
        ENDIF.
      ENDIF.
      MODIFY XY_IPREI FROM WPREI.
    ENDLOOP.
    MAC_ERR_READ 'xy_prei' X_SS-PROGRAMM SPACE.
  ENDLOOP.

ENDFORM.                    " MULTIPLY_BLOCK_DIFFERENCE_PR
