@AbapCatalog.sqlViewName: 'ZCDS_LISTE_PIECE'
@AbapCatalog.compiler.CompareFilter: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Liste des pièces comptables'
define view ZCDS_LISTE_PIECE_view as select from dfkkop 
left outer join dfkkko on dfkkop.augbl = dfkkko.opbel
{
case when dfkkko.blart = 'RP' or dfkkko.blart = 'ST' or dfkkko.blart = 'RC' or dfkkko.blart = 'RV' or dfkkko.blart = 'PE' or dfkkko.blart = 'PP' or dfkkko.blart = 'EB' or dfkkko.blart = 'EV' or dfkkko.blart = 'PA' then dfkkop.augbl else dfkkop.opbel end as opbel,
dfkkop.bukrs as bukrs,
case when dfkkko.blart = 'RP' or dfkkko.blart = 'ST' or dfkkko.blart = 'RC' or dfkkko.blart = 'RV' or dfkkko.blart = 'PE' or dfkkko.blart = 'PP' or dfkkko.blart = 'EB' or dfkkko.blart = 'EV' or dfkkko.blart = 'PA' then dfkkko.blart else dfkkop.blart end as blart,
dfkkop.bldat as bldat,
dfkkop.faedn as faedn,
dfkkop.gpart as gpart,
dfkkop.vkont as vkont,
dfkkop.vtref as vtref,
dfkkop.spart as spart,
sum(dfkkop.skfbt) as sum_skfbt,
sum(dfkkop.betrw) as sum_betrw
--(case when sum(dfkkop.skfbt) <> 0 then sum(dfkkop.skfbt) else sum(dfkkop.betrw) end) as montant_ht
} group by dfkkop.opbel,dfkkop.augbl,dfkkop.bukrs,dfkkko.blart,dfkkop.blart,dfkkop.bldat,dfkkop.faedn,dfkkop.gpart,dfkkop.vkont,dfkkop.vtref,dfkkop.spart;
