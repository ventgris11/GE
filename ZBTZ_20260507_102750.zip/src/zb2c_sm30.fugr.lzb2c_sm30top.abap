* regenerated at 23.08.2017 07:55:14
FUNCTION-POOL ZB2C_SM30                  MESSAGE-ID SV.

* INCLUDE LZB2C_SM30D...                     " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZB2C_SM30T00                           . "view rel. data dcl.
