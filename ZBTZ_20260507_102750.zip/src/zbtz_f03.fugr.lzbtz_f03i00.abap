*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 16.10.2018 at 16:49:50
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
