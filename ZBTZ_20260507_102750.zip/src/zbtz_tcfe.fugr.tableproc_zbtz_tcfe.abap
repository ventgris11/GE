*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZBTZ_TCFE
*   generation date: 20.10.2018 at 17:29:03
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZBTZ_TCFE           .

  PERFORM TABLEPROC.

ENDFUNCTION.
