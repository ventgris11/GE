* regenerated at 22.07.2017 13:06:50
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZNOM_PAIEMENTTOP.                 " Global Data
  INCLUDE LZNOM_PAIEMENTUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZNOM_PAIEMENTF...                 " Subroutines
* INCLUDE LZNOM_PAIEMENTO...                 " PBO-Modules
* INCLUDE LZNOM_PAIEMENTI...                 " PAI-Modules
* INCLUDE LZNOM_PAIEMENTE...                 " Events
* INCLUDE LZNOM_PAIEMENTP...                 " Local class implement.
* INCLUDE LZNOM_PAIEMENTT99.                 " ABAP Unit tests
  INCLUDE LZNOM_PAIEMENTF00                       . " subprograms
  INCLUDE LZNOM_PAIEMENTI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
