FUNCTION-POOL ZE31A. "MESSAGE-ID ...


DATA: okcode(4) TYPE c.
DATA: wa_fkkop LIKE fkkop.
INCLUDE: emsg, iekconst.
*>>>>> \inserted by RM on 22.06.2004
TYPES: BEGIN OF tp_senrec,
         senid TYPE service_prov,
         recid TYPE invoicing_party,
       END OF tp_senrec.
*<<<<< \inserted by RM on 22.06.2004

* constants
CONSTANTS: co_true       TYPE xfeld    VALUE 'X',
           co_herkf_05   TYPE herkf_kk VALUE '05',
           co_augrd_27   TYPE augrd_kk VALUE '27'.

* settlement type for distribution lot
TYPES: BEGIN OF tp_verart_dl,
         keyz1     TYPE keyz1_kk,
         xdl       TYPE xfeld,     " = 'X' in case of distribution lot
         verart_dl TYPE e_verart_dl,
       END OF tp_verart_dl,
       ttp_verart_dl TYPE SORTED TABLE OF tp_verart_dl
                          WITH UNIQUE KEY keyz1.

* global memory for settlement type toward distribution lot
DATA gt_verart_dl TYPE ttp_verart_dl.

DATA:   vorg_read TYPE c VALUE space,
        h_ihvor   LIKE teivv-ihvor,
        h_vorg_jvl LIKE teivv-hvorg,
        h_hvorg   LIKE teivv-hvorg,
        h_opbel   LIKE fkkcl-opbel,
        h_count   TYPE p,
        wa_fkkcl  LIKE e516_fkkcl.

INCLUDE iekivorg.
*>>>>> Added for ISU_DEREG_VBUND_CHECK_0061
*----------------------VTREF, VBUND, VERTRAG, EVER--------------------
TYPES: BEGIN OF mapvtref,
                vtref           TYPE          vtref_kk,
                vbund           TYPE          vbund,
                vertrag         TYPE          vertrag,
                ever            LIKE          ever,
*----------------------INT_CROSSREFNO, KEYDATE, BLDAT-----------------
                int_crossrefno  TYPE          int_crossrefno,
                keydate         TYPE          endabrpe,
                bldat           TYPE          bldat,
       END OF  mapvtref,
       tab_mapvtref             TYPE TABLE OF mapvtref.
*----------------------VKONT, INVOICING_PARTY-------------------------
TYPES: BEGIN OF mapaccounts,
                vkont           TYPE          vkont_kk,
                invoicing_party TYPE          invoicing_party,
       END OF   mapaccounts,
       tab_mapaccounts          TYPE TABLE OF mapaccounts.
constants: co_process_par_invoice_cust type inv_par_process
                                       value '0002'.
