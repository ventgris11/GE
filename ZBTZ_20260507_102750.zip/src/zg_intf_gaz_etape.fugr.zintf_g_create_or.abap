FUNCTION zintf_g_create_or.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA:
    lv_field     TYPE string,
    lv_message   TYPE char255,
    lt_result    TYPE STANDARD TABLE OF efindres,
    ls_findpar   TYPE efindpar,
    lv_anlage    TYPE eanlh-anlage,
    lv_date_rel  TYPE dats,
    lt_eabl      TYPE TABLE OF eabl,
    lt_return    TYPE ztmr_return,
    lt_mr_data   TYPE TABLE OF bapieabl,
    ls_mr_data   TYPE bapieabl,
    lt_mr_reason TYPE TABLE OF bapieablg,
    lt_adat      TYPE TABLE OF eablg,
    ls_adat      TYPE eablg,
    ls_adat_i    TYPE eablg.


  FIELD-SYMBOLS:
    <fs_emetteur>,
    <fs_flux>,
    <fs_num_pce>,
    <fs_date_releve>,
    <ls_result> TYPE efindres.

  CONSTANTS :
    lc_instln TYPE swo_objtyp VALUE 'INSTLN'.

  DEFINE macro_add_message_to_log.
    MESSAGE &1(zintf_g_messages)
       WITH &2
            &3
            &4
            &5
       INTO lv_message.
    RETURN.
  END-OF-DEFINITION.


  CLEAR: lv_field.
  MOVE 'FLUX-EMETTEUR'                    TO lv_field.
  ASSIGN (lv_field)                       TO <fs_emetteur>.

  CLEAR: lv_field.
  MOVE 'FLUX-FLUX'                        TO lv_field.
  ASSIGN (lv_field)                       TO <fs_flux>.

  CLEAR: lv_field.
  MOVE 'FLUX-NUM_PCE'                     TO lv_field.
  ASSIGN (lv_field)                       TO <fs_num_pce>.

  CLEAR: lv_field.
  MOVE 'FLUX-DATE_RELEVE'                 TO lv_field.
  ASSIGN (lv_field)                       TO <fs_date_releve>.

  " Déterminer le N° d'installation
  CLEAR:
    ls_findpar,
    lt_result.

  ls_findpar-i_pod  = <fs_num_pce>.
  ls_findpar-d_date = <fs_date_releve>.

  CALL FUNCTION 'ISU_FINDER'
    EXPORTING
      x_objtype                   = lc_instln
      x_findpar                   = ls_findpar
    TABLES
      yt_result                   = lt_result
    EXCEPTIONS
      insufficient_selection      = 1
      objtype_not_supported       = 2
      additional_selection_needed = 3.
  IF sy-subrc = 0.
    " Récupérer l'installation (objet INSTLN)
    READ TABLE lt_result WITH KEY objtype = lc_instln ASSIGNING <ls_result>.
    IF <ls_result> IS ASSIGNED.
      lv_anlage = <ls_result>-objkey.
      UNASSIGN <ls_result>.
    ENDIF.
  ELSE.
    RETURN.
  ENDIF.

  " Récupération des relèves
  REFRESH: lt_mr_data, lt_mr_reason.
  CALL FUNCTION 'BAPI_MTRREADDOC_GETLIST'
    EXPORTING
      installation      = lv_anlage
*     mrdatefrom        = <fs_date_releve>
      mrdocumenttype    = '2'
    TABLES
      mrdocumentdata    = lt_mr_data
      mrdocumentreasons = lt_mr_reason.
  "si relèves, tri par date décroissante pour garder la dernière
  IF lt_mr_data IS NOT INITIAL.
    SORT lt_mr_data DESCENDING BY targetmrdate mridnumber.
    READ TABLE lt_mr_data INTO ls_mr_data INDEX 1.
    CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
      EXPORTING
        date      = ls_mr_data-targetmrdate
        days      = '10'
        months    = '00'
        signum    = '+'
        years     = '00'
      IMPORTING
        calc_date = lv_date_rel.   "<<< on ajoute 10 j à la dernière relève
  ENDIF.

  IF lv_anlage IS NOT INITIAL.
    SELECT adatsoll
    FROM te418 AS t8
    JOIN eanlh AS lh ON
          t8~termschl EQ lh~ableinh
      AND t8~adatsoll GE lh~ab
      AND t8~adatsoll LE lh~bis
      AND (
            ( t8~begablv LE @sy-datum AND ablesart = '01' )
          OR
            ( t8~adatsoll LE @sy-datum AND ablesart = '03' )
          )
    INTO CORRESPONDING FIELDS OF TABLE @lt_adat
    WHERE
      anlage = @lv_anlage
      AND adatsoll GE @<fs_date_releve>
      AND NOT EXISTS
        ( SELECT lg~adatsoll
            FROM eablg AS lg
            WHERE lg~anlage = @lv_anlage
              AND lg~adatsoll = t8~adatsoll
              AND lg~ablesgr = '01'
              AND lg~unterdr = '' )
    ORDER BY adatsoll.
    IF sy-subrc = 0.
      READ TABLE lt_adat INTO ls_adat   INDEX 1.
      READ TABLE lt_adat INTO ls_adat_i INDEX 2.
    ENDIF.
    IF ls_adat-adatsoll LT lv_date_rel.
      CALL FUNCTION 'Z_ISU_MR_CREATE_FOR_INST'
        EXPORTING
          x_anlage   = lv_anlage
          x_begabrpe = ls_adat_i-adatsoll
        TABLES
          lt_return  = lt_return.
    ELSE.
      CALL FUNCTION 'Z_ISU_MR_CREATE_FOR_INST'
        EXPORTING
          x_anlage   = lv_anlage
          x_begabrpe = ls_adat-adatsoll
        TABLES
          lt_return  = lt_return.
    ENDIF.
    ev_etape = 1.
  ENDIF.

ENDFUNCTION.
