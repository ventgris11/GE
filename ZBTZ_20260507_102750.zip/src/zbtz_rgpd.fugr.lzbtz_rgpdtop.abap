FUNCTION-POOL ZBTZ_RGPD.                    "MESSAGE-ID ..

* INCLUDE LZBTZ_RGPDD...                     " Local class definition
