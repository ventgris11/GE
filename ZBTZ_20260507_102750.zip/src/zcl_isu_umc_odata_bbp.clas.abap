class ZCL_ISU_UMC_ODATA_BBP definition
  public
  inheriting from CL_ISU_UMC_ODATA_BBP
  final
  create public .

public section.

  methods IF_ISU_UMC_ODATA_IMPL~GET_ENTITY
    redefinition .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ISU_UMC_ODATA_BBP IMPLEMENTATION.


METHOD if_isu_umc_odata_impl~get_entity.

  DATA lv_contract_id       TYPE vertrag.
  DATA lv_bbp_id            TYPE isu_umc_budgetbillingplan.
  DATA: lv_partner_id       TYPE bu_partner.
  DATA ls_budgetbillingplan TYPE isus_umc_budgetbillingplan.
  DATA lv_string            TYPE string.
  DATA ls_contract          TYPE isus_umc_contract.
  DATA ls_contract_account  TYPE isus_umc_contractaccount.
  DATA lt_return            TYPE bapiret2_t.
  DATA ls_navigation_path   TYPE /iwbep/s_mgw_tech_navi.
  DATA lt_navigation_path   TYPE /iwbep/t_mgw_tech_navi.
  DATA ls_key1              TYPE /iwbep/s_mgw_tech_pair.
  DATA ls_key2              TYPE /iwbep/s_mgw_tech_pair.
  DATA lt_keys              TYPE /iwbep/t_mgw_tech_pairs.

  DATA : lv_doccalcfact TYPE e_abrbelnra,
         lt_dberchz1    TYPE TABLE OF dberchz1,
         ls_dberchz1    TYPE dberchz1.
**************************************************************************
* Support of long navigation                                             *
**************************************************************************
  lt_navigation_path = io_tech_request_context->get_navigation_path( ).
  READ TABLE  lt_navigation_path INTO  ls_navigation_path INDEX 1.

  IF io_tech_request_context->get_navigation_path( ) IS INITIAL OR ls_navigation_path-nav_prop = gc_nav_property.
**************************************************************************
* Read Keys                                                              *
**************************************************************************
    IF ls_navigation_path-nav_prop = gc_nav_property.
      lt_keys = io_tech_request_context->get_source_keys( ).
    ELSE.
      lt_keys = io_tech_request_context->get_keys( ).
    ENDIF.

    READ TABLE lt_keys INTO ls_key1 WITH KEY name = gc_contract_id.
    READ TABLE lt_keys INTO ls_key2 WITH KEY name = gc_bbp_id.

    lv_contract_id = ls_key1-value.
    lv_bbp_id = ls_key2-value.
**************************************************************************
* Get Account  with contract & contracc API classes                      *
**************************************************************************
    ls_contract = cl_isu_umc_api_contract=>read_contract( lv_contract_id ).

    cl_isu_umc_api_contracc=>read_contract_account(
      EXPORTING iv_contract_account_id = ls_contract-vkonto
      RECEIVING rs_contract_account    = ls_contract_account ).

    lv_partner_id  = convert_alpha( ls_contract_account-gpart ).
**************************************************************************
* Check user authorisation                                               *
**************************************************************************
    check_user_authorisation( iv_account_id  = lv_partner_id
                              iv_entity_type = iv_entity_name ).
**************************************************************************
* Get BBP with the bbp API class                                         *
**************************************************************************
    cl_isu_umc_api_bbp=>read_bbp(
      EXPORTING iv_contractid = lv_contract_id
                iv_bbp_id     = lv_bbp_id
                iv_date       = sy-datum
      IMPORTING es_bbp        = ls_budgetbillingplan
                et_return     = lt_return ).
**************************************************************************
* Business exceptions handling                                           *
**************************************************************************
    handle_business_error( iv_entity_type = iv_entity_name
                           it_return      = lt_return ).
**************************************************************************
* Copy data to gateway                                                   *
**************************************************************************
    process_amountlimit( CHANGING cs_bbp = ls_budgetbillingplan ).

** Ajout Alia Consulting 20170725
** Récupération des informations sur la consommation utilisée pour le plan
** de paiement

    CLEAR : lv_doccalcfact ,
            lt_dberchz1    .

    SELECT SINGLE erchzbelnr
        FROM  eabp
        INTO lv_doccalcfact
        WHERE opbel   = ls_budgetbillingplan-opbel
          AND vertrag = lv_contract_id .
    IF sy-subrc IS INITIAL.
      SELECT * FROM dberchz1
             INTO TABLE lt_dberchz1
             WHERE belnr    = lv_doccalcfact .
*               AND pertyp   NE 'AS' .
      IF sy-subrc IS INITIAL.
        DELETE lt_dberchz1 WHERE abslkz = abap_false. " ++ GE-8469 (LWAT) : On ne veut que la ligne active (pas l'historique)
        LOOP AT lt_dberchz1 INTO ls_dberchz1
                            WHERE  belzart  = 'ZCON'.
          ls_budgetbillingplan-zzconso = ls_budgetbillingplan-zzconso +
                                              ls_dberchz1-v_abrmenge  +
                                              ls_dberchz1-n_abrmenge  .
        ENDLOOP.
        IF ls_budgetbillingplan-zzconso IS INITIAL.
          LOOP AT lt_dberchz1 INTO ls_dberchz1
                              WHERE  belzart  = 'XCONSG'.
            ls_budgetbillingplan-zzconso = ls_budgetbillingplan-zzconso +
                                                ls_dberchz1-v_abrmenge  +
                                                ls_dberchz1-n_abrmenge  .
          ENDLOOP.
        ENDIF.
      ENDIF.
    ENDIF.

** Fin Ajout Alia Consulting 20170725

** Début Ajout Alia Consulting 201700910
* Récupération des PDF échéanciers
    DATA :
      lv_xstring TYPE xstring,
      lv_opbel   TYPE abplannr.

    lv_opbel = ls_budgetbillingplan-opbel. "+3.
    CALL FUNCTION 'ZMFU_CONTENT_PDF_BBP'
      EXPORTING
        iv_opbel   = lv_opbel
      IMPORTING
        ev_pdf_bin = lv_xstring.

    ls_budgetbillingplan-zzpdf = lv_xstring.
** Fin Ajout Alia Consulting 201700910

    er_entity = copy_data_to_ref( ls_budgetbillingplan ).
  ELSE.
**************************************************************************
* Support of long navigation                                             *
**************************************************************************
    TRY.
        super->if_isu_umc_odata_impl~get_entity(
          EXPORTING     iv_entity_name          = iv_entity_name
                        iv_entity_set_name      = iv_entity_set_name
                        iv_source_name          = iv_source_name
                        it_key_tab              = it_key_tab
                        it_navigation_path      = it_navigation_path
                       io_tech_request_context = io_tech_request_context
         IMPORTING     er_entity               = er_entity ).
      CATCH /iwbep/cx_mgw_tech_exception.
        MESSAGE e001(isu_umc_odata) WITH iv_entity_name gc_contract_id INTO lv_string.
        handle_technical_error( 'GET_ENTITY' ).
    ENDTRY.
  ENDIF.
ENDMETHOD.
ENDCLASS.
