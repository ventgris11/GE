*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 17.07.2018 at 19:03:27
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZINTF_IMPAYES...................................*
DATA:  BEGIN OF STATUS_ZINTF_IMPAYES                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_IMPAYES                 .
CONTROLS: TCTRL_ZINTF_IMPAYES
            TYPE TABLEVIEW USING SCREEN '0001'.
*...processing: ZINTF_R_FICHIER.................................*
DATA:  BEGIN OF STATUS_ZINTF_R_FICHIER               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_R_FICHIER               .
CONTROLS: TCTRL_ZINTF_R_FICHIER
            TYPE TABLEVIEW USING SCREEN '0003'.
*...processing: ZINTF_R_LIGNE...................................*
DATA:  BEGIN OF STATUS_ZINTF_R_LIGNE                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_R_LIGNE                 .
CONTROLS: TCTRL_ZINTF_R_LIGNE
            TYPE TABLEVIEW USING SCREEN '0005'.
*.........table declarations:.................................*
TABLES: *ZINTF_IMPAYES                 .
TABLES: *ZINTF_R_FICHIER               .
TABLES: *ZINTF_R_LIGNE                 .
TABLES: ZINTF_IMPAYES                  .
TABLES: ZINTF_R_FICHIER                .
TABLES: ZINTF_R_LIGNE                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
