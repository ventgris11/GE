* regenerated at 23.08.2017 07:55:14
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZB2C_SM30TOP.                     " Global Data
  INCLUDE LZB2C_SM30UXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZB2C_SM30F...                     " Subroutines
* INCLUDE LZB2C_SM30O...                     " PBO-Modules
* INCLUDE LZB2C_SM30I...                     " PAI-Modules
* INCLUDE LZB2C_SM30E...                     " Events
* INCLUDE LZB2C_SM30P...                     " Local class implement.
* INCLUDE LZB2C_SM30T99.                     " ABAP Unit tests
  INCLUDE LZB2C_SM30F00                           . " subprograms
  INCLUDE LZB2C_SM30I00                           . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
