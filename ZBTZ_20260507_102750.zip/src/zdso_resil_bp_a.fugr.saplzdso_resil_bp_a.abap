* regenerated at 21.04.2019 17:53:02
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDSO_RESIL_BP_ATOP.               " Global Data
  INCLUDE LZDSO_RESIL_BP_AUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDSO_RESIL_BP_AF...               " Subroutines
* INCLUDE LZDSO_RESIL_BP_AO...               " PBO-Modules
* INCLUDE LZDSO_RESIL_BP_AI...               " PAI-Modules
* INCLUDE LZDSO_RESIL_BP_AE...               " Events
* INCLUDE LZDSO_RESIL_BP_AP...               " Local class implement.
* INCLUDE LZDSO_RESIL_BP_AT99.               " ABAP Unit tests
  INCLUDE LZDSO_RESIL_BP_AF00                     . " subprograms
  INCLUDE LZDSO_RESIL_BP_AI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
