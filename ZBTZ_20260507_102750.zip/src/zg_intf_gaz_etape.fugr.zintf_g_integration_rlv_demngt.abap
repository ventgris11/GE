FUNCTION zintf_g_integration_rlv_demngt .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  FIELD-SYMBOLS:
    <fs_idenreg>,
    <fs_flux>,
    <fs_num_pce>,
    <fs_date_releve>,
    <fs_flux_re6m>   TYPE zintf_g_re6m,
* FPE GE-83 - implémentation RE1M
    <fs_flux_re1m>   TYPE zintf_g_re1m,
* FPE Fin
    <fs_flux_remm>   TYPE zintf_g_remm.

  DATA:
    lv_field           TYPE string,
    lv_subobj          TYPE balsubobj,
    lv_message         TYPE char255,
    lv_int_ui          TYPE int_ui,
    ls_object          TYPE eedm_isu_objects,
    lv_anlage          TYPE anlage,
    lt_anlage          TYPE isu_t_eanlkey_h,
    ls_obj             TYPE isu17_meterread,
    lt_mr_data         TYPE TABLE OF bapieabl,
    ls_mr_data         TYPE bapieabl,
    lt_mr_reason       TYPE TABLE OF bapieablg,
    ls_return	         TYPE bapireturn1,
    lt_auto            TYPE isu17_meterread_auto,
    ls_eabl            TYPE eabl,
    lv_energie_entier  TYPE v_zwstand,
    lv_energie_decimal TYPE n_zwstand,

    BEGIN OF ls_flux,
      idenreg	                      TYPE zintf_g_id_enreg,
      statut                        TYPE zintf_g_statut,
      num_pce                       TYPE ext_ui,
      emetteur                      TYPE zemetteur_id,
      flux                          TYPE zflux_id,
      date_releve                   TYPE zdate_rel,
      type_releve                   TYPE zzisu_type_releve,
      raison_releve                 TYPE zzisu_raison_releve,
      motif_releve                  TYPE zzmotif_rel,
      debut_periode                 TYPE zzisu_date_deb_per,
      index_brut_debut_periode      TYPE zzisu_index_brut_deb,
      qual_index_brut_debut_periode TYPE zzisu_qlf_index_brut_deb,
      index_conv_debut_periode      TYPE z_index_conv_deb_per,
      qual_index_conv_debut_periode TYPE zqual_index_conv_deb_per,
      fin_periode                   TYPE zdate_fin_per,
      index_brut_fin_periode        TYPE zidx_fin_per,
      qual_index_brut_fin_periode   TYPE zzisu_qlf_index_brut_fin,
      index_conv_fin_periode        TYPE zindex_conv_fin_per,
      qual_index_conv_fin_periode   TYPE zqual_index_conv_fin_per,
      volume_conv                   TYPE zvol_conv,
      qualif_volume_conv            TYPE zqual_vol_conv,
      qualif_pcs                    TYPE zqual_pcs,
      vol_brut_conso                TYPE zzisu_vol_brut,
      qualif_vol_brut_conso         TYPE zzisu_qlf_vol_brut,
      energie_conso                 TYPE zzisu_energie,
      qualif_energie_conso          TYPE zzisu_qlf_energie,
      motif_correction              TYPE zzisu_motif_corr,
      origine_correction            TYPE zzisu_orig_corr,
    END   OF ls_flux.

  DEFINE macro_add_message_to_log.
    MESSAGE ID sy-msgid
          TYPE sy-msgty
        NUMBER sy-msgno
          INTO lv_message
          WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    zcl_tool=>log_add_msg(
      EXPORTING iv_log_object    = zcl_tool=>gc_log_object_intf_gaz
                iv_log_subobject = lv_subobj
                iv_test_mode     = iv_mode_test
      CHANGING  cv_log_handle    = cv_log_handle ).
    RETURN.
  END-OF-DEFINITION.

  ev_etape = 2.

  CLEAR: lv_field.
  MOVE 'FLUX-IDENREG'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_idenreg>.

  CLEAR lv_field.
  MOVE 'FLUX-FLUX' TO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.

  CLEAR lv_field.
  MOVE 'FLUX-NUM_PCE' TO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.

  CLEAR lv_field.
  MOVE 'FLUX-DATE_RELEVE' TO lv_field.
  ASSIGN (lv_field) TO <fs_date_releve>.

  lv_subobj = <fs_flux>.

* Pour récupération de INT_UI
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).
  IF lv_int_ui IS INITIAL.
  ENDIF.

* Pour récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.

  IF ls_object-installation IS INITIAL.
* (ID &1) PCE &2 non rattaché à une installation active à la date du &3
    MESSAGE e044(zintf_g_messages)
       WITH <fs_idenreg>
            <fs_num_pce>
            <fs_date_releve>
       INTO lv_message.
    RETURN.
  ENDIF.

  lv_anlage = ls_object-installation.

  INSERT lv_anlage INTO TABLE lt_anlage.

  " On vérifie si on ne dispose pas déjà d'un historique de releve sur le point
  REFRESH:
    lt_mr_data,
    lt_mr_reason.

  CALL FUNCTION 'BAPI_MTRREADDOC_GETLIST'
    EXPORTING
      installation      = ls_object-installation
      mrdocumenttype    = '1'  "Ordres de relevé
      mrreason          = '03' "Relevé de résiliation emméngt/déméngt
    IMPORTING
      return            = ls_return
    TABLES
      mrdocumentdata    = lt_mr_data
      mrdocumentreasons = lt_mr_reason.

  IF lt_mr_data[] IS INITIAL.
    CALL FUNCTION 'BAPI_MTRREADDOC_GETLIST'
      EXPORTING
        installation      = ls_object-installation
        mrdocumenttype    = '2'  "Résultats relevé
        mrreason          = '03' "Relevé de résiliation emméngt/déméngt
        targetmrdatefrom  = <fs_date_releve>
      IMPORTING
        return            = ls_return
      TABLES
        mrdocumentdata    = lt_mr_data
        mrdocumentreasons = lt_mr_reason.

    IF lt_mr_data[] IS INITIAL.
* (ID &1) PCE &2 Installation &3 sans ordre de déménagement en date du &4
      MESSAGE e094(zintf_g_messages)
         WITH <fs_idenreg>
              <fs_num_pce>
              lv_anlage
              <fs_date_releve>
         INTO lv_message.
      RETURN.
    ENDIF.
  ENDIF.

  READ TABLE lt_mr_data INTO ls_mr_data INDEX 1.
** Ouverture de l'objet relève
  CALL FUNCTION 'ISU_O_METERREAD_OPEN'
    EXPORTING
      x_adatsoll   = <fs_date_releve>
      x_action     = '01'
      x_ablbelnr   = ls_mr_data-mridnumber
      x_wmode      = '2'
      x_select2    = '1'
      x_no_dialog  = 'X'
      x_upd_online = 'X'
      x_no_enqueue = 'X'
      x_auto       = lt_auto
    IMPORTING
      y_obj        = ls_obj
    EXCEPTIONS
      OTHERS       = 99.

  IF sy-subrc NE 0.
    macro_add_message_to_log.
  ENDIF.

  READ TABLE ls_obj-ieabl INTO ls_eabl INDEX 1.

  IF sy-subrc NE 0.
* (ID &1) PCE &2 Installation &3 sans ordre de déménagement en date du &4
    MESSAGE e094(zintf_g_messages)
       WITH <fs_idenreg>
            <fs_num_pce>
            lv_anlage
            <fs_date_releve>
       INTO lv_message.
    RETURN.
  ENDIF.

  CLEAR ls_flux.

* FPE GE-83 - implémentation RE1M
  IF <fs_flux> EQ 'RE6M'.
    ASSIGN flux TO <fs_flux_re6m>.
    MOVE-CORRESPONDING <fs_flux_re6m> TO ls_flux.
  ELSEIF <fs_flux> EQ 'RE1M'.
    ASSIGN flux TO <fs_flux_re1m>.
    MOVE-CORRESPONDING <fs_flux_re1m> TO ls_flux.
  ELSE.
    ASSIGN flux TO <fs_flux_remm>.
    MOVE-CORRESPONDING <fs_flux_remm> TO ls_flux.
  ENDIF.
* FPE GE-83 fin

  CLEAR:
    lv_energie_entier,
    lv_energie_decimal.

  lv_energie_entier = trunc( ls_flux-index_brut_fin_periode ).
  lv_energie_decimal = frac( ls_flux-index_brut_fin_periode ).

  ls_eabl-zwnummer            = 1.
  ls_eabl-adat                = ls_flux-date_releve.
  ls_eabl-v_zwstand           = lv_energie_entier.
  ls_eabl-n_zwstand           = lv_energie_decimal.
  ls_eabl-v_zwstndab          = lv_energie_entier.
  ls_eabl-n_zwstndab          = lv_energie_decimal.
  ls_eabl-adattats            = ls_flux-date_releve.
  ls_eabl-ablstat             = '1'.
  ls_eabl-istablart           = '01'.
  ls_eabl-ablestyp            = '01'.

  ls_eabl-zztype_rel          = ls_flux-type_releve.
  ls_eabl-zzraison_rel        = ls_flux-raison_releve.
  ls_eabl-zzdate_debut        = ls_flux-debut_periode.
  ls_eabl-zzindex_brut_debut  = ls_flux-index_brut_debut_periode.
  ls_eabl-zzqual_index_brut_debut
                              = ls_flux-qual_index_brut_debut_periode.
  IF <fs_flux> EQ 'REMM'.
    ls_eabl-zzindex_conv_debut
                              = ls_flux-index_conv_debut_periode.
    ls_eabl-zzqual_index_conv_debut
                              = ls_flux-qual_index_conv_debut_periode.
  ENDIF.

  ls_eabl-zzdate_fin          = ls_flux-fin_periode.
  ls_eabl-zzqual_index_brut_fin
                              = ls_flux-qual_index_brut_fin_periode.

  IF <fs_flux> EQ 'REMM'.
    ls_eabl-zzindex_conv_fin  = ls_flux-index_conv_fin_periode.
    ls_eabl-zzqual_index_conv_fin
                              = ls_flux-qual_index_conv_fin_periode.
  ENDIF.

  ls_eabl-zzvolume_brut       = ls_flux-vol_brut_conso.
  ls_eabl-zzqual_volume_brut  = ls_flux-qualif_vol_brut_conso.

  IF <fs_flux> EQ 'REMM'.
    ls_eabl-zzvolume_brut_conv
                              = ls_flux-volume_conv.
    ls_eabl-zzqual_volume_conv
                              = ls_flux-qualif_volume_conv.
    ls_eabl-zzqual_coeff_pcs  = ls_flux-qualif_pcs.
  ENDIF.

  ls_eabl-zzenergie           = ls_flux-energie_conso.
  ls_eabl-zzqualif_energie    = ls_flux-qualif_energie_conso.

  IF <fs_flux> EQ 'RE6M' OR <fs_flux> EQ 'RE1M'.
    ls_eabl-zzmotif_corr      = ls_flux-motif_correction.
    ls_eabl-zzorig_corr       = ls_flux-origine_correction.
  ENDIF.

  ls_eabl-zzidenreg           = ls_flux-idenreg.

  MODIFY ls_obj-ieabl FROM ls_eabl INDEX 1.

  CALL FUNCTION 'ISU_O_METERREAD_OPEN_SUBOBJ'
    EXPORTING
      x_action   = '01'
      x_auto     = lt_auto
      x_adatsoll = <fs_date_releve>
    CHANGING
      xy_obj     = ls_obj
    EXCEPTIONS
      OTHERS     = 99.

  IF sy-subrc NE 0.
    macro_add_message_to_log.
  ENDIF.

  CALL FUNCTION 'ISU_O_METERREAD_INPUT'
    CHANGING
      xy_obj = ls_obj
    EXCEPTIONS
      OTHERS = 99.

  IF sy-subrc NE 0.
    macro_add_message_to_log.
  ENDIF.

* Préparation de la sauvegarde
  CALL FUNCTION 'ISU_O_METERREAD_ACTION'
    EXPORTING
      x_okcode = 'PSAV'
    CHANGING
      xy_obj   = ls_obj
    EXCEPTIONS
      OTHERS   = 99.

  IF sy-subrc NE 0.
    macro_add_message_to_log.
  ENDIF.

* sauvegarde
  CALL FUNCTION 'ISU_O_METERREAD_ACTION'
    EXPORTING
      x_okcode = 'SAVE'
    CHANGING
      xy_obj   = ls_obj
    EXCEPTIONS
      OTHERS   = 99.

  IF sy-subrc NE 0.
    macro_add_message_to_log.
  ENDIF.

  CALL FUNCTION 'ISU_O_METERREAD_CLOSE'
    EXPORTING
      x_no_dialog = 'X'
    CHANGING
      xy_obj      = ls_obj
    EXCEPTIONS
      OTHERS      = 99.

  IF sy-subrc NE 0.
    macro_add_message_to_log.
  ENDIF.

  ev_etape = 1.

ENDFUNCTION.
