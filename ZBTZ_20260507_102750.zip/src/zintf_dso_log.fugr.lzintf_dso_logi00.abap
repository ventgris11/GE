*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 11.06.2019 at 17:56:48
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
