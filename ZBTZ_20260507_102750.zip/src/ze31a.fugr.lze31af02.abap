*----------------------------------------------------------------------*
***INCLUDE LE31AF02 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  FILL_HELPER_STR
*&---------------------------------------------------------------------*
FORM fill_helper_str TABLES t_fkkop           STRUCTURE fkkop
                            t_fkkcl           STRUCTURE fkkcl
                     CHANGING
                            tl_mapvtref       TYPE tab_mapvtref
                            tl_mapaccounts    TYPE tab_mapaccounts.
*------------------------------------------------------------
*                      VTREF, VBUND, VERTRAG, EVER-----------
  DATA: wa_mapvtref      TYPE          mapvtref,
*                      VKONT, INVOICING_PARTY----------------
        wa_mapaccounts   TYPE          mapaccounts,
        wa_fkkop         TYPE          fkkop,
        wa_fkkcl         TYPE          fkkcl.
*=======================================================================
*PART I: I_FKKOP I_FKKOP I_FKKOP I_FKKOP I_FKKOP I_FKKOP I_FKKOP
*=======================================================================
  LOOP AT t_fkkop INTO wa_fkkop.
*---------Initialization of all working areas-------------------------
    CLEAR: wa_mapvtref, wa_mapaccounts.
*---------mapvtref----------------------------------------------------

*------------------------------------------mapvtref-VTREF
    IF NOT wa_fkkop-vtref IS INITIAL AND wa_fkkop-subap IS INITIAL.
      MOVE wa_fkkop-vtref TO wa_mapvtref-vtref.
    ENDIF.
*------------------------------------------mapvtref-VBUND
    IF NOT wa_fkkop-vbund IS INITIAL.
      MOVE wa_fkkop-vbund TO wa_mapvtref-vbund.
    ENDIF.
*-----------------------------------------mapvtref-int_crossrefno,
*                                         mapvtref-bldat
    IF NOT wa_fkkop-int_crossrefno IS INITIAL.
      MOVE wa_fkkop-int_crossrefno TO wa_mapvtref-int_crossrefno .
    ENDIF.
    IF NOT wa_mapvtref IS INITIAL.
      MOVE wa_fkkop-bldat TO wa_mapvtref-bldat .
      COLLECT wa_mapvtref INTO tl_mapvtref.
    ENDIF.

*---------mapaccounts------------------------------------------------
*------------------------------------------mapaccounts-INVOICING_PARTY
    IF NOT wa_fkkop-invoicing_party IS INITIAL.
      MOVE wa_fkkop-invoicing_party TO wa_mapaccounts-invoicing_party.
*>>>>> Added 12.08.2008-----------------------------------------------
      MOVE wa_fkkop-vkont           TO wa_mapaccounts-vkont.
*<<<<<<---------------------------------------------------------------

      COLLECT wa_mapaccounts INTO tl_mapaccounts.
    ENDIF.
  ENDLOOP.
*=======================================================================
*PART II: I_FKKCL I_FKKCL I_FKKCL I_FKKCL I_FKKCL I_FKKCL I_FKKCL
*=======================================================================
*   Exactly the same code: replace op by cl --- <fieldsymbol> candidate
  LOOP AT t_fkkcl INTO wa_fkkcl WHERE xaktp NE space.
*---------Initialization of all working areas-------------------------
    CLEAR: wa_mapvtref, wa_mapaccounts.
*---------mapvtref----------------------------------------------------

*------------------------------------------mapvtref-VTREF
    IF NOT wa_fkkcl-vtref IS INITIAL AND wa_fkkcl-subap IS INITIAL.
      MOVE wa_fkkcl-vtref TO wa_mapvtref-vtref.
    ENDIF.
*------------------------------------------mapvtref-VBUND
    IF NOT wa_fkkcl-vbund IS INITIAL.
      MOVE wa_fkkcl-vbund TO wa_mapvtref-vbund.
    ENDIF.
*-----------------------------------------mapvtref-int_crossrefno,
*                                         mapvtref-bldat
    IF NOT wa_fkkcl-int_crossrefno IS INITIAL.
      MOVE wa_fkkcl-int_crossrefno TO wa_mapvtref-int_crossrefno .
    ENDIF.
    IF NOT wa_mapvtref IS INITIAL.
      MOVE wa_fkkcl-bldat TO wa_mapvtref-bldat .
      COLLECT wa_mapvtref INTO tl_mapvtref.
    ENDIF.

*---------mapaccounts------------------------------------------------
*------------------------------------------mapaccounts-INVOICING_PARTY
    IF NOT wa_fkkcl-invoicing_party IS INITIAL.
      MOVE wa_fkkcl-invoicing_party TO wa_mapaccounts-invoicing_party.
*>>>>> Added 12.08.2008-----------------------------------------------
      MOVE wa_fkkcl-vkont           TO wa_mapaccounts-vkont.
*<<<<<<---------------------------------------------------------------
      COLLECT wa_mapaccounts INTO tl_mapaccounts.
    ENDIF.
  ENDLOOP.
ENDFORM.                    " FILL_HELPER_STR
*&---------------------------------------------------------------------*
*&      Form  ISU_CONTRACT_COMPLETE
*&---------------------------------------------------------------------*
FORM isu_contract_complete  CHANGING tl_mapvtref TYPE tab_mapvtref.
*---------------------------------------------
  DATA: wa_mapvtref TYPE mapvtref,
        save_sytabix TYPE sy-tabix.

  LOOP AT tl_mapvtref INTO wa_mapvtref.
    save_sytabix = sy-tabix.

    CALL FUNCTION 'ISU_INTERNAL_VTREF_TO_VERTRAG'
      EXPORTING
        i_vtref   = wa_mapvtref-vtref
      IMPORTING
        e_vertrag = wa_mapvtref-vertrag
      EXCEPTIONS
        OTHERS    = 1.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
    IF NOT wa_mapvtref-vertrag IS INITIAL.
      CALL FUNCTION 'ISU_DB_EVER_SINGLE'
        EXPORTING
          x_vertrag    = wa_mapvtref-vertrag
        IMPORTING
          y_ever       = wa_mapvtref-ever
        EXCEPTIONS
          not_found    = 1
          system_error = 2
          OTHERS       = 3.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
                RAISING input_error.
      ELSE.
        MODIFY tl_mapvtref INDEX save_sytabix
                           FROM  wa_mapvtref TRANSPORTING ever.
      ENDIF.
    ENDIF.
  ENDLOOP.

ENDFORM.                    " ISU_CONTRACT_COMPLETE
*&---------------------------------------------------------------------*
*&      Form  DETERMINE_KEYDATE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--P_TL_MAPCROSSREFNO  text
*----------------------------------------------------------------------*
FORM determine_keydate  CHANGING tl_mapvtref TYPE tab_mapvtref.
*------------------------------------------
  DATA: wa_mapvtref      TYPE mapvtref,
        save_sytabix TYPE sy-tabix,
        wa_ecrossrefno   TYPE ecrossrefno.
  LOOP AT tl_mapvtref INTO wa_mapvtref.
    save_sytabix = sy-tabix.

    IF NOT wa_mapvtref-int_crossrefno IS INITIAL.
      CALL FUNCTION 'ISU_DB_ECROSSREFNO_SINGLE_INT'
        EXPORTING
          x_int_crossrefno = wa_mapvtref-int_crossrefno
        IMPORTING
          y_ecrossrefno    = wa_ecrossrefno
        EXCEPTIONS
          not_found        = 1
          OTHERS           = 2.
      IF sy-subrc = 0.
        wa_mapvtref-keydate = wa_ecrossrefno-keydate.
      ELSE.
        wa_mapvtref-keydate = wa_mapvtref-bldat.
      ENDIF.
    ELSE.
      wa_mapvtref-keydate = wa_mapvtref-bldat.
    ENDIF.
    MODIFY tl_mapvtref INDEX save_sytabix
                       FROM  wa_mapvtref TRANSPORTING keydate.
  ENDLOOP.
ENDFORM.                    " DETERMINE_KEYDATE
*&---------------------------------------------------------------------*
*&      Form  CHECK_DEREG_STATUS
*&---------------------------------------------------------------------*
FORM check_dereg_status  USING    i_process       TYPE inv_par_process
                                  i_vertrag       TYPE vertrag
                                  i_keydate       TYPE endabrpe
                         CHANGING p_param_inv_out TYPE
                                             inv_param_inv_outbound
                                  p_no_sav        TYPE boole_d.
*------------------------------------------------------------------
  CHECK NOT i_vertrag IS INITIAL.
  CALL FUNCTION 'ISU_DEREG_PARAM_INV_REM'
    EXPORTING
      x_process           = i_process
      x_ever_key          = i_vertrag
      x_keydate           = i_keydate
    IMPORTING
      y_param_inv_out     = p_param_inv_out             "Needed
      y_agreement_inactiv = p_no_sav                    "Needed
    EXCEPTIONS
      general_fault       = 1
      no_parameter_found  = 2
      internal_error      = 3
      OTHERS              = 4.

  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.
ENDFORM.                    " CHECK_DEREG_STATUS
*&---------------------------------------------------------------------*
*&      Form  VBUND_DETERMINE
*&---------------------------------------------------------------------*
FORM vbund_determine USING i_account_param
                                    TYPE ttinv_param_inv_outbound_acc
                           i_applk  TYPE applk_kk
                           i_ever   TYPE ever
                      CHANGING
                           p_vbund TYPE vbund.
*----------------------------------------------
  DATA: h_vkont_aggbill TYPE e_edmidevkont_aggbill,
        h_fkkvkp        TYPE fkkvkp.
*--------------------- Determine VKONT AGGR BILL
  CALL FUNCTION 'ISU_AGG_VKONT_DETERMINE'
    EXPORTING
      i_account_param  = i_account_param
      i_applk          = i_applk
      i_ever           = i_ever
    IMPORTING
      vkont_aggbill    = h_vkont_aggbill
    EXCEPTIONS
      no_account_found = 1
      general_error    = 2
      OTHERS           = 3.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.
*--------------------- Detrmine VBUND to VKONT AGGR BILL
  IF NOT h_vkont_aggbill IS INITIAL.
    CALL FUNCTION 'FKK_ACCOUNT_READ'
      EXPORTING
        i_vkont           = h_vkont_aggbill
        i_only_acc_holder = 'X'
        i_applk           = i_applk
      IMPORTING
        e_fkkvkp          = h_fkkvkp
      EXCEPTIONS
        not_found         = 1
        foreign_lock      = 2
        OTHERS            = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ELSE.
      p_vbund =   h_fkkvkp-vbund.
    ENDIF.
  ENDIF.
ENDFORM.                    " VBUND_DETERMINE
