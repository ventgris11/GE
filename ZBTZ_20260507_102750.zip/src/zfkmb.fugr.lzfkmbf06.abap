*&---------------------------------------------------------------------*
*&  Include           LFKMBF06                                         *
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  determine_vknt1
*&---------------------------------------------------------------------*
FORM determine_vknt1_stdbk  TABLES  t_fkkmavs STRUCTURE fkkmavs
                            CHANGING p_vknt1
                                     p_stdbk.

* Static variable to store if event has already been determined
  statics: s_func_module_determined type xfeld value ' '.

  if s_func_module_determined = ' '.
    call function 'FKK_FUNC_MODULE_DETERMINE'
         exporting
              i_fbeve  = '0367'
              i_applk  = applk
         tables
              t_fbstab = t_fbstab_0367
         exceptions
              others   = 0.
    s_func_module_determined = 'X'.
  endif.
* Where-used
  set extended check off.
  if 0 = 1. call function 'FKK_SAMPLE_0367'. endif.
  set extended check on.
* Call event function module
  loop at t_fbstab_0367.
    call function t_fbstab_0367-funcc
         exporting
            t_fkkmavs = t_fkkmavs[]
         changing
            c_vknt1  = p_vknt1
            c_stdbk  = p_stdbk.
  endloop.

* We need a value!
  IF p_vknt1 IS INITIAL.

* Hier muesste Event 0367 aufgerufen werden
* Die alten und neuen Mahnstufen sind auch bekannt
    IF t_fkkmavs-vkont IS INITIAL.
      READ TABLE t_fkkmavs INDEX 1.
    ENDIF.
    p_vknt1 = t_fkkmavs-vkont.

  ENDIF.

  IF p_stdbk IS INITIAL.

    IF t_fkkmavs-vkont IS INITIAL.
      READ TABLE t_fkkmavs INDEX 1.
    ENDIF.
    p_stdbk = t_fkkmavs-stdbk.

  ENDIF.

ENDFORM.                    " determine_vknt1
