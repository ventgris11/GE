*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_FKA5TOP.                      " Global Data
  INCLUDE LZFG_FKA5UXX.                      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_FKA5F...                      " Subroutines
* INCLUDE LZFG_FKA5O...                      " PBO-Modules
* INCLUDE LZFG_FKA5I...                      " PAI-Modules
* INCLUDE LZFG_FKA5E...                      " Events
* INCLUDE LZFG_FKA5P...                      " Local class implement.
* INCLUDE LZFG_FKA5T99.                      " ABAP Unit tests
