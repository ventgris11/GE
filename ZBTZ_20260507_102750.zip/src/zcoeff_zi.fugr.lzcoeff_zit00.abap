*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 25.03.2019 at 09:29:33
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZCOEFF_ZI.......................................*
DATA:  BEGIN OF STATUS_ZCOEFF_ZI                     .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCOEFF_ZI                     .
CONTROLS: TCTRL_ZCOEFF_ZI
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZCOEFF_ZI                     .
TABLES: ZCOEFF_ZI                      .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
