***INCLUDE LFKZ8COM .

* constants for handling of credits
DATA: GC_DDA_CREDITS            TYPE C    VALUE SPACE.

* constants for payment group
DATA: GC_PYGRP_FIRST            TYPE C    VALUE '&'.

* constants for delay times
DATA: GC_COLLECT_EARLIER(3)     TYPE N    VALUE '000',
      GC_COLLECT_EARLIER_REP(3) TYPE N    VALUE '000',
      GC_COLLECT_LATER(3)       TYPE N    VALUE '003',
      GC_COLLECT_LATER_REP(3)   TYPE N    VALUE '030',
      GC_MINDY_FIRST(3)         TYPE N    VALUE '011',
      GC_MAXDY_FIRST(3)         TYPE N    VALUE '016',
      GC_MINDY_RETRY(3)         TYPE N    VALUE '011',
      GC_MAXDY_RETRY(3)         TYPE N    VALUE '999'.
