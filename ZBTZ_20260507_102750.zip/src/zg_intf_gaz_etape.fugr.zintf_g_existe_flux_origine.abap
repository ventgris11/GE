FUNCTION zintf_g_existe_flux_origine .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA: lc_field_num_pce       TYPE fieldname VALUE 'NUM_PCE',
        lc_field_fin_periode   TYPE fieldname VALUE 'FIN_PERIODE',
        lc_field_debut_periode TYPE fieldname VALUE 'DEBUT_PERIODE',
        lc_field_date_releve   TYPE fieldname VALUE 'DATE_RELEVE',
        lc_field_index         TYPE fieldname VALUE 'INDEX_BRUT_FIN_PERIODE',
        lc_field_energie_conso TYPE fieldname VALUE 'ENERGIE_CONSO',
        lc_field_flux          TYPE fieldname VALUE 'FLUX',
        lc_field_statut        TYPE fieldname VALUE 'STATUT',
        lc_field_idenreg       TYPE fieldname VALUE 'IDENREG',
        lv_field_num_pce       TYPE string,
        lv_field_fin_periode   TYPE string,
        lv_field_debut_periode TYPE string,
        lv_field_index         TYPE string,
        lv_field_date_releve   TYPE string,
        lv_field_energie_conso TYPE string,
        lv_field_flux          TYPE string,
        lv_field_statut        TYPE string,
        lv_field_idenreg       TYPE string,
        lv_table               TYPE string,
        lv_string              TYPE string,
        lv_message             TYPE string,
        lv_int_ui              TYPE int_ui.

  DATA: ls_where    TYPE edpline.
  DATA: lt_where    TYPE TABLE OF edpline.

  FIELD-SYMBOLS: <fs_pce>.
  FIELD-SYMBOLS: <fs_fin>.
  FIELD-SYMBOLS: <fs_deb>.
  FIELD-SYMBOLS: <fs_index>.
  FIELD-SYMBOLS: <fs_conso>.
  FIELD-SYMBOLS: <fs_flux>.
  FIELD-SYMBOLS: <fs_statut>.
  FIELD-SYMBOLS: <fs_date_rel>.
  FIELD-SYMBOLS: <lr_struc>.
  FIELD-SYMBOLS: <fs_field_idenreg>.


  DATA :   struct_type TYPE REF TO cl_abap_structdescr,
           itab_type   TYPE REF TO cl_abap_tabledescr,
           dref        TYPE REF TO data.
  FIELD-SYMBOLS : <lt_outtab> TYPE ANY TABLE.


  lv_field_num_pce = 'flux-' && lc_field_num_pce.
  ASSIGN (lv_field_num_pce) TO <fs_pce>.
  IF <fs_pce> IS ASSIGNED.
    lv_field_fin_periode = 'flux-' && lc_field_fin_periode.
    ASSIGN (lv_field_fin_periode) TO <fs_fin>.
    IF <fs_fin> IS ASSIGNED.
      lv_field_debut_periode = 'flux-' && lc_field_debut_periode.
      ASSIGN (lv_field_debut_periode) TO <fs_deb>.
      IF <fs_deb> IS ASSIGNED.
        lv_field_index = 'flux-' && lc_field_index.
        ASSIGN (lv_field_index) TO <fs_index>.
        IF <fs_index> IS ASSIGNED.
          lv_field_energie_conso = 'flux-' && lc_field_energie_conso.
          ASSIGN (lv_field_energie_conso) TO <fs_conso>.
          IF <fs_conso> IS ASSIGNED.
            lv_field_flux = 'flux-' && lc_field_flux.
            ASSIGN (lv_field_flux) TO <fs_flux>.
            IF <fs_flux> IS ASSIGNED.


              lv_table = 'ZINTF_G_' && <fs_flux>.
              struct_type ?= cl_abap_typedescr=>describe_by_name( lv_table ).
              itab_type   = cl_abap_tabledescr=>create( p_line_type = struct_type
                                                        p_table_kind = 'S' ).
              CREATE DATA dref TYPE HANDLE itab_type.
              ASSIGN dref->* TO <lt_outtab>.

** si on a un flux C en statut non final sur le même PCE à la même date
* [le flux C se chargera de faire l’annulation,
*  évite qu’un flux A avec un IDENREG > au flux C annule le flux C qui est censé s’intégrer]
              lv_field_date_releve = 'flux-' && lc_field_date_releve.
              ASSIGN (lv_field_date_releve) TO <fs_date_rel>.

              ls_where = |NUM_PCE = <fs_pce> AND |.                                         APPEND ls_where TO lt_where.
              ls_where = |DATE_RELEVE = <fs_date_rel> AND |.                                APPEND ls_where TO lt_where.
              ls_where = |TYPE_RELEVE = 'C' AND STATUT NOT IN ( '11', '5', '7', '13' ) |. APPEND ls_where TO lt_where.

              SELECT *
                FROM (lv_table)
                INTO TABLE <lt_outtab>
                WHERE (lt_where).
              IF sy-subrc EQ 0.
                ev_etape = 1.

                lv_field_statut = 'flux-' && lc_field_statut.
                ASSIGN (lv_field_statut) TO <fs_statut>.
                IF <fs_statut> IS ASSIGNED.
                  <fs_statut> = zcl_tool=>gc_statut_filtre.
                ENDIF.
                EXIT.
              ENDIF.


**s’il n’y a pas de relève intégrée sur l’installation
*identique aux informations du flux A
*[évite qu’un flux A, censé annuler un flux GRDF, annule une relève déjà annulée,
* normalement ça ne devrait pas arriver mais rajoute une sécurité
*supplémentaire pour ne pas annuler autre chose que ce qui était censé être annulé à la base]

              REFRESH lt_where.
              ls_where = |NUM_PCE = <fs_pce> AND |. APPEND ls_where TO lt_where.
              ls_where = |FIN_PERIODE = <fs_fin> AND |. APPEND ls_where TO lt_where.
              ls_where = |DEBUT_PERIODE = <fs_deb> AND |. APPEND ls_where TO lt_where.
              ls_where = |INDEX_BRUT_FIN_PERIODE = <fs_index> AND |. APPEND ls_where TO lt_where.
              ls_where = |ENERGIE_CONSO = <fs_conso> AND |. APPEND ls_where TO lt_where.
              ls_where = |STATUT = '7' |. APPEND ls_where TO lt_where.

              CREATE DATA dref TYPE HANDLE itab_type.
              ASSIGN dref->* TO <lt_outtab>.

              SELECT *
                FROM (lv_table)
                INTO TABLE <lt_outtab>
                WHERE (lt_where).
              IF sy-subrc NE 0.
                ev_etape = 1.

                lv_field_statut = 'flux-' && lc_field_statut.
                ASSIGN (lv_field_statut) TO <fs_statut>.
                IF <fs_statut> IS ASSIGNED.
                  <fs_statut> = zcl_tool=>gc_statut_filtre.
                ENDIF.
                EXIT.
              ENDIF.


              REFRESH lt_where.
              lv_field_idenreg = 'flux-' && lc_field_idenreg.
              ASSIGN (lv_field_idenreg) TO <fs_field_idenreg>.
              ls_where = |IDENREG <> <fs_field_idenreg> AND |. APPEND ls_where TO lt_where.
              ls_where = |NUM_PCE = <fs_pce> AND |. APPEND ls_where TO lt_where.
              ls_where = |FIN_PERIODE = <fs_fin> AND |. APPEND ls_where TO lt_where.
              ls_where = |DEBUT_PERIODE = <fs_deb> AND |. APPEND ls_where TO lt_where.
              ls_where = |INDEX_BRUT_FIN_PERIODE = <fs_index> AND |. APPEND ls_where TO lt_where.
              ls_where = |ENERGIE_CONSO = <fs_conso> AND |. APPEND ls_where TO lt_where.
              ls_where = |STATUT NOT IN ( '11', '5', '7', '13' ) |. APPEND ls_where TO lt_where.


*Vérifier s'il existe un ou plusieurs flux d’origine qui n’est pas au statut final
              SELECT *
                FROM (lv_table)
                INTO TABLE <lt_outtab>
                WHERE (lt_where).
              IF sy-subrc EQ 0.
*S’il existe un flux d’origine
*Filtrer le flux d’annulation ET le flux d’origine
*Attribuer le message informatif « Flux A : [IDENREG1] filtré avec [IDENREG2] » au flux d’annulation ET au flux d’origine filtré
                ev_etape = 1.

                lv_field_statut = 'flux-' && lc_field_statut.
                ASSIGN (lv_field_statut) TO <fs_statut>.
                IF <fs_statut> IS ASSIGNED.
                  <fs_statut> = zcl_tool=>gc_statut_filtre.
                ENDIF.

                SORT <lt_outtab> BY (lc_field_idenreg) ASCENDING.
                LOOP AT <lt_outtab> ASSIGNING FIELD-SYMBOL(<fs_outtab>).
                  lv_field_statut = '<fs_outtab>-' && lc_field_statut.
                  ASSIGN (lv_field_statut) TO <fs_statut>.
                  IF <fs_statut> IS ASSIGNED.
                    <fs_statut> = zcl_tool=>gc_statut_filtre.
                  ENDIF.

                  lv_string = 'flux-' && lc_field_idenreg.
                  ASSIGN (lv_string) TO <lr_struc>.
                  lv_field_idenreg = '<fs_outtab>-' && lc_field_idenreg.
                  ASSIGN (lv_field_idenreg) TO <fs_field_idenreg>.
                  MESSAGE i256(zintf_g_messages) WITH <lr_struc> <fs_field_idenreg> INTO lv_message.

                  lv_string = 'flux-msg'.
                  ASSIGN (lv_string) TO <lr_struc>.
                  <lr_struc> = lv_message.

                  lv_string = 'flux-msgno'.
                  ASSIGN (lv_string) TO <lr_struc>.
                  <lr_struc> = sy-msgno.

                  lv_string = 'flux-msgty'.
                  ASSIGN (lv_string) TO <lr_struc>.
                  <lr_struc> = sy-msgty.

                  lv_string = 'flux-msgid'.
                  ASSIGN (lv_string) TO <lr_struc>.
                  <lr_struc> = sy-msgid.

                  lv_string = 'flux-msgv1'.
                  ASSIGN (lv_string) TO <lr_struc>.
                  <lr_struc> = sy-msgv1.

                  lv_string = 'flux-msgv2'.
                  ASSIGN (lv_string) TO <lr_struc>.
                  <lr_struc> = sy-msgv2.

                  lv_string = '<fs_outtab>-msg'.
                  ASSIGN (lv_string) TO <lr_struc>.
                  <lr_struc> = lv_message.

                  lv_string = '<fs_outtab>-msgno'.
                  ASSIGN (lv_string) TO <lr_struc>.
                  <lr_struc> = sy-msgno.

                  lv_string = '<fs_outtab>-msgty'.
                  ASSIGN (lv_string) TO <lr_struc>.
                  <lr_struc> = sy-msgty.

                  lv_string = '<fs_outtab>-msgid'.
                  ASSIGN (lv_string) TO <lr_struc>.
                  <lr_struc> = sy-msgid.

                  lv_string = '<fs_outtab>-msgv1'.
                  ASSIGN (lv_string) TO <lr_struc>.
                  <lr_struc> = sy-msgv1.

                  lv_string = '<fs_outtab>-msgv2'.
                  ASSIGN (lv_string) TO <lr_struc>.
                  <lr_struc> = sy-msgv2.
                  UPDATE (lv_table) from <fs_outtab>.
                  COMMIT WORK.
                  EXIT.
                ENDLOOP.
              ELSE.
*Si le flux d’annulation a moins de 5 jours, le flux est récent [date du jour – date de création (ZINTF_G_RE*-DATE_CREATION) < 5]
* Le flux d’annulation type ‘A’ passe au statut de mise en attente synchro
* Attribuer le message  « Flux A : attente réception de la nouvelle relève jusqu'à [5] jours avant d'annuler »
                lv_string = 'flux-date_creation'.
                ASSIGN (lv_string) TO <lr_struc>.
                IF ( sy-datum  - <lr_struc> )  < 5.
                  lv_field_statut = 'flux-' && lc_field_statut.
                  ASSIGN (lv_field_statut) TO <fs_statut>.
                  IF <fs_statut> IS ASSIGNED.
                    <fs_statut> = zcl_tool=>gc_statut_mea_sync.
                  ENDIF.
                  MESSAGE i257(zintf_g_messages) INTO lv_message.

                  lv_string = 'flux-msg'.
                  ASSIGN (lv_string) TO <lr_struc>.
                  <lr_struc> = lv_message.

                  lv_string = 'flux-msgno'.
                  ASSIGN (lv_string) TO <lr_struc>.
                  <lr_struc> = sy-msgno.

                  lv_string = 'flux-msgty'.
                  ASSIGN (lv_string) TO <lr_struc>.
                  <lr_struc> = sy-msgty.

                  lv_string = 'flux-msgid'.
                  ASSIGN (lv_string) TO <lr_struc>.
                  <lr_struc> = sy-msgid.
                  ev_etape = 1.
                ELSE.
                  ev_etape = 2.
                ENDIF.
              ENDIF.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
  ELSE.
*    "Erreur technique
  ENDIF.


ENDFUNCTION.
