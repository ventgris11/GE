* regenerated at 03.04.2019 15:45:50
FUNCTION-POOL ZDSORES_STAT_MAP           MESSAGE-ID SV.

* INCLUDE LZDSORES_STAT_MAPD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDSORES_STAT_MAPT00                    . "view rel. data dcl.
