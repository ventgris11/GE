FUNCTION-POOL ZE25S.

*$*$** Typgruppen & Typen *********************************************
TYPE-POOLS: isu21.
TYPE-POOLS: isu25.
TYPE-POOLS: isudr.
TYPE-POOLS: eemsg.

TABLES: te633.

INCLUDE emsg.
INCLUDE meamac00.
INCLUDE ieupdmod.
INCLUDE ie00flag.
INCLUDE iebbpcod.
INCLUDE ieokcode.
INCLUDE iekconst.
INCLUDE iecominv.
INCLUDE ieacovkk.
INCLUDE le25sh10.
INCLUDE ieaabrvg.
INCLUDE ieastdat.
INCLUDE lea61psh0c.
INCLUDE iee_inv_par_process.
INCLUDE ies31cns.       "Constants for installation disconnection-status
INCLUDE iedcncns.       "Constants for installation disconnection

* global field ISU_S_BBP_CONVERT_EURO and ISU_S_BBP_PORTION_CHANGE
DATA: f_vz_out LIKE regen-kennzx.
* global Tab for TEABSTVOR
DATA: mt_teabstvor LIKE teabstvor OCCURS 0,
      m_teabstvor LIKE teabstvor.

* Speichert die physische Struktur vor einer Aenderung (ifkkop)
DATA  BEGIN OF merkifkkop OCCURS 1.
        INCLUDE STRUCTURE fkkop.
DATA  END   OF merkifkkop.

* Speichert die physische Struktur vor einer Aenderung (ifkkopw)
DATA  BEGIN OF merkifkkopw OCCURS 1.
        INCLUDE STRUCTURE fkkopw.
DATA  END   OF merkifkkopw.

* Cache zum selektieren der Abrechnungsklasse
DATA: eanl_cache  TYPE TABLE OF isu25_eanl_cache,
      cache_count TYPE p.

* Makro zur Fehlerbehandlung im Portionswechsel
SET EXTENDED CHECK OFF.
DATA: h_msg TYPE eemsg_msg_single.
DEFINE mac_close.
* letzte Meldung holen
  mac_prot_msg_last.
* letzte Meldung zwischenspeichern
  h_msg-msgno = last_msg-msgno.
  h_msg-msgid = last_msg-msgid.
  h_msg-msgv1 = last_msg-msgv1.
  h_msg-msgv2 = last_msg-msgv2.
  h_msg-msgv3 = last_msg-msgv3.
  h_msg-msgv4 = last_msg-msgv4.

  perform f20_close_object using &1.
  mac_msg_putx &2 h_msg-msgno h_msg-msgid
               h_msg-msgv1 h_msg-msgv2 h_msg-msgv3 h_msg-msgv4 &3.
END-OF-DEFINITION.
SET EXTENDED CHECK ON.
