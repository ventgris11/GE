*----------------------------------------------------------------------*
***INCLUDE LFKMBF08 .
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  call_charge_exits
*&---------------------------------------------------------------------*
*       The dunning header should be changed in the following
*       fields:
*         CHGID    BONIT
*                          MGE1M MG1TY
*                          MGE2M MG2TY
*                          MGE3M MG3TY
*       The charge events are called here
*----------------------------------------------------------------------*
FORM call_charge_exits  TABLES   pt_fkkmaze STRUCTURE i_fkkmaze
                        CHANGING c_fkkmako TYPE fkkmako.


  STATICS: st_fbstab_0360 LIKE tfkfbc OCCURS 1 WITH HEADER LINE,
           st_fbstab_0361 LIKE tfkfbc OCCURS 1 WITH HEADER LINE,
           st_fbstab_0362 LIKE tfkfbc OCCURS 1 WITH HEADER LINE.

* Have the function modules
  READ TABLE st_fbstab_0360 INDEX 1.
  IF sy-subrc NE 0.
    CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
      EXPORTING
        i_fbeve       = '0360'
        i_applk       = applk
      TABLES
        t_fbstab      = st_fbstab_0360
      EXCEPTIONS
        error_message = 1.
    IF sy-subrc NE 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
    CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
      EXPORTING
        i_fbeve       = '0361'
        i_applk       = applk
      TABLES
        t_fbstab      = st_fbstab_0361
      EXCEPTIONS
        error_message = 1.
    IF sy-subrc NE 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
    CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
      EXPORTING
        i_fbeve       = '0362'
        i_applk       = applk
      TABLES
        t_fbstab      = st_fbstab_0362
      EXCEPTIONS
        error_message = 1.
    IF sy-subrc NE 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
  ENDIF.
* Where-used
  SET EXTENDED CHECK OFF.
  IF 0 = 1.
    CALL FUNCTION 'FKK_SAMPLE_0360'.
    CALL FUNCTION 'FKK_SAMPLE_0361'.
    CALL FUNCTION 'FKK_SAMPLE_0362'.
  ENDIF.
  SET EXTENDED CHECK ON.

  DATA t_dummy_makt LIKE fkkmakt OCCURS 0.
  DATA t_dummy_op   LIKE fkkop   OCCURS 0.
  DATA t_dummy_opk  LIKE fkkopk  OCCURS 0.
  DATA t_fimsg      LIKE fimsg   OCCURS 0 WITH HEADER LINE.
  DATA dummy_fkkko  TYPE fkkko.
* Call the three charge event function modules
* First charge
  LOOP AT st_fbstab_0360.
    CALL FUNCTION st_fbstab_0360-funcc
      EXPORTING
        i_only_calc   = 'X'
      TABLES
        t_fkkmaze     = pt_fkkmaze
        t_fkkmakt     = t_dummy_makt
        t_fkkop       = t_dummy_op
        t_fkkopk      = t_dummy_opk
        t_fimsg       = t_fimsg
      CHANGING
        c_fkkmako     = c_fkkmako
        c_fkkko       = dummy_fkkko
      EXCEPTIONS
        error_message = 1
        OTHERS        = 2.
    IF sy-subrc <> 0.
      PERFORM log_symsg USING space.
    ENDIF.
  ENDLOOP.
* log the result
  PERFORM msg_to_log TABLES t_fimsg.
  REFRESH t_fimsg.

* First charge
  LOOP AT st_fbstab_0361.
    CALL FUNCTION st_fbstab_0361-funcc
      EXPORTING
        i_only_calc   = 'X'
      TABLES
        t_fkkmaze     = pt_fkkmaze
        t_fkkmakt     = t_dummy_makt
        t_fkkop       = t_dummy_op
        t_fkkopk      = t_dummy_opk
        t_fimsg       = t_fimsg
      CHANGING
        c_fkkmako     = c_fkkmako
        c_fkkko       = dummy_fkkko
      EXCEPTIONS
        error_message = 1
        OTHERS        = 2.
    IF sy-subrc <> 0.
      PERFORM log_symsg USING space.
    ENDIF.
  ENDLOOP.
* log the result
  PERFORM msg_to_log TABLES t_fimsg.
  REFRESH t_fimsg.

* First charge
  LOOP AT st_fbstab_0362.
    CALL FUNCTION st_fbstab_0362-funcc
      EXPORTING
        i_only_calc   = 'X'
      TABLES
        t_fkkmaze     = pt_fkkmaze
        t_fkkmakt     = t_dummy_makt
        t_fkkop       = t_dummy_op
        t_fkkopk      = t_dummy_opk
        t_fimsg       = t_fimsg
      CHANGING
        c_fkkmako     = c_fkkmako
        c_fkkko       = dummy_fkkko
      EXCEPTIONS
        error_message = 1
        OTHERS        = 2.
    IF sy-subrc <> 0.
      PERFORM log_symsg USING space.
    ENDIF.
  ENDLOOP.
* log the result
  PERFORM msg_to_log TABLES t_fimsg.
  REFRESH t_fimsg.

ENDFORM.                    " call_charge_exits


*&---------------------------------------------------------------------*
*&      Form  MSG_TO_LOG
*&---------------------------------------------------------------------*
FORM msg_to_log TABLES t_fimsg STRUCTURE fimsg.

  DATA: l_probclass TYPE balprobcl.


  LOOP AT t_fimsg.
    IF t_fimsg-msgpr NA '1234'.
      t_fimsg-msgpr = '4'.
    ENDIF.
*    mac_appl_log_msg t_fimsg-msgty t_fimsg-msgid t_fimsg-msgno
*                t_fimsg-msgv1 t_fimsg-msgv2 t_fimsg-msgv3 t_fimsg-msgv4
*                  t_fimsg-msgpr gl_para_0300-probclass.
    MOVE: t_fimsg-msgpr TO l_probclass.
    CALL FUNCTION 'FKK_AKTIV2_APPL_LOG_MSG'
      EXPORTING
        i_msgty                  = t_fimsg-msgty
        i_msgid                  = t_fimsg-msgid
        i_msgno                  = t_fimsg-msgno
        i_msgv1                  = t_fimsg-msgv1
        i_msgv2                  = t_fimsg-msgv2
        i_msgv3                  = t_fimsg-msgv3
        i_msgv4                  = t_fimsg-msgv4
        i_probclass_this_message = l_probclass
      CHANGING
        i_desired_probclass      = gl_para_0300-probclass.
  ENDLOOP.
  CLEAR t_fimsg.

ENDFORM.                                  " MSG_TO_LOG

*&---------------------------------------------------------------------*
*&      Form  LOG_SYMSG
*&---------------------------------------------------------------------*
FORM log_symsg USING p_level LIKE fimsg-msgpr.

  DATA: h_fimsg LIKE fimsg OCCURS 10 WITH HEADER LINE.

  CLEAR h_fimsg.
  h_fimsg-msgid = sy-msgid.
  h_fimsg-msgty = sy-msgty.
  h_fimsg-msgno = sy-msgno.
  h_fimsg-msgv1 = sy-msgv1.
  h_fimsg-msgv2 = sy-msgv2.
  h_fimsg-msgv3 = sy-msgv3.
  h_fimsg-msgv4 = sy-msgv4.
  h_fimsg-msgpr = '1'.
  APPEND h_fimsg.
  PERFORM msg_to_log TABLES h_fimsg.

ENDFORM.                               " LOG_MESSAGE_PARA
