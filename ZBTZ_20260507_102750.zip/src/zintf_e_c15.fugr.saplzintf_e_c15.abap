* regenerated at 02.10.2020 14:54:39
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZINTF_E_C15TOP.                   " Global Data
  INCLUDE LZINTF_E_C15UXX.                   " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZINTF_E_C15F...                   " Subroutines
* INCLUDE LZINTF_E_C15O...                   " PBO-Modules
* INCLUDE LZINTF_E_C15I...                   " PAI-Modules
* INCLUDE LZINTF_E_C15E...                   " Events
* INCLUDE LZINTF_E_C15P...                   " Local class implement.
* INCLUDE LZINTF_E_C15T99.                   " ABAP Unit tests
  INCLUDE LZINTF_E_C15F00                         . " subprograms
  INCLUDE LZINTF_E_C15I00                         . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
