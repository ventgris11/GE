* regenerated at 02.10.2020 14:54:39
FUNCTION-POOL ZINTF_E_C15                MESSAGE-ID SV.

* INCLUDE LZINTF_E_C15D...                   " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZINTF_E_C15T00                         . "view rel. data dcl.
