*&---------------------------------------------------------------------*
*&  Include           LFKMBF05                                         *
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  EVENT_0303
*&---------------------------------------------------------------------*
FORM event_0303 USING i_fkkvkp STRUCTURE fkkvkp
                CHANGING c_fkkmavs STRUCTURE fkkmavs
                         mahnbar TYPE c.

  READ TABLE t_fbstab_0303 INDEX 1.
  IF sy-subrc NE 0.
    CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
      EXPORTING
        i_fbeve       = '0303'
        i_applk       = applk
      TABLES
        t_fbstab      = t_fbstab_0303
      EXCEPTIONS
        error_message = 1.
* No entry? Abort immediately!
    IF sy-subrc NE 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
  ENDIF.
* Any of the function modules called for event 0303 may decide that the
* current item (C_FKKMAVS) should not appear in a dunning notice:
  mahnbar = 'J'.
  LOOP AT t_fbstab_0303.
    CALL FUNCTION t_fbstab_0303-funcc
      EXPORTING
        para_0300 = gl_para_0300
        i_fkkvkp  = i_fkkvkp
      CHANGING
        c_fkkmavs = c_fkkmavs
      EXCEPTIONS
        write_log = 2
        no_log    = 3.
    IF sy-subrc = 2.
      PERFORM message_append USING sy-msgid sy-msgty sy-msgno
                                   sy-msgv1 sy-msgv2
                                   sy-msgv3 sy-msgv4 '2'.
    ENDIF.
    IF sy-subrc <> 0.
      mahnbar = 'N'.
    ENDIF.
  ENDLOOP.
* Where-used list
  SET EXTENDED CHECK OFF.
  IF 1 = 2. CALL FUNCTION 'FKK_SAMPLE_0303'. ENDIF.
  SET EXTENDED CHECK ON.

ENDFORM.                               " EVENT_0303

*---------------------------------------------------------------------*
*       FORM EVENT_0304                                               *
*---------------------------------------------------------------------*
FORM event_0304 TABLES   t_fkkmavs STRUCTURE fkkmavs
                CHANGING c_fkkmavs STRUCTURE fkkmavs.

  DATA para_0300 TYPE fkkma_0300.

  MOVE-CORRESPONDING gl_para_0300 TO para_0300.

  READ TABLE t_fbstab_0304 INDEX 1.
  IF sy-subrc NE 0.
    CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
      EXPORTING
        i_fbeve       = '0304'
        i_applk       = applk
      TABLES
        t_fbstab      = t_fbstab_0304
      EXCEPTIONS
        error_message = 1
        OTHERS        = 2.
* No entry? Abort immediately!
    IF sy-subrc NE 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
  ENDIF.
  LOOP AT t_fbstab_0304.
    CALL FUNCTION t_fbstab_0304-funcc
      EXPORTING
        para_0300     = para_0300
        i_fkkmavs     = c_fkkmavs
      IMPORTING
        e_xlmst       = c_fkkmavs-xlmst
      TABLES
        it_fkkmavs    = t_fkkmavs
      CHANGING
        c_mahnn       = c_fkkmavs-mahnn
        c_mstnn       = c_fkkmavs-mstnn
        c_mahns       = c_fkkmavs-mahns
        c_dl_manual   = c_fkkmavs-dl_manual
      EXCEPTIONS
        error_message = 1
        OTHERS        = 2.
    IF sy-subrc NE 0.
      PERFORM message_append USING sy-msgid sy-msgty sy-msgno
                                   sy-msgv1 sy-msgv2
                                   sy-msgv3 sy-msgv4 '1'.
    ENDIF.
  ENDLOOP.
* Verwendungsnachweis
  SET EXTENDED CHECK OFF.
  IF 1 = 0.  CALL FUNCTION 'FKK_SAMPLE_0304'. ENDIF.
  SET EXTENDED CHECK ON.

ENDFORM.                               " EVENT_0304

*---------------------------------------------------------------------*
*      Form  EVENT_0306
*---------------------------------------------------------------------*
FORM event_0306 TABLES   i_fkkmavs  STRUCTURE fkkmavs
                         i_fkkmagrp STRUCTURE fkkmagrp.

  STATICS func_mod_0306_determined TYPE xfeld VALUE ' '.

  IF func_mod_0306_determined = ' '.
    CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
      EXPORTING
        i_fbeve       = '0306'
        i_applk       = applk
      TABLES
        t_fbstab      = t_fbstab_0306
      EXCEPTIONS
        error_message = 1
        OTHERS        = 2.
* No entry? Abort immediately!
    IF sy-subrc NE 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
    func_mod_0306_determined = 'X'.
  ENDIF.
  LOOP AT t_fbstab_0306.
    CALL FUNCTION t_fbstab_0306-funcc
      EXPORTING
        i0306_para_0300 = gl_para_0300
      TABLES
        t0306_fkkmavs   = i_fkkmavs
        t0306_fkkmagrp  = i_fkkmagrp
      EXCEPTIONS
        error_message   = 1.
    IF sy-subrc = 1.
      PERFORM message_append USING sy-msgid sy-msgty sy-msgno
                                   sy-msgv1 sy-msgv2
                                   sy-msgv3 sy-msgv4 '1'.
    ENDIF.
  ENDLOOP.
* Verwendungsnachweis
  SET EXTENDED CHECK OFF.
  IF 1 = 0.  CALL FUNCTION 'FKK_SAMPLE_0306'. ENDIF.
  SET EXTENDED CHECK ON.

ENDFORM.                               " EVENT_0306

*---------------------------------------------------------------------*
*       FORM EVENT_0307                                               *
*---------------------------------------------------------------------*
FORM event_0307 TABLES   it_fkkmavs STRUCTURE fkkmavs
                         it_mahnst_tab STRUCTURE fkk_mahnst
                CHANGING p_mahnv TYPE fkkmagrp-mahnv
                         i_fkkmagrp LIKE fkkmagrp.

  DATA para_0300 TYPE fkkma_0300.

  MOVE-CORRESPONDING gl_para_0300 TO para_0300.

  READ TABLE t_fbstab_0307 INDEX 1.
  IF sy-subrc NE 0.
    CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
      EXPORTING
        i_fbeve       = '0307'
        i_applk       = applk
      TABLES
        t_fbstab      = t_fbstab_0307
      EXCEPTIONS
        error_message = 1
        OTHERS        = 2.
*   No entry? Abort immediately!
    IF sy-subrc NE 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
  ENDIF.
  LOOP AT t_fbstab_0307.
    CALL FUNCTION t_fbstab_0307-funcc
      EXPORTING
        i_para_0300   = para_0300
        i_fkkmagrp    = i_fkkmagrp
      IMPORTING
        e_mahnv       = p_mahnv
      TABLES
        it_fkkmavs    = it_fkkmavs
        it_mahnst_tab = it_mahnst_tab
      EXCEPTIONS
        error_message = 1
        OTHERS        = 2.
    IF sy-subrc NE 0.
      PERFORM message_append USING sy-msgid sy-msgty sy-msgno
                                   sy-msgv1 sy-msgv2
                                   sy-msgv3 sy-msgv4 '1'.
    ENDIF.
  ENDLOOP.
* Verwendungsnachweis
  SET EXTENDED CHECK OFF.
  IF 1 = 0.  CALL FUNCTION 'FKK_SAMPLE_0307'. ENDIF.
  SET EXTENDED CHECK ON.

ENDFORM.                               " EVENT_0307
*&---------------------------------------------------------------------*
*&      Form  event_0317
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_I_FKKMAVS  text
*      -->P_I_FKKMAGRP  text
*----------------------------------------------------------------------*
FORM event_0317  TABLES   ct_fkkmavs  STRUCTURE fkkmavs
                          ct_fkkmagrp STRUCTURE fkkmagrp.


  READ TABLE t_fbstab_0317 INDEX 1.

  IF sy-subrc NE 0.
    CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
      EXPORTING
        i_fbeve       = '0317'
        i_applk       = applk
      TABLES
        t_fbstab      = t_fbstab_0317
      EXCEPTIONS
        error_message = 1
        OTHERS        = 2.
*   No entry? Abort immediately!
    IF sy-subrc NE 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
  ENDIF.

  LOOP AT t_fbstab_0317.
    CALL FUNCTION t_fbstab_0317-funcc
      EXPORTING
        i_para_0300   = gl_para_0300
      CHANGING
        ct_fkkmavs    = ct_fkkmavs[]
        ct_fkkmagrp   = ct_fkkmagrp[]
      EXCEPTIONS
        error_message = 1.
    IF sy-subrc NE 0.
      PERFORM message_append USING sy-msgid sy-msgty sy-msgno
                                   sy-msgv1 sy-msgv2
                                   sy-msgv3 sy-msgv4 '1'.
    ENDIF.
  ENDLOOP.
* Verwendungsnachweis
  SET EXTENDED CHECK OFF.
  IF 1 = 0.  CALL FUNCTION 'FKK_SAMPLE_0317'. ENDIF.
ENDFORM.                    " event_0317
