*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 20.02.2019 at 16:37:18
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
