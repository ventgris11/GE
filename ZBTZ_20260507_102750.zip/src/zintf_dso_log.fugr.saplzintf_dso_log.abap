* regenerated at 11.06.2019 17:56:48
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZINTF_DSO_LOGTOP.                 " Global Data
  INCLUDE LZINTF_DSO_LOGUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZINTF_DSO_LOGF...                 " Subroutines
* INCLUDE LZINTF_DSO_LOGO...                 " PBO-Modules
* INCLUDE LZINTF_DSO_LOGI...                 " PAI-Modules
* INCLUDE LZINTF_DSO_LOGE...                 " Events
* INCLUDE LZINTF_DSO_LOGP...                 " Local class implement.
* INCLUDE LZINTF_DSO_LOGT99.                 " ABAP Unit tests
  INCLUDE LZINTF_DSO_LOGF00                       . " subprograms
  INCLUDE LZINTF_DSO_LOGI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
