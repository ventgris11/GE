CLASS zcl_split_csv_eld_gaz DEFINITION
  PUBLIC
  CREATE PUBLIC .

  PUBLIC SECTION.

    TYPES:
      tt_files TYPE STANDARD TABLE OF eps2fili .
    TYPES:
      BEGIN OF ty_longtext,
        msgv1(50),
        msgv2(50),
        msgv3(50),
        msgv4(50),
      END OF ty_longtext .

    DATA p_emet TYPE zemetteur_id .
    DATA p_idflux TYPE zconv_flux .
    DATA pt_files TYPE tt_files .
    CONSTANTS c_log_object TYPE balobj_d VALUE 'ZSPLIT_CSV_ELD_GAZ' ##NO_TEXT.
    CONSTANTS c_log_subobject TYPE balsubobj VALUE 'ZSPLIT_CSV_ELD_GAZ' ##NO_TEXT.
    CONSTANTS c_dreu_emet TYPE string VALUE '17X100A100A04388' ##NO_TEXT.
    CONSTANTS c_grnb_emet TYPE string VALUE '17X100A100A0416I' ##NO_TEXT.
    DATA p_rep_in TYPE fileintern .
    DATA p_rep_ar TYPE fileintern .
    DATA p_rep_refuse TYPE fileintern .
    DATA po_log TYPE REF TO zi_log .
    DATA po_files_manager TYPE REF TO zcl_utils_file_manager .
    DATA p_dir_in TYPE eps2filnam .
    DATA p_dir_ar TYPE eps2filnam .

    METHODS main .
    METHODS constructor
      IMPORTING
        !i_emet       TYPE zemetteur_id
        !i_idflux     TYPE zconv_flux
        !i_rep_in     TYPE fileintern
        !i_rep_ar     TYPE fileintern
        !i_rep_refuse TYPE fileintern .
    METHODS exec_python
      IMPORTING
        !i_name TYPE eps2filnam
      RAISING
        zcx_split_eld_gaz_error .
    METHODS delete_txt
      IMPORTING
        !i_name TYPE eps2filnam
      RAISING
        zcx_split_eld_gaz_error .
    METHODS get_files_from_rep
      RAISING
        zcx_split_eld_gaz_error .
    METHODS get_lines_of_file
      IMPORTING
        !i_name        TYPE eps2filnam
      RETURNING
        VALUE(r_lines) TYPE table_of_strings
      RAISING
        zcx_split_eld_gaz_error .
    METHODS save_log .
    METHODS display_log .
    METHODS treat_file
      IMPORTING
        !i_lines TYPE table_of_strings
        !i_name  TYPE eps2filnam
      RAISING
        zcx_split_eld_gaz_error .
    METHODS create_files
      RAISING
        zcx_split_eld_gaz_error .
    METHODS add_to_archive
      IMPORTING
        !i_name TYPE eps2filnam
      RAISING
        zcx_split_eld_gaz_error .
    METHODS add_to_refuse
      IMPORTING
        !i_name TYPE eps2filnam
      RAISING
        zcx_split_eld_gaz_error .
  PROTECTED SECTION.

  PRIVATE SECTION.
ENDCLASS.



CLASS ZCL_SPLIT_CSV_ELD_GAZ IMPLEMENTATION.


  METHOD add_to_archive.

    DATA :
          ls_longtext  TYPE ty_longtext.

    ls_longtext = i_name.

    TRY .

        po_files_manager->move_file( x_file = CONV string( i_name ) x_lpath_source = p_rep_in x_lpath_target = p_rep_ar x_param1 = p_emet x_param2 = p_idflux x_param3 = space ).

        " Fichier &1&2&3 déplacé dans le répertoire &4
        MESSAGE s006(zsplit_csv_eld_gaz) WITH ls_longtext-msgv1 ls_longtext-msgv2 ls_longtext-msgv3 p_rep_ar INTO DATA(lv_dummy).
        po_log->add_sy_msg( ).

      CATCH zcx_utils_file_error.

        " Impossible de déplacer le fichier &1 dans le répertoire &2
        MESSAGE e007(zsplit_csv_eld_gaz) WITH ls_longtext-msgv1 ls_longtext-msgv2 ls_longtext-msgv3 ls_longtext-msgv4 INTO lv_dummy.
        po_log->add_sy_msg( ).

    ENDTRY.

  ENDMETHOD.


  METHOD add_to_refuse.

    DATA :
          ls_longtext  TYPE ty_longtext.

    ls_longtext = i_name.

    TRY .

        po_files_manager->move_file( x_file = CONV string( i_name ) x_lpath_source = p_rep_in x_lpath_target = p_rep_ar x_param1 = p_emet x_param2 = p_idflux x_param3 = space ).

        " Fichier &1&2&3 déplacé dans le répertoire &4
        MESSAGE s006(zsplit_csv_eld_gaz) WITH ls_longtext-msgv1 ls_longtext-msgv2 ls_longtext-msgv3 p_rep_ar INTO DATA(lv_dummy).
        po_log->add_sy_msg( ).

      CATCH zcx_utils_file_error.

        " Impossible de déplacer le fichier &1 dans le répertoire &2
        MESSAGE e007(zsplit_csv_eld_gaz) WITH ls_longtext-msgv1 ls_longtext-msgv2 ls_longtext-msgv3 ls_longtext-msgv4 INTO lv_dummy.

    ENDTRY.

  ENDMETHOD.


  METHOD constructor.

    p_emet          = i_emet.
    p_rep_in        = i_rep_in.
    p_rep_ar        = i_rep_ar.
    p_rep_refuse    = i_rep_refuse.
    p_idflux        = i_idflux.

    REFRESH : pt_files.

    IF po_log IS NOT BOUND.

      CREATE OBJECT po_log
        EXPORTING
          i_object    = c_log_object
          i_subobject = c_log_subobject.

    ENDIF.

    IF po_files_manager IS NOT BOUND.

      CREATE OBJECT po_files_manager.

    ENDIF.

  ENDMETHOD.


  METHOD create_files.

  ENDMETHOD.


  METHOD delete_txt.

    DATA :
      ls_longtext TYPE ty_longtext,
      lv_filename TYPE string,
      lv_txt      TYPE eps2filnam.

    lv_txt = i_name.
    REPLACE ALL OCCURRENCES OF 'xml' IN lv_txt WITH 'txt'.

    CONCATENATE p_dir_ar lv_txt INTO lv_filename.

    ls_longtext = lv_filename.

    TRY .
        po_files_manager->delete_file( lv_filename ).

        " Fichier &1&2&3&4 supprimé
        MESSAGE s013(zsplit_csv_eld_gaz) WITH ls_longtext-msgv1 ls_longtext-msgv2 ls_longtext-msgv3 ls_longtext-msgv4 INTO DATA(lv_dummy).
        po_log->add_sy_msg( ).

      CATCH zcx_utils_file_error.

        " Fichier &1&2&3&4 n'a pas pu être supprimé
        MESSAGE e009(zsplit_csv_eld_gaz) WITH ls_longtext-msgv1 ls_longtext-msgv2 ls_longtext-msgv3 ls_longtext-msgv4 INTO lv_dummy.
        po_log->add_sy_msg( ).

    ENDTRY.

  ENDMETHOD.


  METHOD display_log.

    po_log->display_log( ).

  ENDMETHOD.


  METHOD exec_python.

  ENDMETHOD.


  METHOD get_files_from_rep.

    DATA :
      lt_file_name_part TYPE table_of_strings.

* On récupére le nom du chemin physique par rapport au nom logique du fichier
    CALL FUNCTION 'FILE_GET_NAME'
      EXPORTING
        logical_filename = p_rep_in
        operating_system = 'VMS'
        parameter_1      = p_emet
        parameter_2      = p_idflux
      IMPORTING
        file_name        = p_dir_in
      EXCEPTIONS
        file_not_found   = 1
        OTHERS           = 2.

    CALL FUNCTION 'FILE_GET_NAME'
      EXPORTING
        logical_filename = p_rep_ar
        operating_system = 'VMS'
        parameter_1      = p_emet
        parameter_2      = p_idflux
      IMPORTING
        file_name        = p_dir_ar
      EXCEPTIONS
        file_not_found   = 1
        OTHERS           = 2.

* On récupére le contenu du répertoire
    CALL FUNCTION 'EPS2_GET_DIRECTORY_LISTING'
      EXPORTING
        iv_dir_name            = p_dir_in
      TABLES
        dir_list               = pt_files
      EXCEPTIONS
        invalid_eps_subdir     = 1
        sapgparam_failed       = 2
        build_directory_failed = 3
        no_authorization       = 4
        read_directory_failed  = 5
        too_many_read_errors   = 6
        empty_directory_list   = 7
        OTHERS                 = 8.

    LOOP AT pt_files ASSIGNING FIELD-SYMBOL(<ls_file>).

      SPLIT <ls_file>-name AT '.' INTO TABLE lt_file_name_part.
      READ TABLE lt_file_name_part ASSIGNING FIELD-SYMBOL(<ls_name_part>) INDEX 2.
      IF sy-subrc NE 0 OR ( sy-subrc EQ 0 AND <ls_name_part> NE 'xml' ).
        DELETE pt_files.
      ENDIF.

    ENDLOOP.

    IF pt_files IS INITIAL.
      " Aucun fichier trouvé
      MESSAGE e001(zsplit_csv_eld_gaz) INTO DATA(lv_dummy).
      " Raise the exception
      RAISE EXCEPTION TYPE zcx_split_eld_gaz_error.
    ENDIF.

  ENDMETHOD.


  METHOD get_lines_of_file.

    DATA :
      lv_line     TYPE string,
      ls_longtext TYPE ty_longtext,
      lv_eof      TYPE xfeld,
      lv_filename TYPE dxlpath,
      lv_txt      TYPE eps2filnam.

    lv_txt = i_name.
    REPLACE ALL OCCURRENCES OF 'xml' IN lv_txt WITH 'txt'.

    lv_filename = p_dir_in && lv_txt.
    ls_longtext = i_name.

    OPEN DATASET lv_filename IN LEGACY TEXT MODE FOR INPUT.
    DO.
      TRY.

          CALL METHOD po_files_manager->read_dataset
            EXPORTING
              x_file = CONV string( lv_filename )
            IMPORTING
              y_line = lv_line
              y_eof  = lv_eof.

          IF lv_eof IS NOT INITIAL.
            EXIT.
          ENDIF.

          APPEND lv_line TO r_lines.

        CATCH zcx_utils_file_error .

          me->add_to_refuse( lv_txt ).
          " Erreur lors de la lecture du fichier &1
          MESSAGE e002(zsplit_csv_eld_gaz) WITH ls_longtext-msgv1 ls_longtext-msgv2 ls_longtext-msgv3 ls_longtext-msgv4.
          " Raise the exception
          RAISE EXCEPTION TYPE zcx_split_eld_gaz_error.

      ENDTRY.

    ENDDO.

    CLOSE DATASET lv_filename.

    " Début de traitement du fichier &1
    MESSAGE s003(zsplit_csv_eld_gaz) WITH ls_longtext-msgv1 ls_longtext-msgv2 ls_longtext-msgv3 ls_longtext-msgv4 INTO DATA(lv_dummy).
    po_log->add_sy_msg( ).

    me->add_to_archive( lv_txt ).

  ENDMETHOD.


  METHOD main.

    DATA :
          lt_lines TYPE table_of_strings.

    TRY .

        me->get_files_from_rep( ).

        LOOP AT pt_files ASSIGNING FIELD-SYMBOL(<ls_file>).

          TRY .

              REFRESH : lt_lines.

              me->exec_python( <ls_file>-name ).
              lt_lines = me->get_lines_of_file( <ls_file>-name ).

              me->treat_file( i_lines = lt_lines i_name = <ls_file>-name ).
              me->create_files( ).

              me->add_to_archive( <ls_file>-name ).

            CATCH zcx_split_eld_gaz_error.

              " On ne fait rien pour le XML mais on supprime le TXT
              me->delete_txt( <ls_file>-name ).

          ENDTRY.

        ENDLOOP.

      CATCH zcx_split_eld_gaz_error.

        po_log->add_sy_msg( ).

    ENDTRY.

  ENDMETHOD.


  METHOD save_log.

    po_log->save( ).

  ENDMETHOD.


  METHOD treat_file.

  ENDMETHOD.
ENDCLASS.
