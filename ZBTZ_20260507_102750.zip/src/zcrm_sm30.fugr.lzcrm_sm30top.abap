* regenerated at 21.04.2017 14:28:03
FUNCTION-POOL ZCRM_SM30                  MESSAGE-ID SV.

* INCLUDE LZCRM_SM30D...                     " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCRM_SM30T00                           . "view rel. data dcl.
