*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFKK_CLRG_SAMTOP.                  " Global Data
  INCLUDE LZFKK_CLRG_SAMUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LFKK_CLRG_SAMF...                  " Subprograms
* INCLUDE LFKK_CLRG_SAMO...                  " PBO-Modules
* INCLUDE LFKK_CLRG_SAMI...                  " PAI-Modules
