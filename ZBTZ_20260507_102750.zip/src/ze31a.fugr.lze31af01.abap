*----------------------------------------------------------------------*
***INCLUDE LE31AF01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  CREATE_DON_GL_POSITION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_T_FKKOPK  text
*      -->P_XY_FKKOP  text
*----------------------------------------------------------------------*
FORM create_don_gl_position TABLES   t_fkkopk STRUCTURE fkkopk
                            USING    xy_fkkop LIKE fkkop
                                     pay_fkkopk LIKE fkkopk
                                     wa_te016 LIKE redonation.

  DATA: h_opupk LIKE fkkopk-opupk.

  LOOP AT t_fkkopk.
    IF h_opupk < t_fkkopk-opupk.
      h_opupk = t_fkkopk-opupk.
    ENDIF.
  ENDLOOP.

  CLEAR: t_fkkopk.

  t_fkkopk-mandt = sy-mandt.
  t_fkkopk-opupk = h_opupk.

  ADD 1 TO t_fkkopk-opupk.
  t_fkkopk-fikey = pay_fkkopk-fikey.
  t_fkkopk-bukrs = xy_fkkop-bukrs.
  t_fkkopk-gsber = xy_fkkop-gsber.
  t_fkkopk-valut = pay_fkkopk-valut.
  t_fkkopk-hkont = wa_te016-hkont.
  PERFORM value_date_check CHANGING t_fkkopk.
  t_fkkopk-betrw = xy_fkkop-betrw.

  APPEND t_fkkopk.
ENDFORM.                               " CREATE_DON_GL_POSITION
*&---------------------------------------------------------------------*
*&      Form  VALUE_DATE_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_T_FKKOPK_HKONT  text
*----------------------------------------------------------------------*
FORM value_date_check CHANGING t_fkkopk LIKE fkkopk.


  DATA:   BEGIN OF xsakfa OCCURS 20.
          INCLUDE STRUCTURE fkksakfa.
  DATA:   END OF xsakfa.
  DATA: rc LIKE sy-subrc.

  CALL FUNCTION 'FKK_HKONT_FIELD_SEL_LIST_READ'
    EXPORTING
      i_hkont = t_fkkopk-hkont
      i_bukrs = t_fkkopk-bukrs
    TABLES
      t_sakfa = xsakfa.

  LOOP AT xsakfa WHERE tname EQ 'FKKOPK'
                 AND   fstat CA '+-'.
    rc = 0.

    CASE xsakfa-fname.
      WHEN 'VALUT'.
        IF t_fkkopk-valut LE '00000000' AND xsakfa-fstat = '+'
        OR t_fkkopk-valut GT '00000000' AND xsakfa-fstat = '-'.
          rc = 4.
        ENDIF.




        IF rc = 4.
          IF t_fkkopk-valut LE '00000000' AND xsakfa-fstat = '+'.
            IF t_fkkopk-valut IS INITIAL.

              t_fkkopk-valut = sy-datlo.



            ENDIF.
          ENDIF.
        ENDIF.
        IF t_fkkopk-valut GT '00000000' AND xsakfa-fstat = '-'.
          CLEAR t_fkkopk-valut.
        ENDIF.
    ENDCASE.
  ENDLOOP.
ENDFORM.                               " VALUE_DATE_CHECK
*&---------------------------------------------------------------------*
*&      Form  CHECK_AND_COMPLETE_T_FKKOP
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_T_FKKOP  text
*      -->P_X_FKKKO  text
*----------------------------------------------------------------------*
FORM check_and_complete_t_fkkop TABLES t_seltab STRUCTURE iseltab
                                USING    p_fkkko LIKE fkkko
                                CHANGING p_fkkop LIKE fkkop.
  CHECK p_fkkko-herkf = co_herkf_pcash OR
        p_fkkko-herkf = co_herkf_pcard OR
        p_fkkko-herkf = co_herkf_pcheq.
  READ TABLE t_seltab WITH KEY selfn = 'VKONT'.
  IF sy-subrc NE 0.
    CLEAR: p_fkkop-vkont.
  ENDIF.


  IF NOT p_fkkop-gpart IS INITIAL AND p_fkkop-vkont IS INITIAL.
    CALL FUNCTION 'FKK_GET_ACCOUNT_OF_PARTNER'
      EXPORTING
        i_partner    = p_fkkop-gpart
      IMPORTING
        e_vkont      = p_fkkop-vkont
      EXCEPTIONS
        system_error = 1
        OTHERS       = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.


  ENDIF.

  IF NOT p_fkkop-gpart IS INITIAL AND NOT p_fkkop-vkont IS INITIAL.


*    CALL SCREEN 100.      screen does not exist !!!
    p_fkkop-optxt = wa_fkkop-optxt.

  ENDIF.



ENDFORM.                               " CHECK_AND_COMPLETE_T_FKKOP

*&---------------------------------------------------------------------*
*&      Form  CHECK_CONTRACT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_X_FKKKO  text
*      <--P_XY_FKKOP  text
*----------------------------------------------------------------------*
FORM check_contract USING    p_fkkko STRUCTURE fkkko
                    CHANGING p_fkkop STRUCTURE fkkop.

  DATA: h_ever LIKE ever,
        open_ever LIKE ever,
        h_fkkvkp  LIKE fkkvkp,
        lx_active TYPE xfeld.

  CHECK p_fkkop-applk NE 'T'.
  IF NOT p_fkkop-vtref IS INITIAL.

    CALL FUNCTION 'ISU_INTERNAL_VTREF_TO_VERTRAG'
      EXPORTING
        i_vtref   = p_fkkop-vtref
        i_subap   = p_fkkop-subap
      IMPORTING
        e_vertrag = h_ever-vertrag
      EXCEPTIONS
        OTHERS    = 1.

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = h_ever-vertrag
      IMPORTING
        output = h_ever-vertrag
      EXCEPTIONS
        OTHERS = 1.


    CALL FUNCTION 'ISU_DB_EVER_SINGLE'
      EXPORTING
        x_vertrag    = h_ever-vertrag
*       X_ACTUAL     = 'X'
      IMPORTING
        y_ever       = open_ever
      EXCEPTIONS
        not_found    = 1
        system_error = 2
        OTHERS       = 3.
    IF sy-subrc = 0.
      IF p_fkkop-gsber IS INITIAL AND NOT open_ever-gsber IS INITIAL.
        p_fkkop-gsber = open_ever-gsber.
      ENDIF.
      p_fkkop-spart = open_ever-sparte.

*---- set SEGMENT
      IF      p_fkkop-segment   IS INITIAL
      AND NOT open_ever-segment IS INITIAL.
*------- segment required?
        CALL FUNCTION 'FKK_SEGMENT_REQUIRED'
          EXPORTING
            i_bukrs   = p_fkkop-bukrs
            i_date    = p_fkkop-budat
          IMPORTING
            is_active = lx_active.
        IF lx_active EQ 'X'.
          p_fkkop-segment = open_ever-segment.
        ENDIF.
      ENDIF.

* Prüfung, ob Buchungskreis im Vertrag abweichend vom eingegebenen
* Buchungskreis ist, nur bei FPE1
      IF NOT p_fkkop-bukrs IS INITIAL AND
         p_fkkop-bukrs NE open_ever-bukrs.
        mac_msg_putx co_msg_error '298' 'EK'
        p_fkkop-bukrs open_ever-bukrs space space space.
        IF 1 = 2.
          MESSAGE e298(ek) WITH p_fkkop-bukrs open_ever-bukrs.
        ENDIF.
      ENDIF.
    ENDIF.

  ENDIF.
  IF p_fkkop-vtref IS INITIAL.
    CLEAR p_fkkop-spart.
  ENDIF.


ENDFORM.                    " CHECK_CONTRACT
*&---------------------------------------------------------------------*
*&      Form  zahlsperre_ermitteln
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_APPLK  text
*      -->P_POKEN  text
*      <--P_ZAHLS  text
*----------------------------------------------------------------------*
FORM zahlsperre_ermitteln USING p_applk
                                   p_poken LIKE tfkpk-poken
                          CHANGING p_zahls LIKE tfk008-zahls.

  STATICS: s_applk   LIKE tfk033d-applk,
           s_poken   LIKE tfkpk-poken,
           s_zahls   LIKE tfk008-zahls.

  DATA   : h_tfk033d LIKE tfk033d.

* Ermitteln des Zahlsperrgrundes zum gesetzten Postenkennzeichen aus
* Buchungsbereich R070 -------------------------------------------------

  IF s_applk = p_applk AND
     s_poken = p_poken.
    p_zahls = s_zahls.
  ELSE.
    CLEAR h_tfk033d.
    h_tfk033d-mandt = sy-mandt.
    h_tfk033d-applk = p_applk.
    h_tfk033d-buber = 'R070'.
    h_tfk033d-key01 = p_poken.

    CALL FUNCTION 'FKK_ACCOUNT_DETERMINE'
      EXPORTING
        i_tfk033d           = h_tfk033d
      IMPORTING
        e_tfk033d           = h_tfk033d
      EXCEPTIONS
        error_in_input_data = 1
        nothing_found       = 2
        OTHERS              = 3.

    SET EXTENDED CHECK OFF.
    IF 1 = 2.
      CALL FUNCTION 'FKK_ACCOUNT_DETERMINE_R070'.
    ENDIF.
    SET EXTENDED CHECK ON.

    IF sy-subrc = 0.
      p_zahls = h_tfk033d-fun01.
    ELSE.
      p_zahls = '*'.
    ENDIF.

    s_applk  = p_applk.
    s_poken  = p_poken.
    s_zahls  = p_zahls.
  ENDIF.


ENDFORM.                    " zahlsperre_ermitteln
*&---------------------------------------------------------------------*
*&      Form  modify_paym_for_contract
*&---------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM modify_paym_for_contract USING    p_fkkko STRUCTURE fkkko
                              CHANGING p_fkkop STRUCTURE fkkop.

  DATA: h_ever LIKE ever,
        open_ever LIKE ever,
        h_fkkvkp LIKE fkkvkp.

  CHECK p_fkkop-applk NE 'T'.
  IF NOT p_fkkop-vtref IS INITIAL.

    CALL FUNCTION 'ISU_INTERNAL_VTREF_TO_VERTRAG'
      EXPORTING
        i_vtref   = p_fkkop-vtref
        i_subap   = p_fkkop-subap
      IMPORTING
        e_vertrag = h_ever-vertrag
      EXCEPTIONS
        OTHERS    = 1.

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = h_ever-vertrag
      IMPORTING
        output = h_ever-vertrag
      EXCEPTIONS
        OTHERS = 1.


    CALL FUNCTION 'ISU_DB_EVER_SINGLE'
      EXPORTING
        x_vertrag    = h_ever-vertrag
*       X_ACTUAL     = 'X'
      IMPORTING
        y_ever       = open_ever
      EXCEPTIONS
        not_found    = 1
        system_error = 2
        OTHERS       = 3.
    IF sy-subrc = 0.

*---- Check whether a move-in date exists. If not the move-in has
*     been cancelled and no postings on this contract are allowed.
*     Exception:
*     ==========
*     If the contract is deregulated then this check won't be
*     processed (Service ID and Invoicing Party are different!)
      IF open_ever-serviceid EQ open_ever-invoicing_party.
        IF open_ever-einzdat IS INITIAL.
          MESSAGE e071(eq) WITH open_ever-vertrag.
        ENDIF.
      ENDIF.

      IF p_fkkop-gsber IS INITIAL AND NOT open_ever-gsber IS INITIAL.
        p_fkkop-gsber = open_ever-gsber.
      ENDIF.
      p_fkkop-spart = open_ever-sparte.
      p_fkkop-bukrs = open_ever-bukrs.

    ENDIF.
    IF p_fkkop-vtref IS INITIAL.
      CLEAR p_fkkop-spart.
    ENDIF.

  ENDIF.

ENDFORM.                    " modify_paym_for_contract


*&---------------------------------------------------------------------*
*&      Form  DET_VERART_DL
*&---------------------------------------------------------------------*
FORM det_verart_dl USING ps_fkkzk     TYPE dfkkzk
                CHANGING pv_verart_dl TYPE e_verart_dl.

  DATA: lv_table     TYPE tabname16 VALUE 'IUEEDPPLOTATHEAD',
        ls_verart_dl TYPE tp_verart_dl,
        lo_error     TYPE REF TO cx_root.

*------------------------ reset settlement type -----------------------*
  CLEAR pv_verart_dl.

* read data from memory and check that the payment lot is a distr. lot *
  READ TABLE gt_verart_dl INTO ls_verart_dl
                          WITH TABLE KEY keyz1 = ps_fkkzk-keyz1.
  IF sy-subrc EQ 0.

*------------ set settlement type for the distribution lot ------------*
    IF ls_verart_dl-xdl EQ co_true.
      pv_verart_dl = ls_verart_dl-verart_dl.
    ENDIF.

*-------------------------- leave sub-routine -------------------------*
    RETURN.

  ENDIF.

*- data not filled in the global memory: determine the settlement type *

*------------ read head structure for the distribution lot ------------*
  CLEAR: ls_verart_dl, lo_error.
  TRY.
      SELECT SINGLE keyz1 verart_dl FROM (lv_table)
        INTO CORRESPONDING FIELDS OF ls_verart_dl
        WHERE keyz1 = ps_fkkzk-keyz1.
    CATCH cx_root INTO lo_error.                        "#EC NO_HANDLER
  ENDTRY.
  IF lo_error IS INITIAL.

*----- set exporting value: settlement type for distribution lot ------*
    pv_verart_dl = ls_verart_dl-verart_dl.

*--------- send the corresponding message to the appl. log ------------*
    IF pv_verart_dl IS INITIAL.

*------------ info message: settlement type '05' will be used ---------*
      MESSAGE i301(iueedpplota) WITH co_herkf_05.

    ELSE.

*---------- info message: settlement type 'XXX' will be used ----------*
      MESSAGE i301(iueedpplota) WITH pv_verart_dl.

    ENDIF.

*--- the payment lot is a distribution lot -> fill the global memory --*
    ls_verart_dl-xdl = co_true.
    INSERT ls_verart_dl INTO TABLE gt_verart_dl.

  ELSE.

*--------------- head structure not in the system yet -----------------*
    PERFORM det_verart_dl_from_spa USING ps_fkkzk-keyz1
                                CHANGING pv_verart_dl.

  ENDIF.

ENDFORM.                    " DET_VERART_DL


*&---------------------------------------------------------------------*
*&      Form  DET_VERART_DL_FROM_SPA
*&---------------------------------------------------------------------*
FORM det_verart_dl_from_spa USING pv_keyz1     TYPE keyz1_kk
                         CHANGING pv_verart_dl TYPE e_verart_dl.

  DATA: ls_verart_dl  TYPE tp_verart_dl,
        lv_recid      TYPE serviceid,
        lv_senid      TYPE serviceid,
        lv_vgroup     TYPE inv_groupvkont,
        lv_keydate    TYPE endabrpe,
        lt_param      TYPE ttinv_param_inv_outbound_ser,
        ls_param      TYPE inv_param_inv_outbound_ser,
        ls_inv_out    TYPE inv_param_inv_outbound,
        ls_avis_param TYPE inv_param_inv_outbound_avis.

*------------------------ reset settlement type -----------------------*
  CLEAR pv_verart_dl.

*-------------- get necessary data from distribution lot --------------*
  CLEAR: lv_senid, lv_recid, lv_vgroup, lv_keydate.
  CALL FUNCTION 'ISU_EED_PMT_PLOT_LOTKEY_SAV'
    EXPORTING
      i_keyz1           = pv_keyz1
    IMPORTING
      e_serviceid       = lv_senid
      e_invoicing_party = lv_recid
      e_v_group         = lv_vgroup
      e_keydate         = lv_keydate
    EXCEPTIONS
      not_found         = 1
      OTHERS            = 2.
  IF sy-subrc NE 0.

*---------------- send I-messages to appl. log in batch ---------------*
    MESSAGE ID sy-msgid TYPE 'I' NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    MESSAGE i300(iueedpplota).

*------------------------- fill global memory -------------------------*
    CLEAR ls_verart_dl.
    ls_verart_dl-keyz1 = pv_keyz1.
    ls_verart_dl-xdl   = co_true.
    INSERT ls_verart_dl INTO TABLE gt_verart_dl.

*-------------------------- leave sub-routine -------------------------*
    RETURN.

  ENDIF.

*------------ read SPA regarding the basic process INV_OUT ------------*
  CLEAR lt_param[].
  CALL FUNCTION 'ISU_DEREG_PARAM_INV_OUTBOUND'
    EXPORTING
      x_keydate          = lv_keydate
      x_initiator        = lv_recid
      x_partner          = lv_senid
    IMPORTING
      y_param            = lt_param
    EXCEPTIONS
      no_parameter_found = 1
      internal_error     = 2
      OTHERS             = 3.
  IF sy-subrc NE 0.

*---------------- send I-messages to appl. log in batch ---------------*
    MESSAGE ID sy-msgid TYPE 'I' NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    MESSAGE i300(iueedpplota).
    MESSAGE i301(iueedpplota) WITH co_herkf_05.

*------------------------- fill global memory -------------------------*
    CLEAR ls_verart_dl.
    ls_verart_dl-keyz1 = pv_keyz1.
    ls_verart_dl-xdl   = co_true.
    INSERT ls_verart_dl INTO TABLE gt_verart_dl.

*-------------------------- leave sub-routine -------------------------*
    RETURN.

  ENDIF.

*------- read parameter outgoing invoices and incoming payments -------*
  CLEAR ls_param.
  READ TABLE lt_param INTO ls_param INDEX 1.

*------- get parameter configuration -> only one SPA is allowed -------*
  CLEAR ls_inv_out.
  READ TABLE ls_param-param INTO ls_inv_out INDEX 1.

*--------------- read parameter for the settlement type ---------------*
  CLEAR ls_avis_param.
  READ TABLE ls_inv_out-avis_param INTO ls_avis_param
       WITH KEY v_group = lv_vgroup.
  IF sy-subrc NE 0.

*---------------- send I-messages to appl. log in batch ---------------*
    MESSAGE i300(iueedpplota).
    MESSAGE i301(iueedpplota) WITH co_herkf_05.

*------------------------- fill global memory -------------------------*
    CLEAR ls_verart_dl.
    ls_verart_dl-keyz1 = pv_keyz1.
    ls_verart_dl-xdl   = co_true.
    INSERT ls_verart_dl INTO TABLE gt_verart_dl.

*-------------------------- leave sub-routine -------------------------*
    RETURN.

  ENDIF.

*-------------------------- fill settlement type ----------------------*
  pv_verart_dl = ls_avis_param-verart_dl.

*--------- send the corresponding message to the appl. log ------------*
  IF pv_verart_dl IS INITIAL.

*------------ info message: settlement type '05' will be used ---------*
    MESSAGE i301(iueedpplota) WITH co_herkf_05.

  ELSE.

*---------- info message: settlement type 'XXX' will be used ----------*
    MESSAGE i301(iueedpplota) WITH pv_verart_dl.

  ENDIF.

*------------------------- fill global memory -------------------------*
  CLEAR ls_verart_dl.
  ls_verart_dl-keyz1     = pv_keyz1.
  ls_verart_dl-xdl       = co_true.
  ls_verart_dl-verart_dl = pv_verart_dl.
  INSERT ls_verart_dl INTO TABLE gt_verart_dl.

ENDFORM.                    " DET_VERART_DL_FROM_SPA
