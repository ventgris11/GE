*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 29.11.2021 at 15:56:24
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
