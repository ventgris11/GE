class ZCL_ISU_PFC_CONS_REG_ASSIGN definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces ISU_PFC_BADI_CONS_ASSIGN .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ISU_PFC_CONS_REG_ASSIGN IMPLEMENTATION.


METHOD isu_pfc_badi_cons_assign~assign_cons_to_register.
** Cette méthode permet de mapper les consommations d'un client dans les différents cadrans
  CASE im_simperiodcons-registercode.
    WHEN 'ZCADRAN1'.
      READ TABLE IM_MASTERDATA_TEMPLATE_CONTR->IZW_ORIG INTO DATA(ls_izw) WITH KEY ZWNUMMER = '001'.
      ex_logical_register = ls_izw-logikzw.
    WHEN 'ZCADRAN2'.
      READ TABLE IM_MASTERDATA_TEMPLATE_CONTR->IZW_ORIG INTO ls_izw WITH KEY ZWNUMMER = '002'.
      ex_logical_register = ls_izw-logikzw.
    WHEN 'ZCADRAN3'.
      READ TABLE IM_MASTERDATA_TEMPLATE_CONTR->IZW_ORIG INTO ls_izw WITH KEY ZWNUMMER = '003'.
      ex_logical_register = ls_izw-logikzw.
    WHEN 'ZCADRAN4'.
      READ TABLE IM_MASTERDATA_TEMPLATE_CONTR->IZW_ORIG INTO ls_izw WITH KEY ZWNUMMER = '004'.
      ex_logical_register = ls_izw-logikzw.
    WHEN 'ZCADRAN5'.
      READ TABLE IM_MASTERDATA_TEMPLATE_CONTR->IZW_ORIG INTO ls_izw WITH KEY ZWNUMMER = '005'.
      ex_logical_register = ls_izw-logikzw.
    WHEN 'ZCADRAN6'.
      READ TABLE IM_MASTERDATA_TEMPLATE_CONTR->IZW_ORIG INTO ls_izw WITH KEY ZWNUMMER = '006'.
      ex_logical_register = ls_izw-logikzw.
    WHEN 'ZCADRAN7'.
      READ TABLE IM_MASTERDATA_TEMPLATE_CONTR->IZW_ORIG INTO ls_izw WITH KEY ZWNUMMER = '007'.
      ex_logical_register = ls_izw-logikzw.
    WHEN 'ZCADRAN8'.
      READ TABLE IM_MASTERDATA_TEMPLATE_CONTR->IZW_ORIG INTO ls_izw WITH KEY ZWNUMMER = '008'.
      ex_logical_register = ls_izw-logikzw.
    WHEN 'ZCADRAN9'.
      READ TABLE IM_MASTERDATA_TEMPLATE_CONTR->IZW_ORIG INTO ls_izw WITH KEY ZWNUMMER = '009'.
      ex_logical_register = ls_izw-logikzw.
    WHEN 'ZCADRAN10'.
      READ TABLE IM_MASTERDATA_TEMPLATE_CONTR->IZW_ORIG INTO ls_izw WITH KEY ZWNUMMER = '010'.
      ex_logical_register = ls_izw-logikzw.
  ENDCASE.
ENDMETHOD.
ENDCLASS.
