*----------------------------------------------------------------------*
***INCLUDE LFKMBF11 .
*----------------------------------------------------------------------*
FORM event_0336  TABLES   ut_fkkmavs    STRUCTURE fkkmavs
                 USING    uf_fkkmagrp        TYPE fkkmagrp
                 CHANGING c_do_not_dun       TYPE boole-boole
                          c_percentage_group TYPE minpz_kk
                          c_percentage_limit TYPE minpz_kk.

  DATA:    lt_fkkmavs     LIKE TABLE OF fkkmavs.
  DATA:    lf_fkkmagrp    LIKE fkkmagrp.

  STATICS: st_fbstab_0336 LIKE TABLE OF tfkfbc WITH HEADER LINE.
  STATICS: s_read         TYPE boole-boole.


  IF s_read IS INITIAL.
    CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
      EXPORTING
        i_fbeve       = '0336'
        i_applk       = gl_para_0300-applk
      TABLES
        t_fbstab      = st_fbstab_0336
      EXCEPTIONS
        error_message = 1.

    MOVE: 'X' TO s_read.
  ENDIF.

  CHECK NOT st_fbstab_0336[] IS INITIAL.

* Using table must not be changed
  MOVE ut_fkkmavs[] TO lt_fkkmavs.
  MOVE uf_fkkmagrp  TO lf_fkkmagrp.

  LOOP AT st_fbstab_0336.
    CALL FUNCTION st_fbstab_0336-funcc
      EXPORTING
        i_fkkmagrp       = lf_fkkmagrp
        vbgut            = '1'
      IMPORTING
        do_not_dun       = c_do_not_dun
        percentage_group = c_percentage_group
        percentage_limit = c_percentage_limit
      TABLES
        it_fkkmavs       = lt_fkkmavs.

    SET EXTENDED CHECK OFF.
    IF 1 = 2.
      CALL FUNCTION 'FKK_SAMPLE_0336'.
    ENDIF.
    SET EXTENDED CHECK ON.

  ENDLOOP.


ENDFORM.                    " event_0336
