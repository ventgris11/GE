*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 21.04.2019 at 17:53:02
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
