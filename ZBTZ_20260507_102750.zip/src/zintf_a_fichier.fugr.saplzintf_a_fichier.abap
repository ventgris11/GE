* regenerated at 03.04.2019 18:10:39
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZINTF_A_FICHIERTOP.               " Global Data
  INCLUDE LZINTF_A_FICHIERUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZINTF_A_FICHIERF...               " Subroutines
* INCLUDE LZINTF_A_FICHIERO...               " PBO-Modules
* INCLUDE LZINTF_A_FICHIERI...               " PAI-Modules
* INCLUDE LZINTF_A_FICHIERE...               " Events
* INCLUDE LZINTF_A_FICHIERP...               " Local class implement.
* INCLUDE LZINTF_A_FICHIERT99.               " ABAP Unit tests
  INCLUDE LZINTF_A_FICHIERF00                     . " subprograms
  INCLUDE LZINTF_A_FICHIERI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
