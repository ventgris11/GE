FUNCTION-POOL ZFKY0.                         "MESSAGE-ID ..

TYPE-POOLS RSDS.

*--------------------------------------------------------------------
* Global data for use in ...XML_SAMPLE...modules
*--------------------------------------------------------------------
data gt_level    type table of string.
data gt_level_20 type table of string.
data g_file      type string.
data header      type string.
*--------------------------------------------------------------------
