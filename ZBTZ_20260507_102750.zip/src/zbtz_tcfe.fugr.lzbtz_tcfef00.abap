*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 20.10.2018 at 17:29:03
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
