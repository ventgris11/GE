*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 29.11.2021 at 15:56:24
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
