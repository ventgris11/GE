FUNCTION-POOL ZFKK_CLRG_SAM.                 "MESSAGE-ID ..

type-pools: slis.
