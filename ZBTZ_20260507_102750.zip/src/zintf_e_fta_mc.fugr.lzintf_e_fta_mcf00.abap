*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 05.07.2024 at 10:17:08
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
