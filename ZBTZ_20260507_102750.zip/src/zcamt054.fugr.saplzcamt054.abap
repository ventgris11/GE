* regenerated at 17.07.2018 19:01:50
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCAMT054TOP.                      " Global Data
  INCLUDE LZCAMT054UXX.                      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCAMT054F...                      " Subroutines
* INCLUDE LZCAMT054O...                      " PBO-Modules
* INCLUDE LZCAMT054I...                      " PAI-Modules
* INCLUDE LZCAMT054E...                      " Events
* INCLUDE LZCAMT054P...                      " Local class implement.
* INCLUDE LZCAMT054T99.                      " ABAP Unit tests
  INCLUDE LZCAMT054F00                            . " subprograms
  INCLUDE LZCAMT054I00                            . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
