*----------------------------------------------------------------------*
*   INCLUDE LFKPZFM0                                                   *
*----------------------------------------------------------------------*

*---------------------------------------------------------------------*
*       FORM MESSAGE                                                  *
*---------------------------------------------------------------------*
FORM MESSAGE USING P_MSGNO LIKE SY-MSGNO.

* default msgid ">2"
  IF MSGID IS INITIAL.
    FIMSG-MSGID = '>2'.
  ELSE.
    FIMSG-MSGID = MSGID.
  ENDIF.
  FIMSG-MSGTY   = 'S'.
  FIMSG-MSGNO   = P_MSGNO.
  FIMSG-MSGV1   = MSGV1.
  FIMSG-MSGV2   = MSGV2.
  FIMSG-MSGV3   = MSGV3.
  FIMSG-MSGV4   = MSGV4.
  CALL FUNCTION 'FI_MESSAGE_COLLECT' EXPORTING I_FIMSG = FIMSG.

* store the "ko" reasons
  IF '029/030/031/025/057/056/026/028/171/172/173/' CS P_MSGNO
  OR '038/039/040/041/063/064/065/066/067' CS P_MSGNO
  OR '282/311/331'                         CS P_MSGNO.
    IF H_MSGNO IS INITIAL.
      H_MSGNO = P_MSGNO.
    ENDIF.
  ENDIF.

* init
  CLEAR: MSGID, MSGV1, MSGV2, MSGV3, MSGV4.

* used messages for cross ref
  SET EXTENDED CHECK OFF.
  IF 1 = 2.
    MESSAGE S282.
    MESSAGE:
      S009,
      S010, S019,
      S020, S024, S025, S026, S028, S029,
      S030, S031, S032, S037, S038, S039,
      S040, S041, S042, S043, S044, S045, S046, S047, S048, S049,
      S056, S057, S063, S064, S065, S066, S067, S072, S074, S091, S092, S093,
      S094, S099, S162, S171, S172, S173,
      S185, S197, S289, S290, S291, S292, S293, S309, S310, S311.
  ENDIF.
  SET EXTENDED CHECK ON.
ENDFORM.
