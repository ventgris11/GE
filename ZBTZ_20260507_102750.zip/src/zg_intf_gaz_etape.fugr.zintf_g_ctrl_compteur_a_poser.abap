FUNCTION zintf_g_ctrl_compteur_a_poser.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
  DATA: lc_field_num_pce     TYPE fieldname VALUE 'NUM_PCE',
        lc_debut_periode     TYPE fieldname VALUE 'DEBUT_PERIODE',
        lc_field_nb_roue_cpt TYPE fieldname VALUE 'NB_ROUE_COMPTEUR',
        lc_field_num_serie   TYPE fieldname VALUE 'NUM_SERIE_COMPTEUR',
        lc_field_flux        TYPE fieldname VALUE 'FLUX',
        lc_field_index_debut TYPE fieldname VALUE 'INDEX_BRUT_DEBUT_PERIODE',
        lc_fin_periode       TYPE fieldname VALUE 'FIN_PERIODE',
        lv_field             TYPE string,
        lv_int_ui            TYPE int_ui,
        lv_anlage            TYPE anlage,
        ls_object            TYPE eedm_isu_objects,
        lt_etdz              TYPE TABLE OF etdz,
        ls_etdz              TYPE etdz,
        ls_etdz_             TYPE etdz,
        lv_date_depose       TYPE sy-datum,
        lv_debut_periode     TYPE sy-datum,
        ls_auto              TYPE isu42_devmod_auto,
        ls_dev               TYPE reg42_dev,
        ls_dev_flag          TYPE reg42_dev_input_flag,
        lv_db_update         TYPE e_update,
        lv_sernr             TYPE lsernr,
        lv_equnr             TYPE equnr,
        lv_ko                TYPE c,
        lt_easts             TYPE TABLE OF easts,
        ls_easts             TYPE easts,
        lv_eadat             TYPE reg30-eadat.


* A créer comme méthode dans ZCL_TOOL
  CLEAR: ls_auto,ls_dev_flag,ls_dev,lv_eadat.
  ev_etape = 1.

  CLEAR: lv_date_depose.
  FIELD-SYMBOLS: <fs_num_pce>,<fs_debut_periode>,<fs_fin_periode>,<fs_nb_roue_compteur>,<fs_num_serie>,<fs_flux>,<fs_idx_debut_periode>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.
  IF <fs_num_pce> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_debut_periode INTO lv_field.
  ASSIGN (lv_field) TO <fs_debut_periode>.
  IF <fs_debut_periode> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_nb_roue_cpt INTO lv_field.
  ASSIGN (lv_field) TO <fs_nb_roue_compteur>.
  IF <fs_nb_roue_compteur> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_flux INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.
  IF <fs_flux> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_serie INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_serie>.
  IF <fs_num_serie> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_index_debut INTO lv_field.
  ASSIGN (lv_field) TO <fs_idx_debut_periode>.
  IF <fs_idx_debut_periode> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_index_debut INTO lv_field.
  ASSIGN (lv_field) TO <fs_fin_periode>.
  IF <fs_fin_periode> IS NOT ASSIGNED.
  ENDIF.



* récupération de INT_UI
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).
  IF lv_int_ui IS INITIAL.
  ENDIF.

* récupération du numéro de l'installation
  CLEAR: ls_object,gv_pose_225.

  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_debut_periode>
    IMPORTING
      es_detail = ls_object.


* récupèration des information de la table ETDZ
  IF ls_object-installation IS NOT INITIAL.

    CALL FUNCTION 'ISU_DB_INSTALL_STRUC_SELECT'
      EXPORTING
        x_anlage     = ls_object-installation
      TABLES
        t_ietdz      = lt_etdz
      EXCEPTIONS
        not_found    = 1
        system_error = 2
        OTHERS       = 3.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.
    lv_anlage = ls_object-installation.
    lv_date_depose = <fs_debut_periode> - 1.

    "Vérifier s'il existe un compteur déposé à la [DEBUT_PERIODE- 1]
    CLEAR ls_etdz.
    READ TABLE lt_etdz INTO ls_etdz WITH KEY bis = lv_date_depose.
    IF sy-subrc EQ 0.
      "ET qu'il n'existe pas un compteur posé à la DEBUT_PERIODE
      CLEAR ls_etdz_.
      READ TABLE lt_etdz INTO ls_etdz_ WITH KEY ab = <fs_debut_periode>.
      IF sy-subrc NE 0.
        "Faire la pose si aucun compteur est posé à la date du début de période
*        ev_etape = 1.

        "---------------------------------------------------------------------------------------
        "Création FIAP
        "---------------------------------------------------------------------------------------

        IF <fs_flux> = 'RE6M' OR <fs_flux> = 'RE1M'.
          CASE <fs_nb_roue_compteur>.
            WHEN '4'.
              ls_dev-matnr      = 'ART_6M_4'.
              ls_dev-zwgruppe   = 'GAZ_6M_4'.
              ls_dev_flag-matnr = 'ART_6M_4'.
            WHEN '5'.
              ls_dev-matnr      = 'ART_6M_5'.
              ls_dev-zwgruppe   = 'GAZ_6M_5'.
              ls_dev_flag-matnr = 'ART_6M_5'.
            WHEN '6'.
              ls_dev-matnr      = 'ART_6M_6'.
              ls_dev-zwgruppe   = 'GAZ_6M_6'.
              ls_dev_flag-matnr = 'ART_6M_6'.
            WHEN '7'.
              ls_dev-matnr      = 'ART_6M_7'.
              ls_dev-zwgruppe   = 'GAZ_6M_7'.
              ls_dev_flag-matnr = 'ART_6M_7'.
          ENDCASE.
        ELSEIF <fs_flux> = 'REMM'.
          CASE <fs_nb_roue_compteur>.
            WHEN '4'.
              ls_dev-matnr      = 'ART_MM_4'.
              ls_dev-zwgruppe   = 'GAZ_MM_4'.
              ls_dev_flag-matnr = 'ART_MM_4'.
            WHEN '5'.
              ls_dev-matnr      = 'ART_MM_5'.
              ls_dev-zwgruppe   = 'GAZ_MM_5'.
              ls_dev_flag-matnr = 'ART_MM_5'.
            WHEN '6'.
              ls_dev-matnr      = 'ART_MM_6'.
              ls_dev-zwgruppe   = 'GAZ_MM_6'.
              ls_dev_flag-matnr = 'ART_MM_6'.
            WHEN '7'.
              ls_dev-matnr      = 'ART_MM_7'.
              ls_dev-zwgruppe   = 'GAZ_MM_7'.
              ls_dev_flag-matnr = 'ART_MM_7'.
            WHEN '8'.
              ls_dev-matnr      = 'ART_MM_8'.
              ls_dev-zwgruppe   = 'GAZ_MM_8'.
              ls_dev_flag-matnr = 'ART_MM_8'.
            WHEN '9'.
              ls_dev-matnr      = 'ART_MM_9'.
              ls_dev-zwgruppe   = 'GAZ_MM_9'.
              ls_dev_flag-matnr = 'ART_MM_9'.
          ENDCASE.
        ELSEIF <fs_flux> = 'REJM' OR <fs_flux> = 'REJJ'.
          ls_dev-matnr      = 'ART_JM/JJ'.
          ls_dev-zwgruppe   = 'G_JM_JJ'.
          ls_dev_flag-matnr = 'ART_JM/JJ'.
        ENDIF.

        ls_dev-ab         = <fs_debut_periode> .
        ls_dev-bis        = '99991231'.

        ls_dev-sparte     = 'ZG'.
        ls_dev-egerr_info =  <fs_num_serie>.
        APPEND ls_dev TO ls_auto-dev.

        " MAJ DEV FLAG
        ls_dev_flag-ab         = <fs_debut_periode>.
        ls_dev_flag-bis        = '99991231'.
        ls_dev_flag-zwgruppe   = 'X'.
        ls_dev_flag-egerr_info = 'X'.
        APPEND ls_dev_flag TO ls_auto-dev_flag.

        ls_auto-contr-okcode = 'SAVE'.


* Créer fiche info appareil
        CALL FUNCTION 'ISU_S_SMALL_DEVICE_CREATE'
          EXPORTING
            x_matnr        = ls_dev-matnr            " Type appareil
            x_keydate      = <fs_debut_periode>
            x_upd_online   = 'X'
            x_no_dialog    = 'X'
            x_auto         = ls_auto
            x_int_num      = 'X'
          IMPORTING
            y_db_update    = lv_db_update
            y_equnr        = lv_equnr
            y_device       = lv_sernr
          EXCEPTIONS
            not_found      = 1
            invalid        = 2
            foreign_lock   = 3
            input_error    = 4
            system_error   = 5
            internal_error = 6
            not_qualified  = 7
            not_customized = 8
            cancelled      = 9
            OTHERS         = 10.

        IF  sy-subrc EQ 0
        AND NOT lv_db_update IS INITIAL.
* 'OK'
        ELSE.
*          ev_etape = 2.
          lv_ko = 'X'.
          EXIT.
* 'KO'
        ENDIF.
        "---------------------------------------------------------------------------------------
        "Pose de la FIAP créée en amont
        "---------------------------------------------------------------------------------------

        IF lv_ko IS INITIAL.
          CONSTANTS: lc_365(3) VALUE 365.

          DATA: ld_date       TYPE datum,
                ld_perverbr   TYPE perverbr,
                ld_thgver     TYPE thgver,
                ld_tarifart   TYPE tarifart,
                ld_date_c(10) TYPE c,
                ld_db_update  TYPE xfeld,
                ls_zw         TYPE isu07_zw,
                lt_zw         TYPE isu07_zwt,
                ls_ger        TYPE isu07_auto_ger,
                ls_auto_pose  TYPE isu07_install_auto.


          ld_date = <fs_debut_periode> - 1.
* Si JJ/JM alors pas de consommation périodique donc on ne sélectionne pas dans cette table
          IF ls_dev-matnr EQ 'ART_JM/JJ'.
            SELECT easts~tarifart eadz~thgver
                   INTO (ld_tarifart,ld_thgver)
                   UP TO 1 ROWS
                   FROM easts AS easts
                   INNER JOIN eadz AS eadz
                   ON eadz~logikzw EQ easts~logikzw
                   AND eadz~bis GE easts~ab
                   AND eadz~ab LE easts~bis
                   WHERE easts~anlage EQ lv_anlage
                   AND easts~ab LE ld_date
                   AND easts~bis GE ld_date
                   AND eadz~bis GE ld_date
                   AND eadz~ab LE ld_date.
            ENDSELECT.
          ELSE.

            "Début:GE-6908: message OPEN_FI du BTE ISUMRORD (Pose compteur)
            SELECT * INTO TABLE lt_easts
                   FROM easts
                   WHERE easts~anlage EQ lv_anlage
                     AND ab  LE ld_date
                     AND bis GE ld_date.

            SORT lt_easts BY bis DESCENDING.
            READ TABLE lt_easts INTO ls_easts INDEX 1.
            IF sy-subrc EQ 0.
              ld_tarifart = ls_easts-tarifart.

              SELECT perverbr thgver
                  INTO (ld_perverbr,ld_thgver) UP TO 1 ROWS
                   FROM easte
                   INNER JOIN eadz
                   ON eadz~logikzw EQ easte~logikzw
                  AND eadz~bis GE easte~ab
                  AND eadz~ab LE easte~bis
                 WHERE easte~logikzw = ls_easts-logikzw
                   AND easte~ab LE ld_date
                   AND eadz~bis GE ld_date
                   AND eadz~ab LE ld_date.
              ENDSELECT.
            ENDIF.
            "Fin  :GE-6908: message OPEN_FI du BTE ISUMRORD (Pose compteur)
          ENDIF.
          IF NOT sy-subrc IS INITIAL.
* Problème dans le modèle de données
*            ev_etape = 2.
            lv_ko = 'X'.

          ELSE.

* Données cadran(s)
            ls_zw-zwnummere       = '001'.
            ls_zw-zwstandce       = <fs_idx_debut_periode>.
            ls_zw-spartype        = '02'.
            ls_zw-geraete         = lv_sernr.
            ls_zw-matnre          = ls_dev-matnr.
            ls_zw-anzerg          = 1.
            ls_zw-thgver          = ld_thgver.

            IF ls_dev-matnr NE 'ART_JM/JJ'.
              ls_zw-anzdaysofperiod = lc_365.
              ls_zw-perverbr        = ld_perverbr.
            ENDIF.
            ls_zw-tarifart        = ld_tarifart.
            IF ls_dev-matnr EQ 'ART_JM/JJ'.
              ls_zw-kondigre = 'GAZ_RTP'.
            ENDIF.
            APPEND ls_zw TO lt_zw.
* Données d'appareil
            ls_ger-matnr     = ls_dev-matnr.
            ls_ger-geraetneu = lv_sernr.
            ls_ger-ausbau    = space.
            ls_ger-sparteneu = 'ZG'.
            ls_ger-action    = '04'.
            APPEND ls_ger TO ls_auto_pose-auto_ger.
* Données de cadran(s)
            ls_auto_pose-auto_zw = lt_zw.
            ls_auto_pose-interface-anlage        = lv_anlage.
            ls_auto_pose-interface-eadat         = <fs_debut_periode>.
            ls_auto_pose-interface-action        = '04'.
            ls_auto_pose-interface-upd_online    = 'X'.
            ls_auto_pose-interface-no_dialog     = 'X'.
            ls_auto_pose-interface-no_event      = 'X'.
            ls_auto_pose-interface-no_statistic  = 'X'.
            ls_auto_pose-interface-no_change_doc = 'X'.
            ls_auto_pose-okcode                  = 'SAVE'.
            ls_auto_pose-zwstand                 = 'X'.
            ls_auto_pose-consumption             = 'X'.



*            lv_eadat = <fs_idx_debut_periode>.
            CALL FUNCTION 'ISU_S_WORKLIST_INSTALL'
              EXPORTING
                x_anlage         = lv_anlage
                x_eadat          = <fs_debut_periode>
                x_geraetneu      = lv_sernr
                x_matnr          = ls_dev-matnr
                x_action         = '04'       " Pose pour calcul de facturation
                x_spartee        = 'ZG' "02
                x_upd_online     = 'X'
                x_no_dialog      = 'X'
                x_no_event       = 'X'
                x_no_statistic   = 'X'
                x_no_change_doc  = 'X'
                x_called_by_idoc = space
              IMPORTING
                y_db_update      = ld_db_update
              CHANGING
                xy_auto          = ls_auto_pose
      "         xy_ext_cont      = lt_cont[]
              EXCEPTIONS
                not_found        = 1
                foreign_lock     = 2
                invalid          = 3
                internal_error   = 4
                not_qualified    = 5
                input_error      = 6
                system_error     = 7
                not_customized   = 8
                OTHERS           = 9.
            IF NOT sy-subrc IS INITIAL.
*              ev_etape = 2.
            ELSE.
*              ev_etape = 1.
              gv_pose_225 = abap_true.
            ENDIF.
          ENDIF.

        ENDIF.

      ELSE.
*        "passer à l'étape 13
*        ev_etape = 2.
      ENDIF.
    ELSE.
*      "passer à l'étape 13
*      ev_etape = 2.
    ENDIF.

  ENDIF.


ENDFUNCTION.
