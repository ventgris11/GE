*----------------------------------------------------------------------*
*   INCLUDE LFKPZFR0                                                   *
*----------------------------------------------------------------------*

*---------------------------------------------------------------------*
*       FORM READ_COMPANY_CODE                                        *
*---------------------------------------------------------------------*
FORM READ_COMPANY_CODE USING P_BUKRS.
  CALL FUNCTION 'FKK_COMP_CODE_DATA'
       EXPORTING
            I_BUKRS       = P_BUKRS
       IMPORTING
            E_T001        = T001
            E_TFK001B     = TFK001B
       EXCEPTIONS
            ERROR_MESSAGE = 4.
  IF SY-SUBRC NE 0.
    MESSAGE ID SY-MSGID TYPE 'E' NUMBER SY-MSGNO
            WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4
            RAISING COMPANY_NOT_FOUND.
  ENDIF.
ENDFORM.                    "READ_COMPANY_CODE

*---------------------------------------------------------------------*
*       FORM READ_HOUSE_BANK                                          *
*---------------------------------------------------------------------*
FORM READ_HOUSE_BANK.

* set return code and check whether table of house bank has to be built
*  READ TABLE T_HBANK INDEX 1.
*  CHECK H_42A_ZBUKR NE IMPORT-OPBUK
*     OR H_42A_ZLSCH NE TFK042E-ZLSCH
*     OR H_42A_WAERS NE IMPORT-WAERS.
*  H_42A_ZBUKR = IMPORT-OPBUK.
*  H_42A_ZLSCH = TFK042E-ZLSCH.
*  H_42A_WAERS = IMPORT-WAERS.

* find house banks for payment method and currency
  REFRESH T_HBANK.
  LOOP AT T_TFK042A WHERE OPBUK EQ IMPORT-OPBUK
                    AND   ZLSCH EQ TFK042E-ZLSCH
                    AND   WAERS EQ IMPORT-WAERS.
* do NOT filter eigbv (other payment methods might follow)
    MOVE-CORRESPONDING T_TFK042A TO T_HBANK.
    APPEND T_HBANK.
  ENDLOOP.

* if search was not successful: find house banks for payment method
  IF SY-SUBRC NE 0.
    LOOP AT T_TFK042A WHERE OPBUK EQ IMPORT-OPBUK
                      AND   ZLSCH EQ TFK042E-ZLSCH
                      AND   WAERS EQ SPACE.
      MOVE-CORRESPONDING T_TFK042A TO T_HBANK.
      APPEND T_HBANK.
    ENDLOOP.
  ENDIF.

* hktid is necessary
  DELETE T_HBANK WHERE HKTID = SPACE.

* any banks found for this payment method and currency?
  READ TABLE T_HBANK INDEX 1.
  CHECK SY-SUBRC EQ 0.

* add data of master record
  LOOP AT T_HBANK.
    CALL FUNCTION 'FKK_BANK_DATA_READ'
         EXPORTING
              I_BUKRS = IMPORT-OPBUK
              I_HBKID = T_HBANK-HBKID
              I_HKTID = T_HBANK-HKTID
         IMPORTING
              E_T012  = T_HBANK-T012
              E_T012K = T_HBANK-T012K
              E_BNKA  = T_HBANK-BNKA
         EXCEPTIONS
              OTHERS  = 4.
    IF SY-SUBRC EQ 0.
      BNKA = T_HBANK-BNKA.
      T_HBANK-BGRUP = BNKA-BGRUP.
      MODIFY T_HBANK.
    ELSE.
      MSGV1 = IMPORT-OPBUK.
      MSGV2 = T_HBANK-HBKID.
      MSGV3 = T_HBANK-HKTID.
      PERFORM MESSAGE USING 042.       "house bank data not found
      DELETE T_HBANK.
    ENDIF.
  ENDLOOP.

* sort and check that a house bank has been found (only for return code)
  SORT T_HBANK.
  READ TABLE T_HBANK INDEX 1.
ENDFORM.                    "READ_HOUSE_BANK


*---------------------------------------------------------------------*
*       FORM READ_PARTNER_BANK                                        *
*---------------------------------------------------------------------*
FORM READ_PARTNER_BANK.
DATA: LOC_RC     LIKE SY-SUBRC.
DATA: LOC_DATUM  TYPE D.
DATA: L_TESTIBAN TYPE TIBAN.
DATA: L_TEST0BK  TYPE BUT0BK.
DATA: L_TIBAN    TYPE TIBAN.

* does partner have any banks?
  CLEAR T_BUS0BK.   " 291200 DMR
  READ TABLE T_BUS0BK INDEX 1.
  CHECK SY-SUBRC EQ 0.

* check whether partner's banks have already been read
  T_PBANK[] = T_PBANK_ALL[].
  READ TABLE T_PBANK WITH KEY PARTNER = T_BUS0BK-PARTNER.
  CHECK SY-SUBRC NE 0.

* read data of partner's banks in the bank master record
  REFRESH T_PBANK.
  LOOP AT T_BUS0BK.
    LOC_RC = 4.

*>> Note 1336384
    IF *T005-LAND1 NE T_BUS0BK-BANKS.
      SELECT SINGLE * FROM T005 INTO *T005 WHERE LAND1 = T_BUS0BK-BANKS.
    ENDIF.

    IF *T005-BNKEY = '2' AND
       T_BUS0BK-BANKS = 'BE'.
      T_BUS0BK-BANKL = T_BUS0BK-BANKN.
    ENDIF.
*<< Note 1336384

* ...read T_BUSIBAN
    CLEAR: T_BUSIBAN.
    READ TABLE T_BUSIBAN WITH KEY BANKS = T_BUS0BK-BANKS
                                  BANKL = T_BUS0BK-BANKL
                                  BANKN = T_BUS0BK-BANKN
                                  BKONT = T_BUS0BK-BKONT.

* ...check buffer table for BNKA
    READ TABLE T_BNKA_BUF WITH KEY BANKS = T_BUS0BK-BANKS
                                   BANKL = T_BUS0BK-BANKL.
    IF SY-SUBRC = 0.
      LOC_RC = 0.
      MOVE-CORRESPONDING T_BNKA_BUF TO BNKA.
      T_BNKA_BUF-COUNT = T_BNKA_BUF-COUNT + 1.
      MODIFY T_BNKA_BUF INDEX SY-TABIX.
    ELSE.

* ...read database
      SELECT SINGLE * FROM BNKA WHERE BANKS EQ T_BUS0BK-BANKS
                                AND   BANKL EQ T_BUS0BK-BANKL.
      LOC_RC = SY-SUBRC.
      IF LOC_RC = 0.
        MOVE-CORRESPONDING BNKA TO T_BNKA_BUF.
        T_BNKA_BUF-COUNT = 1.
        COLLECT T_BNKA_BUF.
      ENDIF.
    ENDIF.

* ...bank found, store in T_PBANK
    IF LOC_RC EQ 0.
      MOVE-CORRESPONDING T_BUS0BK TO T_PBANK. "this also fills IBAN if in BUT0BK
      T_PBANK-XPGRO = BNKA-XPGRO.
      T_PBANK-PSKTO = BNKA-PSKTO.
      T_PBANK-BGRUP = BNKA-BGRUP.
      T_PBANK-BNKA  = BNKA.

* fill T_PBANK-TMPIBAN in any case
      L_TESTIBAN-IBAN = 'NO IBAN IN BUT0BK'.
      MOVE-CORRESPONDING L_TESTIBAN TO L_TEST0BK.
      CLEAR: L_TEST0BK.
      MOVE-CORRESPONDING L_TEST0BK  TO L_TESTIBAN.
* ...IBAN is not in BUT0BK => move from T_BUSIBAN to TMPIBAN
      IF L_TESTIBAN-IBAN = 'NO IBAN IN BUT0BK'.
        MOVE-CORRESPONDING T_BUSIBAN TO L_TIBAN.
        T_PBANK-TMPIBAN = L_TIBAN-IBAN.
* ...IBAN is in BUT0BK => move from BUT0BK to TMPIBAN
      ELSE.
        MOVE-CORRESPONDING T_BUS0BK TO L_TIBAN.
        T_PBANK-TMPIBAN = L_TIBAN-IBAN.
      ENDIF.

* finally append bank with all additional data (IBAN) in T_PBANK
      APPEND T_PBANK.
    ENDIF.
  ENDLOOP.

* keep buffer table for bnka small / delete those not used frequently
  DESCRIBE TABLE T_BNKA_BUF LINES SY-TFILL.
  IF SY-TFILL > 40.
    SORT T_BNKA_BUF BY COUNT DESCENDING.
    DELETE T_BNKA_BUF FROM 20 TO SY-TFILL.
  ENDIF.

* give back all banks
  T_PBANK_ALL[] = T_PBANK[].

* check that partner's banks have been found (only for return code)
  READ TABLE T_PBANK INDEX 1.
ENDFORM.                    "READ_PARTNER_BANK
