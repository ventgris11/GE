*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 21.04.2019 at 17:53:02
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZDSO_RESIL_BP_A.................................*
DATA:  BEGIN OF STATUS_ZDSO_RESIL_BP_A               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDSO_RESIL_BP_A               .
CONTROLS: TCTRL_ZDSO_RESIL_BP_A
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDSO_RESIL_BP_A               .
TABLES: ZDSO_RESIL_BP_A                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
