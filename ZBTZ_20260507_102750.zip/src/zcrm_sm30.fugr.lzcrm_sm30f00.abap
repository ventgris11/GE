*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 15.08.2017 at 21:09:43
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
