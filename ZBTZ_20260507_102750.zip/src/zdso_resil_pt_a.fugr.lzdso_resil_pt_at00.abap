*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 14.04.2019 at 12:20:32
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZDSO_RESIL_PT_A.................................*
DATA:  BEGIN OF STATUS_ZDSO_RESIL_PT_A               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDSO_RESIL_PT_A               .
CONTROLS: TCTRL_ZDSO_RESIL_PT_A
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDSO_RESIL_PT_A               .
TABLES: ZDSO_RESIL_PT_A                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
