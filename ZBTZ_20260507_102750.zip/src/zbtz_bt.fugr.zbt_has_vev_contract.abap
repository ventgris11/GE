FUNCTION zbt_has_vev_contract.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(X_PARTNER) TYPE  BU_PARTNER
*"  EXPORTING
*"     REFERENCE(Y_CLIENT_VEV) TYPE  BOOLEAN
*"----------------------------------------------------------------------
  DATA : lt_install TYPE TABLE OF anlage.

  CLEAR : y_client_vev, lt_install .

  SELECT ever~anlage INTO TABLE lt_install
    FROM fkkvkp INNER JOIN ever   ON fkkvkp~vkont = ever~vkonto
                INNER JOIN ettifn ON ever~anlage  = ettifn~anlage
    WHERE fkkvkp~gpart   EQ x_partner
"      AND ever~einzdat   LE sy-datum
      AND ever~auszdat   GE sy-datum
      AND ettifn~operand IN ('ELPPREM','GLPPREM')
      AND ettifn~bis     GE sy-datum
      AND ettifn~string1 NE space.

  IF lt_install IS NOT INITIAL.
    y_client_vev = abap_true.
  ENDIF.

ENDFUNCTION.
