* regenerated at 07.04.2019 13:51:40
FUNCTION-POOL ZDSORES_STATNEXT           MESSAGE-ID SV.

* INCLUDE LZDSORES_STATNEXTD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDSORES_STATNEXTT00                    . "view rel. data dcl.
