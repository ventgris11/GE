*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 22.04.2019 at 02:53:37
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZDSO_RESIL_DEM..................................*
DATA:  BEGIN OF STATUS_ZDSO_RESIL_DEM                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDSO_RESIL_DEM                .
CONTROLS: TCTRL_ZDSO_RESIL_DEM
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDSO_RESIL_DEM                .
TABLES: ZDSO_RESIL_DEM                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
