*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCAMT054
*   generation date: 08.08.2018 at 09:47:25
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCAMT054            .

  PERFORM TABLEPROC.

ENDFUNCTION.
