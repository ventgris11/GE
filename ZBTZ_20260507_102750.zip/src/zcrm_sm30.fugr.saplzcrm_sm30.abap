* regenerated at 21.04.2017 14:28:03
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCRM_SM30TOP.                     " Global Data
  INCLUDE LZCRM_SM30UXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCRM_SM30F...                     " Subroutines
* INCLUDE LZCRM_SM30O...                     " PBO-Modules
* INCLUDE LZCRM_SM30I...                     " PAI-Modules
* INCLUDE LZCRM_SM30E...                     " Events
* INCLUDE LZCRM_SM30P...                     " Local class implement.
* INCLUDE LZCRM_SM30T99.                     " ABAP Unit tests
  INCLUDE LZCRM_SM30F00                           . " subprograms
  INCLUDE LZCRM_SM30I00                           . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
