FUNCTION zintf_e_pose_fiap_all .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_NB_ROUES) TYPE  ZNB_CHIFFRES_CADRAN
*"     REFERENCE(IV_ID_FLUX) TYPE  ZID_FLUX
*"     REFERENCE(IV_DATE_POSE) TYPE  DATS
*"     REFERENCE(IV_EQUI_TYPE) TYPE  MATNR
*"     REFERENCE(IV_GRP_CADRAN) TYPE  E_ZWGRUPPE
*"     REFERENCE(IV_MATRICULE) TYPE  ZNUM_SERIE
*"     REFERENCE(IT_CADRANS) TYPE  ZINTF_CAD_RES_T
*"     REFERENCE(IV_ANLAGE) TYPE  ANLAGE
*"     REFERENCE(IV_IDENREG) TYPE  ZIDENREG
*"     REFERENCE(IV_TOUT_CADRANS) TYPE  FLAG OPTIONAL
*"  EXPORTING
*"     REFERENCE(EV_STATUT) TYPE  I
*"  CHANGING
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA:
    lv_field     TYPE string,
    lt_etdz      TYPE TABLE OF etdz,
    ls_etdz      TYPE etdz,
    lv_stanzvor  TYPE stanzvor,
    ls_auto      TYPE isu42_devmod_auto,
    lv_device    TYPE geraet,
    lv_sernr     TYPE lsernr,
    lv_equnr     TYPE equnr,
    lv_db_update TYPE e_update,
    ls_dev       TYPE reg42_dev,
    ls_dev_flag  TYPE reg42_dev_input_flag,
    ls_lsernr    TYPE lsernr,
    ls_cadran    TYPE zintf_cad_res,
    lv_cadran    TYPE e_zwnummer,
    lv_len       TYPE i,
    lv_char2     TYPE char2,
    ls_obj       TYPE isu07_install. " ++ GE-3574 (LWAT)

*DEB-IBEN-20190225-GE-4368
  IF cv_log_handle IS NOT INITIAL.
    lv_log_handle = cv_log_handle.
  ENDIF.
*FIN-IBEN-20190225-GE-4368

  ev_statut = 2.

  CLEAR ls_auto.
  CLEAR ls_dev.
  CLEAR ls_dev_flag.

  lv_char2 = iv_nb_roues .
  SHIFT lv_char2 LEFT DELETING LEADING '0'.
  lv_len = strlen( iv_equi_type ) - 1 .

*DEB-IBEN-20200326-GE-5504
  IF lv_char2 IS INITIAL.
    ls_dev-matnr = ls_dev_flag-matnr = iv_equi_type.
    ls_dev-zwgruppe   = iv_grp_cadran.
  ELSE.
*FIN-IBEN-20200326-GE-5504
* Créer constante ou se baser sur la table ETYP
    ls_dev-matnr      = iv_equi_type(lv_len) && lv_char2.
    ls_dev_flag-matnr = iv_equi_type(lv_len) && lv_char2.

    lv_len = strlen( iv_grp_cadran ) - 1 .
    ls_dev-zwgruppe   = iv_grp_cadran(lv_len) && lv_char2.
*DEB-IBEN-20200326-GE-5504
  ENDIF.
*FIN-IBEN-20200326-GE-5504

  ls_dev-ab              = iv_date_pose.
  ls_dev-bis             = '99991231'.
  ls_dev-sparte          = 'ZE'.
  ls_dev-egerr_info      = iv_matricule.

  APPEND ls_dev         TO ls_auto-dev.

  ls_dev_flag-ab         = iv_date_pose.
  ls_dev_flag-bis        = '99991231'.
  ls_dev_flag-zwgruppe   = 'X'.
  ls_dev_flag-egerr_info = 'X'.
  APPEND ls_dev_flag    TO ls_auto-dev_flag.

  ls_auto-contr-okcode = 'SAVE'.

* Créer fiche info appareil
  CALL FUNCTION 'ISU_S_SMALL_DEVICE_CREATE'
    EXPORTING
      x_matnr        = ls_dev-matnr            " Type appareil
      x_keydate      = iv_date_pose
      x_upd_online   = 'X'
      x_no_dialog    = 'X'
      x_auto         = ls_auto
      x_int_num      = 'X'
    IMPORTING
      y_db_update    = lv_db_update
      y_equnr        = lv_equnr
      y_device       = lv_sernr
    EXCEPTIONS
      not_found      = 1
      invalid        = 2
      foreign_lock   = 3
      input_error    = 4
      system_error   = 5
      internal_error = 6
      not_qualified  = 7
      not_customized = 8
      cancelled      = 9
*     error_message  = 10
      OTHERS         = 11.

  IF sy-subrc NE 0
  OR lv_db_update IS INITIAL.
    macro_add_msg_system_to_log.
    RETURN.
  ENDIF.

  DATA: ld_date       TYPE datum,
        ld_perverbr   TYPE perverbr,
        ld_thgver     TYPE thgver,
        ld_zwnummer   TYPE e_zwnummer,
        ld_tarifart   TYPE tarifart,
        ld_date_c(10) TYPE c,
        ld_db_update  TYPE xfeld,
        lt_zw         TYPE isu07_zwt,
        ls_zw         TYPE isu07_zw,
        ls_ger        TYPE isu07_auto_ger,
        ls_auto_pose  TYPE isu07_install_auto.

* Pose de la fiche appareil créée
*
* Récupération :
* de la consommation périodique actuelle (CAR de facturation )
* de la catégorie de tarif
* de la conversion gaz
*
* Les données sont à récupérer à J-1 par rapport à la date de pose
*
  REFRESH lt_zw.
  ld_date = iv_date_pose - 1 .

  SELECT  easts~tarifart
          easte~perverbr
          eadz~thgver
          etdz~zwnummer
    INTO (ld_tarifart,
          ld_perverbr,
          ld_thgver,
          ld_zwnummer)
    FROM easts INNER JOIN easte
                       ON easte~logikzw EQ easts~logikzw
                      AND easte~bis     GE easts~ab
                      AND easte~ab      LE easts~bis
               INNER JOIN eadz
                       ON eadz~logikzw  EQ easts~logikzw
                      AND eadz~bis      GE easts~ab
                      AND eadz~ab       LE easts~bis
               INNER JOIN etdz
                       ON etdz~logikzw  EQ easts~logikzw
                      AND etdz~bis      GE easts~ab
                      AND etdz~ab       LE easts~bis
   WHERE easts~anlage EQ iv_anlage
     AND easts~ab     LE ld_date
     AND easts~bis    GE ld_date
     AND easte~ab     LE ld_date
     AND eadz~bis     GE ld_date
     AND eadz~ab      LE ld_date
     AND etdz~ab      LE ld_date.

    lv_cadran = ld_zwnummer .
    READ TABLE it_cadrans INTO ls_cadran
                          WITH KEY register = lv_cadran.
    CHECK sy-subrc IS INITIAL .

    READ TABLE lt_zw TRANSPORTING NO FIELDS WITH KEY zwnummere = ld_zwnummer.
    CHECK sy-subrc IS NOT INITIAL.

* Données cadran(s)
    ls_zw-zwnummere       = ls_cadran-register.
    ls_zw-zwstandce       = ls_cadran-index_cad.
    ls_zw-spartype        = '01'.
    ls_zw-geraete         = lv_sernr.
    ls_zw-matnre          = ls_dev-matnr.
    ls_zw-anzerg          = 1.
    ls_zw-thgver          = ld_thgver.
*DEB-IBEN-20190214-GE-4098
    IF ls_cadran-tarifart IS NOT INITIAL.
      ls_zw-tarifart        = ls_cadran-tarifart.
    ELSE.
*FIN-IBEN-20190214-GE-4098
      ls_zw-tarifart        = ld_tarifart.
*DEB-IBEN-20190214-GE-4098
    ENDIF.
*FIN-IBEN-20190214-GE-4098

*DEB-IBEN-20190214-GE-4098
    IF ls_cadran-perverbr IS NOT INITIAL.
      ls_zw-perverbr        = ls_cadran-perverbr.
    ELSE.
*FIN-IBEN-20190214-GE-4098
      ls_zw-perverbr        = ld_perverbr.
*DEB-IBEN-20190214-GE-4098
    ENDIF.
*FIN-IBEN-20190214-GE-4098

*DEB-IBEN-20200326-GE-5504
    ls_zw-zwnabr = ls_cadran-zwnabr.
*FIN-IBEN-20200326-GE-5504

    APPEND ls_zw TO lt_zw.

  ENDSELECT.

*DEB-IBEN-20190214-GE-4098
  IF iv_tout_cadrans = abap_true.
    LOOP AT it_cadrans INTO ls_cadran.
      READ TABLE lt_zw TRANSPORTING NO FIELDS WITH KEY zwnummere = ls_cadran-register.
      IF sy-subrc <> 0.
        CLEAR ls_zw.
* Données cadran(s)
        ls_zw-zwnummere       = ls_cadran-register.
        ls_zw-zwstandce       = ls_cadran-index_cad.
        ls_zw-spartype        = '01'.
        ls_zw-geraete         = lv_sernr.
        ls_zw-matnre          = ls_dev-matnr.
        ls_zw-anzerg          = 1.
        ls_zw-tarifart        = ls_cadran-tarifart.
        ls_zw-perverbr        = ls_cadran-perverbr.

*DEB-IBEN-20200326-GE-5504
        ls_zw-zwnabr = ls_cadran-zwnabr.
*FIN-IBEN-20200326-GE-5504

        APPEND ls_zw TO lt_zw.
      ENDIF.
    ENDLOOP.
  ENDIF.
*FIN-IBEN-20190214-GE-4098

  IF lt_zw[] IS INITIAL.
    MESSAGE e158(zintf_e_messages) WITH 'lt_zw vide' INTO DATA(lv_message).
    macro_add_msg_system_to_log.
* Problème dans le modèle de données
    ev_statut = 2.
    EXIT.
  ENDIF.

* Données d'appareil
  ls_ger-matnr     = ls_dev-matnr.
  ls_ger-geraetneu = lv_sernr.
  ls_ger-ausbau    = space.
  ls_ger-sparteneu = 'ZE'.
  ls_ger-action    = '04'.
  APPEND ls_ger TO ls_auto_pose-auto_ger.

* Données de cadran(s)
  ls_auto_pose-auto_zw                 = lt_zw.
  ls_auto_pose-interface-anlage        = iv_anlage.
  ls_auto_pose-interface-eadat         = iv_date_pose.
  ls_auto_pose-interface-action        = '04'.
  ls_auto_pose-interface-upd_online    = 'X'.
  ls_auto_pose-interface-no_dialog     = 'X'.
  ls_auto_pose-interface-no_event      = 'X'.
  ls_auto_pose-interface-no_statistic  = 'X'.
  ls_auto_pose-interface-no_change_doc = 'X'.
  ls_auto_pose-okcode                  = 'SAVE'.
  ls_auto_pose-zwstand                 = 'X'.
  ls_auto_pose-consumption             = 'X'.

** >> GE-3574 (LWAT) 29.12.2018 : Nous avons besoin d'appeler le MF qui convertit la structure AUTO
**    vers la structure X_OBJ car nous souhaitons ajouter des infos sur la relève (ZZIDENREG)
  CALL FUNCTION 'ISU_O_WORKLIST_INSTALL_OPEN'
    EXPORTING
      x_anlage         = iv_anlage
      x_eadat          = iv_date_pose
      x_geraetneu      = lv_sernr
      x_matnr          = ls_dev-matnr
      x_action         = '04'       " Pose pour calcul de facturation
      x_spartee        = 'ZE'
      x_upd_online     = 'X'
      x_no_dialog      = 'X'
      x_no_event       = 'X'
      x_no_statistic   = 'X'
      x_no_change_doc  = 'X'
      x_called_by_idoc = space
    IMPORTING
      y_obj            = ls_obj
    CHANGING
      xy_auto          = ls_auto_pose
    EXCEPTIONS
      not_found        = 1
      foreign_lock     = 2
      invalid          = 3
      internal_error   = 4
      not_qualified    = 5
      input_error      = 6
      system_error     = 7
      not_customized   = 8
      OTHERS           = 9.
  IF sy-subrc <> 0.
    macro_add_msg_system_to_log.
    MESSAGE e158(zintf_e_messages) WITH 'Erreur durant ISU_O_WORKLIST_INSTALL_OPEN' INTO lv_message.
    macro_add_msg_system_to_log.
    RETURN.
  ENDIF.

  " Pour chaque relève, on positionne l'ID enregistrement des flux
  LOOP AT ls_obj-obj-integration-meter_doc-i_reabld ASSIGNING FIELD-SYMBOL(<lr_i_reabld>).
    <lr_i_reabld>-zzidenreg = iv_idenreg.
  ENDLOOP.
** << GE-3574 (LWAT) 29.12.2018

  CALL FUNCTION 'ISU_S_WORKLIST_INSTALL'
    EXPORTING
      x_anlage         = iv_anlage
      x_eadat          = iv_date_pose
      x_geraetneu      = lv_sernr
      x_matnr          = ls_dev-matnr
      x_action         = '04'       " Pose pour calcul de facturation
      x_spartee        = 'ZE'
      x_upd_online     = 'X'
      x_no_dialog      = 'X'
      x_no_event       = 'X'
      x_no_statistic   = 'X'
      x_no_change_doc  = 'X'
      x_called_by_idoc = space
    IMPORTING
      y_db_update      = ld_db_update
    CHANGING
      xy_obj           = ls_obj " ++ GE-3574 (LWAT)
      xy_auto          = ls_auto_pose
    EXCEPTIONS
      not_found        = 1
      foreign_lock     = 2
      invalid          = 3
      internal_error   = 4
      not_qualified    = 5
      input_error      = 6
      system_error     = 7
      not_customized   = 8
*     error_message    = 9
      OTHERS           = 10.

  IF sy-subrc NE 0
  OR lv_db_update IS INITIAL.
    macro_add_msg_system_to_log.
    MESSAGE e158(zintf_e_messages) WITH 'Erreur durant ISU_S_WORKLIST_INSTALL' INTO lv_message.
    macro_add_msg_system_to_log.
    RETURN.
  ENDIF.

  ev_statut = 1.

ENDFUNCTION.
