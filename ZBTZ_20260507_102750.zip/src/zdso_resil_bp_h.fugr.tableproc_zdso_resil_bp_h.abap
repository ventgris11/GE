*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDSO_RESIL_BP_H
*   generation date: 21.04.2019 at 17:54:28
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDSO_RESIL_BP_H     .

  PERFORM TABLEPROC.

ENDFUNCTION.
