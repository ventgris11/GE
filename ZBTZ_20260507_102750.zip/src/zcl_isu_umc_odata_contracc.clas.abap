class ZCL_ISU_UMC_ODATA_CONTRACC definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_ISU_UMC_ODATA_BADI .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ISU_UMC_ODATA_CONTRACC IMPLEMENTATION.
ENDCLASS.
