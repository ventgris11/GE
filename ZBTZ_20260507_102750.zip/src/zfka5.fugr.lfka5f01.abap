*----------------------------------------------------------------------*
***INCLUDE LFKA5F01 .
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  MESSAGE_APPEND
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM message_append TABLES pt_fimsg STRUCTURE fimsg
                    USING  p_msgid p_msgty p_msgno
                           p_msgv1 p_msgv2 p_msgv3 p_msgv4.
  CLEAR pt_fimsg.
  pt_fimsg-msgid = p_msgid.
  pt_fimsg-msgty = p_msgty.
  pt_fimsg-msgno = p_msgno.
  pt_fimsg-msgv1 = p_msgv1.
  pt_fimsg-msgv2 = p_msgv2.
  pt_fimsg-msgv3 = p_msgv3.
  pt_fimsg-msgv4 = p_msgv4.
  APPEND pt_fimsg.
ENDFORM.                               " MESSAGE_APPEND

*&---------------------------------------------------------------------*
*&      Form  CALL_ZP_FB_5060
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM call_zp_fb_5060 TABLES   pt_fkkop STRUCTURE fkkop
                      USING   p_fkkop  STRUCTURE fkkop
                   CHANGING   p_inkgp.

  CHECK h_man_sel IS INITIAL.

  LOOP AT t_tfkfbc_5060.
    CALL FUNCTION t_tfkfbc_5060-funcc
      EXPORTING
        i_fkkop   = p_fkkop
      IMPORTING
        e_inkgp   = p_inkgp
        e_man_sel = h_man_sel
      TABLES
        t_fkkop   = pt_fkkop
      EXCEPTIONS
        OTHERS    = 1.
    IF sy-subrc NE 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
  ENDLOOP.
* ------ for cross reference purpose only -----------------------------*
  SET EXTENDED CHECK OFF.
  IF 1 = 2.
    CALL FUNCTION 'FKK_SAMPLE_5060'.
  ENDIF.
  SET EXTENDED CHECK ON.
* ------ end of cross reference ---------------------------------------*
ENDFORM.                               " CALL_ZP_FB_5060

*&---------------------------------------------------------------------*
*&      Form  CALL_ZP_FB_5059
*&---------------------------------------------------------------------*
*       delete position for releasing to a collection agency
*----------------------------------------------------------------------*
FORM call_zp_fb_5059 TABLES   pt_fkkop_not_submitted STRUCTURE fkkop
                     USING    h_fkkop  STRUCTURE fkkop
                     CHANGING h_rel_instpln LIKE boole-boole.

  REFRESH: pt_fkkop_not_submitted.

  LOOP AT t_tfkfbc_5059.
    CALL FUNCTION t_tfkfbc_5059-funcc
      EXPORTING
        i_fkkop               = h_fkkop
      TABLES
        t_fkkop_not_submitted = pt_fkkop_not_submitted
      CHANGING
        i_rel_instpln         = h_rel_instpln.
    IF sy-subrc NE 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
  ENDLOOP.
* ------ for cross reference purpose only -----------------------------*
  SET EXTENDED CHECK OFF.
  IF 1 = 2.
    CALL FUNCTION 'FKK_SAMPLE_5059'.
  ENDIF.
  SET EXTENDED CHECK ON.
* ------ end of cross reference ---------------------------------------*
ENDFORM.                               " CALL_ZP_FB_5059

*&---------------------------------------------------------------------*
*&      Form  CALL_ZP_FB_5061
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM call_zp_fb_5061 TABLES   pt_fkkop      STRUCTURE fkkop
                              pt_fkkmaze    STRUCTURE fkkmaze
                     USING    ps_fkkop      STRUCTURE fkkop
                              ps_fkkcoll    STRUCTURE dfkkcoll
                     CHANGING ps_fkkcolfile STRUCTURE fkkcolfile.

  LOOP AT t_tfkfbc_5061.
    CALL FUNCTION t_tfkfbc_5061-funcc
      EXPORTING
        i_fkkop      = ps_fkkop
        i_fkkcoll    = ps_fkkcoll
      TABLES
        t_fkkop      = pt_fkkop
        t_fkkmaze    = pt_fkkmaze
      CHANGING
        c_fkkcolfile = ps_fkkcolfile
      EXCEPTIONS
        OTHERS       = 1.
    IF sy-subrc NE 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
  ENDLOOP.
* ------ for cross reference purpose only -----------------------------*
  SET EXTENDED CHECK OFF.
  IF 1 = 2.
    CALL FUNCTION 'FKK_SAMPLE_5061'.
  ENDIF.
  SET EXTENDED CHECK ON.
* ------ end of cross reference ---------------------------------------*
ENDFORM.                               " CALL_ZP_FB_5061

*&---------------------------------------------------------------------*
*&      Form  XSEND_FOR_AGSTA_READ
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM xsend_for_agsta_read USING    p_agsta
                          CHANGING p_xsend.

  CALL FUNCTION 'FKK_DB_TFK050A_SINGLE'
    EXPORTING
      i_agsta           = p_agsta
    IMPORTING
      e_xsend           = p_xsend
    EXCEPTIONS
      not_found         = 1
      initial_parameter = 2
      OTHERS            = 3.
  IF sy-subrc <> 0.
    CLEAR p_xsend.
  ENDIF.
ENDFORM.                               " XSEND_FOR_AGSTA_READ

*&---------------------------------------------------------------------*
*&      Form  CALL_ZP_FB_5062
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM call_zp_fb_5062 TABLES   pt_fkkcoll STRUCTURE dfkkcoll
                              pt_fkkop   STRUCTURE fkkop
                              pt_fkkmaze STRUCTURE fkkmaze
                     CHANGING ps_fkkcolfile_header
                                            STRUCTURE fkkcolfile_header.

  DATA: i_fbstab LIKE tfkfbc OCCURS 1 WITH HEADER LINE,
        h_applk  LIKE fkkop-applk.

  CALL FUNCTION 'FKK_GET_APPLICATION'
    EXPORTING
      i_no_dialog      = 'X'
    IMPORTING
      e_applk          = h_applk
    EXCEPTIONS
      no_appl_selected = 1
      OTHERS           = 2.
  IF sy-subrc <> 0.
    h_applk = '*'.
  ENDIF.

  CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
    EXPORTING
      i_applk  = h_applk
      i_fbeve  = const_event_5062
    TABLES
      t_fbstab = i_fbstab.

* ------ for cross reference purpose only -----------------------------*
  SET EXTENDED CHECK OFF.
  IF 1 = 2.
    CALL FUNCTION 'FKK_SAMPLE_5062'.
  ENDIF.
  SET EXTENDED CHECK ON.
* ------ end of cross reference ---------------------------------------*

  LOOP AT i_fbstab.
    CALL FUNCTION i_fbstab-funcc
      TABLES
        t_fkkcoll           = pt_fkkcoll
        t_fkkop             = pt_fkkop
        t_fkkmaze           = pt_fkkmaze
      CHANGING
        c_fkkcolfile_header = ps_fkkcolfile_header
      EXCEPTIONS
        OTHERS              = 1.
    IF sy-subrc NE 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
               RAISING general_fault.
    ENDIF.
  ENDLOOP.
ENDFORM.                               " CALL_ZP_FB_5062

*&---------------------------------------------------------------------*
*&      Form  CALL_ZP_FB_5063
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM call_zp_fb_5063 TABLES   pt_fkkop      STRUCTURE fkkop
                              pt_fkkmaze    STRUCTURE fkkmaze
                     USING    ps_fkkcoll    STRUCTURE dfkkcoll
                     CHANGING ps_fkkcolfile STRUCTURE fkkcolfile.

  DATA: i_fbstab LIKE tfkfbc OCCURS 1 WITH HEADER LINE,
        h_applk  LIKE fkkop-applk.

  CALL FUNCTION 'FKK_GET_APPLICATION'
    EXPORTING
      i_no_dialog      = 'X'
    IMPORTING
      e_applk          = h_applk
    EXCEPTIONS
      no_appl_selected = 1
      OTHERS           = 2.
  IF sy-subrc <> 0.
    h_applk = '*'.
  ENDIF.

  CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
    EXPORTING
      i_applk  = h_applk
      i_fbeve  = const_event_5063
    TABLES
      t_fbstab = i_fbstab.

* ------ for cross reference purpose only -----------------------------*
  SET EXTENDED CHECK OFF.
  IF 1 = 2.
    CALL FUNCTION 'FKK_SAMPLE_5063'.
  ENDIF.
  SET EXTENDED CHECK ON.
* ------ end of cross reference ---------------------------------------*

  LOOP AT i_fbstab.
    CALL FUNCTION i_fbstab-funcc
      EXPORTING
        i_fkkcoll    = ps_fkkcoll
      TABLES
        t_fkkop      = pt_fkkop
        t_fkkmaze    = pt_fkkmaze
      CHANGING
        c_fkkcolfile = ps_fkkcolfile
      EXCEPTIONS
        OTHERS       = 1.
    IF sy-subrc NE 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
               RAISING general_fault.
    ENDIF.
  ENDLOOP.
ENDFORM.                               " CALL_ZP_FB_5063

*&---------------------------------------------------------------------*
*&      Form  CALL_ZP_FB_5064
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--P_H_FKKCOLFILE_HEADER  text
*----------------------------------------------------------------------*
FORM call_zp_fb_5064 TABLES   pt_fkkcoll STRUCTURE dfkkcoll
                              pt_fkkop   STRUCTURE fkkop
                              pt_fkkmaze STRUCTURE fkkmaze
                     CHANGING ps_fkkcolfile_trailer
                                         STRUCTURE fkkcolfile_trailer.

  DATA: i_fbstab LIKE tfkfbc OCCURS 1 WITH HEADER LINE,
        h_applk  LIKE fkkop-applk.

  CALL FUNCTION 'FKK_GET_APPLICATION'
    EXPORTING
      i_no_dialog      = 'X'
    IMPORTING
      e_applk          = h_applk
    EXCEPTIONS
      no_appl_selected = 1
      OTHERS           = 2.
  IF sy-subrc <> 0.
    h_applk = '*'.
  ENDIF.

  CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
    EXPORTING
      i_applk  = h_applk
      i_fbeve  = const_event_5064
    TABLES
      t_fbstab = i_fbstab.

* ------ for cross reference purpose only -----------------------------*
  SET EXTENDED CHECK OFF.
  IF 1 = 2.
    CALL FUNCTION 'FKK_SAMPLE_5064'.
  ENDIF.
  SET EXTENDED CHECK ON.
* ------ end of cross reference ---------------------------------------*

  LOOP AT i_fbstab.
    CALL FUNCTION i_fbstab-funcc
      TABLES
        t_fkkcoll            = pt_fkkcoll
        t_fkkop              = pt_fkkop
        t_fkkmaze            = pt_fkkmaze
      CHANGING
        c_fkkcolfile_trailer = ps_fkkcolfile_trailer
      EXCEPTIONS
        OTHERS               = 1.
    IF sy-subrc NE 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
               RAISING general_fault.
    ENDIF.
  ENDLOOP.
ENDFORM.                               " CALL_ZP_FB_5064

*&---------------------------------------------------------------------*
*&      Form  CALL_ZP_FB_5065
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM call_zp_fb_5065 TABLES   pt_dfkkcoll      STRUCTURE dfkkcoll
                              pt_all_coll      STRUCTURE dfkkcoll
                              pt_recall_coll   STRUCTURE dfkkcoll
                              pt_reassign_coll STRUCTURE dfkkcoll
                   CHANGING   do_recall.

  DATA: i_fbstab  LIKE tfkfbc OCCURS 1 WITH HEADER LINE,
        p_h_applk LIKE bfkkzgr00-applk.

* ------ determinig application ---------------------------------------*
  CALL FUNCTION 'FKK_GET_APPLICATION'
    IMPORTING
      e_applk       = p_h_applk
    EXCEPTIONS
      error_message = 1.

  CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
    EXPORTING
      i_applk  = p_h_applk
      i_fbeve  = const_event_5065
    TABLES
      t_fbstab = i_fbstab.

* ------ for cross reference purpose only -----------------------------*
  SET EXTENDED CHECK OFF.
  IF 1 = 2.
    CALL FUNCTION 'FKK_SAMPLE_5065'.
  ENDIF.
  SET EXTENDED CHECK ON.
* ------ end of cross reference ---------------------------------------*

  LOOP AT i_fbstab.
    CALL FUNCTION i_fbstab-funcc
      TABLES
        t_dfkkcoll      = pt_dfkkcoll
        t_all_coll      = pt_all_coll
        t_recall_coll   = pt_recall_coll
        t_reassign_coll = pt_reassign_coll
      CHANGING
        do_recall       = do_recall
      EXCEPTIONS
        error_found     = 1
        OTHERS          = 2.
    IF sy-subrc NE 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
               RAISING general_fault.
    ENDIF.
  ENDLOOP.
ENDFORM.                               " CALL_ZP_FB_5065

*&---------------------------------------------------------------------*
*&      Form  delete_locks
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM delete_locks TABLES   t_change_coll STRUCTURE dfkkcoll
                           t_fkkop       STRUCTURE fkkop.

  DATA:     h_loobj1    LIKE dfkklocks-loobj1,
            h_tfk033d   LIKE tfk033d,
            h_spzah     LIKE fkkop-spzah,
            h_mansp     LIKE fkkop-mansp,
            t_dfkklocks LIKE TABLE OF dfkklocks WITH HEADER LINE.
  CONSTANTS:const_proid_spzah  LIKE tfk080f-proid VALUE '10',
            const_proid_mansp  LIKE tfk080f-proid VALUE '01',
            const_lotyp_dfkkop LIKE tfk080b-lotyp VALUE '02',
            const_buber_1054   LIKE tfk033c-buber VALUE '1054'.

* read dunning and payment lock indicator posting area 1054
  CLEAR h_tfk033d.
  CALL FUNCTION 'FKK_GET_APPLICATION'
    EXPORTING
      i_no_dialog      = const_marked
    IMPORTING
      e_applk          = h_tfk033d-applk
    EXCEPTIONS
      no_appl_selected = 1
      OTHERS           = 2.
  h_tfk033d-buber = const_buber_1054.
  PERFORM account_determine CHANGING h_tfk033d.
  h_spzah = h_tfk033d-fun01.
  h_mansp = h_tfk033d-fun02.

  LOOP AT t_change_coll.
    CALL FUNCTION 'FKK_BP_LINE_ITEMS_SELECT'
      EXPORTING
        i_opbel  = t_change_coll-opbel
        ix_opbel = 'X'
        i_inkps  = t_change_coll-inkps
        ix_inkps = 'X'
      TABLES
        pt_fkkop = t_fkkop.

    LOOP AT t_fkkop.
* get locks for open items
      CLEAR: t_dfkklocks, t_dfkklocks[].
      CALL FUNCTION 'FKK_S_LOCK_GET_FOR_DOC_ITEMS'
        EXPORTING
          i_opbel  = t_fkkop-opbel
          i_opupw  = t_fkkop-opupw
          i_opupk  = t_fkkop-opupk
          i_opupz  = t_fkkop-opupz
        TABLES
          et_locks = t_dfkklocks.

      h_loobj1    = t_fkkop-opbel.
      h_loobj1+12 = t_fkkop-opupw.
      h_loobj1+15 = t_fkkop-opupk.
      h_loobj1+19 = t_fkkop-opupz.

      READ TABLE t_dfkklocks WITH KEY loobj1 = h_loobj1
                                      lotyp  = const_lotyp_dfkkop
                                      proid  = const_proid_spzah
                                      lockr  = h_spzah
                                      gpart  = t_fkkop-gpart
                                      vkont  = t_fkkop-vkont.
      IF sy-subrc = 0.
* ------ Delete payment lock ------------------------------------------*
        PERFORM locks_delete USING t_fkkop-gpart
                                   t_fkkop-vkont
                                   h_loobj1 const_proid_spzah
                                   const_lotyp_dfkkop h_spzah
                                   t_dfkklocks-fdate t_dfkklocks-tdate.
      ENDIF.

      READ TABLE t_dfkklocks WITH KEY loobj1 = h_loobj1
                                      lotyp  = const_lotyp_dfkkop
                                      proid  = const_proid_mansp
                                      lockr  = h_mansp
                                      gpart  = t_fkkop-gpart
                                      vkont  = t_fkkop-vkont.

      IF sy-subrc = 0.
* ------ Delete dunning lock ------------------------------------------*
        PERFORM locks_delete USING t_fkkop-gpart
                                   t_fkkop-vkont
                                   h_loobj1 const_proid_mansp
                                   const_lotyp_dfkkop h_mansp
                                   t_dfkklocks-fdate t_dfkklocks-tdate.
      ENDIF.
    ENDLOOP.
  ENDLOOP.
ENDFORM.                    " delete_locks

*&---------------------------------------------------------------------*
*&      Form  LOCKS_delete
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM locks_delete USING p_gpart p_vkont p_loobj1 p_proid
                        p_lotyp p_lockr p_fdate p_tdate.

  CALL FUNCTION 'FKK_S_LOCK_DELETE'
    EXPORTING
      i_loobj1              = p_loobj1
      i_gpart               = p_gpart
      i_vkont               = p_vkont
      i_proid               = p_proid
      i_lotyp               = p_lotyp
      i_lockr               = p_lockr
      i_fdate               = p_fdate
      i_tdate               = p_tdate
    EXCEPTIONS
      already_exist         = 1
      imp_data_not_complete = 2
      no_authority          = 3
      enqueue_lock          = 4
      data_protected        = 5
      OTHERS                = 6.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.
ENDFORM.                    " LOCKS_delete

*&---------------------------------------------------------------------*
*&      Form  account_determine
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM account_determine CHANGING ps_tfk033d STRUCTURE tfk033d.
* ------ Anwendungsspezifische Daten lesen ----------------------------*
  CALL FUNCTION 'FKK_ACCOUNT_DETERMINE'
    EXPORTING
      i_tfk033d           = ps_tfk033d
    IMPORTING
      e_tfk033d           = ps_tfk033d
    EXCEPTIONS
      error_in_input_data = 1
      nothing_found       = 2
      OTHERS              = 3.
* ------ for cross reference purpose only -----------------------------*
  SET EXTENDED CHECK OFF.
  IF 1 = 2. CALL FUNCTION 'FKK_ACCOUNT_DETERMINE_1054'. ENDIF.
  SET EXTENDED CHECK ON.
* ------ end of cross reference ---------------------------------------*
ENDFORM.                               " ACCOUNT_DETERMINE

*&---------------------------------------------------------------------*
*&      Form  opbel_append
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_T_FKKOP  text
*      -->P_I_FKKMAKO_MG2BL
*----------------------------------------------------------------------*
FORM opbel_append TABLES   pt_fkkop STRUCTURE fkkop
                  USING    p_opbel.

  DATA: ht_fkkop LIKE fkkop OCCURS 0 WITH HEADER LINE.

  CHECK NOT p_opbel IS INITIAL.
  CLEAR   ht_fkkop.
  REFRESH ht_fkkop.
  CALL FUNCTION 'FKK_BP_LINE_ITEMS_SEL_BY_OPBEL'
    EXPORTING
      i_opbel  = p_opbel
    TABLES
      pt_fkkop = ht_fkkop
    EXCEPTIONS
      OTHERS   = 1.
  IF sy-subrc = 0.
    LOOP AT ht_fkkop.
      IF NOT ht_fkkop IS INITIAL.
        READ TABLE pt_fkkop WITH KEY opbel = ht_fkkop-opbel
                                     opupw = ht_fkkop-opupw
                                     opupk = ht_fkkop-opupk
                                     opupz = ht_fkkop-opupz.
        IF sy-subrc NE 0.
          APPEND ht_fkkop TO pt_fkkop.
        ENDIF.
      ENDIF.
    ENDLOOP.
  ENDIF.
* ------ Initialize internal tables -----------------------------------*
  CLEAR   ht_fkkop.
  REFRESH ht_fkkop.
ENDFORM.                               " OPBEL_APPEND

*&---------------------------------------------------------------------*
*&      Form  read_buber_1058
*&---------------------------------------------------------------------*
*     read recalling reason from posting area 1058
*----------------------------------------------------------------------*
FORM read_buber_1058 CHANGING p_h_rugrd p_applk.

  DATA: h_tfk033d LIKE tfk033d.

  IF p_applk IS INITIAL.
* ------ determinig application ---------------------------------------*
    CALL FUNCTION 'FKK_GET_APPLICATION'
      IMPORTING
        e_applk       = p_applk
      EXCEPTIONS
        error_message = 1.
  ENDIF.

*--------- Buchungsbereich 1058: Rückrufgrund
  h_tfk033d-applk = p_applk.
  h_tfk033d-buber = '1058'.
  CALL FUNCTION 'FKK_ACCOUNT_DETERMINE'
    EXPORTING
      i_tfk033d     = h_tfk033d
    IMPORTING
      e_tfk033d     = h_tfk033d
    EXCEPTIONS
      error_message = 1
      OTHERS        = 1.
  IF sy-subrc = 0.
    p_h_rugrd = h_tfk033d-fun01.
  ENDIF.

* cross ref
  IF 1 = 2.
    CALL FUNCTION 'FKK_ACCOUNT_DETERMINE_1058'.
  ENDIF.

ENDFORM.                    " read_buber_1058

*&---------------------------------------------------------------------*
*&      Form  create_history
*&---------------------------------------------------------------------*
*       dfkkcoll history
*----------------------------------------------------------------------*
FORM create_history TABLES   p_t_coll         STRUCTURE dfkkcoll
                             p_t_history_coll STRUCTURE dfkkcollh
                             p_t_fimsg        STRUCTURE fimsg.

  DATA: h_lfdnr     LIKE dfkkcollh-lfdnr,
        ht_fkkcollh LIKE dfkkcollh OCCURS 0 WITH HEADER LINE.

  CLEAR: p_t_history_coll, p_t_history_coll[].

  LOOP AT p_t_coll.
    MOVE-CORRESPONDING p_t_coll TO p_t_history_coll.

    IF ( NOT p_t_history_coll-rudat IS INITIAL AND
       NOT p_t_history_coll-rugrd IS INITIAL ) AND
       NOT p_t_history_coll-agsta EQ const_agsta_recall.
      CLEAR: p_t_history_coll-rugrd, p_t_history_coll-rudat.
    ENDIF.

* maintain released amount in case the item was partially paid
    IF p_t_coll-betrz > 0 AND p_t_coll-agsta = const_agsta_freigegeben.
      SUBTRACT p_t_history_coll-betrz FROM p_t_history_coll-betrw.
      CLEAR p_t_history_coll-betrz.
    ENDIF.

    p_t_history_coll-aenam = sy-uname.
    p_t_history_coll-acpdt = sy-datlo.
    p_t_history_coll-acptm = sy-timlo.

    CALL FUNCTION 'FKK_DB_DFKKCOLLH_COUNT'
      EXPORTING
        i_opbel = p_t_history_coll-opbel
        i_inkps = p_t_history_coll-inkps
      IMPORTING
        e_count = h_lfdnr.

    IF p_t_history_coll-agsta GE '20'.
      CALL FUNCTION 'FKK_DB_DFKKCOLLH_SELECT'
        EXPORTING
          i_seltyp   = '2'
          i_opbel    = p_t_coll-opbel
          i_inkps    = p_t_coll-inkps
        TABLES
          t_fkkcollh = ht_fkkcollh
        EXCEPTIONS
          not_found  = 1
          OTHERS     = 2.

      READ TABLE ht_fkkcollh INDEX h_lfdnr.
      IF sy-subrc = 0.
        p_t_history_coll-agsta_or = ht_fkkcollh-agsta_or.
      ELSE.
        p_t_history_coll-agsta_or = p_t_history_coll-agsta.
      ENDIF.
    ELSE.
      p_t_history_coll-agsta_or = p_t_history_coll-agsta.
    ENDIF.

    ADD 1 TO h_lfdnr.

    p_t_history_coll-lfdnr = h_lfdnr.

    APPEND p_t_history_coll.
  ENDLOOP.

  CALL FUNCTION 'FKK_DB_DFKKCOLLH_INSERT'
    TABLES
      i_dfkkcollh = p_t_history_coll.

ENDFORM.                    " create_history

*&---------------------------------------------------------------------*
*&      Form  read_tfk042c
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM read_tfk042c TABLES   p_t_tfk042c STRUCTURE tfk042c.

  DESCRIBE TABLE p_t_tfk042c LINES sy-tfill.

  IF sy-tfill = 0.
    SELECT * FROM  tfk042c INTO TABLE p_t_tfk042c
            WHERE proid = const_proid
              AND datum <= sy-datum.
  ENDIF.
  SORT p_t_tfk042c BY datum DESCENDING.
ENDFORM.                               " read_tfk042c

*&---------------------------------------------------------------------*
*&      Form  items_convert_currency
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM items_convert_currency TABLES  p_t_tfk042c STRUCTURE tfk042c
                                    t_fkkcoll   STRUCTURE dfkkcoll
                                    t_fkkop     STRUCTURE fkkop.
  DATA: lt_bukrs       LIKE fkkop-bukrs,
        ls_fkkvkp      TYPE fkkvkp,
        ls_fkkop       TYPE fkkop,
        ls_fkkop_cprc  TYPE fkkop_cprc,
        lv_0119_unused TYPE xfeld.

  FIELD-SYMBOLS <dfkkcoll> TYPE dfkkcoll.

* Exchange of processing currency (e.g. if country has left the EURO zone
* and some of old EURO items have to be processed in the new local currency
* (event 0119)
  LOOP AT t_fkkcoll ASSIGNING <dfkkcoll>.
    MOVE-CORRESPONDING <dfkkcoll> TO ls_fkkop.
    CALL FUNCTION 'FKK_OPEN_ITEM_CHANGE_PROC_CURR'
      EXPORTING
        i_procid      = '01'
        i_fkkop       = ls_fkkop
      IMPORTING
        e_fkkop_cprc  = ls_fkkop_cprc
        e_0119_unused = lv_0119_unused.
    IF lv_0119_unused = 'X'.
      EXIT.
    ENDIF.
    IF  ls_fkkop_cprc-waers NE space
    AND ls_fkkop_cprc-waers NE <dfkkcoll>-waers.
      MOVE-CORRESPONDING ls_fkkop_cprc TO <dfkkcoll>.
    ENDIF.
  ENDLOOP.

  DESCRIBE TABLE p_t_tfk042c LINES sy-tfill.
  IF sy-tfill = 0.
    EXIT.
  ELSE.
    LOOP AT t_fkkcoll.

* -- determine company code group as of 4.72 --------------------------*
      CALL FUNCTION 'FKK_ACCOUNT_READ'
        EXPORTING
          i_vkont      = t_fkkcoll-vkont
          i_gpart      = t_fkkcoll-gpart
          i_only_gpart = const_marked
        IMPORTING
          e_fkkvkp     = ls_fkkvkp
        EXCEPTIONS
          not_found    = 1
          foreign_lock = 2
          not_valid    = 3
          OTHERS       = 4.

      IF sy-subrc EQ 0.
        READ TABLE p_t_tfk042c WITH KEY proid = const_proid
                                        opbuk = ls_fkkvkp-opbuk
                                        waers = t_fkkcoll-waers.
      ELSE.

        READ TABLE t_fkkop WITH KEY opbel = t_fkkcoll-opbel
                                    inkps = t_fkkcoll-inkps.

        IF sy-subrc EQ 0 AND NOT t_fkkop-bukrs IS INITIAL.
          MOVE t_fkkop-bukrs TO lt_bukrs.
        ELSE.
          SELECT bukrs FROM dfkkop INTO lt_bukrs
                                  WHERE opbel = t_fkkcoll-opbel.
          ENDSELECT.
        ENDIF.

        READ TABLE p_t_tfk042c WITH KEY proid = const_proid
                                        opbuk = lt_bukrs
                                        waers = t_fkkcoll-waers.
      ENDIF.

      IF sy-subrc EQ 0.

        CHECK p_t_tfk042c-datum LE sy-datum.

        CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
          EXPORTING
            date             = sy-datum
            foreign_amount   = t_fkkcoll-betrw
            foreign_currency = t_fkkcoll-waers
            local_currency   = p_t_tfk042c-rwaer
          IMPORTING
            local_amount     = t_fkkcoll-betrw
          EXCEPTIONS
            OTHERS           = 1.

        t_fkkcoll-waers = p_t_tfk042c-rwaer.
        MODIFY t_fkkcoll.
      ENDIF.
    ENDLOOP.
  ENDIF.
ENDFORM.                               " items_convert_currency

*&---------------------------------------------------------------------*
*&      Form  det_pay_coll_blart
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM det_pay_coll_blart CHANGING h_blart.

  DATA: h_tfk033d  LIKE tfk033d.

  CLEAR h_tfk033d.
  CALL FUNCTION 'FKK_GET_APPLICATION'
    EXPORTING
      i_no_dialog      = const_marked
    IMPORTING
      e_applk          = h_tfk033d-applk
    EXCEPTIONS
      no_appl_selected = 1
      OTHERS           = 2.

  h_tfk033d-buber = const_buber_1054.

* ------ Anwendungsspezifische Daten lesen ----------------------------*
  CALL FUNCTION 'FKK_ACCOUNT_DETERMINE'
    EXPORTING
      i_tfk033d           = h_tfk033d
    IMPORTING
      e_tfk033d           = h_tfk033d
    EXCEPTIONS
      error_in_input_data = 1
      nothing_found       = 2
      OTHERS              = 3.
* ------ for cross reference purpose only -----------------------------*
  SET EXTENDED CHECK OFF.
  IF 1 = 2. CALL FUNCTION 'FKK_ACCOUNT_DETERMINE_1054'. ENDIF.
  SET EXTENDED CHECK ON.
* ------ end of cross reference ---------------------------------------*
  h_blart = h_tfk033d-fun04.

ENDFORM.                    " det_pay_coll_blart

*&---------------------------------------------------------------------*
*&      Form  get_rel_fr_dfkkcoll
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM get_rel_fr_dfkkcoll TABLES p_t_fkkrap  STRUCTURE dfkkrap
                                p_paid_tab  TYPE pay_tab_typ
                                p_t_fkkcoll STRUCTURE dfkkcoll
                                p_t_fkkcl   STRUCTURE fkkcl
                         USING  p_i_fkkko   STRUCTURE fkkko
                       CHANGING p_fkkko     STRUCTURE fkkko.

  DATA: t_logfkkop LIKE dfkkop OCCURS 0 WITH HEADER LINE.
  DATA: BEGIN OF t_docs1 OCCURS 0,
          opbel TYPE opbel_kk,
        END OF t_docs1.
  DATA: BEGIN OF t_docs2 OCCURS 0,
          opbel TYPE opbel_kk,
        END OF t_docs2.
  DATA: h_fkkcoll  LIKE dfkkcoll.

*------- read document header of clearing doc only once ----------------
  CALL FUNCTION 'FKK_DOC_HEADER_SELECT_BY_OPBEL'
    EXPORTING
      i_opbel = p_i_fkkko-stbel
    IMPORTING
      e_fkkko = p_fkkko
    EXCEPTIONS
      OTHERS  = 1.

*  IF ( p_i_fkkko-herkf EQ 'R9' OR     " IS-U invoice reversing
*       p_i_fkkko-herkf EQ '78' ) AND  " invoice reversing
*     NOT p_t_fkkcl[] IS INITIAL.
* Internal table T_DOCS1 will not be filled.
* When reversing an IS-U invoice it can happen that cleared invoice
* items have to be resetted first and then reversed. Always look at
* items in table T_FKKCL and set submission status 05.
*  ELSE.
*------- get all document numbers where collection agencies are involved
  LOOP AT p_t_fkkrap WHERE augbl = p_i_fkkko-stbel.

    SELECT * FROM dfkkcoll WHERE opbel = p_t_fkkrap-opbel. "Note 2049299

      IF sy-subrc = 0.
        t_docs1-opbel = p_t_fkkrap-opbel.
        COLLECT t_docs1.
      ENDIF.

    ENDSELECT.
  ENDLOOP.

  IF NOT t_docs1[] IS INITIAL.

    SELECT opbel FROM  dfkkcoll
                 INTO  t_docs2-opbel
                 FOR   ALL ENTRIES IN t_docs1
                 WHERE opbel = t_docs1-opbel.
      COLLECT t_docs2.
    ENDSELECT.
    IF NOT t_docs2[] IS INITIAL.         " Note 2076589
      SORT t_docs2.

*------- get items -----------------------------------------------------
      LOOP AT p_t_fkkrap WHERE augbl = p_i_fkkko-stbel.
        READ TABLE t_docs2 WITH KEY opbel = p_t_fkkrap-opbel BINARY SEARCH.
        CHECK sy-subrc = 0.

        CLEAR: t_logfkkop, t_logfkkop[].
        SELECT * FROM  dfkkop
                 INTO  TABLE t_logfkkop
                 WHERE opbel = p_t_fkkrap-opbel
                 AND   opupw = p_t_fkkrap-opupw      "Note 2042409
                 AND   opupk = p_t_fkkrap-opupk
                 AND   inkps > '000'
                 AND   augst > space.

        PERFORM check_paid_pos TABLES t_logfkkop
                                USING p_t_fkkrap.

        LOOP AT t_logfkkop.
          SELECT * FROM      dfkkcoll
                   APPENDING TABLE p_t_fkkcoll
                   WHERE     opbel = t_logfkkop-opbel
                   AND       inkps = t_logfkkop-inkps.

          IF sy-subrc EQ 0.
            READ TABLE p_t_fkkcoll WITH KEY opbel = t_logfkkop-opbel
                                            inkps = t_logfkkop-inkps.
            CHECK sy-subrc = 0.
*        CHECK p_t_fkkcoll-agsta NE '09'.

            IF p_t_fkkcoll-waers NE t_logfkkop-waers.
              PERFORM convert_currency USING p_t_fkkcoll-waers
                                             t_logfkkop-waers
                                    CHANGING t_logfkkop-betrw.
            ENDIF.

            IF p_fkkko-herkf EQ '16' OR p_fkkko-herkf EQ '17'.
              p_paid_tab-ninkb = t_logfkkop-betrw.
            ELSE.
              p_paid_tab-betrz = t_logfkkop-betrw.
            ENDIF.

            p_paid_tab-opbel = t_logfkkop-opbel.
            p_paid_tab-inkps = t_logfkkop-inkps.
            COLLECT p_paid_tab.
          ENDIF.
        ENDLOOP.
      ENDLOOP.

      SORT p_t_fkkcoll BY opbel inkps.
      DELETE ADJACENT DUPLICATES FROM p_t_fkkcoll.
    ENDIF.

  ENDIF.

  LOOP AT p_t_fkkcl WHERE xaktp  EQ const_marked AND
                          inkps  NE 000.

* select collection agency items
    CALL FUNCTION 'FKK_DB_DFKKCOLL_SINGLE'
      EXPORTING
        i_opbel       = p_t_fkkcl-opbel
        i_inkps       = p_t_fkkcl-inkps
      IMPORTING
        e_fkkcoll     = h_fkkcoll
      EXCEPTIONS
        not_found     = 1
        initial_value = 2
        OTHERS        = 3.
    IF sy-subrc EQ 0.

      MOVE-CORRESPONDING h_fkkcoll TO p_t_fkkcoll.

      READ TABLE p_t_fkkcoll WITH KEY opbel = h_fkkcoll-opbel
                                      inkps = h_fkkcoll-inkps.
      IF sy-subrc NE 0.
        APPEND p_t_fkkcoll.

        MOVE-CORRESPONDING h_fkkcoll TO rev_doc.
        APPEND rev_doc.

      ENDIF.
    ENDIF.
  ENDLOOP.

ENDFORM.                               " get_rel_fr_dfkkcoll

*&---------------------------------------------------------------------*
*&      Form  adapt_fkkcoll
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM adapt_fkkcoll TABLES   p_paid_tab   TYPE pay_tab_typ
                            p_it_fkkcoll STRUCTURE dfkkcoll
                            p_t_fkkcl    STRUCTURE fkkcl
                    USING   paym_blart
                            p_process
                            p_fkkko      STRUCTURE fkkko.

  DATA: t_fkkcoll_buffer LIKE dfkkcoll  OCCURS 0 WITH HEADER LINE,
        wa_dfkkcoll      LIKE dfkkcoll.

  IF p_process = co_pro_return.
    LOOP AT p_it_fkkcoll.
      READ TABLE it_fkkcoll INTO wa_dfkkcoll
                            WITH KEY opbel = p_it_fkkcoll-opbel
                                     inkps = p_it_fkkcoll-inkps.
      IF sy-subrc EQ 0.
        MODIFY p_it_fkkcoll FROM wa_dfkkcoll.
      ENDIF.
    ENDLOOP.
  ENDIF.

  LOOP AT p_paid_tab.

    LOOP AT p_it_fkkcoll WHERE opbel = p_paid_tab-opbel AND
                               inkps = p_paid_tab-inkps AND
                               betrz NE 0.

      IF NOT p_fkkko-herkf EQ '16' OR NOT p_fkkko-herkf EQ '17'.
        p_it_fkkcoll-betrz = p_it_fkkcoll-betrz - p_paid_tab-betrz.
        MODIFY p_it_fkkcoll TRANSPORTING betrz.
      ENDIF.
    ENDLOOP.

    LOOP AT p_it_fkkcoll WHERE opbel = p_paid_tab-opbel AND
                               inkps = p_paid_tab-inkps AND
                               ninkb NE 0.

      IF p_fkkko-herkf EQ '16' OR p_fkkko-herkf EQ '17'.
        p_it_fkkcoll-ninkb = p_it_fkkcoll-ninkb - p_paid_tab-ninkb.
        MODIFY p_it_fkkcoll TRANSPORTING ninkb.
      ENDIF.
    ENDLOOP.

  ENDLOOP.

  t_fkkcoll_buffer[] = p_it_fkkcoll[].

* determine the collection agency status
  CALL FUNCTION 'FKK_DFKKCOLL_STATUS_PAY_GET'
    EXPORTING
      i_herkf     = p_fkkko-herkf
      i_blart_pay = paym_blart
      i_process   = p_process
      i_opbel     = p_fkkko-opbel
    TABLES
      t_fkkcoll   = p_it_fkkcoll
      t_fkkcl     = p_t_fkkcl.

  PERFORM changedocument_write TABLES p_it_fkkcoll
                                      t_fkkcoll_buffer.

ENDFORM.                               " adapt_fkkcoll

*&---------------------------------------------------------------------*
*&      Form  dfkkcoll_update
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM dfkkcoll_update.

  IF mem_pfonc = space.
    PERFORM db_insert ON COMMIT.
    mem_pfonc = const_marked.
  ENDIF.

ENDFORM.                               " dfkkcoll_update

*&---------------------------------------------------------------------*
*&      Form  db_insert
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM db_insert.

  UPDATE dfkkcoll  FROM TABLE it_fkkcoll.
  INSERT dfkkcollh FROM TABLE it_fkkcollh ACCEPTING DUPLICATE KEYS.

  PERFORM db_itable_refresh.

ENDFORM.                               " db_insert

*&---------------------------------------------------------------------*
*&      Form  db_itable_refresh
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM db_itable_refresh.
  CLEAR: it_fkkcoll, it_fkkcollh, mem_pfonc.

ENDFORM.                               " db_itable_refresh

*&---------------------------------------------------------------------*
*&      Form  paid_by_avis
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM check_paid_pos TABLES  p_t_logfkkop STRUCTURE dfkkop
                     USING   p_t_fkkrap  STRUCTURE dfkkrap.

  LOOP AT p_t_logfkkop.
    IF p_t_logfkkop-inkps IS INITIAL OR
       p_t_logfkkop-augst IS INITIAL OR
       p_t_logfkkop-augbl NE p_t_fkkrap-augbl OR
       p_t_logfkkop-opupk NE p_t_fkkrap-opupk.
      DELETE p_t_logfkkop.
    ENDIF.
  ENDLOOP.
ENDFORM.                               " paid_by_avis

*&---------------------------------------------------------------------*
*&      Form  fetch_rel_fr_dfkkcoll
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM fetch_rel_fr_dfkkcoll TABLES  p_t_fkkrap  STRUCTURE dfkkrap
                                   p_paid_tab  TYPE pay_tab_typ
                                   p_t_fkkcoll STRUCTURE dfkkcoll
                                   p_t_fkkcl   STRUCTURE fkkcl
                            USING  p_fkkko     STRUCTURE fkkko
                          CHANGING f_fkkko     STRUCTURE fkkko.

  DATA: t_logfkkop LIKE dfkkop OCCURS 0 WITH HEADER LINE.
  DATA: BEGIN OF t_docs1 OCCURS 0,
          opbel TYPE opbel_kk,
        END OF t_docs1.
  DATA: BEGIN OF t_docs2 OCCURS 0,
          opbel TYPE opbel_kk,
        END OF t_docs2.
  DATA: h_fkkcoll  LIKE dfkkcoll.

*------- read document header of clearing doc only once ----------------
  READ TABLE p_t_fkkrap INDEX 1.
  CALL FUNCTION 'FKK_DOC_HEADER_SELECT_BY_OPBEL'
    EXPORTING
      i_opbel = p_t_fkkrap-augbl
    IMPORTING
      e_fkkko = f_fkkko
    EXCEPTIONS
      OTHERS  = 1.

*------- get all document numbers where collection agencies are involved
  LOOP AT p_t_fkkrap.
    t_docs1-opbel = p_t_fkkrap-opbel.
    COLLECT t_docs1.
  ENDLOOP.

  IF NOT t_docs1[] IS INITIAL.

    SELECT opbel FROM  dfkkcoll
                 INTO  t_docs2-opbel
                 FOR   ALL ENTRIES IN t_docs1
                 WHERE opbel = t_docs1-opbel.
      COLLECT t_docs2.
    ENDSELECT.
    IF NOT t_docs2[] IS INITIAL.       " Note 2076589
      SORT t_docs2.

*------- get items -----------------------------------------------------
      LOOP AT p_t_fkkrap.
        READ TABLE t_docs2 WITH KEY opbel = p_t_fkkrap-opbel BINARY SEARCH.
        CHECK sy-subrc = 0.

        CLEAR: t_logfkkop, t_logfkkop[].
        SELECT * FROM  dfkkop
                 INTO  TABLE t_logfkkop
                 WHERE opbel = p_t_fkkrap-opbel
                 AND   opupw = p_t_fkkrap-opupw      "Note 2042409
                 AND   opupk = p_t_fkkrap-opupk
                 AND   inkps > '000'
                 AND   augst > space.

        PERFORM check_paid_pos TABLES t_logfkkop
                                USING p_t_fkkrap.

        LOOP AT t_logfkkop.
          SELECT * FROM      dfkkcoll
                   APPENDING TABLE p_t_fkkcoll
                   WHERE     opbel = t_logfkkop-opbel
                   AND       inkps = t_logfkkop-inkps.

          IF sy-subrc EQ 0.
            READ TABLE p_t_fkkcoll WITH KEY opbel = t_logfkkop-opbel
                                            inkps = t_logfkkop-inkps.
            CHECK sy-subrc = 0.
*        CHECK p_t_fkkcoll-agsta NE '09'.

            IF p_t_fkkcoll-waers NE t_logfkkop-waers.
              PERFORM convert_currency USING p_t_fkkcoll-waers
                                             t_logfkkop-waers
                                    CHANGING t_logfkkop-betrw.
            ENDIF.

            IF f_fkkko-herkf EQ '16' OR f_fkkko-herkf EQ '17'.
              p_paid_tab-ninkb = t_logfkkop-betrw.
            ELSE.
              p_paid_tab-betrz = t_logfkkop-betrw.
            ENDIF.

            p_paid_tab-opbel = t_logfkkop-opbel.
            p_paid_tab-inkps = t_logfkkop-inkps.
            COLLECT p_paid_tab.
          ENDIF.
        ENDLOOP.
      ENDLOOP.

      SORT p_t_fkkcoll BY opbel inkps.
      DELETE ADJACENT DUPLICATES FROM p_t_fkkcoll.
    ENDIF.

  ENDIF.

* select reversed items for setting AGSTA 05
  LOOP AT p_t_fkkcl WHERE xaktp  EQ const_marked AND
                          augrd  NE space AND
                          inkps  NE 000.

* select collection agency items
    CALL FUNCTION 'FKK_DB_DFKKCOLL_SINGLE'
      EXPORTING
        i_opbel       = p_t_fkkcl-opbel
        i_inkps       = p_t_fkkcl-inkps
      IMPORTING
        e_fkkcoll     = h_fkkcoll
      EXCEPTIONS
        not_found     = 1
        initial_value = 2
        OTHERS        = 3.
    IF sy-subrc EQ 0.

      MOVE-CORRESPONDING h_fkkcoll TO p_t_fkkcoll.

      READ TABLE p_t_fkkcoll WITH KEY opbel = h_fkkcoll-opbel
                                      inkps = h_fkkcoll-inkps.
      IF sy-subrc NE 0.
        APPEND p_t_fkkcoll.

        MOVE-CORRESPONDING h_fkkcoll TO rev_doc.
        APPEND rev_doc.

      ENDIF.
    ENDIF.
  ENDLOOP.

ENDFORM.                    " fetch_rel_fr_dfkkcoll

*&---------------------------------------------------------------------*
*&      Form  build_dfkkcoll
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM build_dfkkcoll TABLES   p_t_fkkcl   STRUCTURE fkkcl
                             p_t_fkkcoll STRUCTURE dfkkcoll
                     USING   p_i_process
                             pay_blart
                             p_herkf.

  DATA: h_fkkcoll     LIKE dfkkcoll,
        h_fkkcoll_tmp LIKE dfkkcoll.

  LOOP AT p_t_fkkcl WHERE xaktp  EQ const_marked AND
                          inkps  NE 000.

* select collection agency items
    CALL FUNCTION 'FKK_DB_DFKKCOLL_SINGLE'
      EXPORTING
        i_opbel       = p_t_fkkcl-opbel
        i_inkps       = p_t_fkkcl-inkps
      IMPORTING
        e_fkkcoll     = h_fkkcoll
      EXCEPTIONS
        not_found     = 1
        initial_value = 2
        OTHERS        = 3.
    IF sy-subrc EQ 0.
*      CHECK h_fkkcoll-agsta NE '09'.         "item was recalled

      "note 2311773
      IF p_i_process = ' '.
        LOOP AT it_fkkcoll INTO h_fkkcoll_tmp
          WHERE opbel = p_t_fkkcl-opbel AND inkps = p_t_fkkcl-inkps.
        ENDLOOP.
        IF sy-subrc = 0.
          h_fkkcoll = h_fkkcoll_tmp.
        ENDIF.
      ENDIF.

      MOVE-CORRESPONDING h_fkkcoll TO p_t_fkkcoll.

      IF p_t_fkkcoll-waers NE p_t_fkkcl-waers.
        PERFORM convert_currency USING  p_t_fkkcoll-waers
                                        p_t_fkkcl-waers
                              CHANGING  p_t_fkkcl-augbw.
      ENDIF.

      IF p_herkf EQ '16' OR p_herkf EQ '17'.   "write off
        p_t_fkkcoll-ninkb = p_t_fkkcoll-ninkb + p_t_fkkcl-augbw.
      ELSE.
        p_t_fkkcoll-betrz = p_t_fkkcoll-betrz + p_t_fkkcl-augbw.
      ENDIF.

      READ TABLE p_t_fkkcoll WITH KEY opbel = h_fkkcoll-opbel
                                      inkps = h_fkkcoll-inkps.
      IF sy-subrc NE 0.
        APPEND p_t_fkkcoll.
      ELSE.
        IF p_herkf EQ '16' OR p_herkf EQ '17'.  "write off
          p_t_fkkcoll-ninkb = p_t_fkkcoll-ninkb + p_t_fkkcl-augbw.
          MODIFY TABLE p_t_fkkcoll TRANSPORTING ninkb.
        ELSE.
          p_t_fkkcoll-betrz = p_t_fkkcoll-betrz + p_t_fkkcl-augbw.
          MODIFY TABLE p_t_fkkcoll TRANSPORTING betrz.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDLOOP.

ENDFORM.                    " build_dfkkcoll

*&---------------------------------------------------------------------*
*&      Form  adapt_dfkkcoll_status
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM adapt_dfkkcoll_status TABLES   p_t_dfkkcoll STRUCTURE dfkkcoll
                                    p_t_fkkcl    STRUCTURE fkkcl
                                    p_t_fkkop    STRUCTURE fkkop
                           USING    p_herkf
                                    paym_blart
                                    p_process.

  DATA: t_fkkcoll_buffer LIKE dfkkcoll  OCCURS 0 WITH HEADER LINE.

  t_fkkcoll_buffer[] = p_t_dfkkcoll[].

* determine the collection agency status
  CALL FUNCTION 'FKK_DFKKCOLL_STATUS_PAY_GET'
    EXPORTING
      i_herkf     = p_herkf
      i_blart_pay = paym_blart
      i_process   = p_process
    TABLES
      t_fkkcoll   = p_t_dfkkcoll
      t_fkkcl     = p_t_fkkcl
      t_fkkop     = p_t_fkkop.

  PERFORM changedocument_write TABLES p_t_dfkkcoll
                                      t_fkkcoll_buffer.

ENDFORM.                    " adapt_dfkkcoll_status

*&---------------------------------------------------------------------*
*&      Form  build_dfkkcollh
*&---------------------------------------------------------------------*
*       build collection agency history table
*----------------------------------------------------------------------*
FORM build_dfkkcollh TABLES   p_t_coll          STRUCTURE dfkkcoll
                              p_t_history_coll  STRUCTURE dfkkcollh
                      USING   p_fkkko_opbel
                              p_process
                              p_budat
                              p_valut.

  DATA: h_lfdnr     LIKE dfkkcollh-lfdnr,
        ht_fkkcollh LIKE dfkkcollh OCCURS 0 WITH HEADER LINE,
        wa_fkkcollh LIKE dfkkcollh.

  CLEAR: p_t_history_coll, p_t_history_coll[].

  LOOP AT p_t_coll.
    MOVE-CORRESPONDING p_t_coll TO p_t_history_coll.

    IF p_process EQ '1' OR p_process EQ '2' OR p_process EQ '3'.
      p_t_history_coll-storb = p_fkkko_opbel.  "reverse doc. number
    ELSE.
      p_t_history_coll-augbl = p_fkkko_opbel.  "clearing doc. number
    ENDIF.

* Move the value date of payment in the history table DFKKCOLLH. If the
* value date is not filled, than move the posting date/clearing date
    IF p_process EQ ' '.                         "Payments
      IF NOT p_valut EQ '00000000'.
        p_t_history_coll-rudat = p_valut.        "-> move value date
      ELSE.
        p_t_history_coll-rudat = p_budat.        "-> move clearing date
      ENDIF.
    ELSEIF p_process EQ '1' OR p_process EQ '2' OR p_process EQ '3'.
      " Reversing/Resetting/Return
      p_t_history_coll-rudat = p_budat.     " -> move posting date
    ENDIF.

    p_t_history_coll-aenam = sy-uname.
    p_t_history_coll-acpdt = sy-datlo.
    p_t_history_coll-acptm = sy-timlo.

    CALL FUNCTION 'FKK_DB_DFKKCOLLH_COUNT'
      EXPORTING
        i_opbel = p_t_history_coll-opbel
        i_inkps = p_t_history_coll-inkps
      IMPORTING
        e_count = h_lfdnr.

    IF p_process = co_pro_return OR p_process = ' '.   "note 2311773
      LOOP AT it_fkkcollh INTO wa_fkkcollh
                    WHERE opbel = p_t_history_coll-opbel
                      AND inkps = p_t_history_coll-inkps.
      ENDLOOP.
      IF sy-subrc = 0.
        h_lfdnr = wa_fkkcollh-lfdnr.
      ENDIF.
    ENDIF.

    IF p_t_history_coll-agsta GE '20'.
      CALL FUNCTION 'FKK_DB_DFKKCOLLH_SELECT'
        EXPORTING
          i_seltyp   = '2'
          i_opbel    = p_t_coll-opbel
          i_inkps    = p_t_coll-inkps
        TABLES
          t_fkkcollh = ht_fkkcollh
        EXCEPTIONS
          not_found  = 1
          OTHERS     = 2.

      READ TABLE ht_fkkcollh INDEX h_lfdnr.
      IF sy-subrc = 0.
        p_t_history_coll-agsta_or = ht_fkkcollh-agsta_or.
      ELSE.
        p_t_history_coll-agsta_or = p_t_history_coll-agsta.
      ENDIF.
    ELSE.
      p_t_history_coll-agsta_or = p_t_history_coll-agsta.
    ENDIF.

    ADD 1 TO h_lfdnr.

    p_t_history_coll-lfdnr = h_lfdnr.

    APPEND p_t_history_coll.
  ENDLOOP.
ENDFORM.                    " build_dfkkcollh

*&---------------------------------------------------------------------*
*&      Form  convert_currency
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM convert_currency USING    waers rwaer
                      CHANGING amount.

  CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
    EXPORTING
      date             = sy-datum
      foreign_amount   = amount
      foreign_currency = rwaer
      local_currency   = waers
    IMPORTING
      local_amount     = amount
    EXCEPTIONS
      OTHERS           = 1.
ENDFORM.                    " convert_currency

*&---------------------------------------------------------------------*
*&      Form  read_events
*&---------------------------------------------------------------------*
FORM read_events.

  DATA: p_applk LIKE fkkop-applk.

* ------ determinig application ---------------------------------------*
  CALL FUNCTION 'FKK_GET_APPLICATION'
    IMPORTING
      e_applk       = p_applk
    EXCEPTIONS
      error_message = 1.

* Determine function modules for events 5059, 5060 --------------------*
  REFRESH t_tfkfbc_5059.
  CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
    EXPORTING
      i_fbeve  = const_event_5059
      i_applk  = p_applk
    TABLES
      t_fbstab = t_tfkfbc_5059
    EXCEPTIONS
      OTHERS   = 1.

  REFRESH t_tfkfbc_5060.
  CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
    EXPORTING
      i_fbeve  = const_event_5060
      i_applk  = p_applk
    TABLES
      t_fbstab = t_tfkfbc_5060
    EXCEPTIONS
      OTHERS   = 1.

ENDFORM.                    " read_events

*&---------------------------------------------------------------------*
*&      Form  create_hist_del_rel
*&---------------------------------------------------------------------*
*       create history for deletion of release
*----------------------------------------------------------------------*
FORM create_hist_del_rel TABLES   p_t_coll STRUCTURE dfkkcoll.

  DATA: h_lfdnr         LIKE dfkkcollh-lfdnr,
        ht_fkkcollh     LIKE dfkkcollh OCCURS 0 WITH HEADER LINE,
        pt_history_coll LIKE dfkkcollh OCCURS 0 WITH HEADER LINE.

  LOOP AT p_t_coll.
    MOVE-CORRESPONDING p_t_coll TO pt_history_coll.

    pt_history_coll-aenam = sy-uname.
    pt_history_coll-acpdt = sy-datlo.
    pt_history_coll-acptm = sy-timlo.
    CLEAR pt_history_coll-agsta.

    CALL FUNCTION 'FKK_DB_DFKKCOLLH_COUNT'
      EXPORTING
        i_opbel = pt_history_coll-opbel
        i_inkps = pt_history_coll-inkps
      IMPORTING
        e_count = h_lfdnr.

    IF pt_history_coll-agsta GE '20'.
      CALL FUNCTION 'FKK_DB_DFKKCOLLH_SELECT'
        EXPORTING
          i_seltyp   = '2'
          i_opbel    = p_t_coll-opbel
          i_inkps    = p_t_coll-inkps
        TABLES
          t_fkkcollh = ht_fkkcollh
        EXCEPTIONS
          not_found  = 1
          OTHERS     = 2.

      READ TABLE ht_fkkcollh INDEX h_lfdnr.
      IF sy-subrc = 0.
        pt_history_coll-agsta_or = ht_fkkcollh-agsta_or.
      ELSE.
        pt_history_coll-agsta_or = pt_history_coll-agsta.
      ENDIF.
    ELSE.
      pt_history_coll-agsta_or = pt_history_coll-agsta.
    ENDIF.

    ADD 1 TO h_lfdnr.

    pt_history_coll-lfdnr = h_lfdnr.

    APPEND pt_history_coll.
  ENDLOOP.

  CALL FUNCTION 'FKK_DB_DFKKCOLLH_INSERT'
    TABLES
      i_dfkkcollh = pt_history_coll.

ENDFORM.                    " create_hist_del_rel

*&---------------------------------------------------------------------*
*&      Form  changedocument_write
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM changedocument_write TABLES p_fkkcoll_new STRUCTURE dfkkcoll
                                 p_fkkcoll_old STRUCTURE dfkkcoll.

  DATA: h_cdtxt LIKE cdtxt OCCURS 0,
        h_field LIKE cdhdr-objectid.

  LOOP AT p_fkkcoll_old.
    READ TABLE p_fkkcoll_new WITH KEY opbel = p_fkkcoll_old-opbel
                                      inkps = p_fkkcoll_old-inkps.
    IF p_fkkcoll_old NE p_fkkcoll_new.
      MOVE-CORRESPONDING p_fkkcoll_old TO ydfkkcoll.
      APPEND ydfkkcoll.
      MOVE-CORRESPONDING p_fkkcoll_new TO xdfkkcoll.
      xdfkkcoll-kz = 'U'.
      APPEND xdfkkcoll.
      CONCATENATE p_fkkcoll_old-opbel p_fkkcoll_old-inkps INTO h_field.
      CALL FUNCTION 'INKASSO_01_WRITE_DOCUMENT'
        EXPORTING
          objectid                = h_field
          tcode                   = sy-tcode
          utime                   = sy-uzeit
          udate                   = sy-datlo
          username                = sy-uname
          planned_or_real_changes = 'R'
          upd_dfkkcoll            = 'U'
        TABLES
          icdtxt_inkasso_01       = h_cdtxt
          xdfkkcoll               = xdfkkcoll
          ydfkkcoll               = ydfkkcoll
        EXCEPTIONS
          OTHERS                  = 1.
      REFRESH: xdfkkcoll, ydfkkcoll.
    ENDIF.
  ENDLOOP.
ENDFORM.                               " changedocument_write
*&---------------------------------------------------------------------*
*&      Form  APPEND_FEE_LINES
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->PT_FKKOP  text
*      -->P_C_FKKMAKO_MG1BL  text
*----------------------------------------------------------------------*
FORM append_fee_lines TABLES   pt_fkkop   STRUCTURE fkkop
                      USING    p_opbel.

  DATA: ht_fkkop LIKE fkkop OCCURS 0 WITH HEADER LINE.

  IF NOT p_opbel IS INITIAL.
    CLEAR pt_fkkop.

* fees and interest are not yet in the database when the dunning
* activity is called, therefore read the document buffer to get
* the document lines
    CALL FUNCTION 'FKK_READ_DOCUMENT_FROM_BUFFER'
      EXPORTING
        i_opbel   = p_opbel
      TABLES
        t_fkkop   = ht_fkkop
      EXCEPTIONS
        not_found = 1
        OTHERS    = 2.

    IF sy-subrc = 0.
      DELETE ht_fkkop WHERE augst = '9'.
      APPEND LINES OF ht_fkkop TO pt_fkkop.
    ENDIF.
  ENDIF.
ENDFORM.                               " APPEND_FEE_LINES

*&---------------------------------------------------------------------*
*&      Form  pay_on_account_codes
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM pay_on_account_codes   USING par_fkkop LIKE fkkop
                                  par_sign  TYPE c
                         CHANGING par_hvorg LIKE fkkop-hvorg
                                  par_tvorg LIKE fkkop-tvorg.

  DATA: loc_betrw TYPE betrw_kk.
  DATA: i_fbstab  LIKE tfkfbc  OCCURS 0 WITH HEADER LINE.

  IF par_sign = '+'.
    loc_betrw = 100.
  ELSE.
    loc_betrw = -100.
  ENDIF.

  CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
    EXPORTING
      i_applk  = par_fkkop-applk
      i_fbeve  = '0113'
    TABLES
      t_fbstab = i_fbstab.

  READ TABLE i_fbstab INDEX 1.
  IF sy-subrc = 0.
    CALL FUNCTION i_fbstab-funcc
      EXPORTING
        i_applk = par_fkkop-applk
        i_gpart = par_fkkop-gpart
        i_vkont = par_fkkop-vkont
        i_vtref = par_fkkop-vtref
        i_subap = par_fkkop-subap
        i_bukrs = par_fkkop-bukrs
        i_betrw = loc_betrw
        i_waers = par_fkkop-waers
      IMPORTING
        e_hvorg = par_hvorg
        e_tvorg = par_tvorg.

    SET EXTENDED CHECK OFF.
    IF 1 = 2.
      CALL FUNCTION 'FKK_SAMPLE_0113'.
    ENDIF.
    SET EXTENDED CHECK ON.
  ENDIF.
ENDFORM.                    "pay_on_account_codes
*&---------------------------------------------------------------------*
*&      Form  DB_DFKKOP_UPDATE
*&---------------------------------------------------------------------*
FORM db_dfkkop_update.
  LOOP AT ut_dfkkop.
    UPDATE dfkkop SET   inkps = ut_dfkkop-inkps
                  WHERE opbel = ut_dfkkop-opbel
                  AND   opupw = ut_dfkkop-opupw
                  AND   opupk = ut_dfkkop-opupk
                  AND   opupz = ut_dfkkop-opupz.
  ENDLOOP.

  REFRESH ut_dfkkop.
ENDFORM.                    " DB_DFKKOP_UPDATE
*&---------------------------------------------------------------------*
*&      Form  DELETE_EMGPA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM delete_emgpa  TABLES   p_t_fkkcoll STRUCTURE dfkkcoll.

  DATA h_emgpa LIKE fkkop-emgpa.

* data for BW trigger update
  DATA: loc_xbw     TYPE xfeld,
        loct_bw_upd LIKE dfkkkobw OCCURS 0 WITH HEADER LINE.

  CLEAR h_emgpa.

  SELECT SINGLE emgpa FROM dfkkop INTO h_emgpa
          WHERE opbel = p_t_fkkcoll-opbel AND
                inkps = p_t_fkkcoll-inkps.

  IF NOT h_emgpa IS INITIAL.

    CALL FUNCTION 'FKK_DB_TFK050B_SINGLE'
      EXPORTING
        i_inkgp           = h_emgpa
      EXCEPTIONS
        not_found         = 1
        initial_parameter = 2
        OTHERS            = 3.

    IF sy-subrc EQ 0.
      UPDATE dfkkop SET emgpa = space
                 WHERE opbel = p_t_fkkcoll-opbel AND
                       inkps = p_t_fkkcoll-inkps.

*---- BW trigger needed ?
      CALL FUNCTION 'FKK_BW_TRIGGER_ACTIVE_CHECK'
        IMPORTING
          ev_active = loc_xbw.

*---- collect trigger for BW
      IF loc_xbw = 'X'.
        loct_bw_upd-opbel = p_t_fkkcoll-opbel.
        COLLECT loct_bw_upd.

*------- forward trigger tables for BW
        CALL FUNCTION 'FKK_DFKKKOBW_UPDATE'
          CHANGING
            ct_dfkkkobw_update = loct_bw_upd[]
          EXCEPTIONS
            OTHERS             = 0.

      ENDIF.
    ENDIF.
  ENDIF.

ENDFORM.                    " DELETE_EMGPA
