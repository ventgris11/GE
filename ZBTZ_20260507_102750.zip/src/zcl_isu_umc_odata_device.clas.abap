class ZCL_ISU_UMC_ODATA_DEVICE definition
  public
  inheriting from CL_ISU_UMC_ODATA_DEVICE
  final
  create public .

public section.

  methods IF_ISU_UMC_ODATA_IMPL~GET_ENTITY
    redefinition .
  methods IF_ISU_UMC_ODATA_IMPL~GET_ENTITYSET
    redefinition .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ISU_UMC_ODATA_DEVICE IMPLEMENTATION.


METHOD if_isu_umc_odata_impl~get_entity.

  DATA ls_device             TYPE isus_umc_device.
  DATA lv_device_id          TYPE equnr.
  DATA lv_string             TYPE string.                   "#EC NEEDED
  DATA lt_keys               TYPE /iwbep/t_mgw_tech_pairs.
  DATA ls_key                TYPE /iwbep/s_mgw_tech_pair.

**************************************************************************
* Support of long navigation                                             *
**************************************************************************
  IF io_tech_request_context->get_navigation_path( ) IS INITIAL.
**************************************************************************
* Read Keys                                                              *
**************************************************************************
    lt_keys = io_tech_request_context->get_keys( ).
    READ TABLE lt_keys INTO ls_key WITH KEY name = gc_device_id.
    lv_device_id = ls_key-value.

    IF lv_device_id IS NOT INITIAL.
**************************************************************************
* check authorization                                                    *
**************************************************************************
      check_authorization_for_equnr( iv_equnr       = lv_device_id
                                     iv_entity_type = iv_entity_name ).

**************************************************************************
* get device from the meterreading API class                             *
**************************************************************************
    ls_device = cl_isu_umc_api_meterreading=>get_device( lv_device_id ).

** Ajout AliA Consulting 20170725 : Récupération du matricule du compteur
      SELECT SINGLE egerr_info
          FROM egerr
          INTO ls_device-zzmatricule
          WHERE equnr = lv_device_id  .

** Fin Ajout AliA Consulting 20170725

**************************************************************************
* Copy data to gateway                                                   *
**************************************************************************
      er_entity = copy_data_to_ref( ls_device ).
    ENDIF.

  ELSE.
**************************************************************************
* Support of long navigation                                             *
**************************************************************************
    TRY.
        super->if_isu_umc_odata_impl~get_entity(
          EXPORTING     iv_entity_name          = iv_entity_name
                        iv_entity_set_name      = iv_entity_set_name
                        iv_source_name          = iv_source_name
                        it_key_tab              = it_key_tab
                        it_navigation_path      = it_navigation_path
                       io_tech_request_context = io_tech_request_context
         IMPORTING     er_entity               = er_entity ).

      CATCH /iwbep/cx_mgw_tech_exception.
MESSAGE e001(isu_umc_odata) WITH iv_entity_name gc_deviceid INTO lv_string.
        handle_technical_error( 'GET_ENTITY' ).
    ENDTRY.
  ENDIF.

ENDMETHOD.


METHOD if_isu_umc_odata_impl~get_entityset.

  DATA lt_devices           TYPE isut_umc_device.
  DATA lv_account_id        TYPE gpart_kk.
  DATA lv_contract_id       TYPE vertrag.
  DATA lv_string            TYPE string.                    "#EC NEEDED
  DATA lt_navigation_path   TYPE /iwbep/t_mgw_tech_navi.
  DATA lt_keys              TYPE /iwbep/t_mgw_tech_pairs.
  DATA ls_key               TYPE /iwbep/s_mgw_tech_pair.

  lt_navigation_path = io_tech_request_context->get_navigation_path( ).
**************************************************************************
* Support of long navigation                                             *
**************************************************************************
  IF lines( lt_navigation_path ) <= 1.
**************************************************************************
* Read Keys                                                              *
**************************************************************************
    lt_keys = io_tech_request_context->get_source_keys( ).
READ TABLE lt_keys INTO ls_key WITH KEY name = cl_isu_umc_odata_contract=>gc_key_attribute.
    lv_contract_id = ls_key-value.

    IF lv_contract_id IS INITIAL.
MESSAGE e008(isu_umc_odata) WITH iv_entity_name cl_isu_umc_odata_contract=>gc_contract_id INTO lv_string.
      handle_technical_error( 'GET_ENTITYSET' ).
    ENDIF.

**************************************************************************
* Check passed filters                                                   *
**************************************************************************
    check_empty_filter( io_tech_request_context ).

**************************************************************************
* check authorization                                                    *
**************************************************************************
lv_account_id = cl_isu_umc_api_meterreading=>get_account_by_contract( lv_contract_id ).

    check_user_authorisation(
          EXPORTING
            iv_account_id  = lv_account_id
            iv_entity_type = iv_entity_name ).

**************************************************************************
* get devices from the meterreading API class                            *
**************************************************************************
lt_devices = cl_isu_umc_api_meterreading=>get_devices( lv_contract_id ).


** Ajout AliA Consulting 20170725 : Récupération du matricule du compteur
    LOOP AT lt_devices ASSIGNING FIELD-SYMBOL(<lr_devices>).
      SELECT SINGLE egerr_info
          FROM egerr
          INTO <lr_devices>-zzmatricule
          WHERE equnr = <lr_devices>-equnr  .
    ENDLOOP.
** Fin Ajout AliA Consulting 20170725


**************************************************************************
* Copy data to gateway                                                   *
**************************************************************************
    er_entityset = copy_data_to_ref( lt_devices ).

  ELSE.
**************************************************************************
* Support of long navigation                                             *
**************************************************************************
    TRY.
        super->if_isu_umc_odata_impl~get_entityset(
          EXPORTING     iv_entity_name           =  iv_entity_name
                        iv_entity_set_name       =  iv_entity_set_name
                        iv_source_name           =  iv_source_name
                    it_filter_select_options =  it_filter_select_options
                    it_order                 =  it_order
                    is_paging                =  is_paging
                    it_navigation_path       =  it_navigation_path
                    it_key_tab               =  it_key_tab
                    iv_filter_string         =  iv_filter_string
                    iv_search_string         =  iv_search_string
                    io_tech_request_context  =  io_tech_request_context
      IMPORTING     er_entityset             =  er_entityset
                    es_response_context      =  es_response_context ).

      CATCH /iwbep/cx_mgw_tech_exception.
MESSAGE e008(isu_umc_odata) WITH iv_entity_name cl_isu_umc_odata_contract=>gc_contract_id INTO lv_string.
        handle_technical_error( 'GET_ENTITYSET' ).
    ENDTRY.
  ENDIF.

ENDMETHOD.
ENDCLASS.
