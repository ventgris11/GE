FUNCTION zintf_g_ctrl_demngt .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA:
    lv_field     TYPE string,
    lv_subobj    TYPE balsubobj,
    lv_message   TYPE char255,
    lv_int_ui    TYPE int_ui,
    ls_object    TYPE eedm_isu_objects,
    lv_equnr     TYPE equnr,
    lv_sernr     TYPE gernr,
    lv_auszbeleg TYPE auszbeleg,
    lv_date      TYPE datum,
    lt_mr_data   TYPE TABLE OF bapieabl,
    ls_mr_data   TYPE bapieabl,
    lt_mr_reason TYPE TABLE OF bapieablg,
    ls_mr_reason TYPE bapieablg,
    lv_success   TYPE crmt_boolean,
    ls_bpem      TYPE zbpem_flux_struct,
    lv_interface TYPE zisu_flxid.

  FIELD-SYMBOLS:
    <fs_emetteur>,
    <fs_flux>,
    <fs_idenreg>,
    <fs_num_pce>,
    <fs_date_releve>,
    <fs_motif_releve>,
    <fs_motif_statut>.

  DEFINE macro_add_message_to_log.
    zcl_tool=>log_add_msg(
      EXPORTING iv_log_object    = zcl_tool=>gc_log_object_intf_gaz
                iv_log_subobject = lv_subobj
                iv_test_mode     = iv_mode_test
      CHANGING  cv_log_handle    = cv_log_handle ).
  END-OF-DEFINITION.

  CLEAR: lv_field.
  MOVE 'FLUX-EMETTEUR'     TO lv_field.
  ASSIGN (lv_field)        TO <fs_emetteur>.

  CLEAR: lv_field.
  MOVE 'FLUX-FLUX'         TO lv_field.
  ASSIGN (lv_field)        TO <fs_flux>.
  MOVE <fs_flux>           TO lv_subobj.

  CLEAR: lv_field.
  MOVE 'FLUX-IDENREG'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_idenreg>.

  CLEAR: lv_field.
  MOVE 'FLUX-NUM_PCE'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_num_pce>.

  CLEAR: lv_field.
  MOVE 'FLUX-DATE_RELEVE'  TO lv_field.
  ASSIGN (lv_field)        TO <fs_date_releve>.

  CLEAR: lv_field.
  MOVE 'FLUX-MOTIF_RELEVE' TO lv_field.
  ASSIGN (lv_field)        TO <fs_motif_releve>.

  CLEAR: lv_field.
  MOVE 'FLUX-STATUT'       TO lv_field.
  ASSIGN (lv_field)        TO <fs_motif_statut>.

  ev_etape = 2.

  CLEAR ls_bpem.
  ls_bpem-num_pce = <fs_num_pce>.
  CASE <fs_flux>.
    WHEN 'ADIF'.
      ls_bpem-date_effet_cont = <fs_date_releve>.
    WHEN 'RE6M' OR 'RE1M' OR 'REMM' OR 'REJJ' OR 'REJM'.
      ls_bpem-date_releve     = <fs_date_releve>.
    WHEN 'AFAC'.
      ls_bpem-date_fin_prest  = <fs_date_releve>.
  ENDCASE.

* Récupération du PCE (Point de Comptage)
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).

  IF lv_int_ui IS INITIAL.
* &1 - &2 - &3 : PCE &4 inexistant
    MESSAGE e084(zintf_g_messages)
       WITH <fs_emetteur>
            <fs_flux>
            <fs_idenreg>
            <fs_num_pce>
       INTO lv_message.

    lv_interface    = <fs_flux> .
    ls_bpem-idenreg = <fs_idenreg>.
    CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
      EXPORTING
        iv_interface_name = lv_interface
        iv_sparte         = 'ZG'
        is_structure      = ls_bpem.

    RETURN.
  ENDIF.

* Récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object
      ev_equnr  = lv_equnr
      ev_sernr  = lv_sernr.

  IF ls_object-installation IS INITIAL.
* (ID &1) PCE &2 non rattaché à une installation active à la date du &3
    MESSAGE e044(zintf_g_messages)
       WITH <fs_idenreg>
            <fs_num_pce>
            <fs_date_releve>
       INTO lv_message.
    RETURN.
  ENDIF.

* Vérification de l'existence d'un contrat
  IF ls_object-contract IS INITIAL.
* (ID &1) PCE &2 non rattaché à un contrat actif à la date du &3
    MESSAGE e045(zintf_g_messages)
       WITH <fs_idenreg>
            <fs_num_pce>
            <fs_date_releve>
       INTO lv_message.
    RETURN.
  ENDIF.

* Vérification de l'existence de la pose de la fiche info appareil
  IF lv_sernr IS INITIAL.
* (ID &1) Pas de FIAP posée sur le contrat &2 du PCE &3 à la date du &4
    MESSAGE e046(zintf_g_messages)
       WITH <fs_idenreg>
            ls_object-contract
            <fs_num_pce>
            <fs_date_releve>
       INTO lv_message.
    RETURN.
  ENDIF.

* Vérification si présence d'un historique de relève sur l'installation
  REFRESH: lt_mr_data,
           lt_mr_reason.
  CALL FUNCTION 'BAPI_MTRREADDOC_GETLIST'
    EXPORTING
      installation      = ls_object-installation
      mrreason          = '03' "Relevé de résiliation emméngt/déméngt
      mrdocumenttype    = '1'  "Ordres de relève
    TABLES
      mrdocumentdata    = lt_mr_data
      mrdocumentreasons = lt_mr_reason.

* Vérification de l'existence ou non d'un document de relève
* avec motif 03 <calcul de facturation pour résiliation suite à déménagement>
* à la date de relève en question
  CLEAR: ls_mr_data.
  READ TABLE lt_mr_data
        INTO ls_mr_data WITH KEY targetmrdate = <fs_date_releve>.

  IF ls_mr_data IS NOT INITIAL.
    ev_etape = 1.
    RETURN.

* DEB - GLIC - GE-3823 - on va également rechercher les relèves de résiliation si aucun OR trouvé
  ELSE.
    REFRESH: lt_mr_data,
             lt_mr_reason.
    CALL FUNCTION 'BAPI_MTRREADDOC_GETLIST'
      EXPORTING
        installation      = ls_object-installation
        mrreason          = '03' "Relevé de résiliation emméngt/déméngt
        mrdocumenttype    = '2'  "Relève
      TABLES
        mrdocumentdata    = lt_mr_data
        mrdocumentreasons = lt_mr_reason.

    CLEAR: ls_mr_data.
    READ TABLE lt_mr_data
          INTO ls_mr_data WITH KEY targetmrdate = <fs_date_releve>.

    IF ls_mr_data IS NOT INITIAL.
      ev_etape = 1.
      RETURN.
    ENDIF.
* FIN - GLIC - GE-3823
  ENDIF.

* Vérification de l'existence d'un document de déménagement
* au cas où le document aurait été créé sans ordre de relève de déménagement
  SELECT SINGLE auszbeleg
           INTO lv_auszbeleg
           FROM eausv
          WHERE vertrag  EQ ls_object-contract
            AND auszdat  EQ <fs_date_releve>
            AND storausz EQ space.

  IF lv_auszbeleg IS NOT INITIAL.
*(ID &1) Le document &2 de déménagement existe SANS ORDRE à la date du &3
* DEB - GLIC - GE-3823 - On passe le message en erreur et on rejette le flux
*    MESSAGE i047(zintf_g_messages)
    MESSAGE e047(zintf_g_messages)
* FIN - GLIC - GE-3823
       WITH <fs_idenreg>
            lv_auszbeleg
            <fs_date_releve>
       INTO lv_message.
    RETURN.
  ENDIF.

*(ID &1) Aucun document de déménagement à la date du &2 pour le PCE &3
  MESSAGE i048(zintf_g_messages)
     WITH <fs_idenreg>
          <fs_date_releve>
          <fs_num_pce>
     INTO lv_message.
  macro_add_message_to_log.

* DEB - GLIC - GE-3823 - Suppression de la création du doc de déménagement car seul l'ADIF est censé le faire
* Vérification de l'absence de relève(s) postérieure(s) à la date de MHS
*  lv_date = <fs_date_releve> - 1. " On prend la veille
*  REFRESH: lt_mr_data,
*           lt_mr_reason.
*  CALL METHOD zcl_tool=>install_liste_releve
*    EXPORTING
*      iv_install        = ls_object-installation
*      iv_date           = lv_date
*    IMPORTING
*      et_releves        = lt_mr_data
*      et_releves_raison = lt_mr_reason.
*
*  READ TABLE lt_mr_data INDEX 1 TRANSPORTING NO FIELDS.
*  IF sy-subrc EQ 0.
** Relève trouvée !!!
** (ID &1) MHS rejetée pour le PCE &2: présence d'une relève en date du &3
*    MESSAGE e049(zintf_g_messages)
*       WITH <fs_idenreg>
*            <fs_num_pce>
*            lv_date
*       INTO lv_message.
*    RETURN.
*  ENDIF.

* Création du document de déménagement
*  CALL METHOD zcl_tool=>moveout_doc_creation
*    EXPORTING
*      iv_contrat    = ls_object-contract
*      iv_date_effet = <fs_date_releve>
*      iv_test_mode  = iv_mode_test
*    IMPORTING
*      ev_auszbeleg  = lv_auszbeleg
*    RECEIVING
*      rv_success    = lv_success.
*
*
*  IF lv_success IS INITIAL.
*    MESSAGE ID sy-msgid
*          TYPE sy-msgty
*        NUMBER sy-msgno
*          WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
*          INTO lv_message.
*    macro_add_message_to_log.
*  ELSE.
*    ev_etape = 1.
** (ID &1) Document de déménagement &2 en date du &3 créé pour le PCE &4
*    MESSAGE i092(zintf_g_messages)
*       WITH <fs_idenreg>
*            lv_auszbeleg
*            <fs_date_releve>
*            <fs_num_pce>
*       INTO lv_message.
*  ENDIF.

* FIN - GLIC - GE-3823

ENDFUNCTION.
