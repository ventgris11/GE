* regenerated at 28.09.2020 18:53:35
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZINTF_E_R15TOP.                   " Global Data
  INCLUDE LZINTF_E_R15UXX.                   " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZINTF_E_R15F...                   " Subroutines
* INCLUDE LZINTF_E_R15O...                   " PBO-Modules
* INCLUDE LZINTF_E_R15I...                   " PAI-Modules
* INCLUDE LZINTF_E_R15E...                   " Events
* INCLUDE LZINTF_E_R15P...                   " Local class implement.
* INCLUDE LZINTF_E_R15T99.                   " ABAP Unit tests
  INCLUDE LZINTF_E_R15F00                         . " subprograms
  INCLUDE LZINTF_E_R15I00                         . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
