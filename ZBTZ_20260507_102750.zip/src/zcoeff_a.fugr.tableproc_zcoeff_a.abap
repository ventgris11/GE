*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCOEFF_A
*   generation date: 25.03.2019 at 09:29:54
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCOEFF_A            .

  PERFORM TABLEPROC.

ENDFUNCTION.
