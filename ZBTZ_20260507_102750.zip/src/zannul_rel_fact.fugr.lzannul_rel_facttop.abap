* regenerated at 29.11.2021 15:56:24
FUNCTION-POOL ZANNUL_REL_FACT            MESSAGE-ID SV.

* INCLUDE LZANNUL_REL_FACTD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZANNUL_REL_FACTT00                     . "view rel. data dcl.
