FUNCTION-POOL ZFG_CREATE_SO.                "MESSAGE-ID ..

* INCLUDE LZFG_CREATE_SOD...                 " Local class definition
