FUNCTION zmfu_content_pdf_bbp .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(IV_OPBEL) TYPE  E_PRINTDOC
*"  EXPORTING
*"     VALUE(EV_PDF_BIN) TYPE  XSTRING
*"     VALUE(EV_PDF_PATH) TYPE  STRING
*"----------------------------------------------------------------------

  DATA :
*    lv_budat             TYPE budat,
    lv_filename_in       TYPE eps2filnam,
    lv_filename_out      TYPE eps2filnam,
    lv_dir_name          TYPE eps2filnam,
    "    lv_ssrep    TYPE eps2filnam.
    lt_dir_list          TYPE TABLE OF eps2fili,
    ls_dir_list          TYPE eps2fili,
    lv_pfx_file          TYPE filep,
    lv_file_mask         TYPE epsfilnam,
    lv_path              TYPE filep,
    lv_complete_filename TYPE pc_path,
    lv_length            TYPE i,
    lv_logical_filename  TYPE fileintern.


*  SELECT SINGLE budat
  SELECT SINGLE *
*  INTO lv_budat
  INTO @DATA(ls_eabp)
  FROM eabp
  WHERE opbel = @iv_opbel.

  CHECK sy-subrc = 0. "Pas de BBP, pas de PDF !!!!

  SELECT SINGLE *
  INTO @DATA(ls_ever)
  FROM ever
  WHERE vertrag = @ls_eabp-vertrag.

  CHECK sy-subrc = 0.

  SELECT *
  FROM dfkkcoh
  WHERE vkont = @ls_ever-vkonto
  AND zzcovtitle_unit <> ''
  AND cotyp = 'R025'
  AND data1 = @iv_opbel
  ORDER BY cdate DESCENDING
  INTO @DATA(ls_dfkkcoh)
  UP TO 1 ROWS.
  ENDSELECT.

  CHECK sy-subrc = 0.

CONCATENATE ls_dfkkcoh-zzsousrep '/' ls_dfkkcoh-zzcovtitle_unit INTO lv_filename_in.
  lv_logical_filename = |ZB2C_BILL_PDF_BBP|.

  " Récupération du chemin complet du PDF
  CALL FUNCTION 'FILE_GET_NAME'
    EXPORTING
*     logical_filename = 'ZISU_BILL_PDF_SF_DUPLICATA'
      logical_filename = lv_logical_filename
      parameter_1      = lv_filename_in
    IMPORTING
      file_name        = lv_filename_out
    EXCEPTIONS
      file_not_found   = 1
      OTHERS           = 2.

  ev_pdf_path = lv_filename_out.

  IF ev_pdf_bin IS REQUESTED.

  OPEN DATASET lv_filename_out FOR INPUT IN BINARY MODE." MESSAGE mess .

  " On recherche le nom exact (DUPLICATA_<numéro de facture>_<date>.pdf)
    IF sy-subrc = 0.
      READ DATASET lv_filename_out INTO ev_pdf_bin.
      CLOSE DATASET lv_filename_out.
    ENDIF.

  ENDIF.

ENDFUNCTION.
