FUNCTION-POOL ZBTZ_INTF.                    "MESSAGE-ID ..

* INCLUDE LZBTZ_INTFD...                     " Local class definition
INCLUDE zbtz_data_common.
