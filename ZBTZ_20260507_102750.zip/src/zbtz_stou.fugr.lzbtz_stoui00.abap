*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 31.07.2017 at 14:56:04
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
