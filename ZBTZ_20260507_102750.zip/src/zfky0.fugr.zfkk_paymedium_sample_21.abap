FUNCTION zfkk_paymedium_sample_21.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(I_PAYH) LIKE  PAYH STRUCTURE  PAYH
*"     VALUE(I_PAYHX) LIKE  PAYHX STRUCTURE  PAYHX
*"     VALUE(I_FORMAT_PARAMS) LIKE  FKKPY_SELE-PARAM
*"     VALUE(I_FILENAME) LIKE  REGUT-FSNAM
*"     VALUE(I_XFILESYSTEM) LIKE  BOOLE-BOOLE
*"  TABLES
*"      T_FILE_OUTPUT STRUCTURE  FKKPY_FILE
*"  CHANGING
*"     VALUE(C_FILENAME) LIKE  REGUT-FSNAM
*"----------------------------------------------------------------------
* Example for german format 'DTAUS0':
*------------------------------------
* data header like dtada.
*
* read table t_file_output index 1.
* header      = t_file_output-line.
* header-a11b = space.
*
* t_file_output-line = header.
* modify t_file_output index 1.
  DATA  :
    c_date          TYPE char8,
    lt_nom_paiement TYPE TABLE OF znom_paiement,
    ls_nom_paiement TYPE znom_paiement.

  WRITE sy-datum TO c_date DDMMYY.

  SELECT * INTO TABLE lt_nom_paiement FROM znom_paiement.
  IF sy-subrc = 0.
    LOOP AT lt_nom_paiement INTO ls_nom_paiement.
      IF c_filename CS ls_nom_paiement-fichier_src.
        EXIT.
      ELSE.
        CLEAR ls_nom_paiement.
      ENDIF.
    ENDLOOP.
  ENDIF.

  IF ls_nom_paiement IS NOT INITIAL.
    IF ls_nom_paiement-changdate <> sy-datum.
      ls_nom_paiement-changdate = sy-datum.
      CLEAR ls_nom_paiement-sequence.
    ENDIF.
    ADD 1 TO ls_nom_paiement-sequence.
    CONCATENATE ls_nom_paiement-fichier_cbl ls_nom_paiement-sequence '_' c_date '_' sy-uzeit INTO c_filename.
    MODIFY znom_paiement FROM ls_nom_paiement.
  ELSE.
    CONCATENATE c_filename '_' c_date '_' sy-uzeit INTO c_filename.
  ENDIF.

   c_filename = '/usr/sap/DI1/GE/interfaces/out/CONNEXIS/AENVOYER/' && c_filename.

ENDFUNCTION.
