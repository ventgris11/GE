*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZINTF_E_FTA_MC
*   generation date: 05.07.2024 at 10:17:07
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZINTF_E_FTA_MC      .

  PERFORM TABLEPROC.

ENDFUNCTION.
