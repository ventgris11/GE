* regenerated at 21.04.2019 18:40:33
FUNCTION-POOL ZDSO_RESIL_PT_H            MESSAGE-ID SV.

* INCLUDE LZDSO_RESIL_PT_HD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDSO_RESIL_PT_HT00                     . "view rel. data dcl.
