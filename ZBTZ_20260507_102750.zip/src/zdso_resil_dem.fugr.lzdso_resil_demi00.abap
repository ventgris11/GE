*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 22.04.2019 at 02:53:37
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
