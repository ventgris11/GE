*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 28.09.2020 at 18:52:23
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: T900............................................*
DATA:  BEGIN OF STATUS_T900                          .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_T900                          .
CONTROLS: TCTRL_T900
            TYPE TABLEVIEW USING SCREEN '0048'.
*...processing: ZBTZ_FLUX.......................................*
DATA:  BEGIN OF STATUS_ZBTZ_FLUX                     .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZBTZ_FLUX                     .
CONTROLS: TCTRL_ZBTZ_FLUX
            TYPE TABLEVIEW USING SCREEN '0001'.
*...processing: ZF03A_RECH_C01..................................*
DATA:  BEGIN OF STATUS_ZF03A_RECH_C01                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZF03A_RECH_C01                .
CONTROLS: TCTRL_ZF03A_RECH_C01
            TYPE TABLEVIEW USING SCREEN '0016'.
*...processing: ZINTF_A_LIGNE...................................*
DATA:  BEGIN OF STATUS_ZINTF_A_LIGNE                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_A_LIGNE                 .
CONTROLS: TCTRL_ZINTF_A_LIGNE
            TYPE TABLEVIEW USING SCREEN '0090'.
*...processing: ZINTF_BYPASS_CTR................................*
DATA:  BEGIN OF STATUS_ZINTF_BYPASS_CTR              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_BYPASS_CTR              .
CONTROLS: TCTRL_ZINTF_BYPASS_CTR
            TYPE TABLEVIEW USING SCREEN '0102'.
*...processing: ZINTF_DSO_RES...................................*
DATA:  BEGIN OF STATUS_ZINTF_DSO_RES                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_DSO_RES                 .
CONTROLS: TCTRL_ZINTF_DSO_RES
            TYPE TABLEVIEW USING SCREEN '0104'.
*...processing: ZINTF_E_AFIL....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_AFIL                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_AFIL                  .
CONTROLS: TCTRL_ZINTF_E_AFIL
            TYPE TABLEVIEW USING SCREEN '0085'.
*...processing: ZINTF_E_C01.....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_C01                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_C01                   .
CONTROLS: TCTRL_ZINTF_E_C01
            TYPE TABLEVIEW USING SCREEN '0006'.
*...processing: ZINTF_E_C01_2...................................*
DATA:  BEGIN OF STATUS_ZINTF_E_C01_2                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_C01_2                 .
CONTROLS: TCTRL_ZINTF_E_C01_2
            TYPE TABLEVIEW USING SCREEN '0060'.
*...processing: ZINTF_E_C01_3...................................*
DATA:  BEGIN OF STATUS_ZINTF_E_C01_3                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_C01_3                 .
CONTROLS: TCTRL_ZINTF_E_C01_3
            TYPE TABLEVIEW USING SCREEN '0002'.
*...processing: ZINTF_E_C01_T...................................*
DATA:  BEGIN OF STATUS_ZINTF_E_C01_T                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_C01_T                 .
CONTROLS: TCTRL_ZINTF_E_C01_T
            TYPE TABLEVIEW USING SCREEN '0087'.
*...processing: ZINTF_E_C12.....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_C12                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_C12                   .
CONTROLS: TCTRL_ZINTF_E_C12
            TYPE TABLEVIEW USING SCREEN '0068'.
*...processing: ZINTF_E_C12_2...................................*
DATA:  BEGIN OF STATUS_ZINTF_E_C12_2                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_C12_2                 .
CONTROLS: TCTRL_ZINTF_E_C12_2
            TYPE TABLEVIEW USING SCREEN '0070'.
*...processing: ZINTF_E_C12_2B..................................*
DATA:  BEGIN OF STATUS_ZINTF_E_C12_2B                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_C12_2B                .
CONTROLS: TCTRL_ZINTF_E_C12_2B
            TYPE TABLEVIEW USING SCREEN '0072'.
*...processing: ZINTF_E_C12_3...................................*
DATA:  BEGIN OF STATUS_ZINTF_E_C12_3                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_C12_3                 .
CONTROLS: TCTRL_ZINTF_E_C12_3
            TYPE TABLEVIEW USING SCREEN '0074'.
*...processing: ZINTF_E_C15_2...................................*
DATA:  BEGIN OF STATUS_ZINTF_E_C15_2                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_C15_2                 .
CONTROLS: TCTRL_ZINTF_E_C15_2
            TYPE TABLEVIEW USING SCREEN '0034'.
*...processing: ZINTF_E_C15_2B..................................*
DATA:  BEGIN OF STATUS_ZINTF_E_C15_2B                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_C15_2B                .
CONTROLS: TCTRL_ZINTF_E_C15_2B
            TYPE TABLEVIEW USING SCREEN '0038'.
*...processing: ZINTF_E_C15_3...................................*
DATA:  BEGIN OF STATUS_ZINTF_E_C15_3                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_C15_3                 .
CONTROLS: TCTRL_ZINTF_E_C15_3
            TYPE TABLEVIEW USING SCREEN '0036'.
*...processing: ZINTF_E_C15_CPTR................................*
DATA:  BEGIN OF STATUS_ZINTF_E_C15_CPTR              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_C15_CPTR              .
CONTROLS: TCTRL_ZINTF_E_C15_CPTR
            TYPE TABLEVIEW USING SCREEN '0100'.
*...processing: ZINTF_E_CHECK...................................*
DATA:  BEGIN OF STATUS_ZINTF_E_CHECK                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_CHECK                 .
CONTROLS: TCTRL_ZINTF_E_CHECK
            TYPE TABLEVIEW USING SCREEN '0026'.
*...processing: ZINTF_E_F03G....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_F03G                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_F03G                  .
CONTROLS: TCTRL_ZINTF_E_F03G
            TYPE TABLEVIEW USING SCREEN '0018'.
*...processing: ZINTF_E_F12.....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_F12                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_F12                   .
CONTROLS: TCTRL_ZINTF_E_F12
            TYPE TABLEVIEW USING SCREEN '0082'.
*...processing: ZINTF_E_F15D....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_F15D                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_F15D                  .
CONTROLS: TCTRL_ZINTF_E_F15D
            TYPE TABLEVIEW USING SCREEN '0004'.
*...processing: ZINTF_E_F15G....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_F15G                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_F15G                  .
CONTROLS: TCTRL_ZINTF_E_F15G
            TYPE TABLEVIEW USING SCREEN '0050'.
*...processing: ZINTF_E_FILE....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_FILE                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_FILE                  .
CONTROLS: TCTRL_ZINTF_E_FILE
            TYPE TABLEVIEW USING SCREEN '0054'.
*...processing: ZINTF_E_FLUX....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_FLUX                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_FLUX                  .
CONTROLS: TCTRL_ZINTF_E_FLUX
            TYPE TABLEVIEW USING SCREEN '0052'.
*...processing: ZINTF_E_LINE....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_LINE                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_LINE                  .
CONTROLS: TCTRL_ZINTF_E_LINE
            TYPE TABLEVIEW USING SCREEN '0062'.
*...processing: ZINTF_E_MESURE..................................*
DATA:  BEGIN OF STATUS_ZINTF_E_MESURE                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_MESURE                .
CONTROLS: TCTRL_ZINTF_E_MESURE
            TYPE TABLEVIEW USING SCREEN '0084'.
*...processing: ZINTF_E_N15.....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_N15                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_N15                   .
CONTROLS: TCTRL_ZINTF_E_N15
            TYPE TABLEVIEW USING SCREEN '0094'.
*...processing: ZINTF_E_N15_3...................................*
DATA:  BEGIN OF STATUS_ZINTF_E_N15_3                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_N15_3                 .
CONTROLS: TCTRL_ZINTF_E_N15_3
            TYPE TABLEVIEW USING SCREEN '0096'.
*...processing: ZINTF_E_N15_3B..................................*
DATA:  BEGIN OF STATUS_ZINTF_E_N15_3B                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_N15_3B                .
CONTROLS: TCTRL_ZINTF_E_N15_3B
            TYPE TABLEVIEW USING SCREEN '0098'.
*...processing: ZINTF_E_R04.....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_R04                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_R04                   .
CONTROLS: TCTRL_ZINTF_E_R04
            TYPE TABLEVIEW USING SCREEN '0024'.
*...processing: ZINTF_E_R04_2...................................*
DATA:  BEGIN OF STATUS_ZINTF_E_R04_2                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_R04_2                 .
CONTROLS: TCTRL_ZINTF_E_R04_2
            TYPE TABLEVIEW USING SCREEN '0022'.
*...processing: ZINTF_E_R04_3...................................*
DATA:  BEGIN OF STATUS_ZINTF_E_R04_3                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_R04_3                 .
CONTROLS: TCTRL_ZINTF_E_R04_3
            TYPE TABLEVIEW USING SCREEN '0012'.
*...processing: ZINTF_E_R15_3...................................*
DATA:  BEGIN OF STATUS_ZINTF_E_R15_3                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_R15_3                 .
CONTROLS: TCTRL_ZINTF_E_R15_3
            TYPE TABLEVIEW USING SCREEN '0056'.
*...processing: ZINTF_E_R16.....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_R16                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_R16                   .
CONTROLS: TCTRL_ZINTF_E_R16
            TYPE TABLEVIEW USING SCREEN '0044'.
*...processing: ZINTF_E_R16_3...................................*
DATA:  BEGIN OF STATUS_ZINTF_E_R16_3                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_R16_3                 .
CONTROLS: TCTRL_ZINTF_E_R16_3
            TYPE TABLEVIEW USING SCREEN '0058'.
*...processing: ZINTF_E_R17.....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_R17                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_R17                   .
CONTROLS: TCTRL_ZINTF_E_R17
            TYPE TABLEVIEW USING SCREEN '0076'.
*...processing: ZINTF_E_R17_3...................................*
DATA:  BEGIN OF STATUS_ZINTF_E_R17_3                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_R17_3                 .
CONTROLS: TCTRL_ZINTF_E_R17_3
            TYPE TABLEVIEW USING SCREEN '0078'.
*...processing: ZINTF_E_R17_3B..................................*
DATA:  BEGIN OF STATUS_ZINTF_E_R17_3B                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_R17_3B                .
CONTROLS: TCTRL_ZINTF_E_R17_3B
            TYPE TABLEVIEW USING SCREEN '0080'.
*...processing: ZINTF_MERCANET..................................*
DATA:  BEGIN OF STATUS_ZINTF_MERCANET                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_MERCANET                .
CONTROLS: TCTRL_ZINTF_MERCANET
            TYPE TABLEVIEW USING SCREEN '0092'.
*...processing: ZINTF_TRNSCO_RLV................................*
DATA:  BEGIN OF STATUS_ZINTF_TRNSCO_RLV              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_TRNSCO_RLV              .
CONTROLS: TCTRL_ZINTF_TRNSCO_RLV
            TYPE TABLEVIEW USING SCREEN '0066'.
*...processing: ZMR_MOTIF_PRIO..................................*
DATA:  BEGIN OF STATUS_ZMR_MOTIF_PRIO                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMR_MOTIF_PRIO                .
CONTROLS: TCTRL_ZMR_MOTIF_PRIO
            TYPE TABLEVIEW USING SCREEN '0017'.
*...processing: ZPARAM_SD.......................................*
DATA:  BEGIN OF STATUS_ZPARAM_SD                     .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZPARAM_SD                     .
CONTROLS: TCTRL_ZPARAM_SD
            TYPE TABLEVIEW USING SCREEN '0030'.
*.........table declarations:.................................*
TABLES: *T900                          .
TABLES: *ZBTZ_FLUX                     .
TABLES: *ZF03A_RECH_C01                .
TABLES: *ZINTF_A_LIGNE                 .
TABLES: *ZINTF_BYPASS_CTR              .
TABLES: *ZINTF_DSO_RES                 .
TABLES: *ZINTF_E_AFIL                  .
TABLES: *ZINTF_E_C01                   .
TABLES: *ZINTF_E_C01_2                 .
TABLES: *ZINTF_E_C01_3                 .
TABLES: *ZINTF_E_C01_T                 .
TABLES: *ZINTF_E_C12                   .
TABLES: *ZINTF_E_C12_2                 .
TABLES: *ZINTF_E_C12_2B                .
TABLES: *ZINTF_E_C12_3                 .
TABLES: *ZINTF_E_C15_2                 .
TABLES: *ZINTF_E_C15_2B                .
TABLES: *ZINTF_E_C15_3                 .
TABLES: *ZINTF_E_C15_CPTR              .
TABLES: *ZINTF_E_CHECK                 .
TABLES: *ZINTF_E_F03G                  .
TABLES: *ZINTF_E_F12                   .
TABLES: *ZINTF_E_F15D                  .
TABLES: *ZINTF_E_F15G                  .
TABLES: *ZINTF_E_FILE                  .
TABLES: *ZINTF_E_FLUX                  .
TABLES: *ZINTF_E_LINE                  .
TABLES: *ZINTF_E_MESURE                .
TABLES: *ZINTF_E_N15                   .
TABLES: *ZINTF_E_N15_3                 .
TABLES: *ZINTF_E_N15_3B                .
TABLES: *ZINTF_E_R04                   .
TABLES: *ZINTF_E_R04_2                 .
TABLES: *ZINTF_E_R04_3                 .
TABLES: *ZINTF_E_R15_3                 .
TABLES: *ZINTF_E_R16                   .
TABLES: *ZINTF_E_R16_3                 .
TABLES: *ZINTF_E_R17                   .
TABLES: *ZINTF_E_R17_3                 .
TABLES: *ZINTF_E_R17_3B                .
TABLES: *ZINTF_MERCANET                .
TABLES: *ZINTF_TRNSCO_RLV              .
TABLES: *ZMR_MOTIF_PRIO                .
TABLES: *ZPARAM_SD                     .
TABLES: T900                           .
TABLES: ZBTZ_FLUX                      .
TABLES: ZF03A_RECH_C01                 .
TABLES: ZINTF_A_LIGNE                  .
TABLES: ZINTF_BYPASS_CTR               .
TABLES: ZINTF_DSO_RES                  .
TABLES: ZINTF_E_AFIL                   .
TABLES: ZINTF_E_C01                    .
TABLES: ZINTF_E_C01_2                  .
TABLES: ZINTF_E_C01_3                  .
TABLES: ZINTF_E_C01_T                  .
TABLES: ZINTF_E_C12                    .
TABLES: ZINTF_E_C12_2                  .
TABLES: ZINTF_E_C12_2B                 .
TABLES: ZINTF_E_C12_3                  .
TABLES: ZINTF_E_C15_2                  .
TABLES: ZINTF_E_C15_2B                 .
TABLES: ZINTF_E_C15_3                  .
TABLES: ZINTF_E_C15_CPTR               .
TABLES: ZINTF_E_CHECK                  .
TABLES: ZINTF_E_F03G                   .
TABLES: ZINTF_E_F12                    .
TABLES: ZINTF_E_F15D                   .
TABLES: ZINTF_E_F15G                   .
TABLES: ZINTF_E_FILE                   .
TABLES: ZINTF_E_FLUX                   .
TABLES: ZINTF_E_LINE                   .
TABLES: ZINTF_E_MESURE                 .
TABLES: ZINTF_E_N15                    .
TABLES: ZINTF_E_N15_3                  .
TABLES: ZINTF_E_N15_3B                 .
TABLES: ZINTF_E_R04                    .
TABLES: ZINTF_E_R04_2                  .
TABLES: ZINTF_E_R04_3                  .
TABLES: ZINTF_E_R15_3                  .
TABLES: ZINTF_E_R16                    .
TABLES: ZINTF_E_R16_3                  .
TABLES: ZINTF_E_R17                    .
TABLES: ZINTF_E_R17_3                  .
TABLES: ZINTF_E_R17_3B                 .
TABLES: ZINTF_MERCANET                 .
TABLES: ZINTF_TRNSCO_RLV               .
TABLES: ZMR_MOTIF_PRIO                 .
TABLES: ZPARAM_SD                      .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
