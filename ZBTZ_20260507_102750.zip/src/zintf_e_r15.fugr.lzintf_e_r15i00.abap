*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 28.09.2020 at 18:53:35
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
