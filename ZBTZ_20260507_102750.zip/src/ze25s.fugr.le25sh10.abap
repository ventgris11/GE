*----------------------------------------------------------------------*
***INCLUDE LE25SH10 .
* data declaration for IS-U budget billing plan migration
*----------------------------------------------------------------------*
*.. tables
  TABLES: te420, te500.

*.. types
  TYPES: BEGIN OF t_vkont_ever,
           vtref        LIKE eabps-vtref,
           must_used(1) TYPE c,
           mast_portion LIKE te420-termschl,
           d_betrag     LIKE emigr_ever-d_betrag,
           count_kz     LIKE emigr_ever-count_kz,
           counter      LIKE emigr_ever-counter.
          INCLUDE STRUCTURE ever.
  TYPES: END OF t_vkont_ever.
  TYPES: t_vkont_ever_tab TYPE t_vkont_ever OCCURS 0.
  TYPES: t_eabp_tab  LIKE eabp OCCURS 0,
         t_eabps_tab LIKE eabps OCCURS 0.
  TYPES: BEGIN OF t_bbp_data,
           bbp_num TYPE i,
           eabp    TYPE t_eabp_tab,
           eabps   TYPE t_eabps_tab,
         END OF t_bbp_data,
         t_bbp_data_tab TYPE t_bbp_data OCCURS 0.

*.. constants
  CONSTANTS: co_signum_add(1)   TYPE c               VALUE '+',
             co_flag_x(1)       TYPE c               VALUE 'X',
             co_domname_abszyk  LIKE dcobjdef-name   VALUE 'ABSZYK',
             co_ihv_vabr        LIKE tfkihvor-ihvor   VALUE '0100',
             co_ihv_abs         LIKE tfkihvor-ihvor   VALUE '0050',
             co_ihv_absoll      LIKE tfkihvor-ihvor   VALUE '0051',
             co_ihv_abspp       LIKE tfkihvor-ihvor   VALUE '0052',
             co_eabp_art_4      LIKE eabp-art        VALUE '4',
             co_augbl_mult      LIKE eabps-augbl     VALUE '*',
             co_augrd_06        LIKE eabps-augrd     VALUE '06',
             co_opupk_1         LIKE eabps-opupk     VALUE 1,
             co_whgrp_001       LIKE eabps-whgrp     VALUE '001',
             co_eabp_vertrag    LIKE dd03d-fieldname VALUE 'VERTRAG',
             co_eabp_vkonto     LIKE dd03d-fieldname VALUE 'VKONTO',
             co_eabp_begperiode LIKE dd03d-fieldname VALUE 'BEGPERIODE',
             co_eabp_endperiode LIKE dd03d-fieldname VALUE 'ENDPERIODE',
             co_eabp_kzabsver   LIKE dd03d-fieldname VALUE 'KZABSVER',
             co_eabp_portion    LIKE dd03d-fieldname VALUE 'PORTION',
             co_eabps_bukrs     LIKE dd03d-fieldname VALUE 'BUKRS',
             co_eabps_tvorg     LIKE dd03d-fieldname VALUE 'TVORG',
             co_eabps_spart     LIKE dd03d-fieldname VALUE 'SPART',
             co_eabps_mwskz     LIKE dd03d-fieldname VALUE 'MWSKZ',
             co_eabps_faedn     LIKE dd03d-fieldname VALUE 'FAEDN',
             co_eabps_betrw     LIKE dd03d-fieldname VALUE 'BETRW',
             co_eabps_txjcd     LIKE dd03d-fieldname VALUE 'TXJCD',
             co_eabps_txdat     LIKE dd03d-fieldname VALUE 'TXDAT',
             co_eabps_hvorg     LIKE dd03d-fieldname VALUE 'HVORG',
             co_eabps_sbetw     LIKE dd03d-fieldname VALUE 'SBETW',
             co_eabps_sbetwo    LIKE dd03d-fieldname VALUE 'SBETWO',
             co_eabps_stakz     LIKE dd03d-fieldname VALUE 'STAKZ',
             co_eabps_kofiz     LIKE dd03d-fieldname VALUE 'KOFIZ',
             co_eabps_hkont     LIKE dd03d-fieldname VALUE 'HKONT',
             co_waers           LIKE dd03d-fieldname VALUE 'WAERS',
             co_gpart           LIKE dd03d-fieldname VALUE 'GPART',
             co_eabps_grbbp     LIKE dd03d-fieldname VALUE 'GRBBP'.



*.. variables
  DATA: v_read_fkkvk(1)  TYPE c,
        v_posnr(3)       TYPE n,
        v_lines          TYPE i,
        v_vgl_dat        TYPE d,
        v_pypla_dat      TYPE d,
        v_dat_sav        TYPE d,
        v_must_passed(1) TYPE c,
        v_input_error    TYPE isu25_input_error,
        v_subrc          LIKE sy-subrc,
        v_vtref          LIKE eabps-vtref,
        v_faedn_sav      LIKE eabps-faedn,
        v_opupw          LIKE eabps-opupw,
        v_pypla          LIKE ever-pypla,
        v_retcode        LIKE sy-subrc,
        v_vtref_sav      LIKE eabps-vtref,
        v_tabix_sav      LIKE sy-tabix.


*.. work areas
  DATA: wa_eabp         LIKE eabp,
        wa_eabps        LIKE eabps,
        wa_fkkvk        LIKE fkkvk,
        wa_fkkvkp       LIKE fkkvkp,
        wa_fkkop        LIKE fkkop,
        wa_ever         LIKE ever,
        wa_te420        LIKE te420,
        wa_migr_ever    LIKE emigr_ever,
        wa_vkont_ever   TYPE t_vkont_ever,
        wa_bbp_data     TYPE t_bbp_data.


*.. internal Tables
  DATA: i_eabps      TYPE isu25_budbildate_table WITH HEADER LINE,
        i_teabps     TYPE isu25_budbildate_table,
        i_vkont_ever TYPE t_vkont_ever_tab,
        i_bbp_data   TYPE t_bbp_data_tab,
        i_eabp       LIKE eabp  OCCURS 0,
        t_te420      LIKE te420 OCCURS 0,
        i_abszyk     LIKE dd07v OCCURS 0         WITH HEADER LINE.


*.. changing Parameters for Call Function
  DATA: ch_obj     TYPE isu25_budbilplan,
        ch_log_bbp TYPE isu25_budbilplan_di.
