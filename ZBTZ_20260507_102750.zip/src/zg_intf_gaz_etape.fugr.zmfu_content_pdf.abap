FUNCTION zmfu_content_pdf .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(IV_OPBEL) TYPE  E_PRINTDOC
*"  EXPORTING
*"     VALUE(EV_PDF_BIN) TYPE  XSTRING
*"     VALUE(EV_PDF_PATH) TYPE  STRING
*"----------------------------------------------------------------------

  DATA :
*    lv_budat             TYPE budat,
    lv_filename_in       TYPE eps2filnam,
    lv_filename_out      TYPE eps2filnam,
    lv_dir_name          TYPE eps2filnam,
    "    lv_ssrep    TYPE eps2filnam.
    lt_dir_list          TYPE TABLE OF eps2fili,
    ls_dir_list          TYPE eps2fili,
    lv_pfx_file          TYPE filep,
    lv_file_mask         TYPE epsfilnam,
    lv_path              TYPE filep,
    lv_complete_filename TYPE pc_path,
    lv_length            TYPE i,
    lv_logical_filename  TYPE fileintern,
    lv_is_b2b            TYPE crmt_boolean.


*  SELECT SINGLE budat
  SELECT SINGLE *
*  INTO lv_budat
  INTO @DATA(ls_erdk)
  FROM erdk
  WHERE opbel = @iv_opbel.

  CHECK sy-subrc = 0. "Pas de facture, pas de PDF !!!!

** Modif AliA Consulting (LWAT) 20170806 : Gestion des factures B2C
  CASE ls_erdk-formkey.
    WHEN 'ZBTZ_ISU_FACTU'. " Facture pour le B2C
      CONCATENATE ls_erdk-budat(6) '/FACTUREB2C_' iv_opbel '_' ls_erdk-budat INTO lv_filename_in.
      lv_logical_filename = |ZB2C_BILL_PDF_SF_FACTURE|.
      lv_is_b2b = abap_false.

    WHEN OTHERS. " Facture pour le B2B
*      CONCATENATE ls_erdk-budat(6) '/DUPLICATA_' iv_opbel '_' lv_budat INTO lv_filename_in.
      CONCATENATE ls_erdk-budat(6) '/DUPLICATA_' iv_opbel '_' ls_erdk-budat INTO lv_filename_in.
      lv_logical_filename = |ZISU_BILL_PDF_SF_DUPLICATA|.
      lv_is_b2b = abap_true.

  ENDCASE.
** Fin Modif AliA Consulting (LWAT) 20170806

  " Récupération du chemin complet du PDF
  CALL FUNCTION 'FILE_GET_NAME'
    EXPORTING
*     logical_filename = 'ZISU_BILL_PDF_SF_DUPLICATA'
      logical_filename = lv_logical_filename
      parameter_1      = lv_filename_in
    IMPORTING
      file_name        = lv_filename_out
    EXCEPTIONS
      file_not_found   = 1
      OTHERS           = 2.

  ev_pdf_path = lv_filename_out.

  IF ev_pdf_bin IS REQUESTED.

    OPEN DATASET lv_filename_out FOR INPUT IN BINARY MODE." MESSAGE mess .

    " On recherche le nom exact (DUPLICATA_<numéro de facture>_<date>.pdf)
    IF sy-subrc = 0.
      READ DATASET lv_filename_out INTO ev_pdf_bin.
      CLOSE DATASET lv_filename_out.
    ELSE.
      " si le fichier n'est pas trouvé, on recherche un autre nom basé sur le modèle :
      " DUPLICATA_<numéro de facture>*
      " Ce cas permet de gérer les factures des moisde Février / Mars 2016
      " qui n'ont pas été générées avec la BUDAT (Récupération CHORUS)
      IF lv_is_b2b IS NOT INITIAL.
        CALL FUNCTION 'FILE_GET_NAME'
          EXPORTING
*           logical_filename = 'ZISU_BILL_PDF_SF_DUPLICATA'
            logical_filename = lv_logical_filename
            parameter_1      = 'DUPLICATA_' && iv_opbel && '*'
          IMPORTING
            file_name        = lv_filename_out
          EXCEPTIONS
            file_not_found   = 1
            OTHERS           = 2.
        CHECK sy-subrc = 0.
        lv_complete_filename = lv_filename_out.
        CALL FUNCTION 'CV120_SPLIT_PATH'
          EXPORTING
            pf_path  = lv_complete_filename
          IMPORTING
            pfx_path = lv_path.

        IF sy-subrc = 0.
          lv_dir_name = lv_path.
          lv_file_mask = 'DUPLICATA_' && iv_opbel && '*'.
          REFRESH lt_dir_list.
          CALL FUNCTION 'EPS2_GET_DIRECTORY_LISTING'
            EXPORTING
              iv_dir_name            = lv_dir_name
              file_mask              = lv_file_mask
            TABLES
              dir_list               = lt_dir_list
            EXCEPTIONS
              invalid_eps_subdir     = 1
              sapgparam_failed       = 2
              build_directory_failed = 3
              no_authorization       = 4
              read_directory_failed  = 5
              too_many_read_errors   = 6
              empty_directory_list   = 7
              OTHERS                 = 8.
          IF sy-subrc <> 0.
* Implement suitable error handling here
          ENDIF.

          IF lines( lt_dir_list ) = 1.
            READ TABLE lt_dir_list INTO ls_dir_list INDEX 1.
            lv_filename_out = ls_dir_list-name.
            " On retire l'extension .pdf puisque le MF suivant la rajoute !!
            lv_length = strlen( lv_filename_out ).
            lv_length = lv_length - 4.
            lv_filename_out = lv_filename_out(lv_length).

            CALL FUNCTION 'FILE_GET_NAME'
              EXPORTING
*               logical_filename = 'ZISU_BILL_PDF_SF_DUPLICATA'
                logical_filename = lv_logical_filename
                parameter_1      = lv_filename_out
              IMPORTING
                file_name        = lv_filename_out
              EXCEPTIONS
                file_not_found   = 1
                OTHERS           = 2.

            OPEN DATASET lv_filename_out FOR INPUT IN BINARY MODE.
            IF sy-subrc = 0.
              READ DATASET lv_filename_out INTO ev_pdf_bin.
              CLOSE DATASET lv_filename_out.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF. "Fin Si lv_is_b2b IS NOT INITIAL.
  ENDIF.

ENDFUNCTION.
