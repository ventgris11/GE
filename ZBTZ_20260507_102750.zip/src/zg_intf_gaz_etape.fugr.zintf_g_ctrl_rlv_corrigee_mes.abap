FUNCTION ZINTF_G_CTRL_RLV_CORRIGEE_MES .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA:
    lv_field           TYPE string,
    lv_pattern         TYPE string,
    lr_cl_abap_matcher TYPE REF TO cl_abap_matcher.

  FIELD-SYMBOLS:
    <fs_raison_releve>.

  CLEAR lv_field.
  MOVE 'FLUX-RAISON_RELEVE' TO lv_field.
  ASSIGN (lv_field) TO <fs_raison_releve>.

  CHECK <fs_raison_releve> IS ASSIGNED.

* Si la raison de relève a une des valeurs suivantes:
*
* 11 MES sur point libre avec auto relève
* 12 MES sur point libre avec reprise d’index de MHS
* 13 MES sur point libre
* 14 Rectification d’index sur MES
* 32 CHF avec index calculé (départ)
* 34 CHF avec index calculé fiabilisé (départ)
* 36 CHF (départ)
* 38 CHF avec déplacement (départ)
* 40 CHF sur index auto relevé (départ)
* 42 MES sur point non libre avec auto relève (départ)
* 44 MES sur point non libre (départ)
* 46 MES sur point non libre avec index calculé (départ)
* 62 Changement de compteur (pose)

* cela signifie que
* la relève corrigée est associée à une mise en service (MES)
* le processus RELEVE CORRIGEE avec MES est donc déclenché
*
  lv_pattern
   = '11|12|13|14|32|34|36|38|40|42|44|46|62'.

  lr_cl_abap_matcher
   = cl_abap_matcher=>create( pattern = lv_pattern
                              text    = <fs_raison_releve> ).

  IF lr_cl_abap_matcher->match( ) IS INITIAL.
    ev_etape = 2.  "C'est une relève corrigée non associée à une MES
  ELSE.
    ev_etape = 1.  "C'est une relève corrigée associée à une MES
  ENDIF.
ENDFUNCTION.
