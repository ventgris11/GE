*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 10.12.2020 at 23:29:49
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
