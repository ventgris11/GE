FUNCTION zintf_g_rlv_depart .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA:          lv_string    TYPE string,
                 lv_message   TYPE char255,
                 lv_int_ui    TYPE int_ui,
                 lv_anlage    TYPE anlage,
                 ls_object    TYPE eedm_isu_objects,
                 lt_mr_data   TYPE TABLE OF bapieabl,
                 ls_mr_data   TYPE bapieabl,
                 lt_mr_reason TYPE TABLE OF bapieablg,
                 ls_mr_reason TYPE bapieablg,
                 lv_mr_find   TYPE crmt_boolean
                 .

  FIELD-SYMBOLS: <lr_flux>     TYPE any,
                 <lr_pce>      TYPE any,
                 <lr_idenreg>  TYPE any,
                 <lr_emetteur> TYPE any,
                 <lr_date_rlv> TYPE any.


  lv_string = 'FLUX-NUM_PCE'.
  ASSIGN (lv_string) TO <lr_pce>.
  lv_string = 'FLUX-IDENREG'.
  ASSIGN (lv_string) TO <lr_idenreg> .
  lv_string = 'FLUX-FLUX'.
  ASSIGN (lv_string) TO <lr_flux> .
  lv_string = 'FLUX-EMETTEUR'.
  ASSIGN (lv_string) TO <lr_emetteur> .
  lv_string = 'FLUX-DATE_RELEVE'.
  ASSIGN (lv_string) TO <lr_date_rlv> .

* Pour récupération de INT_UI
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <lr_pce> ).
  IF lv_int_ui IS INITIAL.
  ENDIF.

* Pour récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <lr_date_rlv>
    IMPORTING
      es_detail = ls_object.
  IF ls_object-installation IS INITIAL.
  ENDIF.

  REFRESH: lt_mr_data, lt_mr_reason.
  CALL METHOD zcl_tool=>install_liste_releve
    EXPORTING
      iv_install        = ls_object-installation
      iv_date           = <lr_date_rlv>
    IMPORTING
      et_releves        = lt_mr_data
      et_releves_raison = lt_mr_reason.

  "on supprime les mr qui ne correspondent
  DELETE lt_mr_reason WHERE mrreason NE '06'.

  CLEAR: lv_mr_find.
  IF lt_mr_reason IS NOT INITIAL.
    LOOP AT lt_mr_reason INTO ls_mr_reason.
      READ TABLE lt_mr_data INTO ls_mr_data WITH KEY mridnumber = ls_mr_reason-mridnumber.
      IF ls_mr_data-targetmrdate = <lr_date_rlv>.
        lv_mr_find = 'X'.
      ENDIF.
    ENDLOOP.
    IF lv_mr_find = 'X'.
      ev_etape = 1.
    ELSE.
      ev_etape = 2.
      MESSAGE i217(zintf_g_messages) WITH <lr_emetteur> <lr_flux> <lr_idenreg> INTO lv_message.
    ENDIF.
  ELSE.
    ev_etape = 2.
    MESSAGE i217(zintf_g_messages) WITH <lr_emetteur> <lr_flux> <lr_idenreg> INTO lv_message.
  ENDIF.



ENDFUNCTION.
