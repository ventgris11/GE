*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZINTF_E_FTA_MC
*   generation date: 05.07.2024 at 10:17:06
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZINTF_E_FTA_MC     .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.
