*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZINTF_A_FICHIER
*   generation date: 03.04.2019 at 18:10:39
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZINTF_A_FICHIER     .

  PERFORM TABLEPROC.

ENDFUNCTION.
