*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 04.04.2019 at 10:47:44
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
