*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZANNUL_REL_FACT
*   generation date: 29.11.2021 at 15:56:23
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZANNUL_REL_FACT    .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.
