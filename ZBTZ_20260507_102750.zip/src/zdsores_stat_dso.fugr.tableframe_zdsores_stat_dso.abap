*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZDSORES_STAT_DSO
*   generation date: 03.04.2019 at 15:42:02
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZDSORES_STAT_DSO   .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.
