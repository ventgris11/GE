*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 13.06.2019 at 19:00:33
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
