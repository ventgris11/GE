*----------------------------------------------------------------------*
***INCLUDE LE21DF01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  select_te305_for_HVORG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM select_te305_for_hvorg  TABLES   p_te305 STRUCTURE te305
                             USING    p_hvorg.

  DATA: ite305 LIKE te305 OCCURS 0 WITH HEADER LINE.
  STATICS: gl_te305 LIKE te305 OCCURS 0 WITH HEADER LINE.

  LOOP AT gl_te305 WHERE hvorg = p_hvorg.
    EXIT.
  ENDLOOP.
  IF sy-subrc NE 0.
    CALL FUNCTION 'ISU_DB_TE305_SELECT_FOR_MAIN'
      EXPORTING
        x_hvorg = p_hvorg
      TABLES
        t_te305 = ite305
      EXCEPTIONS
        OTHERS  = 0.

    APPEND LINES OF ite305 TO gl_te305.
  ENDIF.
  p_te305[] = gl_te305[].
  DELETE p_te305 WHERE hvorg NE p_hvorg.

ENDFORM.                    " select_te305_for_HVORG
