FUNCTION zintf_e_pose_fiap .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_NB_ROUES) TYPE  ZNB_CHIFFRES_CADRAN
*"     REFERENCE(IV_TYPE_GRPE_CADRAN) TYPE  CHAR1
*"     REFERENCE(IV_ID_FLUX) TYPE  ZID_FLUX
*"     REFERENCE(IV_DATE_POSE) TYPE  DATS
*"     REFERENCE(IV_MATRICULE) TYPE  ZNUM_SERIE
*"     REFERENCE(IV_INDEX_CAD_1) TYPE  ZINDEX
*"     REFERENCE(IV_INDEX_CAD_2) TYPE  ZINDEX OPTIONAL
*"     REFERENCE(IV_INDEX_CAD_3) TYPE  ZINDEX OPTIONAL
*"     REFERENCE(IV_INDEX_CAD_4) TYPE  ZINDEX OPTIONAL
*"     REFERENCE(IV_NB_CADRANS) TYPE  ZNB_CADRANS
*"     REFERENCE(IV_ANLAGE) TYPE  ANLAGE
*"     REFERENCE(IV_CONSO_PER_CAD_1) TYPE  PERVERBR OPTIONAL
*"     REFERENCE(IV_CONSO_PER_CAD_2) TYPE  PERVERBR OPTIONAL
*"     REFERENCE(IV_CONSO_PER_CAD_3) TYPE  PERVERBR OPTIONAL
*"     REFERENCE(IV_CONSO_PER_CAD_4) TYPE  PERVERBR OPTIONAL
*"  EXPORTING
*"     REFERENCE(EV_STATUT) TYPE  I
*"  CHANGING
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA:
    lv_field     TYPE string,
    lt_etdz      TYPE TABLE OF etdz,
    ls_etdz      TYPE etdz,
    lv_stanzvor  TYPE stanzvor,
    ls_auto      TYPE isu42_devmod_auto,
    lv_device    TYPE geraet,
    lv_sernr     TYPE lsernr,
    lv_equnr     TYPE equnr,
    lv_db_update TYPE e_update,
    ls_dev       TYPE reg42_dev,
    ls_dev_flag  TYPE reg42_dev_input_flag,
    ls_lsernr    TYPE lsernr.

  ev_statut = 2.

  CLEAR ls_auto.
  CLEAR ls_dev.
  CLEAR ls_dev_flag.

*ART_BASE/MM4    BASE4     Compteur Base 4 roues
*ART_BASE/MM5    BASE5     Compteur Base 5 roues
*ART_BASE/MM6    BASE6     Compteur Base 6 roues
*ART_HCHP/MM4    HCHP4     Compteur HC/HP 4 roues
*ART_HCHP/MM5    HCHP5     Compteur HC/HP 5 roues
*ART_HCHP/MM6    HCHP6     Compteur HC/HP 6 roues
*ART_LINK_B4     L-BASE4   Compteur LINKY Base 4 roues
*ART_LINK_B5     L-BASE5   Compteur LINKY Base 5 roues
*ART_LINK_B6     L-BASE6   Compteur LINKY Base 6 roues
*ART_LINK_HCHP4  L-HCHP4   Compteur LINKY HC/HP 4 roues
*ART_LINK_HCHP5  L-HCHP5   Compteur LINKY HC/HP 5 roues
*ART_LINK_HCHP6  L-HCHP6   Compteur LINKY HC/HP 6 roues

* Créer constante ou se baser sur la table ETYP
  IF iv_id_flux = 'C01'.

    IF iv_type_grpe_cadran = 1.

      CASE iv_nb_roues.
        WHEN '4'.
          ls_dev-matnr      = 'ART_BASE/MM4'.
          ls_dev-zwgruppe   = 'BASE4'.
          ls_dev_flag-matnr = 'ART_BASE/MM4'.
        WHEN '5'.
          ls_dev-matnr      = 'ART_BASE/MM5'.
          ls_dev-zwgruppe   = 'BASE5'.
          ls_dev_flag-matnr = 'ART_BASE/MM5'.
        WHEN '6'.
          ls_dev-matnr      = 'ART_BASE/MM6'.
          ls_dev-zwgruppe   = 'BASE6'.
          ls_dev_flag-matnr = 'ART_BASE/MM6'.
      ENDCASE.

    ELSEIF iv_type_grpe_cadran = 2.

      CASE iv_nb_roues.
        WHEN '4'.
          ls_dev-matnr      = 'ART_HCHP/MM4'.
          ls_dev-zwgruppe   = 'HCHP4'.
          ls_dev_flag-matnr = 'ART_HCHP/MM4'.
        WHEN '5'.
          ls_dev-matnr      = 'ART_HCHP/MM5'.
          ls_dev-zwgruppe   = 'HCHP5'.
          ls_dev_flag-matnr = 'ART_HCHP/MM5'.
        WHEN '6'.
          ls_dev-matnr      = 'ART_HCHP/MM6'.
          ls_dev-zwgruppe   = 'HCHP6'.
          ls_dev_flag-matnr = 'ART_HCHP/MM6'.
      ENDCASE.
    ENDIF.

  ELSEIF iv_id_flux = 'C15'.

    IF iv_type_grpe_cadran = 1.

      CASE iv_nb_roues.
        WHEN '4'.
          ls_dev-matnr      = 'ART_LINK_B4'.
          ls_dev-zwgruppe   = 'L-BASE4'.
          ls_dev_flag-matnr = 'ART_LINK_B4'.
        WHEN '5'.
          ls_dev-matnr      = 'ART_LINK_B5'.
          ls_dev-zwgruppe   = 'L-BASE5'.
          ls_dev_flag-matnr = 'ART_LINK_B5'.
        WHEN '6'.
          ls_dev-matnr      = 'ART_LINK_B6'.
          ls_dev-zwgruppe   = 'L-BASE6'.
          ls_dev_flag-matnr = 'ART_LINK_B6'.
      ENDCASE.

    ELSEIF iv_type_grpe_cadran = 2.

      CASE iv_nb_roues.
        WHEN '4'.
          ls_dev-matnr      = 'ART_LINK_HCHP4'.
          ls_dev-zwgruppe   = 'L-HCHP4'.
          ls_dev_flag-matnr = 'ART_LINK_HCHP4'.
        WHEN '5'.
          ls_dev-matnr      = 'ART_LINK_HCHP5'.
          ls_dev-zwgruppe   = 'L-HCHP5'.
          ls_dev_flag-matnr = 'ART_LINK_HCHP5'.
        WHEN '6'.
          ls_dev-matnr      = 'ART_LINK_HCHP6'.
          ls_dev-zwgruppe   = 'L-HCHP6'.
          ls_dev_flag-matnr = 'ART_LINK_HCHP6'.
      ENDCASE.

* Début AFR - Ajout GE-11728
    ELSEIF iv_type_grpe_cadran = 4.

      CASE iv_nb_roues.
        WHEN '4'.
          ls_dev-matnr      = 'ART_BTINF4_4'.
          ls_dev-zwgruppe   = 'BTINF4_4'.
          ls_dev_flag-matnr = 'ART_BTINF4_4'.
        WHEN '5'.
          ls_dev-matnr      = 'ART_BTINF4_5'.
          ls_dev-zwgruppe   = 'BTINF4_5'.
          ls_dev_flag-matnr = 'ART_BTINF4_5'.
        WHEN '6'.
          ls_dev-matnr      = 'ART_BTINF4_6'.
          ls_dev-zwgruppe   = 'BTINF4_6'.
          ls_dev_flag-matnr = 'ART_BTINF4_6'.
      ENDCASE.
* Fin AFR - Ajout GE-11728

    ENDIF.

  ENDIF.

  ls_dev-ab              = iv_date_pose.
  ls_dev-bis             = '99991231'.
  ls_dev-sparte          = 'ZE'.
  ls_dev-egerr_info      = iv_matricule.
  APPEND ls_dev         TO ls_auto-dev.

  ls_dev_flag-ab         = iv_date_pose.
  ls_dev_flag-bis        = '99991231'.
  ls_dev_flag-zwgruppe   = 'X'.
  ls_dev_flag-egerr_info = 'X'.
  APPEND ls_dev_flag    TO ls_auto-dev_flag.

  ls_auto-contr-okcode = 'SAVE'.

* Créer fiche info appareil
  CALL FUNCTION 'ISU_S_SMALL_DEVICE_CREATE'
    EXPORTING
      x_matnr        = ls_dev-matnr            " Type appareil
      x_keydate      = iv_date_pose
      x_upd_online   = 'X'
      x_no_dialog    = 'X'
      x_auto         = ls_auto
      x_int_num      = 'X'
    IMPORTING
      y_db_update    = lv_db_update
      y_equnr        = lv_equnr
      y_device       = lv_sernr
    EXCEPTIONS
      not_found      = 1
      invalid        = 2
      foreign_lock   = 3
      input_error    = 4
      system_error   = 5
      internal_error = 6
      not_qualified  = 7
      not_customized = 8
      cancelled      = 9
*     error_message  = 10
      OTHERS         = 11.

  IF sy-subrc NE 0
  OR lv_db_update IS INITIAL.
    macro_add_msg_system_to_log.
    RETURN.
  ENDIF.

  DATA: ld_date       TYPE datum,
        ld_perverbr   TYPE perverbr,
        ld_thgver     TYPE thgver,
        ld_zwnummer   TYPE e_zwnummer,
        ld_tarifart   TYPE tarifart,
        ld_date_c(10) TYPE c,
        ld_db_update  TYPE xfeld,
        lt_zw         TYPE isu07_zwt,
        ls_zw         TYPE isu07_zw,
        ls_ger        TYPE isu07_auto_ger,
        ls_auto_pose  TYPE isu07_install_auto.

* Pose de la fiche appareil créée
*
* Récupération :
* de la consommation périodique actuelle (CAR de facturation )
* de la catégorie de tarif
* de la conversion gaz
*
* Les données sont à récupérer à J-1 par rapport à la date de pose
*
  REFRESH lt_zw.
  ld_date = iv_date_pose - 1.

  SELECT  easts~tarifart
          easte~perverbr
          eadz~thgver
          etdz~zwnummer
    INTO (ld_tarifart,
          ld_perverbr,
          ld_thgver,
          ld_zwnummer)
    FROM easts INNER JOIN easte
                       ON easte~logikzw EQ easts~logikzw
                      AND easte~bis     GE easts~ab
                      AND easte~ab      LE easts~bis
               INNER JOIN eadz
                       ON eadz~logikzw  EQ easts~logikzw
                      AND eadz~bis      GE easts~ab
                      AND eadz~ab       LE easts~bis
               INNER JOIN etdz
                       ON etdz~logikzw  EQ easts~logikzw
                      AND etdz~bis      GE easts~ab
                      AND etdz~ab       LE easts~bis
   WHERE easts~anlage EQ iv_anlage
     AND easts~ab     LE ld_date
     AND easts~bis    GE ld_date
     AND easte~ab     LE ld_date
     AND eadz~bis     GE ld_date
     AND eadz~ab      LE ld_date
     AND etdz~ab      LE ld_date.

    IF ld_zwnummer = '1'.

      IF iv_conso_per_cad_1 IS NOT INITIAL.
        ld_perverbr = iv_conso_per_cad_1.
      ENDIF.
* Données cadran(s)
      ls_zw-zwnummere       = '001'.
      ls_zw-zwstandce       = iv_index_cad_1.
      ls_zw-spartype        = '01'.
      ls_zw-geraete         = lv_sernr.
      ls_zw-matnre          = ls_dev-matnr.
      ls_zw-anzerg          = 1.
      ls_zw-thgver          = ld_thgver.
      ls_zw-tarifart        = ld_tarifart.
      ls_zw-perverbr        = ld_perverbr.

      APPEND ls_zw TO lt_zw.

    ELSEIF ld_zwnummer = '2'.

      IF iv_nb_cadrans EQ 2.
        IF iv_conso_per_cad_2 IS NOT INITIAL.
          ld_perverbr = iv_conso_per_cad_2.
        ENDIF.
* Données cadran(s)
        ls_zw-zwnummere     = '002'.
        ls_zw-zwstandce     = iv_index_cad_2.
        ls_zw-spartype      = '01'.
        ls_zw-geraete       = lv_sernr.
        ls_zw-matnre        = ls_dev-matnr.
        ls_zw-anzerg        = 1.
        ls_zw-thgver        = ld_thgver.
        ls_zw-tarifart      = ld_tarifart.
        ls_zw-perverbr      = ld_perverbr.

        APPEND ls_zw TO lt_zw.
      ENDIF.                                                "+GE-13194
*++DEBUT STOU GE-1215
    ELSEIF ld_zwnummer = '3'.

      IF iv_nb_cadrans EQ 3.
        IF iv_conso_per_cad_3 IS NOT INITIAL.
          ld_perverbr = iv_conso_per_cad_3.
        ENDIF.
* Données cadran(s)
        ls_zw-zwnummere     = '003'.
        ls_zw-zwstandce     = iv_index_cad_3.
        ls_zw-spartype      = '01'.
        ls_zw-geraete       = lv_sernr.
        ls_zw-matnre        = ls_dev-matnr.
        ls_zw-anzerg        = 1.
        ls_zw-thgver        = ld_thgver.
        ls_zw-tarifart      = ld_tarifart.
        ls_zw-perverbr      = ld_perverbr.

        APPEND ls_zw TO lt_zw.

      ENDIF.

    ELSEIF ld_zwnummer = '4'.

      IF iv_nb_cadrans EQ 4.
        IF iv_conso_per_cad_4 IS NOT INITIAL.
          ld_perverbr = iv_conso_per_cad_4.
        ENDIF.
* Données cadran(s)
        ls_zw-zwnummere     = '004'.
        ls_zw-zwstandce     = iv_index_cad_4.
        ls_zw-spartype      = '01'.
        ls_zw-geraete       = lv_sernr.
        ls_zw-matnre        = ls_dev-matnr.
        ls_zw-anzerg        = 1.
        ls_zw-thgver        = ld_thgver.
        ls_zw-tarifart      = ld_tarifart.
        ls_zw-perverbr      = ld_perverbr.

        APPEND ls_zw TO lt_zw.

      ENDIF.
*++FIN   STOU GE-1215
    ENDIF.

*    ENDIF. "-GE-13194
  ENDSELECT.

  IF lt_zw[] IS INITIAL.
* Problème dans le modèle de données
    ev_statut = 2.
    EXIT.
  ENDIF.

*GE-13194
  SORT lt_zw BY zwnummere.
  DELETE ADJACENT DUPLICATES FROM lt_zw COMPARING zwnummere.

* Données d'appareil
  ls_ger-matnr     = ls_dev-matnr.
  ls_ger-geraetneu = lv_sernr.
  ls_ger-ausbau    = space.
  ls_ger-sparteneu = 'ZE'.
  ls_ger-action    = '04'.
  APPEND ls_ger TO ls_auto_pose-auto_ger.

* Données de cadran(s)
  ls_auto_pose-auto_zw                 = lt_zw.
  ls_auto_pose-interface-anlage        = iv_anlage.
  ls_auto_pose-interface-eadat         = iv_date_pose.
  ls_auto_pose-interface-action        = '04'.
  ls_auto_pose-interface-upd_online    = 'X'.
  ls_auto_pose-interface-no_dialog     = 'X'.
  ls_auto_pose-interface-no_event      = 'X'.
  ls_auto_pose-interface-no_statistic  = 'X'.
  ls_auto_pose-interface-no_change_doc = 'X'.
  ls_auto_pose-okcode                  = 'SAVE'.
  ls_auto_pose-zwstand                 = 'X'.
  ls_auto_pose-consumption             = 'X'.

  CALL FUNCTION 'ISU_S_WORKLIST_INSTALL'
    EXPORTING
      x_anlage         = iv_anlage
      x_eadat          = iv_date_pose
      x_geraetneu      = lv_sernr
      x_matnr          = ls_dev-matnr
      x_action         = '04'       " Pose pour calcul de facturation
      x_spartee        = 'ZE'
      x_upd_online     = 'X'
      x_no_dialog      = 'X'
      x_no_event       = 'X'
      x_no_statistic   = 'X'
      x_no_change_doc  = 'X'
      x_called_by_idoc = space
    IMPORTING
      y_db_update      = ld_db_update
    CHANGING
      xy_auto          = ls_auto_pose
    EXCEPTIONS
      not_found        = 1
      foreign_lock     = 2
      invalid          = 3
      internal_error   = 4
      not_qualified    = 5
      input_error      = 6
      system_error     = 7
      not_customized   = 8
*     error_message    = 9
      OTHERS           = 10.

  IF sy-subrc NE 0
  OR lv_db_update IS INITIAL.
    macro_add_msg_system_to_log.
    RETURN.
  ENDIF.

  ev_statut = 1.

ENDFUNCTION.
