* regenerated at 22.04.2019 02:53:37
FUNCTION-POOL ZDSO_RESIL_DEM             MESSAGE-ID SV.

* INCLUDE LZDSO_RESIL_DEMD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDSO_RESIL_DEMT00                      . "view rel. data dcl.
