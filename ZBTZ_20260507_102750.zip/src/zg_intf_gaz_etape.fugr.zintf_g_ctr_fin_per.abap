FUNCTION ZINTF_G_CTR_FIN_PER .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

DATA: lc_field_num_pce     TYPE FIELDNAME value 'NUM_PCE',
      lc_field_date_releve TYPE FIELDNAME value 'DATE_RELEVE',
      lv_field             TYPE STRING,
      lv_int_ui            TYPE int_ui,
      ls_object            TYPE eedm_isu_objects,
      lv_date              TYPE dats
      .

FIELD-SYMBOLS: <FS_NUM_PCE>, <FS_DATE_RELEVE>.

  clear: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  assign (lv_field) TO <FS_NUM_PCE>.

  clear: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
  assign (lv_field) TO <FS_DATE_RELEVE>.


  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <FS_NUM_PCE> ).
  IF lv_int_ui IS INITIAL.
  ENDIF.

  IF <FS_NUM_PCE> IS ASSIGNED.
    IF <FS_DATE_RELEVE> IS ASSIGNED.
      lv_date = <fs_date_releve> - 1.
      CLEAR ls_object.
      CALL METHOD zcl_tool=>pod_get_related_object
        EXPORTING
          iv_int_ui = lv_int_ui
          iv_date   = lv_date
        IMPORTING
          es_detail = ls_object.

      IF ls_object-contract IS INITIAL.
         EV_ETAPE = 2.
      ELSE.
         EV_ETAPE = 1.
      ENDIF.
    ELSE.
      "Erreur technique
    ENDIF.
  ELSE.
    "Erreur technique
  ENDIF.

ENDFUNCTION.
