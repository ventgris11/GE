* regenerated at 28.09.2020 18:53:35
FUNCTION-POOL ZINTF_E_R15                MESSAGE-ID SV.

* INCLUDE LZINTF_E_R15D...                   " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZINTF_E_R15T00                         . "view rel. data dcl.
