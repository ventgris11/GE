* regenerated at 16.10.2018 16:49:50
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZBTZ_F03TOP.                      " Global Data
  INCLUDE LZBTZ_F03UXX.                      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZBTZ_F03F...                      " Subroutines
* INCLUDE LZBTZ_F03O...                      " PBO-Modules
* INCLUDE LZBTZ_F03I...                      " PAI-Modules
* INCLUDE LZBTZ_F03E...                      " Events
* INCLUDE LZBTZ_F03P...                      " Local class implement.
* INCLUDE LZBTZ_F03T99.                      " ABAP Unit tests
  INCLUDE LZBTZ_F03F00                            . " subprograms
  INCLUDE LZBTZ_F03I00                            . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
