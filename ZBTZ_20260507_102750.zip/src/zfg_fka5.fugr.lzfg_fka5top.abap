FUNCTION-POOL ZFG_FKA5.                     "MESSAGE-ID ..

* INCLUDE LZFG_FKA5D...                      " Local class definition
