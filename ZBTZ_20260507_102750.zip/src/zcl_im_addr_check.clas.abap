class ZCL_IM_ADDR_CHECK definition
  public
  final
  create public .

public section.

  interfaces IF_EX_ADDRESS_CHECK .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_ADDR_CHECK IMPLEMENTATION.


  METHOD if_ex_address_check~address_postal_check.
    break aantonio.
  ENDMETHOD.


  method IF_EX_ADDRESS_CHECK~IS_ACTIVE_FOR_COUNTRY.
  endmethod.
ENDCLASS.
