* regenerated at 22.04.2019 02:53:37
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDSO_RESIL_DEMTOP.                " Global Data
  INCLUDE LZDSO_RESIL_DEMUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDSO_RESIL_DEMF...                " Subroutines
* INCLUDE LZDSO_RESIL_DEMO...                " PBO-Modules
* INCLUDE LZDSO_RESIL_DEMI...                " PAI-Modules
* INCLUDE LZDSO_RESIL_DEME...                " Events
* INCLUDE LZDSO_RESIL_DEMP...                " Local class implement.
* INCLUDE LZDSO_RESIL_DEMT99.                " ABAP Unit tests
  INCLUDE LZDSO_RESIL_DEMF00                      . " subprograms
  INCLUDE LZDSO_RESIL_DEMI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
