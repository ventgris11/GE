FUNCTION zintf_g_rlv_est_corrigee .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA: lc_field_type_releve TYPE fieldname VALUE 'TYPE_RELEVE',
        lv_field             TYPE string,
        lv_string            TYPE string,
        lv_message           TYPE char255,
        ls_bpem              TYPE zbpem_flux_struct,
        lv_interface         TYPE zisu_flxid,
        lv_success           TYPE crmt_boolean.

  FIELD-SYMBOLS: <fs>.

  FIELD-SYMBOLS: <lr_flux>     TYPE any,
                 <lr_struc>    TYPE any,
                 <lr_idenreg>  TYPE any,
                 <lr_emetteur> TYPE any,
                 <lr_date>     TYPE any.


  lv_string = 'FLUX-NUM_PCE'.
  ASSIGN (lv_string) TO <lr_struc>.
  lv_string = 'FLUX-IDENREG'.
  ASSIGN (lv_string) TO <lr_idenreg> .
  lv_string = 'FLUX-FLUX'.
  ASSIGN (lv_string) TO <lr_flux> .
  lv_string = 'FLUX-EMETTEUR'.
  ASSIGN (lv_string) TO <lr_emetteur> .

  lv_string = 'FLUX-DATE_RELEVE'.
  ASSIGN (lv_string) TO <lr_date> .

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_type_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs>.

  IF <fs> IS ASSIGNED.
    IF <fs> = 'C'.
      ev_etape = 1.
** DEB - GLIC - 08102019 - GE-6120 - filtrer les relèves de type "A" (annulation)
*-GE-14730 {
*    ELSEIF <fs> = 'A'.
*      CLEAR ev_etape.
*      lv_success = zcl_tool=>filtre_releve_gaz( CHANGING flux = flux ).
*      IF lv_success = abap_true.
*        "flux filtré on quitte
*        EXIT.
*      ENDIF.
** FIN - GLIC - 08102019 - GE-6120
*-GE-14730 }
    ELSE.
      ev_etape = 2.
*      MESSAGE e212(zintf_g_messages) WITH <lr_emetteur> <lr_flux> <lr_idenreg> <fs> INTO lv_message.
*      CLEAR ls_bpem.
*      ls_bpem-num_pce =  <lr_struc>.
*      IF <lr_date> IS ASSIGNED .
*        CASE <lr_flux>.
*          WHEN 'ADIF'.
*            ls_bpem-date_effet_cont = <lr_date>.
*          WHEN 'RE6M' OR 'RE1M' OR 'REMM' OR 'REJJ' OR 'REJM'.
*            ls_bpem-date_releve     = <lr_date>.
*          WHEN 'AFAC'.
*            ls_bpem-date_fin_prest  = <lr_date>.
*        ENDCASE.
*      ENDIF.
*
*      lv_interface    = <lr_flux> .
*      ls_bpem-idenreg = <lr_idenreg>.
*
*      CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
*        EXPORTING
*          iv_interface_name = lv_interface
*          iv_sparte         = 'ZG'
*          is_structure      = ls_bpem.

    ENDIF.
  ELSE.
    "Erreur technique
  ENDIF.

ENDFUNCTION.
