*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 10.12.2020 at 23:29:49
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
