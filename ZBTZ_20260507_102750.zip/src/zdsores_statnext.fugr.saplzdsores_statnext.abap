* regenerated at 07.04.2019 13:51:40
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDSORES_STATNEXTTOP.              " Global Data
  INCLUDE LZDSORES_STATNEXTUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDSORES_STATNEXTF...              " Subroutines
* INCLUDE LZDSORES_STATNEXTO...              " PBO-Modules
* INCLUDE LZDSORES_STATNEXTI...              " PAI-Modules
* INCLUDE LZDSORES_STATNEXTE...              " Events
* INCLUDE LZDSORES_STATNEXTP...              " Local class implement.
* INCLUDE LZDSORES_STATNEXTT99.              " ABAP Unit tests
  INCLUDE LZDSORES_STATNEXTF00                    . " subprograms
  INCLUDE LZDSORES_STATNEXTI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
