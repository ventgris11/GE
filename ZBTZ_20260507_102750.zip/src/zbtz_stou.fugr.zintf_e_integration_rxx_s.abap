FUNCTION ZINTF_E_INTEGRATION_RXX_S.
*"--------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_IDENREG) TYPE  ZIDENREG
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN DEFAULT ABAP_FALSE
*"     REFERENCE(IV_ID_FLUX) TYPE  ZID_FLUX
*"  EXPORTING
*"     REFERENCE(EV_ERROR) TYPE  CRMT_BOOLEAN
*"--------------------------------------------------------------------

  CLEAR ev_error.
  lv_log_object    = lc_log_object_intf_elec.
  lv_log_subobject = lc_log_subobject_r04.
  lv_msgid         = lc_msgid_intf_elec.

* Appel en mode &1 pour le flux &2
  IF 1 = 2. MESSAGE i018(zintf_e_messages). ENDIF.
  IF iv_mode_test IS INITIAL.
    macro_add_msg_to_log 'I' '018'
                         'REEL' iv_id_flux '' ''.
  ELSE.
    macro_add_msg_to_log 'I' '018'
                         'TEST' iv_id_flux '' ''.
  ENDIF.

* Sélection des données à traiter
  CASE iv_id_flux.
    WHEN 'R04'.
      CLEAR ls_rxx.
      SELECT SINGLE *
        INTO CORRESPONDING FIELDS OF ls_rxx
        FROM zintf_e_r04
       WHERE idenreg EQ iv_idenreg.

      lv_statut_flux = ls_rxx-statut.

      REFRESH lt_rxx_3.
      SELECT *
        INTO CORRESPONDING FIELDS OF TABLE lt_rxx_3
        FROM zintf_e_r04_3
       WHERE idenreg EQ iv_idenreg
       ORDER BY idenreg
                id_periode
                rang_cadran.
    WHEN 'R15'.
      CLEAR ls_rxx.
      SELECT SINGLE *
        INTO CORRESPONDING FIELDS OF ls_rxx
        FROM zintf_e_r15
       WHERE idenreg EQ iv_idenreg.

      lv_statut_flux = ls_rxx-statut.

      REFRESH lt_rxx_3.
      SELECT *
        INTO CORRESPONDING FIELDS OF TABLE lt_rxx_3
        FROM zintf_e_r15_3
       WHERE idenreg           EQ iv_idenreg
         AND type_classe_tempo EQ 'FOURNI'
       ORDER BY idenreg
                type_classe_tempo
                rang_cadran.
    WHEN 'R16'.
      CLEAR ls_rxx.
      SELECT SINGLE *
        INTO CORRESPONDING FIELDS OF ls_rxx
        FROM zintf_e_r16
       WHERE idenreg EQ iv_idenreg.

      lv_statut_flux = ls_rxx-statut.

      REFRESH lt_rxx_3.
      SELECT *
        INTO CORRESPONDING FIELDS OF TABLE lt_rxx_3
        FROM zintf_e_r16_3
       WHERE idenreg           EQ iv_idenreg
         AND type_classe_tempo EQ 'FOURNI'
       ORDER BY idenreg
                type_classe_tempo
                rang_cadran.
  ENDCASE.

  PERFORM controles_ligne_releve CHANGING ev_error.

  IF ev_error EQ abap_true.
    PERFORM update_ligne_releve USING lc_statut_06_rejet.
    RETURN.
  ENDIF.

************************************************************************
* Détermination du sous-processus de gestion d'une relève
* en fonction de la donnée "Evénement déclencheur" (flux R04)
* ou des données "Statut" ou "Motif" de relève     (flux R15/R16)
************************************************************************

  IF ls_rxx-id_flux EQ 'R04'.
* Détermination du processus en fonction de l'événement déclencheur
    CASE ls_rxx-even_declencheur.
      WHEN '0'.  "Facture de mise en service
        PERFORM processus_releve_emmenagement     CHANGING ev_error.
      WHEN '1'.  "Facture sur relevé
        PERFORM processus_releve_cyclique         CHANGING ev_error.
      WHEN '2'   "Facture acompte intermédiaire
        OR '4'.  "Facture de résiliation
        PERFORM processus_releve_a_filtrer        CHANGING ev_error.
      WHEN '3'.  "Facture événementielle
        IF ls_rxx-date_deb_conso EQ ls_rxx-date_fin_conso.
          PERFORM processus_releve_a_filtrer      CHANGING ev_error.
        ELSE.
          PERFORM processus_releve_evenement      CHANGING ev_error.
        ENDIF.
      WHEN '9'.  "Redressement
        IF ls_rxx-mode_redressement EQ 'A'.
          PERFORM processus_releve_a_filtrer      CHANGING ev_error.
        ELSE.
          PERFORM processus_releve_redressement   CHANGING ev_error.
        ENDIF.
      WHEN OTHERS.
        PERFORM processus_releve_a_filtrer        CHANGING ev_error.
    ENDCASE.

  ELSEIF ls_rxx-id_flux EQ 'R15'.
* Détermination du processus en fonction
* ou du statut de relève ou du motif de relève
    IF ls_rxx-statut_releve EQ 'RECTIFICATIF'.
      PERFORM processus_releve_redressement       CHANGING ev_error.
    ELSE.
      CASE ls_rxx-motif_releve.
        WHEN 'CYCL' "Relevé cyclique
          OR 'FIAB'."Index réel utilisé pour fiabiliser une estimation
          PERFORM processus_releve_cyclique       CHANGING ev_error.
        WHEN 'CFNS' "Changement de fournisseur sortant
          OR 'RES'. "Résiliation
          PERFORM processus_releve_a_filtrer      CHANGING ev_error.
        WHEN 'CFNE' "Changement de fournisseur entrant
          OR 'MES'. "Mise en service
          PERFORM processus_releve_emmenagement   CHANGING ev_error.
        WHEN 'MCT'. "Modification de la formule tarifaire acheminement
          PERFORM processus_releve_evenement      CHANGING ev_error.
        WHEN OTHERS.
          PERFORM processus_releve_a_filtrer      CHANGING ev_error.
      ENDCASE.
    ENDIF.
  ELSEIF ls_rxx-id_flux EQ 'R16'.
*   A définir
  ENDIF.

  IF ev_error EQ abap_true.
    PERFORM update_ligne_releve USING lc_statut_06_rejet.
  ELSE.
    PERFORM update_ligne_releve USING lc_statut_07_integre.
  ENDIF.

ENDFUNCTION.

************************************************************************
* Mise à jour du statut de la ligne du flux R04/R15/R16
************************************************************************
FORM update_ligne_releve USING ev_statut TYPE zintf_g_statut.
  DATA:
    lv_texte_statut TYPE text30.

  IF lv_statut_flux EQ ls_rxx-statut.
    lv_statut_flux = ev_statut.
  ENDIF.

  CASE lv_statut_flux.
    WHEN '01'. lv_texte_statut = 'A intégrer               '.
    WHEN '02'. lv_texte_statut = 'A rejouer                '.
    WHEN '03'. lv_texte_statut = 'MEA - Synchronisation CRM'.
    WHEN '04'. lv_texte_statut = 'MEA - Rejet              '.
    WHEN '05'. lv_texte_statut = 'Acquitté                 '.
    WHEN '06'. lv_texte_statut = 'Rejet                    '.
    WHEN '07'. lv_texte_statut = 'Intégré                  '.
    WHEN '10'. lv_texte_statut = 'En attente d''action CRM  '.
    WHEN '11'. lv_texte_statut = 'Filtré                   '.
    WHEN '12'. lv_texte_statut = 'Synchronisé              '.
    WHEN '13'. lv_texte_statut = 'Gelé                     '.
    WHEN '14'. lv_texte_statut = 'Action manuelle          '.
    WHEN '15'. lv_texte_statut = 'MEA - Action manuelle    '.
    WHEN '16'. lv_texte_statut = 'MEA - Intégration        '.
  ENDCASE.

  IF 1 = 2. MESSAGE i100(zintf_e_messages). ENDIF.
* PRM &1 Installation &2 Flux &3 => &4
  macro_add_msg_to_log 'I' '100'
                       ls_rxx-id_prm
                       lv_anlage
                       ls_rxx-id_flux
                       lv_texte_statut.

* Mise à jour de la ligne de flux R04 avec son statut
  ls_rxx-statut      = lv_statut_flux.
  ls_rxx-msg         = lv_message.
  ls_rxx-msgty       = sy-msgty.
  ls_rxx-msgid       = sy-msgid.
  ls_rxx-msgno       = sy-msgno.
  ls_rxx-msgv1       = sy-msgv1.
  ls_rxx-msgv2       = sy-msgv2.
  ls_rxx-msgv3       = sy-msgv3.
  ls_rxx-msgv4       = sy-msgv4.
  ls_rxx-date_modif  = sy-datum.
  ls_rxx-heure_modif = sy-uzeit.
  ls_rxx-changedby   = sy-uname.

  CASE ls_rxx-id_flux.
    WHEN 'R04'.
      MOVE-CORRESPONDING ls_rxx TO ls_r04.
      UPDATE zintf_e_r04 FROM ls_r04.
    WHEN 'R15'.
      MOVE-CORRESPONDING ls_rxx TO ls_r15.
      UPDATE zintf_e_r15 FROM ls_r15.
    WHEN 'R16'.
      MOVE-CORRESPONDING ls_rxx TO ls_r16.
      UPDATE zintf_e_r16 FROM ls_r16.
  ENDCASE.

ENDFORM.

************************************************************************
* Contrôles préalables des données de relève
* avant tout processus de mise à jour dans les bases de données
************************************************************************
FORM controles_ligne_releve CHANGING ev_error TYPE crmt_boolean.
************************************************************************
* Vérifier s'il s'agit d'une relève avec statut ANNULE (flux R15)
* Auquel cas la filtrer
************************************************************************
  IF  ls_rxx-statut_releve EQ 'ANNULE'
  AND ls_rxx-id_flux       EQ 'R15'.
    IF 1 = 2. MESSAGE e151(zintf_e_messages). ENDIF.
* Flux &1 PRM &2 Statut Relève &3 => passage au statut 11 "FILTRE"
    macro_add_msg_to_log 'E' '151'
                         ls_rxx-id_flux
                         ls_rxx-id_prm
                         ls_rxx-statut_releve ''.
    lv_statut_flux = lc_statut_11_filtre.
    ev_error = abap_true.
    RETURN.
  ENDIF.

************************************************************************
* Vérifier l'existence du PRM à la date de relève
************************************************************************
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num =
ls_rxx-id_prm ).
  IF lv_int_ui IS INITIAL.
    IF 1 = 2. MESSAGE e052(zintf_e_messages). ENDIF.
* PRM &1 non trouvé => passage au statut "Attention Action CRM"
    macro_add_msg_to_log 'E' '052'
                         ls_rxx-id_prm '' '' ''.
    lv_statut_flux = lc_statut_10_action_crm.
    ev_error = abap_true.
    RETURN.
  ENDIF.

* Récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = ls_rxx-date_fin_conso
    IMPORTING
      es_detail = ls_object
      ev_equnr  = lv_equnr
      ev_sernr  = lv_sernr.

  IF ls_object-installation IS INITIAL.
    IF 1 = 2. MESSAGE e241(zintf_e_messages). ENDIF.
* Aucune installation trouvée pour le PRM &1 à la date du &2
    macro_add_msg_to_log 'E' '241'
                         ls_rxx-id_prm
                         ls_rxx-date_fin_conso '' ''.
    ev_error = abap_true.
    RETURN.
  ENDIF.

  lv_anlage = ls_object-installation.

************************************************************************
* Vérifier l'existence du contrat actif à la date de relève
************************************************************************
  IF ls_object-contract IS INITIAL.
* PRM &1 non rattaché à un contrat actif à la date du &2
    IF 1 = 2. MESSAGE e045(zintf_e_messages). ENDIF.
    macro_add_msg_to_log 'E' '045'
                         ls_rxx-id_prm
                         ls_rxx-date_fin_conso '' ''.
    ev_error = abap_true.
    RETURN.
  ENDIF.

************************************************************************
* Vérifier l'existence d'une fiche info appareil à la date de relève
************************************************************************
  IF lv_sernr IS INITIAL.
* Pas de FIAP posée sur le contrat &1 du PCE &2 à la date du &3
    IF 1 = 2. MESSAGE e046(zintf_e_messages). ENDIF.
    macro_add_msg_to_log 'E' '046'
                         ls_object-contract
                         ls_rxx-id_prm
                         ls_rxx-date_fin_conso ''.
    ev_error = abap_true.
    RETURN.
  ENDIF.

************************************************************************
* Vérifier l'existence d'un équipement à la date de relève
************************************************************************
  IF lv_equnr IS INITIAL.
    IF 1 = 2. MESSAGE e232(zintf_e_messages). ENDIF.
* Aucun équipement pour le PRM &1 en date du &2
    macro_add_msg_to_log 'E' '232'
                         ls_rxx-id_prm
                         ls_rxx-date_fin_conso '' ''.
    ev_error = abap_true.
    RETURN.
  ENDIF.

  CLEAR ls_egerr.
  SELECT * FROM egerr
           INTO ls_egerr UP TO 1 ROWS
          WHERE equnr EQ lv_equnr
            AND bis   GE ls_rxx-date_fin_conso
            AND ab    LE ls_rxx-date_fin_conso.
  ENDSELECT.

  IF ls_egerr IS INITIAL.
    IF 1 = 2. MESSAGE e232(zintf_e_messages). ENDIF.
* Aucun équipement pour le PRM &1 en date du &2
    macro_add_msg_to_log 'E' '232'
                         ls_rxx-id_prm
                         ls_rxx-date_fin_conso '' ''.
    ev_error = abap_true.
    RETURN.
  ENDIF.

* Récupérer ou déterminer
* le numéro de compteur (ou numéro de série) transmis dans le flux
  CLEAR lv_egerr_info.

  CASE ls_rxx-id_flux.
    WHEN 'R04'.
      lv_egerr_info = ls_rxx-matr_compteur.
    WHEN 'R15'.
      LOOP AT lt_rxx_3
         INTO ls_rxx_3
        WHERE num_serie NE space.
        lv_egerr_info = ls_rxx_3-num_serie.
        EXIT.
      ENDLOOP.
    WHEN 'R16'.
      LOOP AT lt_rxx_3
         INTO ls_rxx_3
        WHERE matr_compteur NE space.
        lv_egerr_info = ls_rxx_3-matr_compteur.
        EXIT.
      ENDLOOP.
  ENDCASE.

  IF NOT lv_egerr_info IS INITIAL.
************************************************************************
* Vérifier l'existence d'un numéro de compteur
* Si absence, mise à jour du numéro de compteur
************************************************************************
    IF ls_egerr-egerr_info IS INITIAL.
      ls_egerr_old = ls_egerr.
      ls_egerr-egerr_info = lv_egerr_info.

      CALL FUNCTION 'ISU_DB_EGERR_UPDATE'
        EXPORTING
          x_egerr         = ls_egerr
          x_egerr_old     = ls_egerr_old
          x_upd_mode      = 'U'
          x_no_change_doc = 'X'.

      IF 1 = 2. MESSAGE i248(zintf_e_messages). ENDIF.
* Mise à jour du numéro de compteur &1 pour l'équipement &2 du PRM &3
      macro_add_msg_to_log 'I' '248'
                           lv_egerr_info
                           lv_equnr
                           ls_rxx-id_prm ''.
    ELSEIF ls_egerr-egerr_info NE lv_egerr_info.
      IF 1 = 2. MESSAGE e252(zintf_e_messages). ENDIF.
* Numéro de compteur &1 invalide pour l'équipement &2 du PRM &3
      macro_add_msg_to_log 'E' '252'
                           lv_egerr_info
                           lv_equnr
                           ls_rxx-id_prm ''.
      ev_error = abap_true.
      RETURN.
    ENDIF.
  ENDIF.

************************************************************************
* Vérifier le nombre de cadrans
************************************************************************
* Déterminer le nombre de cadrans lié au groupe de cadrans de l'appareil
  CLEAR lv_nb_cadrans.
  SELECT MAX( zwnummer )
        INTO lv_nb_cadrans
        FROM ezwg
       WHERE zwgruppe EQ ls_egerr-zwgruppe.

* Récupérer (R04) ou déterminer (R15) (R16)
* le nombre de cadrans transmis dans le flux
  CASE ls_rxx-id_flux.
    WHEN 'R04'.
*     ls_rxx-nb_cadrans
    WHEN 'R15'.
      SELECT MAX( rang_cadran )
        INTO ls_rxx-nb_cadrans
        FROM zintf_e_r15_3
       WHERE idenreg EQ ls_rxx-idenreg.
    WHEN 'R16'.
      SELECT MAX( rang_cadran )
        INTO ls_rxx-nb_cadrans
        FROM zintf_e_r16_3
       WHERE idenreg EQ ls_rxx-idenreg.
  ENDCASE.

* Vérification du nombre de cadrans par rapport à celui attendu
  IF lv_nb_cadrans NE ls_rxx-nb_cadrans.
    IF 1 = 2. MESSAGE e225(zintf_e_messages). ENDIF.
* Nombre de cadrans invalide: &1 était attendu au lieu de &2
    macro_add_msg_to_log 'E' '225'
                         lv_nb_cadrans
                         ls_rxx-nb_cadrans '' ''.
    ev_error = abap_true.
    RETURN.
  ENDIF.
ENDFORM.
