FUNCTION zintf_e_depose_fiap_all_msg .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_ANLAGE) TYPE  ANLAGE
*"     REFERENCE(IV_DATE_DEPOSE) TYPE  DATS
*"     REFERENCE(IV_DATE_CADRAN) TYPE  DATS OPTIONAL
*"     REFERENCE(IV_ID_FLUX) TYPE  ZID_FLUX
*"     REFERENCE(IT_CADRANS) TYPE  ZINTF_CAD_RES_T OPTIONAL
*"     REFERENCE(IV_IDENREG) TYPE  ZIDENREG
*"     REFERENCE(IV_ID_PRM) TYPE  EXT_UI
*"     REFERENCE(IV_MES) TYPE  FLAG OPTIONAL
*"     REFERENCE(IV_RELEVE_02) TYPE  FLAG OPTIONAL
*"  EXPORTING
*"     REFERENCE(EV_STATUT) TYPE  I
*"  CHANGING
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA : ls_cadran TYPE zintf_cad_res.
  ev_statut = 2.

*DEB-IBEN-20190225-GE-4368
  IF cv_log_handle IS NOT INITIAL.
    lv_log_handle = cv_log_handle.
  ENDIF.
*FIN-IBEN-20190225-GE-4368

  lv_date = iv_date_depose + 1.

  PERFORM f_install_depose_fiap USING iv_anlage
                                      lv_date
                                      'ZE'
                             CHANGING lv_success.

  IF lv_success IS INITIAL.
* Le message d'erreur est émis dans la méthode
    RETURN.
  ENDIF.

  "Pas de MAJ index en cas date MES = Date dépose
  IF iv_mes = abap_true.
    ev_statut = 1.
    RETURN.
  ENDIF.

  IF iv_date_cadran IS INITIAL.
    lv_date = iv_date_depose .
  ELSE.
    lv_date = iv_date_cadran .
  ENDIF.

  REFRESH:
      lt_mr_data,
      lt_mr_reason.

  CALL FUNCTION 'BAPI_MTRREADDOC_GETLIST'
    EXPORTING
      installation      = iv_anlage
      mrdocumenttype    = '2'
    IMPORTING
      return            = ls_return
    TABLES
      mrdocumentdata    = lt_mr_data
      mrdocumentreasons = lt_mr_reason.

  INSERT iv_anlage INTO TABLE lt_anlage.

  lv_ok = abap_true .

  LOOP AT it_cadrans INTO ls_cadran.

***STOU DEBUT GE-1255
*    CLEAR ls_mr_data.
*    READ TABLE lt_mr_data
*          INTO ls_mr_data
*      WITH KEY targetmrdate = lv_date
*               register     = ls_cadran-register.

    LOOP AT lt_mr_data INTO ls_mr_data
                       WHERE targetmrdate = lv_date
                         AND register     = ls_cadran-register.
***STOU FIN   GE-1255

      CLEAR : ls_obj ,
              lt_auto .
* Ouverture de l'objet relève
      CALL FUNCTION 'ISU_O_METERREAD_OPEN'
        EXPORTING
          x_adatsoll            = lv_date
          x_action              = '01'
          x_ablbelnr            = ls_mr_data-mridnumber
          x_wmode               = '2'
          x_select2             = '1'
          x_no_dialog           = 'X'
          x_upd_online          = 'X'
          x_no_enqueue          = 'X'
          x_auto                = lt_auto
        IMPORTING
          y_obj                 = ls_obj
        EXCEPTIONS
          not_found             = 1
          foreign_lock          = 2
          internal_error        = 3
          input_error           = 4
          existing              = 5
          number_error          = 6
          general_fault         = 7
          system_error          = 8
          manual_abort          = 9
          gasdat_not_found      = 10
          no_mrrel_registers    = 11
          internal_warning      = 12
          not_authorized        = 13
          not_qualified         = 14
          anpstorno_not_allowed = 15
          already_billed        = 16
*         error_message         = 17
          OTHERS                = 16.

      IF NOT sy-subrc IS INITIAL.
        lv_ok = abap_false.
        macro_add_msg_system_to_log.
        RETURN.
      ENDIF.

      CLEAR ls_ieabl.
      READ TABLE ls_obj-ieabl
            INTO ls_ieabl     INDEX 1.

      IF NOT sy-subrc IS INITIAL.
        lv_ok = abap_false.
* Aucune relève pour l'installation &1 du PRM &2 en date du &3
        MESSAGE e171(zintf_e_messages)
           WITH iv_anlage
                iv_id_prm
                iv_date_depose
           INTO lv_message.
        RETURN.
      ENDIF.

      lv_index_entier    = trunc( ls_cadran-index_cad ).
      lv_index_decimales =  frac( ls_cadran-index_cad ).

      ls_ieabl-zwnummer             = ls_mr_data-register.
      ls_ieabl-v_zwstand            = lv_index_entier.
      ls_ieabl-n_zwstand            = lv_index_decimales.
      ls_ieabl-v_zwstndab           = lv_index_entier.
      ls_ieabl-n_zwstndab           = lv_index_decimales.
      ls_ieabl-adattats             = lv_date.
      ls_ieabl-ablstat              = '1'.
      ls_ieabl-istablart            = '01'.
      ls_ieabl-ablestyp             = '01'.
      ls_ieabl-zzidenreg            = iv_idenreg.

      MODIFY ls_obj-ieabl
        FROM ls_ieabl     INDEX 1.

      CALL FUNCTION 'ISU_O_METERREAD_OPEN_SUBOBJ'
        EXPORTING
          x_action   = '01'
          x_auto     = lt_auto
          x_adatsoll = lv_date
        CHANGING
          xy_obj     = ls_obj
        EXCEPTIONS
*         error_message = 1
          OTHERS     = 99.

      IF NOT sy-subrc IS INITIAL.
        lv_ok = abap_false.
        macro_add_msg_system_to_log.
        RETURN.
      ENDIF.

      CALL FUNCTION 'ISU_O_METERREAD_INPUT'
        CHANGING
          xy_obj = ls_obj
        EXCEPTIONS
*         error_message = 1
          OTHERS = 99.

      IF NOT sy-subrc IS INITIAL.
        lv_ok = abap_false.
        macro_add_msg_system_to_log.
        RETURN.
      ENDIF.

* Préparation de la sauvegarde
      CALL FUNCTION 'ISU_O_METERREAD_ACTION'
        EXPORTING
          x_okcode = 'PSAV'
        CHANGING
          xy_obj   = ls_obj
        EXCEPTIONS
*         error_message = 1
          OTHERS   = 99.

      IF NOT sy-subrc IS INITIAL.
        lv_ok = abap_false.
        macro_add_msg_system_to_log.
        RETURN.
      ENDIF.

* sauvegarde
      CALL FUNCTION 'ISU_O_METERREAD_ACTION'
        EXPORTING
          x_okcode = 'SAVE'
        CHANGING
          xy_obj   = ls_obj
        EXCEPTIONS
*         error_message = 1
          OTHERS   = 99.

      IF NOT sy-subrc IS INITIAL.
        lv_ok = abap_false.
        macro_add_msg_system_to_log.
        RETURN.
      ENDIF.

      CALL FUNCTION 'ISU_O_METERREAD_CLOSE'
        EXPORTING
          x_no_dialog = 'X'
        CHANGING
          xy_obj      = ls_obj
        EXCEPTIONS
*         error_message = 1
          OTHERS      = 99.

      IF NOT sy-subrc IS INITIAL.
        lv_ok = abap_false.
        macro_add_msg_system_to_log.
        RETURN.
      ENDIF.
    ENDLOOP. "++GE-1255

    IF iv_releve_02 = abap_on.
      lv_releve_active = '1'.
      PERFORM creation_ordre_releve_02 USING iv_idenreg
                                             lv_releve_active
                                             lv_date
                                             ls_mr_data-register
                                             ls_cadran-index_cad
                                    CHANGING lv_ok.

      IF lv_ok EQ abap_false.
        EXIT.
      ENDIF.
    ENDIF.
  ENDLOOP.

  IF lv_ok = abap_true.
    ev_statut = 1.
  ENDIF.


ENDFUNCTION.

FORM f_install_depose_fiap USING iv_install	TYPE anlage
                                 iv_date_effet  TYPE datum
                                 iv_sparte  TYPE sparte
                           CHANGING ev_success TYPE crmt_boolean.

  DATA: lv_nb_cadrans TYPE i,
        ls_zw         TYPE isu07_zw,
        ls_auto       TYPE isu07_install_auto,
        ls_auto_ger   TYPE isu07_auto_ger,
        lv_db_update  TYPE e_update,
        lv_message    TYPE string,
        lv_matnr      TYPE matnr,
        lv_zwgruppe   TYPE e_zwgruppe,
        lv_equnr      TYPE equnr,
        lv_sernr      TYPE lsernr,
        lv_geraet     TYPE geraet,
        lt_cadrans    TYPE TABLE OF ezwg,
        ls_cadrans    TYPE ezwg.

  INCLUDE: iee07action.

  CLEAR ev_success.

* Si l'installation n'est pas fournie, on redétermine tout

    CALL METHOD zcl_tool=>pod_get_related_object
      EXPORTING
        iv_installation = iv_install
        iv_date         = iv_date_effet
      IMPORTING
        ev_matnr        = lv_matnr
        ev_equnr        = lv_equnr.

* On doit déterminer le matériel (article) et le groupe de cadrans
  SELECT       egerr~matnr
               egerr~geraet
               egerr~zwgruppe
         INTO (lv_matnr,
               lv_sernr,
               lv_zwgruppe) UP TO 1 ROWS
         FROM eastl AS eastl
   INNER JOIN egerr AS egerr
           ON egerr~logiknr EQ eastl~logiknr
          AND egerr~bis     GE eastl~ab
          AND egerr~ab      LE eastl~bis
        WHERE eastl~anlage  EQ iv_install
          AND eastl~bis     GE iv_date_effet
          AND eastl~ab      LE iv_date_effet
          AND egerr~bis     GE iv_date_effet
          AND egerr~ab      LE iv_date_effet.
  ENDSELECT.

  IF sy-subrc NE 0.
    IF iv_sparte = 'ZE'.
* Numéro d'équipement &1 inconnu dans EGERR
      MESSAGE e066(zintf_e_messages)
         WITH lv_equnr
         INTO lv_message.
    ELSE.
*   ADIF : Impossible de trouver le numéro d'équipement &1 dans EGERR
      MESSAGE e066(zintf_g_messages)
         WITH lv_equnr
         INTO lv_message.
    ENDIF.
    EXIT.
  ENDIF.

  " Vérification du type d'appareil pour déterminer le nombre de cadrans
  REFRESH lt_cadrans.
  SELECT * FROM ezwg
     INTO TABLE lt_cadrans
          WHERE zwgruppe = lv_zwgruppe.

  IF sy-subrc NE 0.
* Impossible de trouver la configuration de l'équipement => On quitte !
    IF iv_sparte = 'ZE'.
* Groupe de cadrans &1 du type d'appareil &2 lié à l'équipement &3
* inconnu
      MESSAGE e067(zintf_e_messages)
         WITH lv_zwgruppe
              lv_matnr
              lv_equnr
         INTO lv_message.
    ELSE.
* ADIF : Configuration des cadrans du produit &1 inexistante
      MESSAGE e067(zintf_g_messages)
         WITH lv_matnr
         INTO lv_message.
    ENDIF.
    EXIT.
  ENDIF.

  ls_auto-interface-anlage        = iv_install.
* Dépose pour calcul de facturation
  ls_auto-interface-action        = co_close_relation.
  ls_auto-interface-eadat         = iv_date_effet.
  ls_auto-interface-upd_online    = abap_true.
  ls_auto-interface-no_dialog     = abap_true.
  ls_auto-interface-no_event      = abap_true.
  ls_auto-interface-no_statistic  = abap_true.
  ls_auto-interface-no_change_doc = abap_true.

* Sauvegarde
    ls_auto-okcode                = 'SAVE'.

  ls_auto-zwstand                 = abap_true.

* Dépose de tous les cadrans
  LOOP AT lt_cadrans INTO ls_cadrans.
    CLEAR ls_zw.
    ls_zw-geraeta   = lv_sernr.
    ls_zw-spartype  = ls_cadrans-spartyp.
    ls_zw-matnra    = lv_matnr.
    ls_zw-zwstandca = '0'.
    ls_zw-zwnummera = ls_cadrans-zwnummer.
    IF iv_sparte = 'ZE'.
      ls_zw-spartypa  = '01'. "Electricité
    ELSE.
      ls_zw-spartypa  = '02'. "Gaz
    ENDIF.
    ls_zw-anzerg    = ls_cadrans-anzerg.
    APPEND ls_zw TO ls_auto-auto_zw.
  ENDLOOP.

* Données de l'appareil
  ls_auto_ger-geraetalt = lv_sernr.
  ls_auto_ger-matnralt  = lv_matnr.
  IF iv_sparte = 'ZE'.
    ls_auto_ger-sparte  = 'ZE'. "Electricité
  ELSE.
    ls_auto_ger-sparte  = 'ZG'. "Gaz
  ENDIF.
* Dépose pour calcul de facturation
  ls_auto_ger-action    = co_close_relation.
  ls_auto_ger-ausbau    = abap_true.
  APPEND ls_auto_ger TO ls_auto-auto_ger.

* Dépose FIAP
  CALL FUNCTION 'ISU_S_WORKLIST_INSTALL'
    EXPORTING
      x_anlage        = iv_install
      x_eadat         = iv_date_effet
      x_geraetalt     = ls_auto_ger-geraetalt
      x_matnralt      = ls_auto_ger-matnralt
* Dépose pour calcul de facturation
      x_action        = co_close_relation
      x_spartea       = ls_auto_ger-sparte "'ZG'
      x_upd_online    = abap_true
      x_no_dialog     = abap_true
      x_no_event      = abap_true
      x_no_statistic  = abap_true
      x_no_change_doc = abap_true
    IMPORTING
      y_db_update     = lv_db_update
    CHANGING
      xy_auto         = ls_auto
    EXCEPTIONS
      not_found       = 1
      foreign_lock    = 2
      invalid         = 3
      internal_error  = 4
      not_qualified   = 5
      input_error     = 6
      system_error    = 7
      not_customized  = 8
*     error_message   = 9
      OTHERS          = 99.

* Si code retour <> 0, il y a forcément eu un problème
* Sinon, si nous ne sommes pas en mode test,
* il faut impérativement que le flag de mise à jour de la BDD soit 'X'
  IF ( sy-subrc NE 0 )
  OR ( lv_db_update IS INITIAL ).
    CLEAR ev_success.
  ELSE.
    ev_success = abap_true.
  ENDIF.
ENDFORM.
