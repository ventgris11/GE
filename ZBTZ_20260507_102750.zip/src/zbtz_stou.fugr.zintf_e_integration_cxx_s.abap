FUNCTION ZINTF_E_INTEGRATION_CXX_S.
*"--------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_IDENREG) TYPE  ZIDENREG
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN DEFAULT ABAP_FALSE
*"     REFERENCE(IV_ID_FLUX) TYPE  ZID_FLUX
*"  EXPORTING
*"     REFERENCE(EV_ERROR) TYPE  CRMT_BOOLEAN
*"--------------------------------------------------------------------

  lv_log_object    = lc_log_object_intf_elec.
  lv_log_subobject = lc_log_subobject_c01.
  lv_msgid         = lc_msgid_intf_elec.

* Appel en mode &1 pour le flux &2
  IF 1 = 2. MESSAGE i018(zintf_e_messages). ENDIF.
  IF iv_mode_test IS INITIAL.
    macro_add_msg_to_log 'I' '018'
                         'REEL' iv_id_flux '' ''.
  ELSE.
    macro_add_msg_to_log 'I' '018'
                         'TEST' iv_id_flux '' ''.
  ENDIF.

  lv_id_flux = iv_id_flux.

  IF lv_id_flux = 'C01'.

* Sélection des données à traiter
    SELECT SINGLE *
      INTO CORRESPONDING FIELDS OF ls_cxx
      FROM zintf_e_c01
     WHERE idenreg EQ iv_idenreg.

    SELECT *
      INTO TABLE lt_c01_2
      FROM zintf_e_c01_2
     WHERE idenreg EQ iv_idenreg
  ORDER BY idenreg
           id_periode.

    SELECT *
      INTO TABLE lt_c01_3
      FROM zintf_e_c01_3
     WHERE idenreg EQ iv_idenreg
  ORDER BY idenreg
           id_periode
           rang_cadran.

  ELSEIF lv_id_flux = 'C15'.

* Sélection des données à traiter
    SELECT SINGLE *
      INTO CORRESPONDING FIELDS OF ls_cxx
      FROM zintf_e_c15
     WHERE idenreg EQ iv_idenreg.

    SELECT *
       INTO TABLE lt_c15_2
       FROM zintf_e_c15_2
      WHERE idenreg EQ iv_idenreg
   ORDER BY idenreg
            id_releve.

    SELECT *
       INTO TABLE lt_c15_2b
       FROM zintf_e_c15_2b
      WHERE idenreg EQ iv_idenreg.

    SELECT *
        INTO TABLE lt_c15_3
        FROM zintf_e_c15_3
       WHERE idenreg EQ iv_idenreg
    ORDER BY idenreg
             id_releve.
  ENDIF.

* Par défaut, le flag erreur est positionné à VRAI
* Seule la réussite de l'intégration positionnera le flag à FAUX
  ev_error = abap_true.

  lv_statut_flux    = ls_cxx-statut.
  lv_zz_ref_externe = ls_cxx-num_dossier.

  CASE lv_id_flux.
    WHEN 'C01'.
      IF ls_cxx-even_declencheur     EQ 'S'.
        PERFORM mise_en_service_contrat      USING iv_mode_test
                                          CHANGING ev_error.
      ELSEIF ls_cxx-even_declencheur EQ 'R'.
        PERFORM mise_hors_service_contrat    USING iv_mode_test
                                          CHANGING ev_error.
      ELSEIF ls_cxx-even_declencheur EQ 'M'.
        PERFORM modification_contrat         USING iv_mode_test
                                          CHANGING ev_error.
      ELSE.
* Type d'événement &1 non géré pour les infos contrat &2 du PRM &3
        IF 1 = 2. MESSAGE e084(zintf_e_messages). ENDIF.
        macro_add_msg_to_log 'E' '084'
                             ls_cxx-even_declencheur
                             ls_cxx-id_flux
                             ls_cxx-id_prm ''.
        PERFORM update_ligne_cxx USING lc_statut_06_rejet.
        RETURN.
      ENDIF.
    WHEN 'C15'.
      IF ls_cxx-nature_evenement     EQ 'MES'
      OR ls_cxx-nature_evenement     EQ 'CFNE'.
        PERFORM mise_en_service_contrat      USING iv_mode_test
                                          CHANGING ev_error.
      ELSEIF ls_cxx-nature_evenement EQ 'RES'
          OR ls_cxx-nature_evenement EQ 'CFNS'.
        PERFORM mise_hors_service_contrat    USING iv_mode_test
                                          CHANGING ev_error.
      ELSEIF ls_cxx-nature_evenement EQ 'CMAT'
          OR ls_cxx-nature_evenement EQ 'MCT'
          OR ls_cxx-type_evenement   EQ 'MIGRATION'.
        PERFORM modification_contrat         USING iv_mode_test
                                          CHANGING ev_error.
      ELSE.
* Type d'événement &1 non géré pour les infos contrat &2 du PRM &3
        IF 1 = 2. MESSAGE e084(zintf_e_messages). ENDIF.
        macro_add_msg_to_log 'E' '084'
                             ls_cxx-nature_evenement
                             ls_cxx-id_flux
                             ls_cxx-id_prm ''.
        PERFORM update_ligne_cxx USING lc_statut_06_rejet.
        RETURN.
      ENDIF.
  ENDCASE.

ENDFUNCTION.

FORM update_ligne_cxx USING ev_statut TYPE zintf_g_statut.

  DATA:
    lv_texte_statut TYPE text30.

  CASE ev_statut.
    WHEN '01'. lv_texte_statut = 'A intégrer               '.
    WHEN '02'. lv_texte_statut = 'A rejouer                '.
    WHEN '03'. lv_texte_statut = 'MEA - Synchronisation CRM'.
    WHEN '04'. lv_texte_statut = 'MEA - Rejet              '.
    WHEN '05'. lv_texte_statut = 'Acquitté                 '.
    WHEN '06'. lv_texte_statut = 'Rejet                    '.
    WHEN '07'. lv_texte_statut = 'Intégré                  '.
    WHEN '10'. lv_texte_statut = 'En attente d''action CRM  '.
    WHEN '11'. lv_texte_statut = 'Filtré                   '.
    WHEN '12'. lv_texte_statut = 'Synchronisé              '.
    WHEN '13'. lv_texte_statut = 'Gelé                     '.
    WHEN '14'. lv_texte_statut = 'Action manuelle          '.
    WHEN '15'. lv_texte_statut = 'MEA - Action manuelle    '.
    WHEN '16'. lv_texte_statut = 'MEA - Intégration        '.
  ENDCASE.

* Mise à jour de la ligne C01
  ls_cxx-statut      = ev_statut.
  ls_cxx-msg         = lv_message.
  ls_cxx-msgty       = sy-msgty.
  ls_cxx-msgid       = sy-msgid.
  ls_cxx-msgno       = sy-msgno.
  ls_cxx-msgv1       = sy-msgv1.
  ls_cxx-msgv2       = sy-msgv2.
  ls_cxx-msgv3       = sy-msgv3.
  ls_cxx-msgv4       = sy-msgv4.
  ls_cxx-date_modif  = sy-datum.
  ls_cxx-heure_modif = sy-uzeit.
  ls_cxx-changedby   = sy-uname.

  IF lv_id_flux = 'C01'.
    MOVE-CORRESPONDING ls_cxx TO ls_c01.
    UPDATE zintf_e_c01 FROM ls_c01.
  ELSEIF lv_id_flux = 'C15'.
    MOVE-CORRESPONDING ls_cxx TO ls_c15.
    UPDATE zintf_e_c15 FROM ls_c15.
  ENDIF.

  IF 1 = 2. MESSAGE i100(zintf_e_messages). ENDIF.
* PRM &1 Installation &2 Flux &3 => &4
  macro_add_msg_to_log 'I' '100'
                       ls_cxx-id_prm
                       lv_anlage
                       ls_cxx-id_flux
                       lv_texte_statut.

ENDFORM.
