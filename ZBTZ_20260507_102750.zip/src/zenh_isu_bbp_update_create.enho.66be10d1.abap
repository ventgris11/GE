"Name: \FU:ISU_BBP_UPDATE_CREATE\SE:END\EI
ENHANCEMENT 0 ZENH_ISU_BBP_UPDATE_CREATE.
** En standard, SAP ne génère pas le formulaire du plan de mensualisation en dehors de la transaction EA61. Ce fonctionnement est incorrect car
** nous ne disposons pas du formulaire ni dans la réplication (MOVE_IN_BBP) ni dans le cas d'une remensu suite à une facture de régul
  zcl_tool=>check_enh_active( exporting IV_ENHANCEMENT_NAME = 'ZENH_ISU_BBP_UPDATE_CREATE'
                              importing ev_active = DATA(lv_active) ).
  CHECK lv_active IS NOT INITIAL.
  IF xy_obj-eabp-art EQ '2' " Facturation
    OR xy_obj-eabp-art = '1'  " Emménagement
    OR xy_obj-eabp-art = '0'. " Bascule BIM vers MENS (création du plan via MF directement)
    xy_obj-contr-no_dialog = abap_true. " On ne veut pas de popup
    x_printparams-PRINTPARAMS-tddest = 'ZADS'.
    X_PRINTPARAMS-PRINTPARAMS-DELAYED_PRINT = abap_true. " Paramètre à forcer pour réellement imprimer
    CLEAR xy_obj-reprint.
    CALL FUNCTION 'ISU_BBP_FILL_REPRINT'
      EXPORTING
        k_effak  = 'X'
        k_effag  = 'X'
        k_effav  = 'X'
        k_t_ever = 'X'
        k_eabps  = 'X'
        k_t_eabp = 'X'
        k_ejvlk  = 'X'
        k_t_ejvl = 'X'
      CHANGING
        xy_obj   = xy_obj.

    PERFORM f25_process_rc USING xy_obj-eabp
                                 l_rc
                        CHANGING l_objkey.
    PERFORM f25_process_reprint USING l_objkey
                                      x_printparams
                             CHANGING xy_obj.
  ENDIF.
ENDENHANCEMENT.
