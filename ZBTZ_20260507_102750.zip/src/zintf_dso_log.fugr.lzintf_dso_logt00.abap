*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 11.06.2019 at 17:56:48
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZINTF_DSO_LOG...................................*
DATA:  BEGIN OF STATUS_ZINTF_DSO_LOG                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_DSO_LOG                 .
CONTROLS: TCTRL_ZINTF_DSO_LOG
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZINTF_DSO_LOG                 .
TABLES: ZINTF_DSO_LOG                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
