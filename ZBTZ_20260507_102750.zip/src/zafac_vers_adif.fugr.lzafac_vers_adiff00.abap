*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 20.02.2019 at 16:37:18
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
