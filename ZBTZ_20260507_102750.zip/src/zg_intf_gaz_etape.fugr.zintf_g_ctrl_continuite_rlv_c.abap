FUNCTION zintf_g_ctrl_continuite_rlv_c.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
* Création   : (GE-11713)                                              *
* DATE       : 14/10/2021                                              *                                                                                                                                                                      *
* USER       : HBENDHAFER                                              *
* TAG        : HBD                                                     *
* Description: Controle continuité date/index                          *
* OT         : DI1K928978                                              *
*"----------------------------------------------------------------------


ENDFUNCTION.
