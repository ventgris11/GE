FUNCTION zintf_g_ctrl_rlv_bascule_1m.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA: lc_field_raison_rlv  TYPE fieldname VALUE 'RAISON_RELEVE',
        lc_field_num_pce     TYPE fieldname VALUE 'NUM_PCE',
        lc_field_id_flux     TYPE fieldname VALUE 'FLUX',
        lc_field_fin_periode TYPE fieldname VALUE 'FIN_PERIODE',
        lv_field             TYPE string,
        lv_int_ui            TYPE int_ui,
        lv_message           TYPE char255,
        lt_re1m              TYPE TABLE OF zintf_g_re1m.

  CONSTANTS:
    lc_raison_87 TYPE char2 VALUE '87', "Bascule 1M
    lc_raison_89 TYPE char2 VALUE '89'.  "Bascule 1M

  FIELD-SYMBOLS: <fs>, <fs_num_pce>, <fs_flux>, <fs_date_fin_periode>.

  DEFINE macro_add_message_to_log.
    ev_etape = 2.
    MESSAGE &1(zintf_g_messages)
       WITH &2
            &3
            &4
            &5
       INTO lv_message.
    RETURN.
  END-OF-DEFINITION.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_raison_rlv INTO lv_field.
  ASSIGN (lv_field) TO <fs>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_id_flux INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_fin_periode INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_fin_periode>.

  IF <fs_flux> = 'RE6M'.
    IF <fs> IS ASSIGNED.
      IF <fs> EQ lc_raison_87 OR
        <fs> EQ lc_raison_89.
        " si raison bascule 1M, on vérifie présence de flux 1M
*DEB-GLIC-20191219 - GE-7640
*        SELECT *
*          INTO TABLE lt_re1m
*          FROM zintf_g_re1m
*          WHERE num_pce = <fs_num_pce>
*          AND statut <> 7
*          AND debut_periode = <fs_date_fin_periode>.
        SELECT *
          INTO TABLE lt_re1m
          FROM zintf_g_re1m
          WHERE num_pce = <fs_num_pce>.
*FIN-GLIC-20191219 - GE-7640
        IF lt_re1m IS NOT INITIAL.
          ev_etape = 1.
        ELSE.
          IF 1 = 2. MESSAGE e503(zintf_g_messages). ENDIF.
          macro_add_message_to_log e503 <fs_num_pce> '' '' ''.
        ENDIF.
*GE-7446 - GLIC - 23/12/2019 - Début
      ELSE.
        ev_etape = 1.
      ENDIF.
*GE-7446 - GLIC - 23/12/2019 - Fin
    ENDIF.
  ELSE.
    ev_etape = 1.
  ENDIF.

ENDFUNCTION.
