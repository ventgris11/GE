*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFKCITOP.                          " Global Data
INCLUDE LZFKCIEVE.
*  INCLUDE LFKCIEVE.
  INCLUDE LZFKCIUXX.                          " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LFKCIF...                          " Subprograms
* INCLUDE LFKCIO...                          " PBO-Modules
* INCLUDE LFKCII...                          " PAI-Modules

INCLUDE LZFKCIO01.
*INCLUDE LFKCIO01.

INCLUDE LZFKCIF01.
*INCLUDE LFKCIF01.

INCLUDE LZFKCII01.
*INCLUDE LFKCII01.

INCLUDE LZFKCIINI.
*INCLUDE LFKCIINI.

INCLUDE LZFKCIF02.
*INCLUDE LFKCIF02.
