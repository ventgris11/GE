*----------------------------------------------------------------------*
***INCLUDE LFKMBF03 .
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  DUNNING_BLOCK_IN_ACC
*&---------------------------------------------------------------------*
FORM message_dunning_block_in_acc USING i_gpart LIKE fkkvkp-gpart
                                    i_vkont LIKE fkkvkp-vkont
                                    i_mansp LIKE dfkklocks-lockr.

  STATICS: BEGIN OF vkont_tab OCCURS 10,
             gpart LIKE fkkop-gpart,
             vkont LIKE fkkop-vkont,
           END OF vkont_tab.

  READ TABLE vkont_tab INDEX 1.
  IF sy-subrc = 0 AND vkont_tab-gpart NE i_gpart.
    REFRESH vkont_tab.
  ENDIF.
  vkont_tab-gpart = i_gpart.
  vkont_tab-vkont = i_vkont.
  READ TABLE vkont_tab WITH KEY gpart = i_gpart vkont = i_vkont.
  IF sy-subrc NE 0.
    PERFORM message_append USING '>3' 'S' '223' i_vkont i_gpart i_mansp
                                                space
                                                '4'.
    IF 1 = 2. MESSAGE e223 WITH i_vkont i_gpart i_mansp. ENDIF.
    APPEND vkont_tab.
*   Increment the counter for accounts with dunning locks
    CALL FUNCTION 'FKKMACNT_ADD_COUNTER'
      EXPORTING
        i_countid = con_count_dunnlock_account.
  ENDIF.

ENDFORM.                               " DUNNING_BLOCK_IN_ACC

*&---------------------------------------------------------------------*
*&      Form  POST_BLOCK_IN_ACCOUNT
*&---------------------------------------------------------------------*
FORM post_block_in_account USING i_gpart LIKE fkkvkp-gpart
                                 i_vkont LIKE fkkvkp-vkont
                                 i_postblock LIKE dfkklocks-lockr.

  STATICS: BEGIN OF vkont_tab OCCURS 10,
             gpart LIKE fkkop-gpart,
             vkont LIKE fkkop-vkont,
           END OF vkont_tab.

  READ TABLE vkont_tab INDEX 1.
  IF sy-subrc = 0 AND vkont_tab-gpart NE i_gpart.
    REFRESH vkont_tab.
  ENDIF.
  vkont_tab-gpart = i_gpart.
  vkont_tab-vkont = i_vkont.
  READ TABLE vkont_tab WITH KEY gpart = i_gpart vkont = i_vkont.
  IF sy-subrc NE 0.
    PERFORM message_append USING '>3' 'S' '295' i_vkont i_postblock
                                                space space '2'.
    IF 1 = 2. MESSAGE e295 WITH i_vkont i_postblock. ENDIF.
    APPEND vkont_tab.
*   Increment the counter for accounts with posting locks
    CALL FUNCTION 'FKKMACNT_ADD_COUNTER'
      EXPORTING
        i_countid = con_count_postlock_account.
  ENDIF.

ENDFORM.                               " DUNNING_BLOCK_IN_ACCOUNT


*&---------------------------------------------------------------------*
*&      Form  CHECK_BLOCK_IN_VKONT
*&---------------------------------------------------------------------*
*       This form must be the first to look for locks
*       via FKK_S_LOCK_GET because the initialization takes place here!
*&---------------------------------------------------------------------*
FORM check_block_in_vkont USING    i_fkkvkp STRUCTURE fkkvkp
                          CHANGING p_mansp LIKE dfkklocks-lockr
                                   p_postblock LIKE dfkklocks-lockr.

  DATA: ls_structure LIKE dfkkop.
  DATA it_dfklock LIKE dfkklocks OCCURS 0 WITH HEADER LINE.
  DATA it_dependant_dfklock LIKE dfkklocks OCCURS 0 WITH HEADER LINE.
  DATA: l_x_lock_exist_first(1) TYPE c.
  DATA: l_x_lock_exist(1) TYPE c.
  DATA: l_x_dependant_lock_exist(1) TYPE c.

  ls_structure-gpart = i_fkkvkp-gpart.
  ls_structure-vkont = i_fkkvkp-vkont.
  CLEAR l_x_lock_exist_first.

* Initialize mass access for FKK_S_LOCK_GET for all process IDs
  PERFORM initialize_lock_get USING i_fkkvkp gl_para_0300-ausdt.

* check dunning block in contract account
  CALL FUNCTION 'FKK_S_LOCK_GET'
    EXPORTING
      i_keystructure           = ls_structure
      i_lotyp                  = gc_lotyp_partner_account
      i_proid                  = gc_proid_dunning
      i_lockdate               = gl_para_0300-ausdt
      i_x_mass_access          = 'X'
      i_x_dependant_locktypes  = space
    IMPORTING
      e_x_lock_exist           = l_x_lock_exist_first
      e_x_dependant_lock_exist = l_x_dependant_lock_exist
    TABLES
      et_locks                 = it_dfklock
      et_dependant_locks       = it_dependant_dfklock.

  READ TABLE it_dfklock INDEX 1.
  IF sy-subrc = 0.
    p_mansp = it_dfklock-lockr.
*    move-corresponding it_dfklock to i_fkkcfcslocks.
  ELSE.
    CLEAR p_mansp.
* check general posting block in contract account
*    CALL FUNCTION 'FKK_S_LOCK_GET'
*      EXPORTING
*        i_keystructure           = ls_structure
*        i_lotyp                  = gc_lotyp_partner_account
*        i_proid                  = gc_proid_post
*        i_lockdate               = gl_para_0300-ausdt
*        i_x_mass_access          = 'X'
*        i_x_dependant_locktypes  = space
*      IMPORTING
*        e_x_lock_exist           = l_x_lock_exist_first
*        e_x_dependant_lock_exist = l_x_dependant_lock_exist
*      TABLES
*        et_locks                 = it_dfklock
*        et_dependant_locks       = it_dependant_dfklock.
*
*    READ TABLE it_dfklock INDEX 1.
*    IF sy-subrc = 0.
*      p_postblock = it_dfklock-lockr.
**      move-corresponding it_dfklock to i_fkkcfcslocks.
*    ELSE.
*      CLEAR p_postblock.
*    ENDIF.
  ENDIF.

ENDFORM.                               " CHECK_BLOCK_IN_VKONT
*&---------------------------------------------------------------------*
*&      Form  GET_PAYMENT_BLOCK_IN_ITEM
*&---------------------------------------------------------------------*
FORM get_payment_block_in_item
         USING    i_fkkop LIKE fkkop
         CHANGING paym_block_in_item LIKE dfkklocks-lockr.

  DATA: ls_structure LIKE dfkkop.
  DATA it_dfklock LIKE dfkklocks OCCURS 0 WITH HEADER LINE.
  DATA it_dependant_dfklock LIKE dfkklocks OCCURS 0 WITH HEADER LINE.
  DATA: l_x_lock_exist_first(1) TYPE c.
  DATA: l_x_lock_exist(1) TYPE c.
  DATA: l_x_dependant_lock_exist(1) TYPE c.

  ls_structure-gpart = i_fkkop-gpart.
  ls_structure-vkont = i_fkkop-vkont.
  ls_structure-opbel = i_fkkop-opbel.
  ls_structure-opupk = i_fkkop-opupk.
  ls_structure-opupw = i_fkkop-opupw.
  ls_structure-opupz = i_fkkop-opupz.
  CLEAR l_x_lock_exist_first.

  CALL FUNCTION 'FKK_S_LOCK_GET'
       EXPORTING
            i_keystructure           = ls_structure
            i_lotyp                  = gc_lotyp_position
            i_proid                  = gc_proid_in_out_pay
            i_lockdate               = gl_para_0300-ausdt
            i_x_mass_access          = 'X'
            i_x_dependant_locktypes  = 'X'
*            i_x_only_check_locks     = 'X'
      IMPORTING
            e_x_lock_exist           = l_x_lock_exist_first
            e_x_dependant_lock_exist = l_x_dependant_lock_exist
      TABLES
            et_locks                 = it_dfklock
            et_dependant_locks       = it_dependant_dfklock.

  READ TABLE it_dfklock INDEX 1.
  IF sy-subrc = 0.
    paym_block_in_item = it_dfklock-lockr.
  ELSE.
    IF i_fkkop-opupw = '000'.
      CLEAR paym_block_in_item.
    ELSE.

      CLEAR ls_structure-opupw.
      CLEAR l_x_lock_exist_first.

      CALL FUNCTION 'FKK_S_LOCK_GET'
           EXPORTING
                i_keystructure           = ls_structure
                i_lotyp                  = gc_lotyp_position
                i_proid                  = gc_proid_inc_pay
                i_lockdate               = gl_para_0300-ausdt
                i_x_mass_access          = 'X'
                i_x_dependant_locktypes  = 'X'
*                i_x_only_check_locks     = 'X'
          IMPORTING
                e_x_lock_exist           = l_x_lock_exist_first
                e_x_dependant_lock_exist = l_x_dependant_lock_exist
          TABLES
                et_locks                 = it_dfklock
                et_dependant_locks       = it_dependant_dfklock.

      READ TABLE it_dfklock INDEX 1.
      IF sy-subrc = 0.
        paym_block_in_item = it_dfklock-lockr.
* when we have an instalment plan or a bbp then we can block the whole
* plan from payment run with setting the dunning block on the sample
* document
      ELSEIF ls_structure-opupw NE '000'.
        ls_structure-opupw = '000'.
        ls_structure-opupz = '000'.

        CALL FUNCTION 'FKK_S_LOCK_GET'
          EXPORTING
            i_keystructure           = ls_structure
            i_lotyp                  = gc_lotyp_position
            i_proid                  = gc_proid_inc_pay
            i_lockdate               = gl_para_0300-ausdt
            i_x_mass_access          = 'X'
            i_x_dependant_locktypes  = space
          IMPORTING
            e_x_lock_exist           = l_x_lock_exist_first
            e_x_dependant_lock_exist = l_x_dependant_lock_exist
          TABLES
            et_locks                 = it_dfklock
            et_dependant_locks       = it_dependant_dfklock.

        READ TABLE it_dfklock INDEX 1.
        IF sy-subrc = 0.
          paym_block_in_item = it_dfklock-lockr.
        ELSE.
          CLEAR paym_block_in_item.
        ENDIF.
      ELSE.
        CLEAR paym_block_in_item.
      ENDIF.
    ENDIF.
  ENDIF.

ENDFORM.                               " GET_PAYMENT_BLOCK_IN_ITEM

*&---------------------------------------------------------------------*
*&      Form  DUNNING_BLOCK_IN_ITEM
*&---------------------------------------------------------------------*
FORM dunning_block_in_item
         USING    i_fkkop LIKE fkkop
         CHANGING dunn_block_in_item LIKE dfkklocks-lockr.

  DATA: ls_structure LIKE dfkkop.
  DATA it_dfklock LIKE dfkklocks OCCURS 0 WITH HEADER LINE.
  DATA it_dependant_dfklock LIKE dfkklocks OCCURS 0 WITH HEADER LINE.
  DATA: l_x_lock_exist_first(1) TYPE c.
  DATA: l_x_lock_exist(1) TYPE c.
  DATA: l_x_dependant_lock_exist(1) TYPE c.

  ls_structure-gpart = i_fkkop-gpart.
  ls_structure-vkont = i_fkkop-vkont.
  ls_structure-opbel = i_fkkop-opbel.
  ls_structure-opupk = i_fkkop-opupk.
  ls_structure-opupw = i_fkkop-opupw.
  ls_structure-opupz = i_fkkop-opupz.
  CLEAR l_x_lock_exist_first.
  CALL FUNCTION 'FKK_S_LOCK_GET'
    EXPORTING
      i_keystructure           = ls_structure
      i_lotyp                  = gc_lotyp_position
      i_proid                  = gc_proid_dunning
      i_lockdate               = gl_para_0300-ausdt
      i_x_mass_access          = 'X'
      i_x_dependant_locktypes  = space
    IMPORTING
      e_x_lock_exist           = l_x_lock_exist_first
      e_x_dependant_lock_exist = l_x_dependant_lock_exist
    TABLES
      et_locks                 = it_dfklock
      et_dependant_locks       = it_dependant_dfklock.

  READ TABLE it_dfklock INDEX 1.
  IF sy-subrc = 0.
*   dunn_block_in_item = it_dfklock-lockr.
    PERFORM set_dunn_block_in_item TABLES it_dfklock
                                   CHANGING dunn_block_in_item.
* when we have an instalment plan or a bbp then we can block the whole
* plan from being dunned with setting the dunning block on the sample
* document
  ELSEIF ls_structure-opupw NE '000'.
    ls_structure-opupw = '000'.
    ls_structure-opupz = '000'.

    CALL FUNCTION 'FKK_S_LOCK_GET'
      EXPORTING
        i_keystructure           = ls_structure
        i_lotyp                  = gc_lotyp_position
        i_proid                  = gc_proid_dunning
        i_lockdate               = gl_para_0300-ausdt
        i_x_mass_access          = 'X'
        i_x_dependant_locktypes  = space
      IMPORTING
        e_x_lock_exist           = l_x_lock_exist_first
        e_x_dependant_lock_exist = l_x_dependant_lock_exist
      TABLES
        et_locks                 = it_dfklock
        et_dependant_locks       = it_dependant_dfklock.

    READ TABLE it_dfklock INDEX 1.
    IF sy-subrc = 0.
*     dunn_block_in_item = it_dfklock-lockr.
      PERFORM set_dunn_block_in_item TABLES it_dfklock
                                     CHANGING dunn_block_in_item.
    ELSE.
      CLEAR dunn_block_in_item.
    ENDIF.
  ELSE.
    CLEAR dunn_block_in_item.
  ENDIF.

ENDFORM.                               " DUNNING_BLOCK_IN_ITEM

*&---------------------------------------------------------------------*
*&      Form  fill_proid_table
*&---------------------------------------------------------------------*
*       Prepares global table with all process IDs for
*       mass access of locks.
*----------------------------------------------------------------------*
FORM fill_proid_table.

  REFRESH gt_all_proid.
  CLEAR gt_all_proid.
  gt_all_proid-sign = 'I'.
  gt_all_proid-option = 'EQ'.

  gt_all_proid-low = gc_proid_dunning.         " 01 Dunning
  APPEND gt_all_proid.
  gt_all_proid-low = gc_proid_post.            " 09 Posting
  APPEND gt_all_proid.
  gt_all_proid-low = gc_proid_in_out_pay.      " 10 Payment
  APPEND gt_all_proid.
  gt_all_proid-low = gc_proid_inc_pay.         " 02 Incoming payment
  APPEND gt_all_proid.

ENDFORM.                    " fill_proid_table

*&---------------------------------------------------------------------*
*&      Form  initialize_lock_get
*&---------------------------------------------------------------------*
*       Perform one access to the locks with all process IDs.
*       This way the mass access should work for all process IDs.
*&---------------------------------------------------------------------*
FORM initialize_lock_get USING    i_fkkvkp STRUCTURE fkkvkp
                                  i_ausdt LIKE sy-datum.

  DATA: ls_structure LIKE dfkkop.
  DATA it_dfklock_dummy LIKE dfkklocks OCCURS 0 WITH HEADER LINE.

* Prepare PROID table for lock mass access
  DESCRIBE TABLE gt_all_proid.
  IF sy-tfill = 0.
    PERFORM fill_proid_table.
  ENDIF.

  ls_structure-gpart = i_fkkvkp-gpart.
  ls_structure-vkont = i_fkkvkp-vkont.

  CALL FUNCTION 'FKK_S_LOCK_GET'
       EXPORTING
          i_keystructure                 = ls_structure
          i_lotyp                  = gc_lotyp_partner_account
          i_lockdate                     = i_ausdt
          i_x_mass_access                = 'X'
          i_x_dependant_locktypes        = 'X'
          i_x_only_check_locks           = 'X'
*      IMPORTING
*         E_X_LOCK_EXIST                 =
*         E_X_DEPENDANT_LOCK_EXIST       =
       TABLES
          it_proid                       = gt_all_proid
          et_locks                       = it_dfklock_dummy
      EXCEPTIONS
         OTHERS                         = 1.
  IF sy-subrc <> 0.
    PERFORM message_append  USING
                   sy-msgid  sy-msgty  sy-msgno
                   sy-msgv1  sy-msgv2  sy-msgv3  sy-msgv4 space.
  ENDIF.


ENDFORM.                    " initialize_lock_get
*&---------------------------------------------------------------------*
*&      Form  set_dunn_block_in_item
*&---------------------------------------------------------------------*
*       sets the dunning block in item
*       depending on tfk047s-xmahn "Restrict Dunning Lock"
*----------------------------------------------------------------------*
*      -->P_IT_DFKLOCK  table of found dunning blocks in the item
*      <--P_DUNN_BLOCK_IN_ITEM  dunning block in item
*----------------------------------------------------------------------*
FORM set_dunn_block_in_item
          TABLES   p_it_dfklock STRUCTURE dfkklocks
          CHANGING p_dunn_block_in_item LIKE dfkklocks-lockr.

  DATA: lines                 TYPE i,
        unrestricted_found(1) TYPE c.
  CLEAR: lines,
         unrestricted_found.

  DESCRIBE TABLE p_it_dfklock LINES lines.
* If there is only one dunning block, take it
  IF lines = 1.
    READ TABLE p_it_dfklock INDEX 1.
    p_dunn_block_in_item = p_it_dfklock-lockr.
  ELSE.
    LOOP AT p_it_dfklock.
      PERFORM read_tfk047s USING p_it_dfklock-lockr.
      IF tfk047s-xmahn IS INITIAL.
        unrestricted_found = 'X'.
        EXIT.
      ENDIF.
    ENDLOOP.
* If there is at least one unrestricted dunning block in the item,
* take it
*>>> note 868877
*    IF unrestricted_found IS INITIAL.
    IF NOT unrestricted_found IS INITIAL.
*<<< note 868877
      p_dunn_block_in_item = p_it_dfklock-lockr.
* If there are only restricted dunning blocks in the item,
* take one of them.
    ELSE.
      READ TABLE p_it_dfklock INDEX 1.
      p_dunn_block_in_item = p_it_dfklock-lockr.
    ENDIF.

  ENDIF.


ENDFORM.                    " set_dunn_block_in_item
*&---------------------------------------------------------------------*
*&      Form  CHECK_BANK_ID
*&    Contract account used for payment transactions fkkvkp-vkonv
*&    can be different from the contract account in fkkvkp-vkont.
*&    Thatswhy the Bank ID from FKK_ACCOUNT_GET_BANK_ID {i_ebvty}
*&    should be used instead of i_fkkvkp-ebvty.
*&---------------------------------------------------------------------*
FORM check_bank_id USING i_ezawe  TYPE fkkvkp-ezawe
                         i_ebvty  TYPE fkkvkp-ebvty
                         i_xfromvtref  TYPE boole-boole        "Note 1907452
                         i_abwre_vtref TYPE abwre_kk           "Note 1907452
                         i_vtref  TYPE vtref_kk                "Note 1934796
                         i_fkkvkp TYPE fkkvkp
                         i_ausdt  TYPE ausdt_kk
                         i_emmnd  TYPE emmnd_kk                "Note 1979354
                   CHANGING e_invalid_bank_id.

  STATICS: s_gpart TYPE fkkvkp-gpart,
           s_vkont TYPE fkkvkp-vkont,
           s_ezawe TYPE fkkvkp-ezawe,               "Note 1846329
           s_ebvty TYPE fkkvkp-ebvty,               "Note 1846329
           s_vtref TYPE vtref_kk,                   "Note 1934796
           s_emmnd TYPE emmnd_kk,                   "Note 1979354
           s_invalid_bank_id.
  DATA:    l_gpart TYPE fkkvkp-gpart.

  IF i_ebvty IS INITIAL OR
     i_ezawe IS INITIAL.
    CLEAR e_invalid_bank_id.
  ELSE.
    IF NOT i_fkkvkp-gpart = s_gpart OR
       NOT i_fkkvkp-vkont = s_vkont OR               ">>Note 1846329
       NOT i_ezawe = s_ezawe OR
       NOT i_ebvty = s_ebvty OR
       NOT i_vtref = s_vtref OR                        "Note 1934796
       NOT i_emmnd = s_emmnd.                          "Note 1979354
      CLEAR: e_invalid_bank_id, s_invalid_bank_id.   "<<Note 1846329
      s_gpart = i_fkkvkp-gpart.
      s_vkont = i_fkkvkp-vkont.
      s_ezawe = i_ezawe.                             "Note 1846329
      s_ebvty = i_ebvty.                             "Note 1846329
      s_vtref = i_vtref.                             "Note 1934796
      s_emmnd = i_emmnd.                             "Note 1979354

*     Contract account used for payment transactions is set
      IF NOT i_fkkvkp-vkonv IS INITIAL AND
         NOT i_fkkvkp-gparv IS INITIAL.
        l_gpart = i_fkkvkp-gparv.
      ELSE.
*       Alternative payer is defined         " Note 1332690
        IF NOT i_fkkvkp-abwre IS INITIAL.    " Note 1332690
          l_gpart = i_fkkvkp-abwre.          " Note 1332690
        ELSE.                                " Note 1332690
          l_gpart = i_fkkvkp-gpart.
        ENDIF.
      ENDIF.

*     Payment parameters are active in contract
*     PSOB_PAY_ACT = X
      IF NOT i_xfromvtref IS INITIAL AND             ">> Note 1907452
         NOT i_abwre_vtref IS INITIAL.
*       Alternative payer is defined in contract
        l_gpart = i_abwre_vtref.
      ENDIF.                                         "<< Note 1907452

*   " Check if the Bank Details ID for Incoming Payments is valid
      CALL FUNCTION 'BUP_BANK_CHECK'
        EXPORTING
          i_partner        = l_gpart
          i_bkvid          = i_ebvty
          i_valdt_sel      = i_ausdt
        EXCEPTIONS
          bank_not_found   = 1
          wrong_parameters = 2
          internal_error   = 3
          not_valid        = 4
          OTHERS           = 5.
      IF sy-subrc <> 0.
        IF sy-subrc = 4.
          PERFORM message_append USING 'R1' 'S' '703'
                                       i_ebvty
                                       i_ausdt
                                       space
                                       space '4'.
          IF 1 = 2. " Where used list
            MESSAGE s703(R1) WITH i_ebvty i_ausdt.
          ENDIF.
        ELSE.
          PERFORM message_append USING 'R1' 'S' '242'
                                       l_gpart            "Note 1846329
                                       i_ebvty
                                       space
                                       space '4'.
          IF 1 = 2. " Where used list
            MESSAGE s242(r1) WITH i_ebvty l_gpart.
          ENDIF.
        ENDIF.
*       Bank Details ID for Incoming Payments is not valid
*       -> the contract account should be dunned
        e_invalid_bank_id = 'X'.
        s_invalid_bank_id = e_invalid_bank_id.             "Note 1846329
      ENDIF.
      CHECK e_invalid_bank_id IS INITIAL.                  "Note 1758081
      READ TABLE t_fbstab_0368 INDEX 1.                    ">> Note 1955232
      IF sy-subrc NE 0.
        REFRESH t_fbstab_0368.
        CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
          EXPORTING
            i_fbeve       = '0368'
            i_applk       = applk
          TABLES
            t_fbstab      = t_fbstab_0368
          EXCEPTIONS
            error_message = 1
            OTHERS        = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                  WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
        ENDIF.
      ENDIF.
      READ TABLE t_fbstab_0368 INDEX 1.
      CALL FUNCTION t_fbstab_0368-funcc
        EXPORTING
          I_FKKVKP                =  i_fkkvkp
          I_GPART_PAYER           =  l_gpart
          I_VTREF                 =  i_vtref
          I_EZAWE                 =  i_ezawe
          I_EBVTY                 =  i_ebvty
          I_AUSDT                 =  i_ausdt
          I_EMMND                 =  i_emmnd               "Note 1979354
        IMPORTING
          E_CHECK_UNSUCCESSFUL    =  e_invalid_bank_id
       EXCEPTIONS
          ERROR_MESSAGE           = 1.
*     Notes 1816722, 1934796
*     Where-used list for event
      SET EXTENDED CHECK OFF.
      IF 1 = 2. CALL FUNCTION 'FKK_SAMPLE_0368'. ENDIF.
      SET EXTENDED CHECK ON.                                "<< Note 1955232
      s_invalid_bank_id = e_invalid_bank_id.                "Note 1846329
      IF NOT e_invalid_bank_id IS INITIAL.
        PERFORM message_append USING sy-msgid  'S'  sy-msgno
                sy-msgv1  sy-msgv2  sy-msgv3  sy-msgv4 '4'.
      ENDIF.
    ELSE.                                                 "<<Note 1758081
      e_invalid_bank_id = s_invalid_bank_id.                "Note 1846329
    ENDIF.                                                  "Note 1846329
  ENDIF.
ENDFORM.                                    " CHECK_BANK_ID
