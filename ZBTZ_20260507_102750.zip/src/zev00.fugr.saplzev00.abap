*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZEV00TOP.      " Global Data
  INCLUDE LZEV00UXX.      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* include lev00f00.      " Subprograms
* INCLUDE LEV00O...      " PBO-Modules
* INCLUDE LEV00I...      " PAI-Modules

  INCLUDE IEAGETMNGBASIS.

* >>>>> Japan, WWT 12.11.2002
  DATA: CO_FBNAME(30) TYPE C VALUE 'ISU_QUANTI26'.
  INCLUDE IELABLGR.
  INCLUDE IEJBPVAL.
  INCLUDE IEJBPFUNC.
* <<<<< Japan, WWT 12.11.2002


INCLUDE LZEV00F01.
*  INCLUDE LEV00F01.
