*-------------------------------------------------------------------
***INCLUDE LFKMBF01 .
*-------------------------------------------------------------------

*&---------------------------------------------------------------------*
*&      Form  MAHNHISTORIE_PRUEFEN
*&---------------------------------------------------------------------*
FORM mahnhistorie_pruefen TABLES   t_fkkmako STRUCTURE fkkmako
                          USING p_laufd LIKE fkkmako-laufd
                                p_laufi LIKE fkkmako-laufi
                                p_xextm LIKE fkkma_0300-xextm
                          CHANGING e_flag TYPE xfeld.
  LOOP AT t_fkkmako
    WHERE ( laufd NE p_laufd OR   " check only entries from different
            laufi NE p_laufi )    " runs
      AND xmsto = space.
    IF p_laufi IS INITIAL AND p_xextm = '1'.
      CHECK NOT t_fkkmako-laufi IS INITIAL. "Skip check for entries from this dunning simulation with different LAUFD
    ENDIF.

    IF t_fkkmako-mdrkd IS INITIAL.
      IF NOT t_fkkmako-relea IS INITIAL.  "Not released
*       Dunning with exceeded release date doesn't prevent next dunning.
        CHECK t_fkkmako-reldate GE sy-datum.  "Release still possible
      ENDIF.

      PERFORM message_append USING '>3' 'W' '233' t_fkkmako-laufd
                                                  t_fkkmako-laufi
                                                  t_fkkmako-gpart
                                                  space '2'.
      SET EXTENDED CHECK OFF.
      IF 1 = 0. MESSAGE s233. ENDIF.
      SET EXTENDED CHECK ON.

      IF NOT t_fkkmako-relea IS INITIAL.  "Not released
        PERFORM message_append USING '>W' 'W' '026' t_fkkmako-laufd
                                                    t_fkkmako-laufi
                                                    space space '2'.
        SET EXTENDED CHECK OFF.
        IF 1 = 0. MESSAGE s026(>w). ENDIF.
        SET EXTENDED CHECK ON.
      ENDIF.

      e_flag = 'X'.
      EXIT.
    ENDIF.

  ENDLOOP.

ENDFORM.                               " MAHNHISTORIE_PRUEFEN

*&---------------------------------------------------------------------*
*&      Form  POSTEN_ABMISCHEN
*&---------------------------------------------------------------------*
*       Die offenen Posten werden mit den Daten aus dem Vertragskonto  *
*       und aus der Mahnhistorie abgemischt und dabei in Mahngruppen   *
*       aufgeteilt.
**----------------------------------------------------------------------
FORM posten_abmischen TABLES i_fkkop STRUCTURE fkkop
                             i_fkkvkp STRUCTURE fkkvkp
                             i_fkkmako STRUCTURE fkkmako
                             i_fkkmaze STRUCTURE fkkmaze
                             i_fkkmavs STRUCTURE fkkmavs
                             i_fkkmagrp STRUCTURE fkkmagrp
                        USING  u_sort TYPE xfeld
                      CHANGING e_flag LIKE boole-boole.

  DATA mahnbar.
* Barzahler-Konto (L_XCASH_ACCOUNT = 'X') soll grunds. gemahnt werden:
  DATA: l_xcash_account TYPE xcash_kk,
* Fuer den einzelnen Posten kann es auch anders sein:
        l_xcash_item    TYPE xcash_kk,
        l_invalid_bank_id.
  DATA: l_ezawe LIKE fkkvkp-ezawe,
        l_ebvty LIKE fkkvkp-ebvty.
  DATA dunn_block_in_acc LIKE dfkklocks-lockr.
  DATA post_block_in_acc LIKE dfkklocks-lockr.
  DATA paym_block_in_item LIKE dfkklocks-lockr.
  DATA dunn_block_in_item LIKE dfkklocks-lockr.
  DATA l_blocked_dueto_workflow TYPE boole-boole.
  DATA l_ltext TYPE tfk4eyet-ltext.
  DATA l_dummy TYPE fkkmavs-bukrs.
  DATA l_ddl_key TYPE fkkddl_key.
  DATA wa_tfk047u TYPE tfk047u.
  DATA wa_masterdata TYPE fkk_masterdata.
  DATA l_delete   TYPE xfeld.
  DATA l_timestamp TYPE itemgrp_cm_kk.
  DATA lt_fkkmaze_sort TYPE fkkmaze_sort.               " Note 2129902

  FIELD-SYMBOLS <wa_fkkop> LIKE i_fkkop.

* We have a selected range of dunning procedures in the dunning
* specific run parameters
  STATICS r_mahnv TYPE fkk_rt_mahnv.

* Drop header line of contract account list:
* (This is needed 22 lines below.)
  CLEAR i_fkkvkp.

  IF g_flex_dunn_active IS INITIAL.
    PERFORM get_range_mahnv_from_memory CHANGING r_mahnv.
  ENDIF.

  REFRESH: i_fkkmavs, i_fkkmagrp.

  SORT i_fkkop BY gpart vkont vtref.
  lt_fkkmaze_sort[] = i_fkkmaze[].                      " Note 2129902

* Recognize if we are dealing with only one item
  DATA lx_only_one_item TYPE xfeld.
  DESCRIBE TABLE i_fkkop.
  IF sy-tfill = 1.
    lx_only_one_item = 'X'.
  ELSE.
    CLEAR lx_only_one_item.
  ENDIF.

* Set new ranges for dfkklocks - only for paralellisation
* object GPART                                          "Note 1785083
  IF g_flex_dunn_active IS NOT INITIAL.
    PERFORM set_fkklocks_ranges TABLES i_fkkop.
  ENDIF.                                                "Note 1785083

  LOOP AT i_fkkop ASSIGNING <wa_fkkop>.  " ASSIGNING saves performance
*   Fill dunning line with contents of open item
    CLEAR i_fkkmavs.
    MOVE-CORRESPONDING <wa_fkkop> TO i_fkkmavs.
*   Beim allerersten Mal ist I_FKKVKP noch leer und dann ist die
*   IF-Bedingung immer erfuellt
    IF i_fkkvkp-vkont <> i_fkkmavs-vkont OR  " new account in LOOP?
       i_fkkvkp-gpart <> i_fkkmavs-gpart.
*     Ermitteln der mahnrelevanten Daten aus dem Vertragskonto
      READ TABLE i_fkkvkp WITH KEY vkont = i_fkkmavs-vkont
                                   gpart = i_fkkmavs-gpart.
      IF sy-subrc NE 0.
        PERFORM message_append USING '>3' 'S' '002'
                               i_fkkmavs-vkont i_fkkmavs-gpart
                               space space '1'.
        SET EXTENDED CHECK OFF.
        IF 0 = 1. MESSAGE e002(>3). ENDIF. " Verwendungsnachweis
        SET EXTENDED CHECK ON.
        CONTINUE.   "Posten überspringen, kommt nicht in Mahnvorschlag
      ENDIF.
*     Check dunning block in contract account
      PERFORM check_block_in_vkont USING    i_fkkvkp
                                   CHANGING dunn_block_in_acc
                                            post_block_in_acc.
*     Check dunning block - Pruefung aus Mahnsperre
      IF NOT dunn_block_in_acc IS INITIAL.
        PERFORM message_dunning_block_in_acc USING i_fkkvkp-gpart
                                                       i_fkkvkp-vkont
                                                      dunn_block_in_acc.
        CONTINUE.  " go to next item (LOOP at i_fkkop)
      ENDIF.
*     Check post block - Prüfung auf Buchungssperre
*      IF NOT post_block_in_acc IS INITIAL.
*        PERFORM post_block_in_account USING i_fkkvkp-gpart
*                                            i_fkkvkp-vkont
*                                            post_block_in_acc.
*        CONTINUE.  " go to next item (LOOP at i_fkkop)
*      ENDIF.
*     Check if customer has bank id - Prüfen, ob Kunde Abbucher ist
      CALL FUNCTION 'FKK_ACCOUNT_GET_BANK_ID'
        EXPORTING
          x_fkkvkp      = i_fkkvkp
          x_datum       = gl_para_0300-ausdt
          x_mass_access = 'X'  " note 459689
        IMPORTING
          y_ebvty       = l_ebvty
          y_xcash       = l_xcash_account
          y_ezawe       = l_ezawe
        EXCEPTIONS
          fault         = 1
          OTHERS        = 2.
      IF sy-subrc <> 0.
        PERFORM message_append USING sy-msgid 'S' sy-msgno
                               sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 '1'.
        CONTINUE.  " go to next item (LOOP at i_fkkop)
      ENDIF.
    ELSE.
*     Same GPART/VKONT (same contract account) as previous item
      IF NOT dunn_block_in_acc IS INITIAL. "OR
        "NOT post_block_in_acc IS INITIAL.
*       Item has to be dropped due to a lock in the account
*       (Message has already been given previously)
        CONTINUE.  " go to next item (LOOP at i_fkkop)
      ENDIF.
    ENDIF.

    l_xcash_item = l_xcash_account.
*   Event 0364 for incoming payment method (EZAWE)
*   from contract object (VTREF) level:
    DATA: l_xfromvtref  TYPE boole-boole,
          l_abwre       TYPE abwre_kk.                          "Note 1907452

    PERFORM event_0364_ezawe_from_vtref USING i_fkkmavs-gpart
                                              i_fkkmavs-vkont
                                              i_fkkmavs-vtref
                                              i_fkkmavs-subap
                                              gl_para_0300-ausdt
                             CHANGING l_xcash_item l_ezawe l_xfromvtref
                                      l_ebvty                   "Note 1811989
                                      l_abwre.                  "Note 1907452

    IF NOT i_fkkmavs-pymet IS INITIAL.
*     Item contains Payment method. Therefore we assume that
*     this item will be caught by the payment program.
*     In other words: For the present item the business partner has
*     no duty to trigger the payment by himself
*     and therefore should not be dunned.
*     (A possible payment block in item is checked below.)
*     Für diesem Posten ist der Kunde nicht als Barzahler anzusehen.
*     CLEAR l_xcash_item.
*     If it is a RealTimePayment (RTP) Payment Method, this still is Self-Payer (L_XCASH_ITEM=X)
DATA: l_rtpty type rtpty_kk.
      CALL FUNCTION 'FKK_PAYMENT_METHOD_CHECK_RTP'
        EXPORTING
          I_BUKRS                      = i_fkkmavs-bukrs
          I_GPART                      = i_fkkmavs-gpart
          I_VKONT                      = i_fkkmavs-vkont
          I_PYBUK                      = i_fkkmavs-pybuk
          I_PYMET                      = i_fkkmavs-pymet
*         I_OPBUK                      =
        IMPORTING
          E_RTPTY                      = l_rtpty.
      if l_rtpty is initial.
        clear: l_xcash_item.
      endif.
      IF <wa_fkkop>-pymet   IS NOT INITIAL.            ">> Note 1993154
        l_ezawe  = <wa_fkkop>-pymet.
      ENDIF.
      IF <wa_fkkop>-embvt   IS NOT INITIAL.
        l_ebvty = <wa_fkkop>-embvt.
      ENDIF.                                           "<< Note 1993154
    ENDIF.
    IF i_fkkmavs-stakz EQ 'K'.
*     Inbound correspondence request cannot be cleared by payment run.
*     Incoming payment method in contract (account) doesn't change XCASH flag.
      MOVE 'X' TO l_xcash_item.
    ENDIF.

*   In event 0365 the incoming payment method and other things
*   can be checked once again
    DATA l_not_dunn_other_reason TYPE boole-boole. " exclude item
    DATA l_fimsg TYPE fimsg.                   " Message from event 0365
    PERFORM event_0365             USING l_ezawe
                                         l_ebvty           "Note 1758081
                                         i_fkkvkp
                                         <wa_fkkop>
                                         gl_para_0300-ausdt
                                CHANGING l_xcash_item
                                         l_not_dunn_other_reason
                                         l_fimsg.

    IF l_not_dunn_other_reason = 'X'.
*     A check in event 0365 said that the item should not be dunned
      IF NOT l_fimsg-msgno IS INITIAL AND NOT l_fimsg-msgid IS INITIAL.
*       Put the message into application log as returned by event 0365
        PERFORM message_append USING l_fimsg-msgid 'S'
                                     l_fimsg-msgno
                                     l_fimsg-msgv1
                                     l_fimsg-msgv2
                                     l_fimsg-msgv3
                                     l_fimsg-msgv4 '4'.
      ENDIF.
      CONTINUE.  " go to next item (LOOP at i_fkkop)
    ENDIF.

*   For grouping reasons we need the company code currency explicitly:
    PERFORM get_local_currency USING    i_fkkmavs-bukrs
                               CHANGING i_fkkmavs-hwaer
                                        l_dummy.

*   Wenn wir keinen Barzahler haben, werden nur diejenigen Posten
*   gemahnt, die eine Eingangszahlsperre haben.
    IF l_xcash_item IS INITIAL.
*     If bank ID is not valid, than the position should be dunned
*     even if there is a payment method defined
      PERFORM check_bank_id USING l_ezawe
                                  l_ebvty
                                  l_xfromvtref                          "Note 1907452
                                  l_abwre                               "Note 1907452
                                  i_fkkmavs-vtref                       "Note 1934796
                                  i_fkkvkp
                                  gl_para_0300-ausdt
                                  i_fkkmavs-emmnd                       "Note 1979354
                         CHANGING l_invalid_bank_id.
*     Look for a payment block in the item
      PERFORM get_payment_block_in_item USING    <wa_fkkop>
                                    CHANGING paym_block_in_item.
*     Anmerkung: Wir pruefen an dieser Stelle nicht mehr, ob eine
*     Zahlsperre auf Stammdatenebene vorliegt. Das ist bereits
*     in FKK_ACCOUNT_GET_BANK_ID und ggf. in Event 0364 geschehen.
*     (Es wird nicht als sinnvoll angesehen, ein Zahlweg nur auf
*     Postenebene zu haben und die Sperre nur auf Stammdatenebene.
*     Ein solcher Posten wird also nicht gemahnt, obwohl er vom
*     Zahlprogramm nicht reguliert werden kann.)
      IF paym_block_in_item IS INITIAL AND
         l_invalid_bank_id IS INITIAL.
*       (Item is not blocked for payment)
        IF NOT i_fkkmavs-pymet IS INITIAL.
*         Meldung: Zahlweg sitzt im Beleg
*         ACHTUNG: bis 4.63 wurde hier die BANKVERBINDUNG statt
*         des ZAHLWEGS ueberprueft!!!!
          PERFORM message_append USING '>3' 'S' '243' i_fkkmavs-opbel
                              i_fkkvkp-vkont i_fkkvkp-gpart space '4'.
          IF 1 = 2.                            "Verwendungsnachweis
            MESSAGE s243(>3) WITH i_fkkvkp-gpart i_fkkvkp-vkont
                                  i_fkkmavs-opbel.
          ENDIF.
        ELSE.
          IF l_xfromvtref IS INITIAL.
*           Eingangszahlweg sitzt im Vertragskonto
            PERFORM bank_id_in_account USING i_fkkvkp-gpart
                                           i_fkkvkp-vkont
                                           l_ezawe.
          ELSE.
*           Eingangszahlweg sitzt auf Objektebene
            PERFORM bank_id_in_vtref USING i_fkkvkp-gpart
                                           i_fkkvkp-vkont
                                           i_fkkmavs-vtref
                                           l_ezawe.
          ENDIF.
        ENDIF.

        CLEAR l_ddl_key.
        MOVE: i_fkkvkp-gpart TO l_ddl_key-gpart,
              i_fkkvkp-vkont TO l_ddl_key-vkont.
        IF NOT l_xfromvtref IS INITIAL.
          MOVE i_fkkmavs-vtref TO l_ddl_key-vtref.
          MOVE i_fkkmavs-subap TO l_ddl_key-subap.
        ENDIF.
        CALL FUNCTION 'FKK_CHECK_CEILINGAMOUNT'
          EXPORTING
            i_ddl_key        = l_ddl_key
            i_fkkmavs        = i_fkkmavs
          IMPORTING
            e_betrw_dunnable = i_fkkmavs-betrw
            e_betrh_dunnable = i_fkkmavs-betrh.

        IF NOT i_fkkmavs-betrw IS INITIAL.
          PERFORM message_append USING '>1' 'S' '694'
                                              i_fkkmavs-opbel
                                              i_fkkmavs-opupw
                                              i_fkkmavs-opupk
                                              i_fkkmavs-opupz
                                              '4'.
          IF 1 = 2.
            MESSAGE s694(>1) WITH i_fkkmavs-opbel
                                  i_fkkmavs-opupw
                                  i_fkkmavs-opupk
                                  i_fkkmavs-opupz.
          ENDIF.
        ELSE.
*         Document number for application log
          PERFORM message_append USING '>1' 'S' '692' i_fkkmavs-opbel
                                                      i_fkkmavs-opupw
                                                      i_fkkmavs-opupk
                                                      i_fkkmavs-opupz
                                                      '4'.
          IF 1 = 2.
            MESSAGE s692(>1) WITH i_fkkmavs-opbel
                                  i_fkkmavs-opupw
                                  i_fkkmavs-opupk
                                  i_fkkmavs-opupz.
          ENDIF.
*         Do not take this item for dunning!
          CONTINUE.  " go to next item (LOOP at i_fkkop)
        ENDIF.
      ENDIF.
    ENDIF.
*   Check if item is to be checked (4-eye-principle)
    IF NOT i_fkkmavs-c4eye IS INITIAL.
      CALL FUNCTION 'FKK_CHECK_BLOCKED_BY_WORKFLOW'
        EXPORTING
          i_c4eye   = i_fkkmavs-c4eye
          i_proid   = gc_proid_dunning
        IMPORTING
          e_blocked = l_blocked_dueto_workflow
          e_ltext   = l_ltext.
      IF l_blocked_dueto_workflow = 'X'.
        PERFORM message_append USING '>3' 'S' '890'
                l_ltext <wa_fkkop>-opbel
                <wa_fkkop>-opupw <wa_fkkop>-opupk '4'.
        SET EXTENDED CHECK OFF.
        IF 1 = 2. MESSAGE e890(>3). ENDIF.
        SET EXTENDED CHECK ON.
        CONTINUE.  " go to next item (LOOP at i_fkkop)
      ENDIF.
    ENDIF.

*   check if dunning block is in item
    PERFORM dunning_block_in_item USING    <wa_fkkop>
                                  CHANGING dunn_block_in_item.
    IF i_fkkmavs-mansp IS INITIAL OR
       i_fkkmavs-mansp = gc_multiple_locks.    " Note 1303550
      i_fkkmavs-mansp = dunn_block_in_item.
    ENDIF.

*   Fill four fields with actual values from contract account
    i_fkkmavs-opbuk = i_fkkvkp-opbuk.  " Buchungskreisgruppe
    i_fkkmavs-stdbk = i_fkkvkp-stdbk.  " (Standard) Buchungskreis
    i_fkkmavs-abwma = i_fkkvkp-abwma.  "abweichender Mahnempfänger
    i_fkkmavs-adrma = i_fkkvkp-adrma.  "Adresse abweichender Mahnempf.
    i_fkkmavs-mgrup = i_fkkvkp-mgrup.                       "Mahngruppe
*   Fill the fields for additional receivable rules
    PERFORM set_add_receivable_fields
            USING i_fkkmavs-opbuk
                  i_fkkmavs-hvorg
                  i_fkkmavs-tvorg
            CHANGING i_fkkmavs-cdunn
                     i_fkkmavs-pdunn
                     i_fkkmavs-setdl.

************ Ermittlung des Mahnverfahrens **************
*   An der Stelle ist ein Event eingebaut, damit noch
*   der IS-U-Vertrag wegen Mahnsperre und abw. Mahnverfahren eingelesen
*   wird (Umzug!!)
    PERFORM event_0303 USING i_fkkvkp
                       CHANGING i_fkkmavs mahnbar.
    IF mahnbar = 'N'.
      CONTINUE.  " go to next item (LOOP at i_fkkop)
    ENDIF.

    IF g_flex_dunn_active IS INITIAL.
*   Ist kein Mahnverfahren im Posten, wird das Mahnverfahren aus dem
*   Vertragskonto verwendet. Ist dort auch keines eingetragen, erfolgt
*   keine Mahnung.
      IF i_fkkmavs-mahnv IS INITIAL.
        IF i_fkkvkp-mahnv IS INITIAL.
          PERFORM no_dunning_proc_in_account USING i_fkkvkp-gpart
                                                   i_fkkvkp-vkont.
          CONTINUE.  " go to next item (LOOP at i_fkkop)
        ENDIF.
*     Dunning procedure from account:
        i_fkkmavs-mahnv = i_fkkvkp-mahnv.
      ENDIF.
*   Für Raten wird noch das alternative Mahnverfahren gelesen
      IF i_fkkmavs-stakz = 'R'.
        PERFORM read_tfk047a USING i_fkkmavs-mahnv.
        IF sy-subrc = 0 AND
           NOT tfk047a-altmv IS INITIAL.
          i_fkkmavs-mahnv = tfk047a-altmv.
        ENDIF.
      ENDIF.
*   Check whether the dunning procedur of the item is in the
*   selected range of dunning procedures.
      IF NOT i_fkkmavs-mahnv IN r_mahnv.
        PERFORM message_append USING '>3' 'S' '419' i_fkkmavs-opbel
                                                    i_fkkmavs-mahnv
                                                    space space
                                                    '4'.
        ##stmnt_exit
        CONTINUE.  " go to next item (LOOP at i_fkkop)
        MESSAGE s419(>3) WITH i_fkkmavs-opbel i_fkkmavs-mahnv.
      ENDIF.
    ENDIF.

*   Verarbeitung einer Mahnsperre im OP
    IF NOT i_fkkmavs-mansp IS INITIAL.
* Ist eine Mahnsperre im Posten, wird geprüft, ob dieser trotzdem
* mahnbar ist. Sonst wird er nicht übernommen.
      PERFORM read_tfk047s USING i_fkkmavs-mansp.
      IF sy-subrc = 0 AND
        tfk047s-xmahn IS INITIAL.
*       Im Beleg &1 ist die Mahnsperre &2 eingetragen
        PERFORM message_append USING '>3' 'S' '225' i_fkkmavs-opbel
                                                    i_fkkmavs-mansp
                                                    space space
                                                    '2'.
        ##stmnt_exit
        CONTINUE.  " go to next item (LOOP at i_fkkop)
        MESSAGE s225 WITH i_fkkmavs-opbel i_fkkmavs-mansp.
      ELSE.
*       Item has a dunning lock but it is
*       a dunnable (restricted) lock
      ENDIF.
    ENDIF.

*   Fill master data grouping fields and strategy
    IF NOT g_flex_dunn_active IS INITIAL.
      MOVE-CORRESPONDING i_fkkmavs TO wa_masterdata.        "#EC ENHOK
      CALL FUNCTION 'FKK_GET_CMGRP'
        EXPORTING
          i_masterdata         = wa_masterdata
          i_bukrs              = i_fkkmavs-bukrs
          i_applk              = gl_para_0300-applk
        IMPORTING
          e_vkgrp              = i_fkkmavs-vkontgrp
          e_vtgrp              = i_fkkmavs-vtrefgrp
          e_strat              = i_fkkmavs-strat
        EXCEPTIONS
          no_gpart             = 1
          no_vkont             = 2
          masterdata_not_found = 3
          unknown_bukrs        = 4
          OTHERS               = 5.
      IF sy-subrc <> 0.
        PERFORM message_append USING sy-msgid sy-msgty sy-msgno
                                     sy-msgv1 sy-msgv2
                                     sy-msgv3 sy-msgv4 '1'.
        CONTINUE.

      ELSEIF i_fkkmavs-strat IS INITIAL.
        CALL FUNCTION 'FKK_STRATEGY_DETERMINE'
          EXPORTING
            i_masterdata = wa_masterdata
            i_vkgrp      = i_fkkmavs-vkontgrp
            i_vtgrp      = i_fkkmavs-vtrefgrp
            i_applk      = gl_para_0300-applk
          IMPORTING
            e_strat      = i_fkkmavs-strat
            e_vkgrp      = i_fkkmavs-vkontgrp
            e_vtgrp      = i_fkkmavs-vtrefgrp
          TABLES
            it_fkkvkp    = i_fkkvkp.

        IF i_fkkmavs-strat IS INITIAL.
          PERFORM message_append USING 'FKK_CM' 'S' '061'
                                       wa_masterdata-gpart wa_masterdata-vkont
                                       wa_masterdata-vtref '' '1'.
          CONTINUE.                                         "#EC *
          MESSAGE s061(fkk_cm) WITH wa_masterdata-gpart     "#EC *
                wa_masterdata-vkont wa_masterdata-vtref.    "#EC *
        ENDIF.

      ENDIF.
    ENDIF.


*   Ermitteln Mahnstufe und Mahndatum aus Mahnhistorie
    CALL FUNCTION 'FKK_GET_PREVIOUS_DUNNING_LEVEL'
      EXPORTING
        i_fkkmavs       = i_fkkmavs
        i_sorted        = 'X'                                   " Note 2129902
        t_fkkmaze_sort  = lt_fkkmaze_sort                       " Note 2129902
      IMPORTING
        e_mahns         = i_fkkmavs-mahns
        e_mahnn         = i_fkkmavs-mahnn
        e_mstyp         = i_fkkmavs-mstyp
        e_mahnd         = i_fkkmavs-mahnd
        e_step_last     = i_fkkmavs-step_last
        e_strat_last    = i_fkkmavs-strat_last
        e_itemgrp_last  = i_fkkmavs-itemgrp_last
        e_grpfield_last = i_fkkmavs-grpfield_last
      TABLES
        xt_fkkmaze      = i_fkkmaze
        xt_fkkmako      = i_fkkmako.

    IF g_flex_dunn_active IS INITIAL.
* If dunning level is still zero look for additional receivables
      IF i_fkkmavs-mahns IS INITIAL AND i_fkkmavs-setdl = 'X'.
*     Check whether the present line it is an additional receivalbe
*     booked as a dunning charge or interest in the dunning history
        PERFORM get_first_dl_for_additional_re
                TABLES i_fkkmako
                USING    i_fkkmavs-opbel
                         i_fkkmavs-mahnv
                CHANGING i_fkkmavs-mahns
                         i_fkkmavs-mstyp
                         i_fkkmavs-mahnd.
        CLEAR i_fkkmavs-mahnn.
      ENDIF.

*   New dunning level manually set.
*   Always dun, also if dunning level decreases.
      IF NOT i_fkkmavs-mahnn IS INITIAL.
        CLEAR i_fkkmavs-mahns.
        MOVE 'X' TO i_fkkmavs-dl_manual.
      ENDIF.

* Posten wird noch einer Mahngruppe zugeordnet und mit der
* Gruppennummer versehen
      CLEAR i_fkkmagrp.
*   Nach den Gruppierungsregeln in der Tabelle tfk047f
*   werden die gruppierungsrelevanten Felder in der Mahngruppe gefüllt.
      CALL FUNCTION 'FKK_CREATE_DUNNING_GROUP'
        EXPORTING
          i_fkkmavs       = i_fkkmavs
          i_para_0300     = gl_para_0300
          i_only_one_item = lx_only_one_item
        IMPORTING
          e_fkkmagrp      = i_fkkmagrp
          e_mstnn         = i_fkkmavs-mstnn
          e_xlmst         = i_fkkmavs-xlmst
        CHANGING
          c_mahnn         = i_fkkmavs-mahnn
        EXCEPTIONS
          error_message   = 1
          OTHERS          = 2.
      IF sy-subrc NE 0.
        PERFORM message_append USING sy-msgid sy-msgty sy-msgno
                                     sy-msgv1 sy-msgv2
                                     sy-msgv3 sy-msgv4 '1'.
        CONTINUE.   " go to next item (LOOP at i_fkkop)
      ENDIF.

*   Wenn die Mahngruppe noch nicht vorhanden ist, wird sie aufgenommen
      COLLECT i_fkkmagrp.    " The COLLECT statement sets SY_TABIX

    ELSE.
*     If collection step is empty look for additional receivables  ">>Note 2042997
      IF i_fkkmavs-step_last IS INITIAL AND i_fkkmavs-setdl = 'X'.
*     Check whether the present line it is an additional receivalbe
*     booked as a dunning charge or interest in the dunning history
        PERFORM get_step_and_group_for_add_rec
                TABLES i_fkkmako
                USING    i_fkkmavs-opbel
                CHANGING i_fkkmavs-grpfield_last
                         i_fkkmavs-itemgrp_last
                         i_fkkmavs-strat_last
                         i_fkkmavs-step_last
                         i_fkkmavs-mahnd.
      ENDIF.                                                       "<< Note 2042997
*   Flexible dunning                                       ">>Note 2024380
      IF NOT i_fkkmavs-step_last IS INITIAL.
        CLEAR wa_tfk047u.
        CALL FUNCTION 'FKK_GET_TFK047U'
          EXPORTING
            i_step    = i_fkkmavs-step_last
          IMPORTING
            e_tfk047u = wa_tfk047u
          EXCEPTIONS
            OTHERS    = 0.

        IF NOT wa_tfk047u-closegroup IS INITIAL.
          IF NOT i_fkkmavs-itemgrp_last IS INITIAL.
*           Keep itemgroup closed
            MOVE i_fkkmavs-itemgrp_last TO i_fkkmavs-itemgrp.
          ELSE.
*           Freeze item group
          IF l_timestamp IS INITIAL.
            GET TIME STAMP FIELD l_timestamp.
          ENDIF.
          MOVE l_timestamp TO i_fkkmavs-itemgrp.
        ENDIF.
      ENDIF.
      ENDIF.                                               "<< Note 2024380

*     Event for grpfield and deletion of items
*     Default implementation deletes items with FAEDN > AUSDT
      READ TABLE t_fbstab_0312 INDEX 1.
      IF sy-subrc NE 0.
        CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
          EXPORTING
            i_fbeve       = '0312'
            i_applk       = gl_para_0300-applk
          TABLES
            t_fbstab      = t_fbstab_0312
          EXCEPTIONS
            error_message = 0.
      ENDIF.
      LOOP AT t_fbstab_0312.
        CLEAR l_delete.
        CALL FUNCTION t_fbstab_0312-funcc
          EXPORTING
            i_ausdt       = gl_para_0300-ausdt
            i_fkkmavs     = i_fkkmavs
            i_fkkvkp      = i_fkkvkp
            i_para_0300   = gl_para_0300
          IMPORTING
            e_grpfield    = i_fkkmavs-grpfield
            e_item_delete = l_delete
            e_itemgrp     = i_fkkmavs-itemgrp.             " Note 2024380
      ENDLOOP.
      SET EXTENDED CHECK OFF.
      IF 1 = 2. CALL FUNCTION 'FKK_SAMPLE_0312'. ENDIF.
      SET EXTENDED CHECK ON.

      IF NOT l_delete IS INITIAL.
        CONTINUE.
      ENDIF.

*     Create groups
      CLEAR i_fkkmagrp.
      MOVE: i_fkkmavs-gpart    TO i_fkkmagrp-gpart,
            i_fkkmavs-vkontgrp TO i_fkkmagrp-vkontgrp,
            i_fkkmavs-vtrefgrp TO i_fkkmagrp-vtrefgrp,
            i_fkkmavs-grpfield TO i_fkkmagrp-grpfield,
            i_fkkmavs-itemgrp  TO i_fkkmagrp-itemgrp,
*           Strategy is unique within one master data group.
*           Fill fkkmagrp-strat for BRF.
            i_fkkmavs-strat    TO i_fkkmagrp-strat.
      READ TABLE i_fkkmagrp WITH KEY gpart    = i_fkkmagrp-gpart
                                     vkontgrp = i_fkkmagrp-vkontgrp
                                     vtrefgrp = i_fkkmagrp-vtrefgrp
                                     grpfield = i_fkkmagrp-grpfield
                                     itemgrp  = i_fkkmagrp-itemgrp.
      IF NOT sy-subrc IS INITIAL.
        APPEND i_fkkmagrp.
        MOVE sy-tabix TO i_fkkmagrp-mgrpx.
        MODIFY i_fkkmagrp INDEX sy-tabix.
      ENDIF.
    ENDIF.

*   Die lfdnr der Mahngruppe wird im Posten gespeichert, um die
*   Zuordnung zur Mahngruppe sicherzustellen
    i_fkkmavs-mgrpx = sy-tabix.

*   Posten in interne Tabelle aufnehmen !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    APPEND i_fkkmavs.

  ENDLOOP.

  IF g_flex_dunn_active IS INITIAL.
*   Mahngruppenfelder ändern - bspw. Mahnverfahren neu setzen
    PERFORM event_0306 TABLES i_fkkmavs
                              i_fkkmagrp.
  ELSE.
* chamopion/challenger
    DATA: t1_fkkmagrp TYPE fkkmagrp_t,
          t2_fkkmagrp TYPE fkkmagrp_t.
    t1_fkkmagrp[] = i_fkkmagrp[].
    CALL FUNCTION 'FKK_CHALL_STRATEGY_DETERMINE'
      EXPORTING
        i_date      = gl_para_0300-ausdt
        it_fkkmagrp = t1_fkkmagrp
      IMPORTING
        et_fkkmagrp = t2_fkkmagrp.
    i_fkkmagrp[] = t2_fkkmagrp[].
    LOOP AT i_fkkmagrp WHERE NOT strat_champ IS INITIAL.
      LOOP AT i_fkkmavs WHERE gpart    = i_fkkmagrp-gpart
                          AND vkontgrp = i_fkkmagrp-vkontgrp
                          AND vtrefgrp = i_fkkmagrp-vtrefgrp
                          AND grpfield = i_fkkmagrp-grpfield
                          AND itemgrp  = i_fkkmagrp-itemgrp.
        i_fkkmavs-strat = i_fkkmagrp-strat.
        MODIFY TABLE i_fkkmavs.
      ENDLOOP.
    ENDLOOP.
    PERFORM event_0317 TABLES i_fkkmavs
                              i_fkkmagrp.
  ENDIF.

*-Clarifikation Controller beschicken
* Obsolete coding:
*  call function 'CFCSLOCKS_MODIFY'
*       tables
*            t_fkkcfcslocks = i_fkkcfcslocks
*       exceptions
*            others         = 0.

  DATA l_number_of_dunn_groups TYPE sy-tfill.
  DESCRIBE TABLE i_fkkmagrp LINES l_number_of_dunn_groups.
  IF l_number_of_dunn_groups > 0.
*   Message for the application protocol
    PERFORM message_append USING '>3' 'S' '226' l_number_of_dunn_groups
                                 space space space '4'.
    IF 1 = 2.
      MESSAGE s226 WITH l_number_of_dunn_groups. " Where-used
    ENDIF.
*   Increment counter for built dunning groups:
    CALL FUNCTION 'FKKMACNT_ADD_COUNTER'
      EXPORTING
        i_countid = con_count_built_groups  " groups to be checked
        i_value   = l_number_of_dunn_groups.
*   Something has to be done further:
    e_flag = space.
  ELSE.
    e_flag = 'X'. " No further processing to do
  ENDIF.

ENDFORM.                               " POSTEN_ABMISCHEN

*&---------------------------------------------------------------------*
*&      Form  event_0365
*&---------------------------------------------------------------------*
*       Call event 0365
*       Additional check of payment method
*----------------------------------------------------------------------*
FORM event_0365             USING    i_ezawe  TYPE fkkvkp-ezawe
                                     i_ebvty  TYPE fkkvkp-ebvty    "Note 1758081
                                     i_fkkvkp TYPE fkkvkp
                                     i_fkkop  TYPE fkkop
                                     i_ausdt  TYPE ausdt_kk
                           CHANGING c_xcash  TYPE xcash_kk
                                    c_not_dunn_other_reason TYPE boole_d
                                    c_fimsg  TYPE fimsg.

* Static variable to store if event has already been determined
  STATICS: s_func_module_determined TYPE xfeld VALUE ' '.

* Initialize
  CLEAR: c_not_dunn_other_reason,
         c_fimsg.

  IF s_func_module_determined = ' '.
    CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
      EXPORTING
        i_fbeve  = '0365'
        i_applk  = applk
      TABLES
        t_fbstab = t_fbstab_0365
      EXCEPTIONS
        OTHERS   = 0.
    s_func_module_determined = 'X'.
  ENDIF.
  LOOP AT t_fbstab_0365.
    CALL FUNCTION t_fbstab_0365-funcc
      EXPORTING
        i_ezawe                = i_ezawe
        i_ebvty                = i_ebvty        "Note 1758081
        i_fkkvkp               = i_fkkvkp
        i_fkkop                = i_fkkop
        i_ausdt                = i_ausdt
      IMPORTING
        e_xcash                = c_xcash
        e_other_reason         = c_not_dunn_other_reason
        e_fimsg                = c_fimsg
      EXCEPTIONS
        exception_with_message = 1
        OTHERS                 = 2.
    IF sy-subrc <> 0.
*     unknown error
      PERFORM message_append USING sy-msgid sy-msgty sy-msgno
              sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 '4'.
    ENDIF.
  ENDLOOP.
* Where-used list for this event
  SET EXTENDED CHECK OFF.
  IF 1 = 2. CALL FUNCTION 'FKK_SAMPLE_0365'. ENDIF.
  SET EXTENDED CHECK ON.

ENDFORM.                    " event_0365

*&---------------------------------------------------------------------*
*&      Form  BANK_ID_IN_ACCOUNT
*&---------------------------------------------------------------------*
*       This form provides a message that there is an incoming
*       payment method.
*       Only one message should be given for each contract account.
*&---------------------------------------------------------------------*
FORM bank_id_in_account USING i_gpart LIKE fkkop-gpart
                              i_vkont LIKE fkkop-vkont
                              i_ezawe LIKE fkkvkp-ezawe.

  STATICS: BEGIN OF vkont_tab OCCURS 10,
             gpart LIKE fkkop-gpart,
             vkont LIKE fkkop-vkont,
           END OF vkont_tab.

  READ TABLE vkont_tab INDEX 1.
  IF sy-subrc = 0 AND vkont_tab-gpart NE i_gpart.
    REFRESH vkont_tab.
  ENDIF.
  vkont_tab-gpart = i_gpart.
  vkont_tab-vkont = i_vkont.
* (The READ statement does not change header line of VTREF_TAB
* if correct entry is not found)
  READ TABLE vkont_tab WITH KEY gpart = i_gpart vkont = i_vkont.
  IF sy-subrc NE 0.
*   Contract account &1 contains incoming payment method &2
    PERFORM message_append USING '>3' 'S' '224' i_vkont i_ezawe i_gpart
                                                space '4'.
    IF 1 = 2.          "Verwendungsnachweis
      MESSAGE s224(>3) WITH i_vkont i_ezawe i_gpart.
    ENDIF.
    APPEND vkont_tab.
  ENDIF.
ENDFORM.                               " BANK_ID_IN_ACCOUNT

*&---------------------------------------------------------------------*
*&      Form  BANK_ID_IN_VTREF
*&---------------------------------------------------------------------*
*&    This is basically a copy from FORM BANK_ID_IN_ACCOUNT
*&---------------------------------------------------------------------*
FORM bank_id_in_vtref USING i_gpart LIKE fkkop-gpart
                            i_vkont LIKE fkkop-vkont
                            i_vtref TYPE vtref_kk
                            i_ezawe LIKE fkkvkp-ezawe.

  STATICS: BEGIN OF vtref_tab OCCURS 10,
             gpart LIKE fkkop-gpart,
             vkont LIKE fkkop-vkont,
             vtref LIKE fkkop-vtref,
           END OF vtref_tab.

  READ TABLE vtref_tab INDEX 1.
  IF sy-subrc = 0 AND vtref_tab-gpart <> i_gpart.
    REFRESH vtref_tab.
  ENDIF.
  vtref_tab-gpart = i_gpart.
  vtref_tab-vkont = i_vkont.
  vtref_tab-vtref = i_vtref.
* (The READ statement does not change header line of VTREF_TAB
* if correct entry is not found)
  READ TABLE vtref_tab WITH KEY gpart = i_gpart vkont = i_vkont
                                                vtref = i_vtref.
  IF sy-subrc NE 0.
*   Contract ... contains incoming payment method
    PERFORM message_append USING '>3' 'S' '368'
                   i_ezawe i_gpart i_vkont i_vtref
                                                '4'.
    IF 1 = 2.                          "Verwendungsnachweis
      MESSAGE s368(>3) WITH i_ezawe i_gpart i_vkont i_vtref.
    ENDIF.
    APPEND vtref_tab.
  ENDIF.
ENDFORM.                               " BANK_ID_IN_VTREF

*&---------------------------------------------------------------------*
*&      Form  NO_DUNNING_PROC_IN_ACCOUNT
*&---------------------------------------------------------------------*
FORM no_dunning_proc_in_account USING gpart LIKE fkkvkp-gpart
                                      vkont LIKE fkkvkp-vkont.

  STATICS: BEGIN OF vkont_tab OCCURS 10,
             gpart LIKE fkkop-gpart,
             vkont LIKE fkkop-vkont,
           END OF vkont_tab.

  READ TABLE vkont_tab INDEX 1.
  IF sy-subrc = 0 AND vkont_tab-gpart NE gpart.
    REFRESH vkont_tab.
  ENDIF.
  vkont_tab-gpart = gpart.
  vkont_tab-vkont = vkont.
  READ TABLE vkont_tab WITH KEY gpart = gpart vkont = vkont.
  IF sy-subrc NE 0.
    PERFORM message_append USING '>3' 'S' '234' vkont gpart
                                   space space '1'.
    SET EXTENDED CHECK OFF.
    IF 1 = 2. MESSAGE s234(>3). ENDIF.
    SET EXTENDED CHECK ON.
    APPEND vkont_tab.
  ENDIF.
ENDFORM.                               " NO_DUNNING_PROC_IN_ACCOUNT

*&---------------------------------------------------------------------*
*&      Form  Event_0364_eZAWE_FROM_VTREF
*&---------------------------------------------------------------------*
FORM event_0364_ezawe_from_vtref USING    i_fkkop_gpart LIKE fkkop-gpart
                                          i_fkkop_vkont LIKE fkkop-vkont
                                          i_fkkop_vtref LIKE fkkop-vtref
                                          i_fkkop_subap LIKE fkkop-subap
                                          i_date LIKE sy-datum
                                 CHANGING c_xcash TYPE xcash_kk
                                          c_ezawe TYPE ezawe_kk
                                    e_ezawe_from_vtref TYPE boole-boole
                                          c_ebvty TYPE ebvty_kk              "Note 1811989
                                          c_abwre TYPE abwre_kk.             "Note 1907452

  DATA: l_xcash TYPE xcash_kk.
  DATA: l_ezawe TYPE ezawe_kk.
  DATA: l_active TYPE boole-boole,
        l_ebvty TYPE ebvty_kk,               "Note 1811989
        l_abwre TYPE abwre_kk.               "Note 1907452

  CLEAR e_ezawe_from_vtref.

  READ TABLE t_fbstab_0364 INDEX 1.
  IF sy-subrc NE 0.
    REFRESH t_fbstab_0364.
    CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
      EXPORTING
        i_fbeve       = '0364'
        i_applk       = applk
      TABLES
        t_fbstab      = t_fbstab_0364
      EXCEPTIONS
        error_message = 1
        OTHERS        = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
  ENDIF.
  READ TABLE t_fbstab_0364 INDEX 1.
  CALL FUNCTION t_fbstab_0364-funcc
    EXPORTING
      i_gpart  = i_fkkop_gpart
      i_vkont  = i_fkkop_vkont
      i_vtref  = i_fkkop_vtref
      i_subap  = i_fkkop_subap
      i_date   = i_date
    IMPORTING
      e_xcash  = l_xcash
      e_ezawe  = l_ezawe
      e_active = l_active
      e_ebvty  = l_ebvty                              "Note 1811989
      e_abwre  = l_abwre                              "Note 1907452
    EXCEPTIONS
      OTHERS   = 0.
*   Where-used list for event
  SET EXTENDED CHECK OFF.
  IF 1 = 2. CALL FUNCTION 'FKK_SAMPLE_0364'. ENDIF.
  SET EXTENDED CHECK ON.
  IF sy-subrc = 0 AND l_active = 'X'.
*     When determination of parameters from object level
*     is successful and these parameters should be taken then
*     overwrite values from contract account level
    c_xcash = l_xcash.
    c_ezawe = l_ezawe.
    e_ezawe_from_vtref = 'X'.
    c_ebvty = l_ebvty.                                "Note 1811989
    c_abwre = l_abwre.                                "Note 1907452
  ENDIF.

ENDFORM.                               " Event_0364_eZAWE_FROM_VTREF
*&---------------------------------------------------------------------*
*&      Form  SET_FKKLOCKS_RANGES
*&---------------------------------------------------------------------*
FORM SET_FKKLOCKS_RANGES  TABLES  u_t_fkkop STRUCTURE fkkop. ">> Note 1785083

  FIELD-SYMBOLS: <l_fkkop> LIKE LINE OF u_t_fkkop.
  DATA: gpart_low  LIKE fkkvkp-gpart,
        gpart_high LIKE fkkvkp-gpart.

  CHECK u_t_fkkop[] IS NOT INITIAL.

* Read lowest GPART
  READ TABLE u_t_fkkop ASSIGNING <l_fkkop> INDEX 1.
  gpart_low = <l_fkkop>-gpart.

* Read highest GPART
  READ TABLE u_t_fkkop ASSIGNING <l_fkkop> INDEX sy-tfill.
  gpart_high = <l_fkkop>-gpart.

* Set ranges for lock interval
  CALL FUNCTION 'FKK_S_RANGE_VALUES_SET'
    EXPORTING
      i_init_type   = 'G'
      i_lower_limit = gpart_low
      i_upper_limit = gpart_high
    EXCEPTIONS
      OTHERS        = 1.

ENDFORM.                    " SET_FKKLOCKS_RANGES            "<< Note 1785083
