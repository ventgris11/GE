FUNCTION zintf_g_ctrl_date_rlv .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
**
** Par défaut, à partir des relèves pertinentes déjà intégrées,
** la recherche s'effectue sur la date de relève précise
**
** Excepté dans le cas d'une première relève où
** après une MES (Mise en Service) ou un CHF (Changement de Fournisseur),
** un décalage de plus ou moins 5 jours est autorisé avec la date de MES ou de CHF
**
** Ce traitement particulier est dû à la relève qui est quasiment toujours en décalage
** avec l'ADIF.
**

  DATA:
    lv_field     TYPE string,
    lv_equnr     TYPE equnr,
    lt_eabl      TYPE TABLE OF eabl,
    ls_eabl      TYPE eabl,
    ls_eablg     TYPE eablg,
    lv_ok        TYPE crmt_boolean,
    lv_message   TYPE char255,
    lv_low       TYPE rvari_val_255,
    lv_tolerance TYPE i,
    lv_date_min  TYPE dats,
    lv_date_max  TYPE dats,
    lr_cx_root   TYPE REF TO cx_root,
    ls_bpem      TYPE zbpem_flux_struct,
    lv_interface TYPE zisu_flxid.

  FIELD-SYMBOLS:
    <fs_emetteur>,
    <fs_flux>,
    <fs_idenreg>,
    <fs_num_pce>,
    <fs_debut_periode>.

  CLEAR: lv_field.
  MOVE 'FLUX-EMETTEUR'      TO lv_field.
  ASSIGN (lv_field)         TO <fs_emetteur>.

  CLEAR: lv_field.
  MOVE 'FLUX-FLUX'          TO lv_field.
  ASSIGN (lv_field)         TO <fs_flux>.

  CLEAR: lv_field.
  MOVE 'FLUX-IDENREG'       TO lv_field.
  ASSIGN (lv_field)         TO <fs_idenreg>.

  CLEAR: lv_field.
  MOVE 'FLUX-NUM_PCE'       TO lv_field.
  ASSIGN (lv_field)         TO <fs_num_pce>.

  CLEAR: lv_field.
  MOVE 'FLUX-DEBUT_PERIODE' TO lv_field.
  ASSIGN (lv_field)         TO <fs_debut_periode>.

  ev_etape = 2.

  CLEAR ls_bpem.
  ls_bpem-num_pce =  <fs_num_pce>.
  IF <fs_debut_periode> IS ASSIGNED .
    CASE <fs_flux>.
      WHEN 'ADIF'.
        ls_bpem-date_effet_cont = <fs_debut_periode>.
      WHEN 'RE6M' OR 'REMM' OR 'REJJ' OR 'REJM'.
        ls_bpem-date_releve     = <fs_debut_periode>.
      WHEN 'AFAC'.
        ls_bpem-date_fin_prest  = <fs_debut_periode>.
    ENDCASE.
  ENDIF.

  CLEAR:
    lv_ok,
    lv_equnr,
    lt_eabl[].

  CLEAR lv_ok.
  zcl_tool=>get_all_eabl_from_equipment(
    EXPORTING
      iv_ext_ui = <fs_num_pce>
      iv_date   = <fs_debut_periode>
    IMPORTING
      ev_ok     = lv_ok
      ev_equnr  = lv_equnr
      et_eabl   = lt_eabl ).



  IF lv_ok EQ abap_false
  OR lt_eabl[] IS INITIAL.
* &1 - &2 - &3 : Aucune relève pertinente pour le PCE &4
    MESSAGE e242(zintf_g_messages)
      WITH <fs_emetteur>
           <fs_flux>
           <fs_idenreg>
           <fs_num_pce>
      INTO lv_message.

    lv_interface    = <fs_flux>.
    ls_bpem-idenreg = <fs_num_pce>.

    CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
      EXPORTING
        iv_interface_name = lv_interface
        iv_sparte         = 'ZG'
        is_structure      = ls_bpem.

    RETURN.
  ENDIF.

  SET PARAMETER ID 'EQN' FIELD lv_equnr.

  CLEAR ls_eabl.

* Vérification s'il s'agit de la bonne date de la relève
*DEB-IBEN-20210301-GE-11502
*  READ TABLE lt_eabl
*        INTO ls_eabl INDEX 1.
*  IF ls_eabl-adat EQ <fs_debut_periode>.
  LOOP AT lt_eabl INTO ls_eabl.
    IF ls_eabl-zzdate_fin EQ <fs_debut_periode> OR gv_pose_225 EQ abap_true.
*FIN-IBEN-20210301-GE-11502
* Relève OK
      ev_etape = 1.
      SET PARAMETER ID 'EAB' FIELD ls_eabl-ablbelnr.
      RETURN.
    ENDIF.
*DEB-IBEN-20210301-GE-11502
  ENDLOOP.
*FIN-IBEN-20210301-GE-11502

* Vérification s'il s'agit d'une relève de MES ou de CHF
  CLEAR ls_eablg.
  SELECT SINGLE *
           FROM eablg
           INTO ls_eablg
          WHERE ablbelnr EQ ls_eabl-ablbelnr
            AND ablesgr  EQ '06'.

  IF sy-subrc NE 0.
* &1 - &2 - &3 : La dernière relève n'a pas une date début de période au &4
    MESSAGE e237(zintf_g_messages)
      WITH <fs_emetteur>
           <fs_flux>
           <fs_idenreg>
           <fs_debut_periode>
      INTO lv_message.
    RETURN.
  ENDIF.

* Vérification si la relève est comprise à +/- x jours
* en fonction de la tolérance définie ou non
* Si aucune valeur n'est définie, par défaut la tolérance est fixée à 5 jours
  lv_tolerance = 5.

* Récupération de la tolérance autorisée pour les premières relèves après MES / CHF
  SELECT SINGLE low
           INTO lv_low
           FROM tvarvc
          WHERE name EQ 'ZINTF_G_1ERE_RELEVE_TOLERANCE'.

  IF sy-subrc EQ 0.
    TRY.
        lv_tolerance = lv_low.
      CATCH cx_root INTO lr_cx_root.
        lv_tolerance = 5.
    ENDTRY.
  ENDIF.

  lv_date_min = <fs_debut_periode> - lv_tolerance.
  lv_date_max = <fs_debut_periode> + lv_tolerance.

  IF ls_eabl-adat BETWEEN lv_date_min AND lv_date_max.
* Relève OK
    ev_etape = 1.
    SET PARAMETER ID 'EAB' FIELD ls_eabl-ablbelnr.
    RETURN.
  ENDIF.

* &1 - &2 - &3 : La dernière relève n'a pas une date début de période au &4
  MESSAGE e237(zintf_g_messages)
    WITH <fs_emetteur>
         <fs_flux>
         <fs_idenreg>
         <fs_debut_periode>
    INTO lv_message.

ENDFUNCTION.
