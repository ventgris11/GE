*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 03.04.2019 at 18:10:39
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZINTF_A_FICHIER.................................*
DATA:  BEGIN OF STATUS_ZINTF_A_FICHIER               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_A_FICHIER               .
CONTROLS: TCTRL_ZINTF_A_FICHIER
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZINTF_A_FICHIER               .
TABLES: ZINTF_A_FICHIER                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
