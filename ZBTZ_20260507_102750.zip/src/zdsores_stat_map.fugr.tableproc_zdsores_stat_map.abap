*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDSORES_STAT_MAP
*   generation date: 03.04.2019 at 15:45:50
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDSORES_STAT_MAP    .

  PERFORM TABLEPROC.

ENDFUNCTION.
