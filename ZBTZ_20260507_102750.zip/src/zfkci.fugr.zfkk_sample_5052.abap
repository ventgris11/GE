FUNCTION zfkk_sample_5052.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(I_POSTYP) TYPE  POSTYP_KK
*"     REFERENCE(I_FKKCOLLH_I) LIKE  FKKCOLLH_I STRUCTURE  FKKCOLLH_I
*"       OPTIONAL
*"     REFERENCE(I_LFDNR) TYPE  LFDNR_KK OPTIONAL
*"  CHANGING
*"     REFERENCE(C_FKKCOLLP_IM) LIKE  FKKCOLLP_IM STRUCTURE
*"        FKKCOLLP_IM OPTIONAL
*"     REFERENCE(C_FKKCOLLP_IP) LIKE  FKKCOLLP_IP STRUCTURE
*"        FKKCOLLP_IP OPTIONAL
*"     REFERENCE(C_FKKCOLLP_IR) LIKE  FKKCOLLP_IR STRUCTURE
*"        FKKCOLLP_IR OPTIONAL
*"----------------------------------------------------------------------
  TYPES : BEGIN OF ty_commun,
            opbel TYPE opbel_kk,
            inkps TYPE inkps_kk,
            vkont TYPE vkont_kk,
            gpart TYPE gpart_kk,
          END OF ty_commun.

  TYPES : BEGIN OF ty_dfkkcolh,
            rudat   TYPE rgdat_kk,
            betrz   TYPE betrz_kk,
            blart   TYPE blart,
            betrz_e TYPE betrz_kk,
          END OF ty_dfkkcolh.

  DATA : ls_commun    TYPE ty_commun,
         ls_data_file TYPE ci_collpos_ir,
         ls_fkkcoll   TYPE dfkkcoll,
         lt_dfkkcollh TYPE TABLE OF ty_dfkkcolh,
         lv_betrz     TYPE betrz_kk,
         ls_dfkkcollh TYPE ty_dfkkcolh,
         ls_fkkop     TYPE dfkkop,
         lv_opupk     TYPE opupk_kk,
         lv_ur        TYPE ableinheit,
         ls_fkkvkp    TYPE fkkvkp,
         ls_dfkkrp    TYPE dfkkrp,
         lv_contrat   TYPE vertrag.

  DEFINE m_format_date.
    IF &1 IS NOT INITIAL.
        &2 = &1+6(2) && '/' && &1+4(2) && '/' && &1(4) .
    ENDIF.
  END-OF-DEFINITION.

  CASE i_postyp .
    WHEN '1' OR '5'  OR '4' OR '7'.
      "Payment: use structure C_FKKCOLLP_IP
      MOVE-CORRESPONDING c_fkkcollp_ip TO ls_commun.
    WHEN '2' .
      "Recall: use structure C_FKKCOLLP_IR
      MOVE-CORRESPONDING c_fkkcollp_ir TO ls_commun.
    WHEN '3' .
      "Master data changes: use structure C_FKKCOLLP_IM
  ENDCASE .

  lv_opupk = ls_commun-inkps .
  SELECT SINGLE *
     FROM dfkkop
     INTO ls_fkkop
     WHERE opbel = ls_commun-opbel
       AND opupk = lv_opupk .

  SELECT SINGLE *
    FROM dfkkcoll
    INTO ls_fkkcoll
    WHERE opbel = ls_commun-opbel
      AND inkps = ls_commun-inkps .


  FIELD-SYMBOLS <fs_dfkkcollh> TYPE ty_dfkkcolh.

  SELECT dfkkcollh~rudat
         dfkkcollh~betrz
         dfkkko~blart
    FROM dfkkcollh LEFT JOIN dfkkko
      ON dfkkcollh~augbl =  dfkkko~opbel
    INTO TABLE lt_dfkkcollh
    WHERE dfkkcollh~opbel = ls_commun-opbel
      AND dfkkcollh~inkps = ls_commun-inkps .
  IF sy-subrc IS INITIAL.
    SORT lt_dfkkcollh BY betrz ASCENDING .
    CLEAR : lv_betrz.
    LOOP AT lt_dfkkcollh ASSIGNING <fs_dfkkcollh>.
      <fs_dfkkcollh>-betrz_e = <fs_dfkkcollh>-betrz - lv_betrz .
      lv_betrz = <fs_dfkkcollh>-betrz .
    ENDLOOP.
  ENDIF.

  SELECT SINGLE *
       FROM fkkvkp
       INTO ls_fkkvkp
       WHERE vkont = ls_commun-vkont
         AND gpart = ls_commun-gpart.

  SELECT SINGLE * FROM dfkkrp
    INTO ls_dfkkrp
    WHERE opbel = ls_commun-opbel.

  CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
    EXPORTING
      input  = ls_fkkop-vtref
    IMPORTING
      output = lv_contrat.

  SELECT SINGLE eanlh~ableinh
    INTO lv_ur
    FROM eanlh INNER JOIN ever
      ON eanlh~anlage = ever~anlage
    WHERE ever~vertrag = lv_contrat .


  ls_data_file-zdebut_dso_file = '|'.
  ls_data_file-zposte          = ls_commun-inkps.

  ls_data_file-zpartner = ls_commun-gpart.

  IF matches( val = lv_ur regex = '.+BM.+').
    ls_data_file-ztype_facture = 'BIM' .
  ELSEIF matches( val = lv_ur regex = '.+AM.+').
    ls_data_file-ztype_facture = 'MENS' .
  ENDIF.

  m_format_date : sy-datum ls_data_file-zdate_transmission .


  CLEAR ls_data_file-zdate_naissance .


  ls_data_file-zenergie = ls_fkkop-spart .

*  ls_data_file-zref_dso = '?' .

  CLEAR : ls_data_file-zmotif_rejet .

  ls_data_file-zopbel           = ls_commun-opbel.
  m_format_date : ls_fkkop-faedn ls_data_file-zdate_echeance .
  ls_data_file-zmontant_init    = ls_fkkcoll-betrw .

  CLEAR : ls_data_file-zfrais         ,
          ls_data_file-zinterets      ,
          ls_data_file-zclause_penale .

  ls_data_file-zvkont   = ls_commun-vkont .
  ls_data_file-zcontrat = lv_contrat .

  LOOP AT lt_dfkkcollh INTO ls_dfkkcollh.
    IF ls_dfkkcollh-blart = 'BE'.
      ADD ls_dfkkcollh-betrz_e TO ls_data_file-zmontant_encaiss_dso .
    ELSE.
     ADD ls_dfkkcollh-betrz_e TO ls_data_file-zmontant_encaiss_gdp_btz .
    ENDIF.
  ENDLOOP.

  SORT lt_dfkkcollh  BY rudat DESCENDING.
  LOOP AT lt_dfkkcollh INTO ls_dfkkcollh WHERE blart NE 'BE'.
m_format_date : ls_dfkkcollh-rudat ls_data_file-zdate_encaiss_dso_gdp_btz .
    EXIT.
  ENDLOOP.

  READ TABLE lt_dfkkcollh INTO ls_dfkkcollh WITH KEY blart = 'BE'.
  IF sy-subrc IS INITIAL.
    m_format_date : ls_dfkkcollh-rudat ls_data_file-zdate_encaiss_dso.
  ENDIF.


  ls_data_file-zmontant_restant = ls_fkkcoll-betrw                   -
                                  ls_data_file-zmontant_encaiss_dso  -
                                 ls_data_file-zmontant_encaiss_gdp_btz .

  m_format_date : ls_fkkcoll-rudat ls_data_file-zdate_cloture  .
  IF ls_fkkcoll-agsta = '09'.
    ls_data_file-zmotif_cloture   = ls_fkkcoll-rugrd.
  ENDIF.

  IF i_postyp = '4'.
    ls_data_file-zmotif_dette = 'REJET'.
  ELSE.
    ls_data_file-zmotif_dette = 'IMPAY'.
  ENDIF.

  CASE i_postyp .
    WHEN '1'  OR '4' OR '5' OR '7'.
      "Payment: use structure C_FKKCOLLP_IP
      MOVE-CORRESPONDING ls_data_file TO c_fkkcollp_ip .
    WHEN '2' .
      "Recall: use structure C_FKKCOLLP_IR
      MOVE-CORRESPONDING ls_data_file TO c_fkkcollp_ir .
    WHEN '3' .
      "Master data changes: use structure C_FKKCOLLP_IM
      MOVE-CORRESPONDING ls_data_file TO c_fkkcollp_im .
  ENDCASE .

ENDFUNCTION.
