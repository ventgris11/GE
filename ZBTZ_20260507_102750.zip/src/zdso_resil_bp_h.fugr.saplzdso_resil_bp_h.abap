* regenerated at 21.04.2019 17:54:28
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDSO_RESIL_BP_HTOP.               " Global Data
  INCLUDE LZDSO_RESIL_BP_HUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDSO_RESIL_BP_HF...               " Subroutines
* INCLUDE LZDSO_RESIL_BP_HO...               " PBO-Modules
* INCLUDE LZDSO_RESIL_BP_HI...               " PAI-Modules
* INCLUDE LZDSO_RESIL_BP_HE...               " Events
* INCLUDE LZDSO_RESIL_BP_HP...               " Local class implement.
* INCLUDE LZDSO_RESIL_BP_HT99.               " ABAP Unit tests
  INCLUDE LZDSO_RESIL_BP_HF00                     . " subprograms
  INCLUDE LZDSO_RESIL_BP_HI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
