*---------------------------------------------------------------------*
*  INCLUDE LFKPZO00                                                   *
*---------------------------------------------------------------------*

*---------------------------------------------------------------------*
*      Module  INITIALIZATION                                         *
*---------------------------------------------------------------------*
MODULE INITIALIZATION OUTPUT.

  IF XDISPLAY IS INITIAL.
    SET PF-STATUS '100'.
  ELSE.
    SET PF-STATUS '100' EXCLUDING 'SELE'.
  ENDIF.
  SET TITLEBAR '100'.
  PERFORM SCREEN_MODIF.

ENDMODULE.


*---------------------------------------------------------------------*
*      Module  PAYMENT_METHOD_GET                                     *
*---------------------------------------------------------------------*
MODULE PAYMENT_METHOD_GET OUTPUT.

  FKK042Z-ZLSCH = T_F4-ZLSCH.
  FKK042Z-TEXT1 = T_F4-TEXT1.
  FKK042Z-XEINZ = T_F4-XEINZ.
  H_PRIOR       = T_F4-PRIOR.
  PERFORM SCREEN_MODIF.

ENDMODULE.
