FUNCTION zintf_g_ctrl_facture .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
* Modification   (GE-11713)                                            *
* DATE       : 11/10/2021                                              *                                                                                                                                                                      *
* USER       : HBENDHAFER                                              *
* TAG        : HBD                                                     *
* Description: Filtrer les bdoc deja annulés du processus d'annulation *
*                                                             de bdocs *
* OT         : DI1K928959   DI1K928967   DI1K928985                    *
*"----------------------------------------------------------------------

  DATA:
    lv_field        TYPE string,
    lv_int_ui       TYPE int_ui,
    lv_anlage       TYPE anlage,
    ls_object       TYPE eedm_isu_objects,
    lt_anlage       TYPE isu_t_eanlkey_h,
    lv_instdata     TYPE isu2a_instdata,
    lt_idispdata    TYPE isu_bi_inst_dispdata_tab,
    lv_idispdata    TYPE isu_bi_inst_dispdata,
    lt_ianl_bdoc    TYPE isu_bi_inst_billdoc_disp_tab,
    lv_ianl_bdoc    TYPE isu_bi_inst_billdoc_disp,
    lv_spcanc       TYPE spcanc,
    lv_etrg	        TYPE etrg,
    lv_bcancel_data	TYPE isu2a_bcancel_data,
    lv_message      TYPE char255.

  FIELD-SYMBOLS:
    <fs_emetteur>,
    <fs_flux>,
    <fs_idenreg>,
    <fs_num_pce>,
    <fs_date_releve>,
    <fs_type>, <fs_raison>. "++GE-2200

  DEFINE macro_add_message_to_log.
    ev_etape = 2.
    MESSAGE &1(zintf_g_messages)
       WITH <fs_emetteur>
            <fs_flux>
            <fs_idenreg>
            &2
       INTO lv_message.
    RETURN.
  END-OF-DEFINITION.

  ev_etape = 1.

  CLEAR: lv_field.
  MOVE 'FLUX-EMETTEUR'     TO lv_field.
  ASSIGN (lv_field)        TO <fs_emetteur>.

  CLEAR: lv_field.
  MOVE 'FLUX-FLUX'         TO lv_field.
  ASSIGN (lv_field)        TO <fs_flux>.

  CLEAR: lv_field.
  MOVE 'FLUX-IDENREG'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_idenreg>.

  CLEAR: lv_field.
  MOVE 'FLUX-NUM_PCE'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_num_pce>.


*++ STOU DEBUT GE-2200
*  CLEAR: lv_field.
*  MOVE 'FLUX-TYPE_RELEVE' TO lv_field.
*  ASSIGN (lv_field) TO <fs_type>.
*
*  CLEAR: lv_field.
*  MOVE 'FLUX-RAISON_RELEVE' TO lv_field.
*  ASSIGN (lv_field) TO <fs_raison>.

*-- STOU DEBUT GE-2204
*  IF <fs_flux> = 'RE6M' AND <fs_raison> IS ASSIGNED AND <fs_type> IS ASSIGNED .
*    IF <fs_raison> = '87' AND <fs_type> = 'S'.
*      CLEAR: lv_field.
*      MOVE 'FLUX-FIN_PERIODE' TO lv_field.
*      ASSIGN (lv_field) TO <fs_date_releve>.
*    ELSE.
*      CLEAR: lv_field.
*      MOVE 'FLUX-DATE_RELEVE' TO lv_field.
*      ASSIGN (lv_field) TO <fs_date_releve>.
*    ENDIF.
*  ELSE.
*    CLEAR: lv_field.
*    MOVE 'FLUX-DATE_RELEVE' TO lv_field.
*    ASSIGN (lv_field) TO <fs_date_releve>.
*  ENDIF.
*-- STOU FIN   GE-2204

  CLEAR: lv_field.
  MOVE 'FLUX-DATE_RELEVE'                 TO lv_field.
  ASSIGN (lv_field)                       TO <fs_date_releve>.

*++ STOU FIN   GE-2200

* Récupération du PCE
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).

  IF lv_int_ui IS INITIAL.
    IF 1 = 2. MESSAGE e240(zintf_g_messages). ENDIF.
*   &1 - &2 - &3 : PCE &4 inconnu
    macro_add_message_to_log e240 <fs_num_pce>.
  ENDIF.

* Récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.

  IF ls_object-installation IS INITIAL.
    IF 1 = 2. MESSAGE e241(zintf_g_messages). ENDIF.
*   &1 - &2 - &3 : Aucune installation trouvée pour le PCE &4
    macro_add_message_to_log e241 <fs_num_pce>.
  ENDIF.

  lv_anlage = ls_object-installation.

  INSERT lv_anlage INTO TABLE lt_anlage.

* Recherche des informations nécessaires aux différentes annulations
  CALL FUNCTION 'ISU_INST_BIVIEW_SELECT'
    EXPORTING
      x_ab         = <fs_date_releve>
      x_ianlkey    = lt_anlage
    IMPORTING
      y_instdata   = lv_instdata
    CHANGING
      xy_idispdata = lt_idispdata.

  CLEAR lv_idispdata.
  READ TABLE lt_idispdata INTO lv_idispdata WITH KEY anlage = lv_anlage.

* Contrôle s'il existe bien des documents de calcul de facturation
  CHECK lv_idispdata-ianl_bdoc[] IS NOT INITIAL.

  lt_ianl_bdoc = lv_idispdata-ianl_bdoc.

* Elimination des documents de calcul de facturation sans numéro
  DELETE lt_ianl_bdoc WHERE belnr IS INITIAL.

* Elimination des documents de calcul de facturation
* liés à des relèves antérieures à la relève corrigée
  DELETE lt_ianl_bdoc WHERE endabrpe LT <fs_date_releve>.

*&-<Début HBD
  "Elimination des documents deja annulés
  DATA : lt_erch      TYPE TABLE OF erch,
         ls_erch      TYPE erch,
         ls_ianl_bdoc TYPE isu_bi_inst_billdoc_disp.

  REFRESH lt_erch.
  IF lt_ianl_bdoc IS NOT INITIAL.
    SELECT * FROM erch INTO TABLE lt_erch FOR ALL ENTRIES IN lt_ianl_bdoc
      WHERE belnr = lt_ianl_bdoc-belnr.

    DELETE lt_erch WHERE stornodat IS INITIAL.
    DELETE lt_erch WHERE bcreason IS INITIAL.

    SORT lt_ianl_bdoc BY belnr.
    SORT lt_erch BY belnr.
  ENDIF.
  LOOP AT lt_erch INTO ls_erch.
    CLEAR ls_ianl_bdoc.
    READ TABLE lt_ianl_bdoc INTO ls_ianl_bdoc WITH KEY belnr = ls_erch-belnr BINARY SEARCH.
    IF sy-subrc EQ 0.
      "document deja annulé -> à supprimer de la selection
      DELETE lt_ianl_bdoc WHERE belnr EQ ls_erch-belnr.
    ENDIF.
  ENDLOOP.
*&- Fin HBD >

* Contrôle s'il existe bien des documents de calcul de facturation
* liés à des relèves postérieures ou égales à la relève corrigée
  CHECK lt_ianl_bdoc[] IS NOT INITIAL.

* Tri pour annuler les documents de calcul de facturation
* du plus récent au ancien sur la période considérée

  SORT lt_ianl_bdoc BY endabrpe DESCENDING.

  LOOP AT lt_ianl_bdoc INTO lv_ianl_bdoc.
* Facture aussi à annuler ?
    IF lv_ianl_bdoc-opbel IS INITIAL.
      lv_spcanc      = space.
    ELSE.
      lv_spcanc      = 'X'.
    ENDIF.
* Annulation des documents de calcul de facturation
    CALL FUNCTION 'ISU_BILL_CANCELLATION_INTERN'
      EXPORTING
        x_belnr        = lv_ianl_bdoc-belnr
        x_spcanc       = lv_spcanc
        x_bcreason     = 'Z1'
      IMPORTING
        y_etrg         = lv_etrg
        y_bcancel_data = lv_bcancel_data
      EXCEPTIONS
        general_fault  = 1
        system_error   = 2
        not_qualified  = 3
        foreign_lock   = 4
        OTHERS         = 9.

    IF sy-subrc NE 0.
      IF 1 = 2. MESSAGE e246(zintf_g_messages). ENDIF.
* &1 - &2 - &3 : Annulation document calcul facturation &4 impossible.
      macro_add_message_to_log e246 lv_ianl_bdoc-belnr.
    ENDIF.
  ENDLOOP.

  SET PARAMETER ID 'BILLPROCESS' FIELD lv_anlage.

ENDFUNCTION.
