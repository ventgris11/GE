* regenerated at 11.06.2019 17:56:48
FUNCTION-POOL ZINTF_DSO_LOG              MESSAGE-ID SV.

* INCLUDE LZINTF_DSO_LOGD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZINTF_DSO_LOGT00                       . "view rel. data dcl.
