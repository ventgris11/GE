FUNCTION zintf_g_ctrl_facture_recn .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
* Modification   (GE-11713)                                            *
* DATE       : 05/10/2021                                              *                                                                                                                                                                      *
* USER       : HBENDHAFER                                              *
* TAG        : HBD                                                     *
* Description: Annulation des releves ayant des correctives            *
*                          (dont dates de releves >= lv_date_releve) + *
* Garder que les releves annulables via EL37 dans le processus         *
* d'annulation des releves.                                            *
* OT         : DI1K928985 / DI1K928991                                 *
*"----------------------------------------------------------------------

  DATA:
    lv_field         TYPE string,
    lv_ablbelnr      TYPE ablbelnr,
    lv_date_releve   TYPE adat,
    lv_int_ui        TYPE int_ui,
    lv_anlage        TYPE anlage,
    ls_object        TYPE eedm_isu_objects,
    lt_anlage        TYPE isu_t_eanlkey_h,
    lv_instdata      TYPE isu2a_instdata,
    lt_idispdata     TYPE isu_bi_inst_dispdata_tab,
    lv_idispdata     TYPE isu_bi_inst_dispdata,
    lt_ianl_bdoc     TYPE isu_bi_inst_billdoc_disp_tab,
    lv_ianl_bdoc     TYPE isu_bi_inst_billdoc_disp,
    lt_iabl          TYPE isu_bi_inst_eabl_disp_tab, "HBD GE-11713
    ls_iabl          TYPE isu_bi_inst_eabl_disp,     "HBD GE-11713
    lv_spcanc        TYPE spcanc,
    lv_etrg	         TYPE etrg,
    lv_bcancel_data	 TYPE isu2a_bcancel_data,
    lv_message       TYPE char255,
*DEB-IBEN-20210118-GE-10867
    lv_low           TYPE rvari_val_255,
    lv_jours_facture TYPE i,
*FIN-IBEN-20210118-GE-10867
*&-<Début HBD GE-11713
    lt_eablg         TYPE TABLE OF eablg,
    ls_eablg         TYPE          eablg,
    lv_success       TYPE      abap_bool,
    lv_mr_not_found  TYPE      abap_bool,
    lv_message_mr    TYPE         string,
    lt_erch          TYPE TABLE OF erch,
    ls_erch          TYPE      erch,
    lt_erdk          TYPE TABLE OF erdk,
    ls_erdk          TYPE erdk.
*&- Fin HBD GE-11713>
  FIELD-SYMBOLS:
    <fs_emetteur>,
    <fs_flux>,
    <fs_idenreg>,
    <fs_num_pce>,
*DEB-IBEN-20210118-GE-10867
    <fs_fin_periode>.
*FIN-IBEN-20210118-GE-10867

  DEFINE macro_add_message_to_log.
    ev_etape = 2.
    MESSAGE &1(zintf_g_messages)
       WITH <fs_emetteur>
            <fs_flux>
            <fs_idenreg>
            &2
       INTO lv_message.
    RETURN.
  END-OF-DEFINITION.

  ev_etape = 1.

  CLEAR lv_field.
  MOVE 'FLUX-EMETTEUR'     TO lv_field.
  ASSIGN (lv_field)        TO <fs_emetteur>.

  CLEAR lv_field.
  MOVE 'FLUX-FLUX'         TO lv_field.
  ASSIGN (lv_field)        TO <fs_flux>.

  CLEAR lv_field.
  MOVE 'FLUX-IDENREG'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_idenreg>.

  CLEAR lv_field.
  MOVE 'FLUX-NUM_PCE'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_num_pce>.

*DEB-IBEN-20210118-GE-10867
  CLEAR lv_field.
  MOVE 'FLUX-FIN_PERIODE'  TO lv_field.
  ASSIGN (lv_field)        TO <fs_fin_periode>.
*FIN-IBEN-20210118-GE-10867

  GET PARAMETER ID 'EAB' FIELD lv_ablbelnr.

  IF NOT sy-subrc IS INITIAL.
    MESSAGE e168(zintf_g_messages)
       WITH 'Impossible de poursuivre le traitement'
            'du processus ZINTF_G_CTRL_FACTURE_RECN'
       INTO lv_message.
    ev_etape = 2.
    RETURN.
  ENDIF.


  SELECT SINGLE adat
    FROM eabl
    INTO lv_date_releve
   WHERE ablbelnr EQ lv_ablbelnr.

  IF NOT sy-subrc IS INITIAL.
    MESSAGE e168(zintf_g_messages)
       WITH 'Impossible de poursuivre le traitement'
            'du processus ZINTF_G_CTRL_FACTURE_RECN'
       INTO lv_message.
    ev_etape = 2.
    RETURN.
  ENDIF.

* Récupération du PCE
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).

  IF lv_int_ui IS INITIAL.
    IF 1 = 2. MESSAGE e240(zintf_g_messages). ENDIF.
*   &1 - &2 - &3 : PCE &4 inconnu
    macro_add_message_to_log e240 <fs_num_pce>.
  ENDIF.

* Récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = lv_date_releve
    IMPORTING
      es_detail = ls_object.

  IF ls_object-installation IS INITIAL.
    IF 1 = 2. MESSAGE e241(zintf_g_messages). ENDIF.
*   &1 - &2 - &3 : Aucune installation trouvée pour le PCE &4
    macro_add_message_to_log e241 <fs_num_pce>.
  ENDIF.

  lv_anlage = ls_object-installation.

  INSERT lv_anlage INTO TABLE lt_anlage.

* Recherche des informations nécessaires aux différentes annulations
  CALL FUNCTION 'ISU_INST_BIVIEW_SELECT'
    EXPORTING
      x_ab         = lv_date_releve
      x_ianlkey    = lt_anlage
    IMPORTING
      y_instdata   = lv_instdata
    CHANGING
      xy_idispdata = lt_idispdata.

  CLEAR lv_idispdata.
  READ TABLE lt_idispdata INTO lv_idispdata WITH KEY anlage = lv_anlage.

* Contrôle s'il existe bien des documents de calcul de facturation
*  CHECK lv_idispdata-ianl_bdoc[] IS NOT INITIAL.



*DEB-IBEN-20210118-GE-10867
  SELECT SINGLE low
           INTO lv_low
           FROM tvarvc
          WHERE name EQ 'ZINTF_G_REXX_C_JOURS_FACTURE'.

  lv_jours_facture = lv_low.

*FIN-IBEN-20210118-GE-10867

  lt_ianl_bdoc = lv_idispdata-ianl_bdoc.

* Elimination des documents de calcul de facturation sans numéro
  DELETE lt_ianl_bdoc WHERE belnr IS INITIAL.

* Elimination des documents de calcul de facturation
*DEB-IBEN-20210317-GE-11713
** liés à des relèves antérieures ou égales à la relève corrigée
*  DELETE lt_ianl_bdoc WHERE endabrpe LE lv_date_releve.
* liés à des relèves antérieures à la relève corrigée
*  DELETE lt_ianl_bdoc WHERE endabrpe LT lv_date_releve.
  DELETE lt_ianl_bdoc WHERE endabrpe LE lv_date_releve.  "HBD-GE-11713

  "HBD-GE-11713 : verifier que les documents remontés ne sont pas déja annulés
  REFRESH lt_erch.
  IF lt_ianl_bdoc IS NOT INITIAL.
    SELECT * FROM erch INTO TABLE lt_erch
      FOR ALL ENTRIES IN lt_ianl_bdoc
      WHERE belnr = lt_ianl_bdoc-belnr.

    DELETE lt_erch WHERE stornodat IS INITIAL.
    DELETE lt_erch WHERE bcreason  IS INITIAL.

    SORT lt_ianl_bdoc BY belnr.
    LOOP AT lt_erch INTO ls_erch.
      READ TABLE lt_ianl_bdoc TRANSPORTING NO FIELDS WITH KEY belnr = ls_erch-belnr BINARY SEARCH.
      IF sy-subrc EQ 0.
        DELETE lt_ianl_bdoc WHERE belnr = ls_erch-belnr.
      ENDIF.
    ENDLOOP.
  ENDIF.
*FIN-IBEN-20210317-GE-11713
*&-<Début GE-11713
  lt_iabl = lv_idispdata-iabl.
  DELETE lt_iabl WHERE ablbelnr IS INITIAL.
  DELETE lt_iabl WHERE adat LE lv_date_releve.
  SORT lt_iabl BY adat ASCENDING.
*&- Fin GE-11713>
* Contrôle s'il existe bien des documents de calcul de facturation
* liés à des relèves postérieures à la relève corrigée
  IF lt_ianl_bdoc[] IS NOT INITIAL. "HBD-GE-11713
*    CHECK lt_ianl_bdoc[] IS NOT INITIAL.

    "HBD-GE-11713-recuperation des dates d'impression DRUCKDAT(ERDK)
    REFRESH lt_erdk.
    SELECT * FROM erdk INTO TABLE lt_erdk FOR ALL ENTRIES IN lt_ianl_bdoc
      WHERE opbel = lt_ianl_bdoc-opbel.
    DELETE lt_erdk WHERE opbel IS INITIAL.
    SORT lt_erdk BY opbel.
* Tri pour annuler les documents de calcul de facturation
* du plus récent au ancien sur la période considérée

    SORT lt_ianl_bdoc BY endabrpe DESCENDING.

    LOOP AT lt_ianl_bdoc INTO lv_ianl_bdoc WHERE opbel IS NOT INITIAL.
*DEB-IBEN-20210503-GE-12024
** Facture aussi à annuler ?
*    IF lv_ianl_bdoc-opbel IS INITIAL.
*      lv_spcanc      = space.
*    ELSE.
*      lv_spcanc      = 'X'.
*    ENDIF.
*FIN-IBEN-20210503-GE-12024
      "HBD-GE-11713
      CLEAR ls_erdk.
      READ TABLE lt_erdk INTO ls_erdk WITH KEY opbel = lv_ianl_bdoc-opbel BINARY SEARCH.
      IF sy-subrc EQ 0.
*DEB-IBEN-20210118-GE-10867

        "HBD-GE-13162: controle ancienneté facture
        DATA : lv_days      TYPE vtbbewe-atage,
               lv_date_to   TYPE vtbbewe-dberbis,
               lv_date_from TYPE vtbbewe-dbervon.
        CLEAR : lv_days,lv_date_to,lv_date_from.

        lv_date_to   = sy-datum.
        lv_date_from = <fs_fin_periode>.

        CALL FUNCTION 'FIMA_DAYS_AND_MONTHS_AND_YEARS'
          EXPORTING
            i_date_from = lv_date_from
*           I_KEY_DAY_FROM       =
            i_date_to   = lv_date_to
*           I_KEY_DAY_TO         =
*           I_FLG_SEPARATE       = ' '
          IMPORTING
            e_days      = lv_days
*           E_MONTHS    =
*           E_YEARS     =
          .
        IF sy-subrc EQ 0.
          "HBD-GE-13162: controle ancienneté facture
*        IF ( abs( <fs_fin_periode> - sy-datum ) > lv_jours_facture ) AND ls_erdk-druckdat IS INITIAL.
          IF ( abs( lv_days ) > lv_jours_facture ) AND ls_erdk-druckdat IS NOT INITIAL.
            MESSAGE e255(zintf_g_messages)
               WITH <fs_num_pce>
                    lv_ianl_bdoc-opbel
                    <fs_fin_periode>
               INTO lv_message.
            ev_etape = 2.
            RETURN.
          ENDIF.
        ENDIF.
      ENDIF.
*FIN-IBEN-20210118-GE-10867
*DEB-IBEN-20210503-GE-12024
* Annulation des documents de calcul de facturation
*    CALL FUNCTION 'ISU_BILL_CANCELLATION_INTERN'
*      EXPORTING
*        x_belnr        = lv_ianl_bdoc-belnr
*        x_spcanc       = lv_spcanc
*        x_bcreason     = 'Z1'
*      IMPORTING
*        y_etrg         = lv_etrg
*        y_bcancel_data = lv_bcancel_data
*      EXCEPTIONS
*        general_fault  = 1
*        system_error   = 2
*        not_qualified  = 3
*        foreign_lock   = 4
*        OTHERS         = 9.
*
*    IF sy-subrc NE 0.
*      IF 1 = 2. MESSAGE e246(zintf_g_messages). ENDIF.
** &1 - &2 - &3 : Annulation document calcul facturation &4 impossible.
*      macro_add_message_to_log e246 lv_ianl_bdoc-belnr.
*    ENDIF.
*FIN-IBEN-20210503-GE-12024
    ENDLOOP.



*DEB-IBEN-20210503-GE-12024
    DATA: lv_error_annul TYPE string,
          lv_error_rap   TYPE abap_bool,
          lv_lines       TYPE i.

    CLEAR : lv_ianl_bdoc, lv_lines .                          "HBD-GE-11713
    DESCRIBE TABLE lt_ianl_bdoc LINES lv_lines.
    READ TABLE lt_ianl_bdoc INTO lv_ianl_bdoc  INDEX lv_lines.
    IF sy-subrc = 0.
      lv_date_releve = lv_ianl_bdoc-endabrpe.
    ENDIF.

* Annulation des documents de calcul de facturation
    CALL METHOD zcl_tool=>annule_factures
      EXPORTING
        iv_date         = lv_date_releve
        iv_installation = lv_anlage
      IMPORTING
        ev_error        = lv_error_annul
        ev_error_rap    = lv_error_rap.

    IF lv_error_annul IS NOT INITIAL AND lv_error_rap = abap_false.
      "Erreur dans méthode annulation.
      ev_etape = 2.
      RETURN.
    ELSE.
      "&-<Début-HBD-GE-11713 : Annulation des releves dont la date de releve >= lv_date_releve

      "récuperer les releves à annuler
      REFRESH lt_eablg.
      SELECT * FROM eablg INTO TABLE lt_eablg
        WHERE anlage =  lv_anlage
        AND   adatsoll GE lv_date_releve.

      "garder que les releves annulables via EL37 (supprimer les 03 06 08 12 14 15 19 20 21 22 23 24 25 26 27 90 91)
      DELETE lt_eablg WHERE ablesgr EQ '03'
                      OR    ablesgr EQ '06'
                      OR    ablesgr EQ '08'
                      OR    ablesgr EQ '12'
                      OR    ablesgr EQ '14'
                      OR    ablesgr EQ '15'
                      OR    ablesgr EQ '19'
                      OR    ablesgr EQ '20'
                      OR    ablesgr EQ '21'
                      OR    ablesgr EQ '22'
                      OR    ablesgr EQ '23'
                      OR    ablesgr EQ '24'
                      OR    ablesgr EQ '25'
                      OR    ablesgr EQ '26'
                      OR    ablesgr EQ '27'
                      OR    ablesgr EQ '90'
                      OR    ablesgr EQ '91'.
      "annuler les releves
      CLEAR : ls_eablg,lv_message_mr,lv_mr_not_found,lv_success.
      LOOP AT  lt_eablg INTO ls_eablg.
        CALL METHOD zcl_tool=>mr_cancel
          EXPORTING
            iv_mr_number         = ls_eablg-ablbelnr    " Numéro d'identification interne du document de relevé
            iv_mr_motif          = ls_eablg-ablesgr     " Motif de relevé
            iv_mr_type_to_cancel = '5'    " Type de documents à annuler (ordre de relève ...)
          IMPORTING
            ev_message           = lv_message_mr
            ev_mr_not_found      = lv_mr_not_found   " Variable logique
            ev_success           = lv_success.       " Variable logique

        IF lv_success IS INITIAL. "Pas possible de supprimer la relève => On quitte
*           "Erreur dans méthode annulation.
          ev_etape = 2.
          RETURN.
        ENDIF.
      ENDLOOP.
      "&-Fin-HBD-GE-11713 : Annulation des releves dont la date de releve >= lv_date_releve >

    ENDIF.
*FIN-IBEN-20210503-GE-12024
  ELSE.
    "HBD-GE-11713 : annulation des releves ne possedant pas un doc de calcul/ facture
    "récuperer les releves à annuler
    CLEAR ls_iabl.
    READ TABLE lt_iabl INTO ls_iabl INDEX 1.
    IF sy-subrc EQ 0.
      lv_date_releve = ls_iabl-adat.
      REFRESH lt_eablg.
      SELECT * FROM eablg INTO TABLE lt_eablg
        WHERE anlage   =  lv_anlage
        AND   adatsoll GE lv_date_releve
        AND   unterdr  = ''.
      "garder que les releves annulables via EL37 (supprimer les 03 06 08 12 14 15 19 20 21 22 23 24 25 26 27 90 91)
      DELETE lt_eablg WHERE ablesgr EQ '03'
                      OR    ablesgr EQ '06'
                      OR    ablesgr EQ '08'
                      OR    ablesgr EQ '12'
                      OR    ablesgr EQ '14'
                      OR    ablesgr EQ '15'
                      OR    ablesgr EQ '19'
                      OR    ablesgr EQ '20'
                      OR    ablesgr EQ '21'
                      OR    ablesgr EQ '22'
                      OR    ablesgr EQ '23'
                      OR    ablesgr EQ '24'
                      OR    ablesgr EQ '25'
                      OR    ablesgr EQ '26'
                      OR    ablesgr EQ '27'
                      OR    ablesgr EQ '90'
                      OR    ablesgr EQ '91'.

    ENDIF.
    "annuler les releves
    CLEAR : ls_eablg,lv_message_mr,lv_mr_not_found,lv_success.
    LOOP AT  lt_eablg INTO ls_eablg.
      CALL METHOD zcl_tool=>mr_cancel
        EXPORTING
          iv_mr_number         = ls_eablg-ablbelnr    " Numéro d'identification interne du document de relevé
          iv_mr_motif          = ls_eablg-ablesgr     " Motif de relevé
          iv_mr_type_to_cancel = '5'    " Type de documents à annuler (ordre de relève ...)
        IMPORTING
          ev_message           = lv_message_mr
          ev_mr_not_found      = lv_mr_not_found   " Variable logique
          ev_success           = lv_success.       " Variable logique

      IF lv_success IS INITIAL. "Pas possible de supprimer la relève => On quitte
*           "Erreur dans méthode annulation.
        ev_etape = 2.
        RETURN.
      ENDIF.
    ENDLOOP.

  ENDIF.


  "HBD-GE-11713 : Suite à l'annulation des releves, des OR sont parfois constatés dans l'install quand la date de releve 02
  "correspond à la date de releve cyclique de l'UR -> annulation de ses OR
  REFRESH lt_eablg.

  SELECT eablg~mandt
         eablg~ablbelnr
         eablg~anlage
         eablg~ablesgr
         eablg~abrdats
         eablg~ableinh
         eablg~adatsoll
         eablg~unterdr
     FROM eablg
    JOIN eabl ON ( eablg~ablbelnr = eabl~ablbelnr )
    INTO TABLE lt_eablg
    WHERE anlage =  lv_anlage
    AND   eablg~adatsoll GE lv_date_releve
    AND   ablstat = '0'
    AND   unterdr = ''.
  "garder que les releves annulables via EL37 (supprimer les 03 06 08 12 14 15 19 20 21 22 23 24 25 26 27 90 91)
  DELETE lt_eablg WHERE ablesgr EQ '03'
                  OR    ablesgr EQ '06'
                  OR    ablesgr EQ '08'
                  OR    ablesgr EQ '12'
                  OR    ablesgr EQ '14'
                  OR    ablesgr EQ '15'
                  OR    ablesgr EQ '19'
                  OR    ablesgr EQ '20'
                  OR    ablesgr EQ '21'
                  OR    ablesgr EQ '22'
                  OR    ablesgr EQ '23'
                  OR    ablesgr EQ '24'
                  OR    ablesgr EQ '25'
                  OR    ablesgr EQ '26'
                  OR    ablesgr EQ '27'
                  OR    ablesgr EQ '90'
                  OR    ablesgr EQ '91'.
  "annuler les releves
  CLEAR : ls_eablg,lv_message_mr,lv_mr_not_found,lv_success.
  LOOP AT  lt_eablg INTO ls_eablg.
    CALL METHOD zcl_tool=>mr_cancel
      EXPORTING
        iv_mr_number         = ls_eablg-ablbelnr    " Numéro d'identification interne du document de relevé
        iv_mr_motif          = ls_eablg-ablesgr     " Motif de relevé
        iv_mr_type_to_cancel = '5'    " Type de documents à annuler (ordre de relève ...)
      IMPORTING
        ev_message           = lv_message_mr
        ev_mr_not_found      = lv_mr_not_found   " Variable logique
        ev_success           = lv_success.       " Variable logique

    IF lv_success IS INITIAL. "Pas possible de supprimer la relève => On quitte
*           "Erreur dans méthode annulation.
      ev_etape = 2.
      RETURN.
    ENDIF.
  ENDLOOP.


  SET PARAMETER ID 'BILLPROCESS' FIELD lv_anlage.

ENDFUNCTION.
