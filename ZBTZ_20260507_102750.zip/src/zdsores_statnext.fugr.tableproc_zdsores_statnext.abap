*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDSORES_STATNEXT
*   generation date: 07.04.2019 at 13:51:40
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDSORES_STATNEXT    .

  PERFORM TABLEPROC.

ENDFUNCTION.
