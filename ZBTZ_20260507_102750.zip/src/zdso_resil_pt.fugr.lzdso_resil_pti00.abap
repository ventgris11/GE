*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 05.04.2019 at 12:51:31
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
