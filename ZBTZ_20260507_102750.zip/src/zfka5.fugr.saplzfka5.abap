*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFKA5TOP.                         " Global Data
  INCLUDE LZFKA5UXX.                         " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFKA5F...                         " Subroutines
* INCLUDE LZFKA5O...                         " PBO-Modules
* INCLUDE LZFKA5I...                         " PAI-Modules
* INCLUDE LZFKA5E...                         " Events
* INCLUDE LZFKA5P...                         " Local class implement.
* INCLUDE LZFKA5T99.                         " ABAP Unit tests
