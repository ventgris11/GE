*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZDSO_RESIL_PT_H
*   generation date: 21.04.2019 at 18:40:32
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZDSO_RESIL_PT_H    .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.
