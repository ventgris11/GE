"Name: \TY:CL_ISU_POD\ME:SET_PROPERTY_POD_EXT\SE:END\EI
ENHANCEMENT 0 ZENH_CL_ISU_POD.
** Par défaut, la modification du BEGRU ne permet pas de mettre à jour correctement le champ car le standard
** modifie la structure p_pod alors que le save utilise dialog. On force donc une modification du dialog ici
  IF x_property EQ 'BEGRU'.
*    p_obj-DATA-ui-euihead-begru = x_value.
    p_obj-dialog-header-begru = x_value.
  ENDIF.
ENDENHANCEMENT.
