FUNCTION z_isu_sample_tfk116_exclfacneg.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(X_VERVAR) LIKE  TFK115-VERVAR
*"     VALUE(X_VERART) LIKE  TFK110-VERART OPTIONAL
*"     VALUE(X_BLDAT) LIKE  FKKKO-BLDAT OPTIONAL
*"     VALUE(X_IFNAM) LIKE  TFK116-IFNAM
*"     VALUE(X_XSORT) LIKE  BOOLE-BOOLE DEFAULT SPACE
*"  TABLES
*"      T_E516_FKKCL STRUCTURE  E516_FKKCL
*"      T_SELTAB STRUCTURE  ISELTAB OPTIONAL
*"----------------------------------------------------------------------
* Ce MF a pour objectif de ne filtrer les pièces de type FA avec un montant négatif lors
* de rapprochement

  CASE x_ifnam.
    WHEN 'Z_EXCL_F_NEG'. " Controle sur le nom de la zone
      " On exclut les postes sont liés à une facture négatives
      LOOP AT t_e516_fkkcl ASSIGNING FIELD-SYMBOL(<lr_e516_fkkcl>).
        IF <lr_e516_fkkcl>-i_xnpos_te516 NE abap_true.
          " Si type de pièce FA (Facture) et montant négatif => On filtre
*DEB-IBEN-20200317-GE-8490
*          CHECK ( <lr_e516_fkkcl>-blart = 'FA' OR <lr_e516_fkkcl>-blart = 'AF' OR <lr_e516_fkkcl>-blart = 'RP' ) AND <lr_e516_fkkcl>-betrw < 0.
          "Exclusion des postes dont le montant est négatif pour les types de pièce ‘RP'
          " uniquement lorsque le secteur d’activité est absent
          CHECK ( <lr_e516_fkkcl>-blart = 'FA' OR <lr_e516_fkkcl>-blart = 'AF' OR ( <lr_e516_fkkcl>-blart = 'RP' AND <lr_e516_fkkcl>-spart IS NOT INITIAL ) ) AND <lr_e516_fkkcl>-betrw < 0.
          <lr_e516_fkkcl>-e_zreg_te516 = '2'.
*FIN-IBEN-20200317-GE-8490
        ENDIF.
      ENDLOOP.
  ENDCASE.
ENDFUNCTION.
