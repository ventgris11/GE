FUNCTION Z_FKK_SAMPLE_0651.
*"--------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(I_DFKKZA) LIKE  DFKKZA STRUCTURE  DFKKZA
*"     VALUE(I_PARA) LIKE  FKKPY_PARA STRUCTURE  FKKPY_PARA OPTIONAL
*"     VALUE(I_DPAYC) LIKE  DPAYC STRUCTURE  DPAYC OPTIONAL
*"     VALUE(I_PYBUK) TYPE  PYBUK_KK OPTIONAL
*"     VALUE(I_BASICS) TYPE  FKK_MAD_BASICS OPTIONAL
*"  EXPORTING
*"     VALUE(E_RESULT) LIKE  FKKPY_0651_RESULT
*"  STRUCTURE  FKKPY_0651_RESULT
*"  TABLES
*"      T_FK042A STRUCTURE  TFK042A
*"--------------------------------------------------------------------
*---------------------------------------------------------------------*
* preparation                                                         *
*---------------------------------------------------------------------*

* store import parameters in global fields
*  IMPORT-OPBUK = I_DFKKZA-BUKRS.
*  IMPORT-PYBUK = I_DFKKZA-PYBUK.
  IMPORT-WAERS = I_DFKKZA-WAERS.
  IMPORT-RWBTR = I_DFKKZA-BETRW.
  IMPORT-RBETR = I_DFKKZA-BETRH.
  IMPORT-CHKHB = 'X'.
  T_TFK042A[]  = T_FK042A[].

* PYBUK is always filled (see LFKPMASSFR0)
* ...from DFKKZA-PYBUK if filled
* ...else through FKK_PYBUK_DETERMINE_FOR_REPAYM
  IMPORT-PYBUK = I_PYBUK.
  IMPORT-OPBUK = I_PYBUK.    "because IMPORT-OPBUK used later on e.g. in CHECK_HOUSE_BANK

* read country and currency of company code
  PERFORM READ_COMPANY_CODE USING IMPORT-PYBUK.

* message about start of house bank selection
  PERFORM MESSAGE USING 185.

* init
  CLEAR: E_RESULT.

* read payment method
  CALL FUNCTION 'FKK_PAYMENT_METHOD_READ'
       EXPORTING
            I_PYBUK              = IMPORT-PYBUK
            I_PYMET              = I_DFKKZA-PYMET
       IMPORTING
            E_FKK042Z            = FKK042Z
            E_TFK042E            = TFK042E
       TABLES
            T_TFK042W            = T_TFK042W
       EXCEPTIONS
            NOT_FOUND_IN_COUNTRY = 1
            NOT_FOUND_IN_COMPANY = 2
            NOT_VALID            = 3
            OTHERS               = 4.
  IF SY-SUBRC NE 0.
    MSGID = SY-MSGID.
    MSGV1 = SY-MSGV1.
    MSGV2 = SY-MSGV2.
    MSGV3 = SY-MSGV3.
    MSGV4 = SY-MSGV4.
    PERFORM MESSAGE USING SY-MSGNO.
    EXIT.
  ENDIF.

* check house bank
  PERFORM CHECK_HOUSE_BANK USING SUBRC.
  CHECK SUBRC = 0.

* result
  E_RESULT-HBKID = T_HBANK-HBKID.
  E_RESULT-HKTID = T_HBANK-HKTID.

" if I_DFKKZA-BETRW > 10.
  E_RESULT-HBKID = 'HSBC'."CDEPA'."T_HBANK-HBKID.
  E_RESULT-HKTID = 'HSBC'. "T_HBANK-HKTID.
" endif.

* success message
  MSGV1 = T_HBANK-HBKID.
  MSGV2 = T_HBANK-HKTID.
  PERFORM MESSAGE USING 048.
ENDFUNCTION.
