* regenerated at 12.09.2019 11:03:16
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZINTF_E_C15_C_OPTOP.              " Global Data
  INCLUDE LZINTF_E_C15_C_OPUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZINTF_E_C15_C_OPF...              " Subroutines
* INCLUDE LZINTF_E_C15_C_OPO...              " PBO-Modules
* INCLUDE LZINTF_E_C15_C_OPI...              " PAI-Modules
* INCLUDE LZINTF_E_C15_C_OPE...              " Events
* INCLUDE LZINTF_E_C15_C_OPP...              " Local class implement.
* INCLUDE LZINTF_E_C15_C_OPT99.              " ABAP Unit tests
  INCLUDE LZINTF_E_C15_C_OPF00                    . " subprograms
  INCLUDE LZINTF_E_C15_C_OPI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
