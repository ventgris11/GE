*-------------------------------------------------------------------
***INCLUDE LFKMBF02 .
*-------------------------------------------------------------------

*&---------------------------------------------------------------------*
*&      Form  POSTEN_VERARBEITEN
*&---------------------------------------------------------------------*
*       Die offenen Posten werden nach Gruppen getrennt in
*       Päckchen aufgeteilt und diese einzeln weiterverarbeitet        *
*----------------------------------------------------------------------*
*  -->  I_FKKMAVS    offene Posten, bereits mit Mahnstufen versehen
*  -->  I_FKKMAGRP   Mahngruppen
*  <--  MV_FKKMAVS   Mahnvorschlag
*----------------------------------------------------------------------*
FORM posten_verarbeiten TABLES i_fkkmavs  STRUCTURE fkkmavs
                               i_fkkmagrp STRUCTURE fkkmagrp
                               i_fkkmared STRUCTURE fkkmared
                               mv_fkkmavs STRUCTURE fkkmavs.

* offene Posten, die zu einer Gruppe gehören
  DATA grp_fkkmavs  LIKE fkkmavs OCCURS 100 WITH HEADER LINE.
  DATA grp_fkkmared LIKE TABLE OF fkkmared WITH HEADER LINE.
* Vergleichsstruktur, um die Posten zu einer Gruppe zuzuordnen
  DATA cmp_fkkmagrp LIKE fkkmagrp.
* Zaehler fuer die interne Tabelle (SY-TABIX wg DELETE nicht geeignet)
  DATA mgrpx LIKE fkkmagrp-mgrpx.
  FIELD-SYMBOLS <fkkmavs>  TYPE fkkmavs.
  FIELD-SYMBOLS <fkkmared> TYPE fkkmared.

  REFRESH: grp_fkkmavs,
           mv_fkkmavs.

* Check whether there are any goups available
  DESCRIBE TABLE i_fkkmagrp.
  CHECK sy-tfill > 0.

  mgrpx = 0.
  LOOP AT i_fkkmagrp.
    REFRESH: grp_fkkmavs, grp_fkkmared.
* Gruppenzugehoerigkeit ist über die Zeilennummer der internen
* Tabelle I_FKKMAGRP, also SY-TABIX, festgelegt und wird hier ueber
* die Variable MGRPX kontrolliert.
    ADD 1 TO mgrpx.
    LOOP AT i_fkkmavs ASSIGNING <fkkmavs>
      WHERE mgrpx = mgrpx.
      APPEND <fkkmavs> TO grp_fkkmavs.
    ENDLOOP.
    LOOP AT i_fkkmared ASSIGNING <fkkmared>
    WHERE mgrpx = mgrpx.
      APPEND <fkkmared> TO grp_fkkmared.
    ENDLOOP.

*   Fill date of issue                           " Note 1630816
    MOVE akt_mahnd TO i_fkkmagrp-ausdt.          " Note 1630816

    PERFORM mahngruppe_verarbeiten TABLES grp_fkkmavs
                                          grp_fkkmared
                                   USING  i_fkkmagrp.
    DESCRIBE TABLE grp_fkkmavs.
* Gibt es in dieser Gruppe keinen Mahnvorschlag, wird sie gelöscht.
    IF sy-tfill = 0.
      DELETE i_fkkmagrp.
    ELSE.
* Die Gruppe wird dem Mahnvorschlag angehängt
      APPEND LINES OF grp_fkkmavs TO mv_fkkmavs.
* Zaehler wird noch eingetragen. Mit diesem Zaehler wird die
* Gruppenzugehoerigkeit gekennzeichet.
      i_fkkmagrp-mgrpx = mgrpx.
      MODIFY i_fkkmagrp.
    ENDIF.
  ENDLOOP.

ENDFORM.                               "  POSTEN_VERARBEITEN

*&---------------------------------------------------------------------*
*&      Form  MAHNGRUPPE_VERARBEITEN
*&---------------------------------------------------------------------*
*       den offenen Posten einer Mahngruppe werden die neuen           *
*       Mahnstufen zugeordnet, dabei werden Posten, die nicht          *
*       mahnrelevant sind, aus der Tabelle entfernt                    *
*----------------------------------------------------------------------*
*       <--> Table I_FKKMAVS       all open items of one group
*----------------------------------------------------------------------*
FORM mahngruppe_verarbeiten TABLES i_fkkmavs  STRUCTURE fkkmavs
                                   i_fkkmared STRUCTURE fkkmared
                            USING  i_fkkmagrp STRUCTURE fkkmagrp.

  DATA sum_betrh LIKE fkkop-betrh.     "Summe der Guthaben
  DATA sum_betrw LIKE fkkop-betrw.     "Summe der Guthaben
  DATA max_mahns LIKE fkkmavs-mahns.   "höchste Mahnstufe
  DATA akt_mahns LIKE fkkmavs-mahns.   "Mahnstufe der Mahnung
*  data akt_mstyp like fkkmavs-mstyp.   "Typ zu akt_mahns
  DATA max_mahnd LIKE fkkmavs-mahnd.   "letztes Mahndatum
  DATA l_reached  TYPE boole-boole.
  DATA l_rhyth    TYPE tfk047b-rhyth.
  DATA last_mahns LIKE fkkmavs-mahns. "letzte Mahnstufe "20.03.2000
  DATA xstudt.                        "flag: mind. ein Posten gestundet
  DATA xdebitexist.                   "flag: es gibt eine Forderung
  DATA xlesszero.                     "flag: Saldo kleiner Numm
  DATA x_dunnable_item_in_group.      "flag: in mindestens einem Posten
*                       " der Gruppe eine Mahnstufe groesser 0 erreicht
  DATA xlastlevel.                    "flag: letzte Mahnstufe erreicht
  DATA xlmst_group.                   "flag: es gibt einen Posten in der
*                      " Gruppe, der die letzte Mahnstufe erreicht hatte

* Hilfsfelder für Mahnverfahren und Mahnstufe. Dies muß nicht unbedingt
* in der Mahngruppe stehen.
  DATA h_mahnv LIKE fkkmagrp-mahnv.
  DATA h_waers LIKE fkkmagrp-waers.
  DATA h_bukrs LIKE fkkmagrp-bukrs.    "new KK4K008950
  DATA wa_mahnst_tab TYPE mahnst_tab_struc.
  DATA mahnst_tab TYPE mahnst_tab_type.
* Mindestprozentsatz
  DATA: l_do_not_dun         TYPE boole-boole,
        l_percentage_group   TYPE minpz_kk,
        l_percentage_limit   TYPE minpz_kk.


  REFRESH mahnst_tab.
  CLEAR: max_mahns, max_mahnd, sum_betrh, sum_betrw,
*         akt_mstyp,
         xlastlevel.

* für jeden Posten wird die jeweils neue Mahnstufe ermittelt

***** Hier werden nur die Verzugstage und mahnbare Mahnsperren geprüft,
***** nicht aber Grenzbeträge, das kommt später
  PERFORM mahnstufen_ermitteln TABLES i_fkkmavs
                                      i_fkkmared
                                      mahnst_tab
                             CHANGING max_mahnd
                                      sum_betrh  " Sum credits
                                      sum_betrw  " Sum credits
                                      xstudt
                                      xdebitexist
                                      xlesszero
                                      x_dunnable_item_in_group
                                      xlmst_group.

* Fehler aus dem Form auswerten und ins Protokoll schreiben:
* 1) Der Saldo ist kleiner als Null
  IF xlesszero = 'X'.
*   Drop all items of this group
    REFRESH i_fkkmavs.
    PERFORM message_append USING '>3' 'S' '257' space space
                                 space space '4'.
    SET EXTENDED CHECK OFF.
    IF 1 = 2. MESSAGE s257(>3). ENDIF.
    SET EXTENDED CHECK ON.
    EXIT.
  ENDIF.
  IF x_dunnable_item_in_group IS INITIAL.
*   Nicht mahnbar, weil kein Posten eine Mahnstufe groesser 0 erreicht
*   (Ist an dieser Stelle normalerweise der Fall, weil die Verzugstage
*   nicht erreicht wurden, was für jeden Posten in Event 0304 geprüft
*   wurde.)
****   Get a dunning procedure for the protocol message
***    loop at i_fkkmavs where betrw > 0.
***      exit.
***    endloop.
*   Drop all items of this group
    REFRESH i_fkkmavs.
    PERFORM message_append USING '>3' 'S' '346'
                               space space space space '4'.
    IF xstudt = 'X'.
      PERFORM message_append USING '>3' 'S' '235' space
                                   space space space '4'.
    ENDIF.
    SET EXTENDED CHECK OFF.
    IF 1 = 2. MESSAGE: s346(>3), s235(>3). ENDIF.
    SET EXTENDED CHECK ON.
    EXIT.
  ENDIF.

* Fuehrendes Vertragskonto bestimmen.
  PERFORM determine_vknt1_stdbk TABLES i_fkkmavs
                                CHANGING i_fkkmagrp-vknt1
                                         i_fkkmagrp-stdbk.

  DATA: mahnv_line1 TYPE mahnv_kk.
  DATA: x_mahnv_not_unique TYPE xfeld.
  DATA: waers_line1 TYPE waers_kk.
  DATA: x_waers_not_unique TYPE xfeld.
  FIELD-SYMBOLS <fkkmavs> TYPE fkkmavs.
  FIELD-SYMBOLS <fkkmared> TYPE fkkmared.
* Mahnverfahren MAHNV Währung WAERS und führender Buchungskreis OPBUK
* aus der Mahngruppe entnehmen, sofern
* sie dort eingetragen ist, sonst aus dem ersten Beleg
  READ TABLE i_fkkmavs INDEX 1.
  IF i_fkkmagrp-mahnv IS INITIAL.
    mahnv_line1 = i_fkkmavs-mahnv.
*   Check whether MAHNV is unique in this group
    CLEAR x_mahnv_not_unique.
    LOOP AT i_fkkmavs ASSIGNING <fkkmavs>.
      IF <fkkmavs>-mahnv <> mahnv_line1.
        x_mahnv_not_unique = 'X'.
        EXIT.                      "  exit from loop
      ENDIF.
    ENDLOOP.
    IF x_mahnv_not_unique = 'X'.
*     Call Event 0307
      PERFORM event_0307 TABLES i_fkkmavs
                                mahnst_tab
                         CHANGING h_mahnv
                                  i_fkkmagrp.
      IF h_mahnv IS INITIAL.
*       Message: Event 0307 did not provide a dunning procedure
        PERFORM message_append USING '>3' 'E' '345'
                       <fkkmavs>-gpart i_fkkmavs-vkont
                       <fkkmavs>-opbel space '2'.
        SET EXTENDED CHECK OFF.
        IF 1 = 2. MESSAGE s345(>3). ENDIF.
        SET EXTENDED CHECK ON.
*       Drop all items of this group because it can not be dunned
        REFRESH i_fkkmavs.
        EXIT.                   " Exit from FORM mahngruppe_verarbeiten
      ELSE.
        i_fkkmagrp-mahnv = h_mahnv.
      ENDIF.
    ELSE.
      i_fkkmagrp-mahnv = mahnv_line1.
      h_mahnv = mahnv_line1.
    ENDIF.
  ELSE.
*   Take dunning procedure from grouping structure
    h_mahnv = i_fkkmagrp-mahnv.
  ENDIF.
* Die nächsten Zeilen sind genauso wie in Hinweis 415926
  IF h_mahnv IS INITIAL.
    PERFORM message_append USING '>3' 'E' '481'
                       h_mahnv space space space '2'.
*   Drop all items of this group because it can not be dunned
    REFRESH i_fkkmavs.
    EXIT.                    " Exit from Form mahngruppe_verarbeiten
  ENDIF.

* Determine currency of dunning notice
  READ TABLE i_fkkmavs INDEX 1.
  IF i_fkkmagrp-waers IS INITIAL.
* >>>> note 433981 XGK
    waers_line1 = i_fkkmavs-waers.
* Check whether WAERS (currency) is unique in this group
    CLEAR x_waers_not_unique.
    LOOP AT i_fkkmavs ASSIGNING <fkkmavs>.
      IF <fkkmavs>-waers <> waers_line1.
        x_waers_not_unique = 'X'.
        EXIT.                      "  exit from loop
      ENDIF.
    ENDLOOP.
    LOOP AT i_fkkmared ASSIGNING <fkkmared>.
      IF <fkkmared>-waers <> waers_line1.
        x_waers_not_unique = 'X'.
        EXIT.
      ENDIF.
    ENDLOOP.
* Take transaction currency h_waers from the item only if all items
* have the same currency
    IF x_waers_not_unique = 'X'.
      CLEAR h_waers.
    ELSE.
      h_waers = waers_line1.
    ENDIF.
* <<<< note 433981 XGK
  ELSE.
    h_waers = i_fkkmagrp-waers.
  ENDIF.
* Beachte: mit Event 0309 kann das Feld FKKMAGRP-OPBUK geloescht werden
  IF i_fkkmagrp-opbuk IS INITIAL.
    h_bukrs = i_fkkmavs-bukrs.
  ELSE.
    h_bukrs = i_fkkmagrp-opbuk.
  ENDIF.

* Hauswaehrung aus dem (führenden) Buchungskreis h_bukrs ermitteln
* Merke die Waehrung und den zugehoerigen Buchungskreis
  IF g_local_waers IS INITIAL OR g_local_bukrs NE h_bukrs.
    PERFORM get_local_currency
            USING     h_bukrs
         CHANGING     g_local_waers
                      g_local_bukrs.
  ENDIF.

  DATA l_error_occurred TYPE xfeld.
* check the maximum dunning level for this dunning step
* höchste Mahnstufe aller Posten (der Gruppe) ermitteln
******* Hier werden die Grenzbeträge geprüft *******
  PERFORM mahnstufen_tabelle_verarbeiten
                                      TABLES mahnst_tab
                                       USING h_mahnv
                                             h_waers      g_local_waers
                                             sum_betrh    sum_betrw
                                             xlmst_group
                                    CHANGING
* Maximale Mahnstufe der Posten, die nicht die letzte Mahnstufe
* erreicht haben:
                                             akt_mahns
* Letzte Mahnstufe, falls es Posten in dieser Stufe gab:
                                             last_mahns
* Kennzeichen fuer Posten in letzter Mahnstufe vorhanden:
                                             i_fkkmagrp-xlmst
                                             l_error_occurred.
  IF l_error_occurred = 'X'.
*   Drop all items of this group because it can not be dunned
*   An appropriate message must have been set.
    REFRESH i_fkkmavs.
    EXIT.                    " Exit from Form mahngruppe_verarbeiten
  ENDIF.

* Ist letzte Mahnstufe erreicht, prüfe, ob weitere Mahnung erfolgen soll
  IF i_fkkmagrp-xlmst = 'X'.
    PERFORM last_dunning_level TABLES   i_fkkmavs
                               USING    i_fkkmagrp-mahnv
                                        i_fkkmagrp-gpart
                                        last_mahns
                               CHANGING i_fkkmagrp-xlmst
                                        akt_mahns.
    CHECK i_fkkmagrp-xlmst IS INITIAL.
    xlastlevel = 'X'.
  ENDIF.
* Sind selbst die Grenzbeträge für Mahnstufe 1 nicht erreicht, wird
* nicht gemahnt.
  IF akt_mahns = 0.
    REFRESH i_fkkmavs.
    PERFORM message_append USING '>3' 'S' '258' h_mahnv
                                 space space space '4'.
*   "Grenzbetrag im Mahnverfahren &1 nicht erreicht"
    IF 1 = 2. MESSAGE s258(>3) WITH h_mahnv. ENDIF.
    EXIT.
  ENDIF.

* Jetzt steht mit AKT_MAHNS die Mahnstufe der Mahnung fest (GD) ***
* Ich schreibe die Mahnstufe (und -typ) in die Gruppierungsstruktur.
* Dann braucht die Mahnstufe nicht mehr in FKK_DETERMINE_DUNNING_HISTORY
* aus den Posten bestimmt zu werden
  i_fkkmagrp-mahnn = akt_mahns.
  DATA l_tfk047b TYPE tfk047b.
  PERFORM read_tfk047b USING h_mahnv akt_mahns
                       CHANGING l_tfk047b.
  i_fkkmagrp-mstnn = l_tfk047b-mstyp.

* Grenzprozentsatz pruefen
  PERFORM event_0336 TABLES    i_fkkmavs
                     USING     i_fkkmagrp
                     CHANGING  l_do_not_dun
                               l_percentage_group
                               l_percentage_limit.

  IF NOT l_do_not_dun IS INITIAL.
    REFRESH: i_fkkmavs, i_fkkmared.
    PERFORM message_append USING '>4' 'S' '670' space space
                                  space space '4'.
    PERFORM message_append USING '>4' 'S' '671' l_percentage_group l_percentage_limit
                                  space space '4'.
    SET EXTENDED CHECK OFF.
    IF 1 = 2. MESSAGE: s670(>4), s671(>4). ENDIF.
    SET EXTENDED CHECK ON.
    EXIT.
  ENDIF.

* >>>> note 532203 XGK >>>>>>>>>
** An dieser Stelle wird noch eine Prüfung benötigt, ob es mindestens
** eine Mahnstufe gibt, in der die Grenzbeträge überhaupt erreicht
** sind (keine Mahnung soll durch Kleinbeträge ausgelöst werden)
*  data rc.
*  if l_tfk047b-xaend is initial.
*    loop at mahnst_tab into wa_mahnst_tab
*      where mahns <= l_tfk047b-mahns.
*      perform check_minimum_amount using h_waers local_waers
*                                         h_mahnv wa_mahnst_tab-mahns
*                                         wa_mahnst_tab-betrw
*                                         wa_mahnst_tab-betrh
*                                changing rc.
*      if rc ne '1'.
*        exit.
*      endif.
*    endloop.
*    if sy-subrc = 0 and rc ne '0'.
*      refresh i_fkkmavs.
*      perform message_append using '>3' 'S' '258' h_mahnv
*                                   space space space '4'.
*      if 1 = 2. message s258(>3) with h_mahnv. endif.
*      exit.
*    endif.
*  endif.
* <<<<< note 532203 XGK <<<<<<

* darf die Mahnstufe überhaupt ausgelöst werden?
  IF l_tfk047b-xextm NE space AND
     l_tfk047b-xextm NE gl_para_0300-xextm.
    REFRESH i_fkkmavs.
    IF gl_para_0300-xextm = '1'.       " = Mahnlauf
      PERFORM message_append USING '>3' 'S' '244' l_tfk047b-mahns
                                   l_tfk047b-mahnv l_tfk047b-xextm
                                   space '4'.
      SET EXTENDED CHECK OFF.
      IF 1 = 2. MESSAGE s244(>3). ENDIF.
      SET EXTENDED CHECK ON.
      EXIT.
    ENDIF.
  ENDIF.

  IF NOT max_mahnd IS INITIAL.
* Mahnrhythmus der höchsten Mahnstufe prüfen
*   max_mahnd + l_rhyth <= akt_mahnd

    IF gl_para_0300-xextm = '1'.
      MOVE l_tfk047b-rhyth TO l_rhyth.
    ELSEIF gl_para_0300-xextm = '2'.
      MOVE l_tfk047b-arhyt TO l_rhyth.
    ENDIF.
*********** Hier wird der Mahnrhythmus geprüft ************
    CALL FUNCTION 'FKK_DUNN_GET_FREQUENCY'
      EXPORTING
        x_mahnv          = i_fkkmagrp-mahnv
        x_mahnd          = max_mahnd
        x_ausdt          = akt_mahnd
        x_rhyth          = l_rhyth
      IMPORTING
        e_rhythm_reached = l_reached
      EXCEPTIONS
        OTHERS           = 1.
    IF sy-subrc NE 0.
      PERFORM message_append USING sy-msgid 'E' sy-msgno
                                sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
                                space.
      EXIT.
    ENDIF.
* Bei Mahnlauf (XEXTM = '1') wird normaler Mahnrhythmus geprüft, bei
* anderen Programmen dagegen der abweichende Mahnrhythmus.
    IF l_reached IS INITIAL.
* wenn der Mahnrhythmus für die Mahnstufe nicht erreicht ist, wird
* keine Mahnung erzeugt.
      i_fkkmagrp-xmgrh = 'X'.
      PERFORM message_append USING '>3' 'S' '228' l_tfk047b-mahns
                                   l_tfk047b-mahnv l_tfk047b-rhyth
                                   space '4'.
      SET EXTENDED CHECK OFF.
      IF 1 = 2. MESSAGE s228(>3). ENDIF.
      SET EXTENDED CHECK ON.
      EXIT.
    ENDIF.
  ENDIF.
* Die Mahnstufen der Posten werden auf die höchste Mahnstufe begrenzt.
  PERFORM mahnstufen_anpassen TABLES i_fkkmavs
                              USING  l_tfk047b-mahnv
                                     l_tfk047b-mahns
                                     i_fkkmagrp-xlmst
                                     l_tfk047b-mstyp
                                     l_tfk047b-xpost
                                     l_tfk047b-xnbgm
                        CHANGING max_mahns. " max DL of changed items

* In den Zeilen der Mahngruppe muss eine Hauptforderung
* oder eine mahnauslösende Nebenforderung enthalten sein.
* Eine mahnauslösende Nebenforderung wird hier
* auch als "main receivable" bezeichnet.
  DATA: main_receivable_found TYPE xfeld.
  DATA: l_subrc.
  PERFORM search_main_receivable TABLES i_fkkmavs
                CHANGING main_receivable_found. "  l_subrc.
*  if l_subrc <> 0.
*    exit.
*  endif.
  IF main_receivable_found IS INITIAL.
*   Only additional receivables in group -> do not dun
*   Drop items of this group
    REFRESH i_fkkmavs.
*   Count one group as dropped
    CALL FUNCTION 'FKKMACNT_ADD_COUNTER'
      EXPORTING
        i_countid = con_count_main_rec_missing.
*   Give message for application protocol:
    PERFORM message_append USING '>3' 'S' '411'
                   space space space space '4'.
*   Where-used for message:
    SET EXTENDED CHECK OFF.
    IF 1 = 2. MESSAGE s411(>3). ENDIF.
    SET EXTENDED CHECK ON.
*   Leave FORM mahngruppe_verarbeiten:
    EXIT.
  ENDIF.

* Wenn sich in keinem Posten die Mahnstufe erhöht hat,
* blieb MAX_MAHNS auf Null und es wird abhängig vom
* Kennzeichen TFK047B-XAEND nicht gemahnt.
  IF max_mahns = 0 AND
     l_tfk047b-xaend IS INITIAL.
*   and xlastlevel is initial. "Ansichtssache
    i_fkkmagrp-xmgrh = 'X'.
    PERFORM message_append USING '>3' 'S' '229' l_tfk047b-mahns
                                 space space space '4'.
    SET EXTENDED CHECK OFF.
    IF 1 = 2. MESSAGE s229(>3). ENDIF.
    SET EXTENDED CHECK ON.
    EXIT.
  ELSE.
* Zahlunsgziel aus der Zahlungsfrist ermitteln
    IF l_tfk047b-frist > 0.
      CALL FUNCTION 'FKK_DUNN_GET_DUE_DATE'
        EXPORTING
          x_mahnv = l_tfk047b-mahnv
          x_frist = l_tfk047b-frist
          x_ausdt = gl_para_0300-ausdt
        IMPORTING
          y_frdat = i_fkkmagrp-frdat
        EXCEPTIONS
          OTHERS  = 1.
      IF sy-subrc NE 0.
        PERFORM message_append USING sy-msgid 'S' sy-msgno
                                  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
                                     '1'.
      ENDIF.
    ELSE.
      CLEAR i_fkkmagrp-frdat.
    ENDIF.
* alles in Ordnung: Erfolgsmeldung ins Protokoll
    PERFORM message_append USING '>3' 'S' '254'
                                 l_tfk047b-mahnv l_tfk047b-mahns
                                 i_fkkmavs-gpart space '4'.
    SET EXTENDED CHECK OFF.
    IF 1 = 2. MESSAGE s254(>3). ENDIF. "Verwendungsnachweis
    SET EXTENDED CHECK ON.
  ENDIF.

* Collection success
  IF NOT l_tfk047b-xdsuc IS INITIAL.
    i_fkkmagrp-scdst = '1'.
    IF NOT i_fkkmagrp-frdat IS INITIAL.
      i_fkkmagrp-sucdt = i_fkkmagrp-frdat + 7.
    ELSE.
      i_fkkmagrp-sucdt = gl_para_0300-ausdt + 14.
    ENDIF.
  ENDIF.

ENDFORM.                               " MAHNGRUPPE_VERARBEITEN

*&---------------------------------------------------------------------*
*&      Form  MAHNSTUFEN_ERMITTELN
*&---------------------------------------------------------------------*
*       Für jeden Posten wird die neue Mahnstufe gesetzt.              *
*       Diese ist entweder die vorgegebene Mahnstufe aus der           *
*       FKKMAZE, oder sie wird vom Programm ermittelt.                 *
*       In der Mahnstufentabelle werden die Mahnstufen zusammengefasst *
*----------------------------------------------------------------------*
*  <--  max_mahnd   Datum der letzten Mahnung (in dieser Mahngruppe)
*       max_mahns   höchste Mahnstufe, die erreicht werden kann
*       sum_betrh   Betrag der offenen Gutschriften und Zahlungen
*       last_mahns  FLAG: letzte Mahnstufe erreicht
*----------------------------------------------------------------------*
FORM mahnstufen_ermitteln TABLES i_fkkmavs  STRUCTURE fkkmavs
                                 i_fkkmared STRUCTURE fkkmared
                                 c_mahnst_tab TYPE mahnst_tab_type
                        CHANGING max_mahnd LIKE fkkmavs-mahnd
                                 sum_betrh LIKE fkkmavs-betrh
                                 sum_betrw LIKE fkkmavs-betrw
                                 xstudt TYPE c
                                 xdebitexist TYPE c
                                 xlesszero TYPE c
                                 x_dunnable_item_in_group TYPE c
                                 xlmst_group TYPE c.

* Die Ermittlung der nächsten Mahnstufe erfolgt im Ereignis 304.
* Damit der Kunde die Möglichkeit hat, eigene Kriterien zur Bestimmung
* der nächsten Mahnstufe zu definieren, werden an das Ereignis alle
* Posten des Mahnvorschlags übergeben.

  DATA:
    it_fkkmavs LIKE fkkmavs OCCURS 0 WITH HEADER LINE,
    int_sum_betrh LIKE fkkmavs-betrh,
    f_debit.

* Posten kopieren, damit im Event keine Seiteneffekte auftreten können.
  it_fkkmavs[] = i_fkkmavs[].

* Es werden noch einige Prüfungen durchgeführt, die im erweiterten
* Protokoll genau darstellen sollen, warum keine Mahnung durchgeführt
* werden kann:
* 1. Saldo < 0
* 2. keine Forderungen vorhanden
* 3. Verzugstage der ersten Mahnstufe erreicht oder nicht
* 4. mindestens ein Posten ist gestundet
  CLEAR: xstudt,                     " 4.
         xdebitexist,
         xlesszero,                  " 1.
         x_dunnable_item_in_group,   " 3.
         int_sum_betrh,
         xlmst_group.

  FIELD-SYMBOLS <fkkmavs>  TYPE fkkmavs.
  FIELD-SYMBOLS <fkkmared> TYPE fkkmared.
  LOOP AT i_fkkmavs ASSIGNING <fkkmavs>.
    IF <fkkmavs>-xlmst EQ 'X' .                     "Note 1543727
      PERFORM read_tfk047a USING <fkkmavs>-mahnv.   "Note 1543727
    ENDIF.                                          "Note 1543727
* letztes Mahndatum aus den Posten ermitteln
* The lines are ignored for calculation of the last dunning date
* if the last dunning level has been reached and VLMST = 4
    IF <fkkmavs>-mahnd > max_mahnd  AND             "Note 1543727
       NOT ( <fkkmavs>-xlmst EQ 'X' AND             "Note 1543727
         tfk047a-vlmst EQ '4' ).                    "Note 1543727
      max_mahnd = <fkkmavs>-mahnd.
    ENDIF.
* Für die Saldoprüfung werden die Beträge addiert
    IF <fkkmavs>-pdunn = 'X' AND                    "Note 1543727
       NOT ( <fkkmavs>-xlmst EQ 'X' AND             "Note 1543727
         tfk047a-vlmst EQ '4' ).                    "Note 1543727
      ADD <fkkmavs>-betrh TO int_sum_betrh.
    ENDIF.
* Guthaben:
* es ist möglich, dass ein Posten sowohl Forderungen als auch
* Guthaben enthält, z.B. Faktura-Belege oder Belege, die
* Rundungsdifferenzen enthalten.
* Pragmatischer Ansatz: Diese Guthaben erhalten Mahnstufen, wie die
* zugehörigen Forderungen. Dazu muss aber zu jedem Guthaben geschaut
* werden, ob es Forderungen gibt.
* Problem: Guthaben, das nur eine Habenzeile der Rundungsdifferenz
* hat.
* E credits:
* E if in one document we have credit items and debit items, the
* E the items are considered together
    DATA: h_sum LIKE fkkmavs-betrh.                         "21.03.2000

    f_debit = space.
    IF <fkkmavs>-betrh < 0.
      CLEAR h_sum.
*     Attention: do not use the same WA for loop
      DATA: wa_fkkmavs LIKE fkkmavs.
      LOOP AT i_fkkmavs INTO wa_fkkmavs
        WHERE opbel = <fkkmavs>-opbel.
        ADD wa_fkkmavs-betrh TO h_sum.
      ENDLOOP.
*      LOOP AT i_fkkmavs
*        WHERE opbel = <fkkmavs>-opbel.
*        ADD <fkkmavs>-betrh TO h_sum.
*      ENDLOOP.
      IF sy-subrc NE 0 OR h_sum < 0.
        f_debit = 'X'.
      ENDIF.
*      LOOP AT I_FKKMAVS  TRANSPORTING NO FIELDS
*        WHERE OPBEL = <fkkmavs>-OPBEL
*          AND BETRH > 0.
*        EXIT.
*      ENDLOOP.
*      IF SY-SUBRC NE 0.
*        F_DEBIT = 'X'.
*      ENDIF.
    ENDIF.
    IF f_debit = 'X'.
      IF <fkkmavs>-faedn LE gl_para_0300-ausdt.
*       Add up negative items
        IF <fkkmavs>-pdunn = 'X'.                  " see note 654200
          ADD <fkkmavs>-betrh TO sum_betrh.
          ADD <fkkmavs>-betrw TO sum_betrw.
        ENDIF.
      ELSE.
        <fkkmavs>-xinfo = 'X'.
*        MODIFY i_fkkmavs. not needed because of ASSIGN
      ENDIF.
    ELSE.
      xdebitexist = 'X'.
* Ob die nächste Mahnstufe bereits vorgegeben wurde
* (also FKKMAZE-MAHNN gesetzt), muss in Event 0304
* berücksichtigt werden.
*     Für Erhöhen der Mahnstufe Event 0304
      PERFORM event_0304 TABLES it_fkkmavs
                           CHANGING <fkkmavs>.

* Note 401786 >>>>
*      clear <fkkmavs>-mahns.
* Note 401786 <<<<

      IF NOT <fkkmavs>-mahnn IS INITIAL AND <fkkmavs>-mstnn IS INITIAL.
*       Wenn es eine neue Mahnstufe gibt,
*       aber der Mahnstufentyp noch fehlt:
*       Mahnstufentyp der neuen Mahnstufe bestimmen und als
*       neuen Mahnstufentyp im Mahnvorschlag setzen:
        DATA l_tfk047b TYPE tfk047b.
        PERFORM read_tfk047b USING <fkkmavs>-mahnv
                                   <fkkmavs>-mahnn
                             CHANGING l_tfk047b.
        IF sy-subrc = 0.
          <fkkmavs>-mstnn = l_tfk047b-mstyp.
        ENDIF.
      ENDIF.

      IF <fkkmavs>-mahnn = 0.
* wenn Mahnstufe 1 nicht erreicht wird, wird Posten vom Mahnvorschlag
* ausgenommen
* Ist das Stundungsdatum gesetzt, wird noch ein Merker gesetzt, um
* spaeter ein Protokolleintrag zu haben.
        IF <fkkmavs>-studt > <fkkmavs>-faedn.
          xstudt = 'X'.
        ENDIF.
        <fkkmavs>-xinfo = 'X'.
      ENDIF.
* Note 574047 >>>>> Start >>>>>
* If item has been in last level already and flag "last dunning level"
* is "3", the item is marked as informative only.
      IF <fkkmavs>-xlmst EQ 'X' .
        PERFORM read_tfk047a USING <fkkmavs>-mahnv.
        IF tfk047a-vlmst EQ '3' OR                      "Note 1543727
           tfk047a-vlmst EQ '4'.                        "Note 1543727
          <fkkmavs>-xinfo = 'X' .
          xlmst_group = 'X'.    "set XLMST for this group
        ENDIF.
      ENDIF.
* Note 574047 <<<<< End <<<<<<<

*      MODIFY i_fkkmavs. not needed bedause of ASSIGN

* Posten, die aus lokaler Sicht gemahnt werden können,
* haben eine positive Mahnstufe und keine Mahnsperre:
      IF <fkkmavs>-mahnn > 0 AND
         <fkkmavs>-xinfo IS INITIAL AND            " note 574047
         <fkkmavs>-mansp IS INITIAL.
*       Posten mit Mahnsperre beteiligen sich nicht
*       an der Grenzbetragspruefung.
*       Mahnbarer Posten vorhanden:
*       (Mindestens ein Posten ist ueberfaellig)
        x_dunnable_item_in_group = 'X'.  " old name: XLEVELONE
*       Fuer die neue Mahnstufe wird die Tabelle gefuellt.
        PERFORM mahnstufen_tabelle_fuellen TABLES  c_mahnst_tab
                                           USING <fkkmavs>-mahnn
                                                 <fkkmavs>-betrh
                                                 <fkkmavs>-betrw
                                                 <fkkmavs>-xlmst
                                                 <fkkmavs>-pdunn.
      ENDIF.
    ENDIF.
  ENDLOOP.

  LOOP AT i_fkkmared ASSIGNING <fkkmared>.
    SUBTRACT <fkkmared>-betrh FROM int_sum_betrh.
    SUBTRACT <fkkmared>-betrh FROM sum_betrh.
    SUBTRACT <fkkmared>-betrw FROM sum_betrw.
  ENDLOOP.

  IF int_sum_betrh < 0.
    xlesszero = 'X'.
  ENDIF.

ENDFORM.                               " MAHNSTUFEN_ERMITTELN

*&---------------------------------------------------------------------*
*&      Form  MAHNSTUFEN_TABELLE_FUELLEN
*&---------------------------------------------------------------------*
*       In der Mahnstufentabelle werden die vorhandenen neuen          *
*       Mahnstufen und die Summen der Forderungen einer Mahnstufe      *
*       festgehalten                                                   *
*----------------------------------------------------------------------*
*  -->  mahns     Mahnstufe, die der Posten erreichen könnte
*  -->  betrh     noch offener Betrag des Postens in Hauswaehrung
*  -->  betrw     noch offener betrag des Postens
*  -->  xmlst     Posten hatte letzte Mahnstufe schon erreicht.
*  -->  p_add     Betrag bei Summation beruecksichtigen
*----------------------------------------------------------------------*
FORM mahnstufen_tabelle_fuellen
                   TABLES
                       c_mahnst_tab TYPE mahnst_tab_type
                   USING
                       mahns TYPE mahns_kk
                       betrh TYPE betrh_kk
                       betrw TYPE betrw_kk
                       xmlst TYPE xfeld
                       p_add TYPE xfeld.

  DATA: tabix LIKE sy-tabix.
  DATA: l_betrh LIKE fkkmavs-betrh,
        l_betrw LIKE fkkmavs-betrw.

* IF i_fkkmavs is an additional receivable
* which should not be added to the dunning sum
  MOVE: betrh TO l_betrh,
        betrw TO l_betrw.

  IF p_add = ' '.
    CLEAR l_betrh.
    CLEAR l_betrw.
  ENDIF.

  READ TABLE c_mahnst_tab WITH KEY mahns = mahns .
  tabix = sy-tabix.
  IF sy-subrc = 0.
* an entry for this dunning level already in c_mahnst_tab
* so add the amounts and set XLMST

* XLMST is set whenever an item has been dunnend
* before on the last dunning level
    IF NOT xmlst IS INITIAL.
      c_mahnst_tab-xlmst = xmlst.
    ENDIF.
    ADD l_betrh TO c_mahnst_tab-betrh .
    ADD l_betrw TO c_mahnst_tab-betrw.
    MODIFY c_mahnst_tab INDEX tabix.
  ELSE.
* an entry for this dunning level not yet in c_mahnst_tab
* so add a new entry
    c_mahnst_tab-mahns = mahns.
    c_mahnst_tab-betrh = l_betrh.
    c_mahnst_tab-betrw = l_betrw.
* open items on last dunning level will be checked separately
* Posten auf letzter Mahnstufe werden extra geprüft
    c_mahnst_tab-xlmst = xmlst.
    APPEND c_mahnst_tab.
  ENDIF.                               " sy-subrc = 0

ENDFORM.                               " MAHNSTUFEN_TABELLE_FUELLEN

*&---------------------------------------------------------------------*
*&      Form  MAHNSTUFEN_TABELLE_VERARBEITEN
*&---------------------------------------------------------------------*
*       Es wird die höchste Mahnstufe, für die der Grenzbetrag
*       erreicht ist, ermittelt.
*----------------------------------------------------------------------*
*  -->  mahnv                  Mahnverfahren der Mahngruppe
*       waers                  Währung der Mahngruppe
*       sum_betrh              Summe der Gutschriften Hauswaehrung
*       sum_betrw              Summe der Gutschriften
*  <--  max_mahns              höchste Mahnstufe der Posten,
*                              die nicht die letzte
*                              Mahnstufe erreicht haben
*  <--  last_mahnst            letzte Mahnstufe (falls dazu Posten
*                              vorhanden sind)
*  <--  xlmst                  Flag: Posten mit letzter Mahnstufe
*                                                       vorhanden
*  <--  e_error_occurred       Fehler ist aufgetreten
*----------------------------------------------------------------------*
FORM mahnstufen_tabelle_verarbeiten
       TABLES c_mahnst_tab TYPE mahnst_tab_type
       USING mahnv LIKE tfk047c-mahnv
             waers LIKE tfk047c-waers
             p_local_waers LIKE t001-waers
             value(sum_betrh) LIKE tfk047c-minbt
             value(sum_betrw) LIKE tfk047c-minbt
             xlmst_group TYPE xfeld
    CHANGING max_mahns LIKE tfk047c-mahns
             last_mahns LIKE tfk047c-mahns                  "20.03.2000
             xlmst      TYPE xfeld
             e_error_occurred TYPE xfeld.

* Guthabenbetrag retten, damit Grenzbeträge auch ohne die Posten, die
* bereits letzte Mahnstufe erreicht haben, geprüft werden können
  DATA:
    hlp_sum_betrw LIKE tfk047c-minbt,
    hlp_sum_betrh LIKE tfk047c-minbt.
* Local variable for indicator "do not lower dunning level"
  DATA l_not_lower_dl TYPE tfk047a-not_lower_dl.
* Read dunning procedure customizing
  PERFORM read_tfk047a USING mahnv.
* Put the indicator which is needed below in a local variable
  l_not_lower_dl = tfk047a-not_lower_dl.

  DATA rc LIKE sy-subrc.

  CLEAR e_error_occurred.
* In den Datenfeldern SUM_BETRH und SUM_BETRW stehen jetzt die Summe der
* Guthaben. Dieses wurde im Form MAHNSTUFEN_ERMITTELN ermittelt.
  hlp_sum_betrw = sum_betrw.
  hlp_sum_betrh = sum_betrh.

  max_mahns = 0.
  xlmst = space.

* Lücken in der Mahnstufentabelle sollen entfernt werden, damit die
* Mahnstufen von gemahnten Belegen nicht vermindert wird.
  PERFORM mahnstufen_tabelle_erweitern TABLES c_mahnst_tab
                                       USING mahnv.

* Mahnstufentabelle wird absteigend nach Mahnstufe sortiert
  SORT c_mahnst_tab BY xlmst DESCENDING
                     mahns DESCENDING.

  LOOP AT c_mahnst_tab.
* Zu dem Betrag der jeweiligen Mahnstufe werden die der höheren
* Mahnstufe dazugezählt und die der Gutschriften abgezogen
    ADD c_mahnst_tab-betrh TO sum_betrh.
* Summierung in Transaktionswaehrung nur wenn sie eindeutig ist
    IF NOT waers IS INITIAL.                      " note 433981
      ADD c_mahnst_tab-betrw TO sum_betrw.
    ENDIF.                                        " note 433981

    PERFORM check_minimum_amount USING waers g_local_waers
                                       mahnv c_mahnst_tab-mahns
                                       sum_betrw sum_betrh
                                 CHANGING rc.
    CASE rc.
      WHEN '0'.                        " Grenzbetrag erreicht
* Wenn Grenzbetrag mit Posten der letzten Mahnstufe geprüft wurden,
* wird die Verarbeitung abhängig vom Wert in TFK047A-VLMST durchgeführt.
* Hier wird der entsprechende Merker gesetzt
        IF c_mahnst_tab-xlmst = 'X'.
          xlmst = 'X'.
* Die höchste Mahnstufe wird noch gemerkt, falls doch alle Posten
* berücksichtigt werden sollen
          last_mahns = c_mahnst_tab-mahns.
* Dann werden die zu prüfenden Beträge zurückgesetzt, damit geprüft
* werden kann, welche Mahnstufe ohne die Posten auf letzter Mahnstufe
* ausgelöst werden würde
          sum_betrh = hlp_sum_betrh.
          sum_betrw = hlp_sum_betrw.
          CONTINUE.       " Go to next line of table C_MAHNST_TAB
        ELSE.
* Maximale Mahnstufe nur für Posten, die nicht die letzte Mahnstufe
* erreicht haben
          max_mahns = c_mahnst_tab-mahns.
          EXIT.            " Exit from loop at C_MAHNST_TAB
        ENDIF.
      WHEN '1'.                        "Grenzbetrag nicht erreicht
* Verarbeitung wird mit dem nächsten Wert der Mahnstufentabelle
* fortgesetzt, also mit der nächstniedrigen Mahnstufe

* See notes 651507 + 876434
        IF c_mahnst_tab-xlmst = 'X'.
          xlmst = 'X'.
        ENDIF.
        CONTINUE.       " Go to next line of table C_MAHNST_TAB
      WHEN '2'.                        " Grenzbetrag nicht gefunden
* Verarbeitung wird abgebrochen. Fehlereintrag wurde durch
* Form CHECK_MINIMUM_AMOUNT bereits ins Protokoll geschrieben.
        e_error_occurred = 'X'.
        EXIT.            " Exit from loop at C_MAHNST_TAB
    ENDCASE.
  ENDLOOP.
* Note 574047 >>>>> Start >>>>>
* Flag "group reached last dunning level" is set here because an
* item with last dunning level has been excluded.
  IF xlmst_group EQ 'X'.
    xlmst = 'X'.
  ENDIF.
* Note 574047 <<<<< End <<<<<<<

ENDFORM.     " Form mahnstufen_tabelle_verarbeiten

*&---------------------------------------------------------------------*
*&      Form  MAHNSTUFEN_ANPASSEN
*&---------------------------------------------------------------------*
*       In allen Posten wird die Mahnstufe auf die höchste Mahnstufe,
*       in der der Grenzbetrag erreicht wurde, begrenzt.               *
*       Dabei muß geprüft werden, ob sich trotzdem noch eine Mahnstufe
*       geändert hat.
*----------------------------------------------------------------------*
*   --> XLMST  Kennzeichen "letzte Mahnstufe"
*                  ist für die Gruppe gesetzt
*   <--  mas_mahns  hoechste Mahnstufe fuer Posten, in denen sich
*                   die Mahnstufe erhoeht hat
*----------------------------------------------------------------------*
FORM mahnstufen_anpassen TABLES i_fkkmavs STRUCTURE fkkmavs
                   USING  i_mahnv  TYPE mahnv_kk
                          akt_mahns LIKE fkkmaze-mahns
                          xlmst TYPE c
                          akt_mstyp LIKE fkkmaze-mstyp
                          xpost LIKE tfk047b-xpost   " print all items
                          xnbgm LIKE tfk047b-xnbgm   " only dunned items
                 CHANGING max_mahns TYPE mahns_kk.

* Declaration
  DATA l_not_lower_dl TYPE tfk047a-not_lower_dl.
  FIELD-SYMBOLS <fkkmavs> TYPE fkkmavs.

* Read dunning procedure customizing
  PERFORM read_tfk047a USING i_mahnv.
* Put the indicator which is needed below in a local variable
  l_not_lower_dl = tfk047a-not_lower_dl.

* Wegen dem Kennzeiche XNBGM wird noch eine Begrenzungsmahnstufe
* ermittelt
*  data vor_mahns like fkkmaze-mahns.

*  vor_mahns = akt_mahns - 1.    " eigentlich evtl. falsch wenn Luecken
**                               " in Abfolge der Mahnstufen im
**                               " Mahnverfahren sind
  DATA l_tabix TYPE sy-tabix.

  LOOP AT i_fkkmavs ASSIGNING <fkkmavs>.
*   Keep current line number
    l_tabix = sy-tabix.
* Prüfen, ob Posten aufgrund der Vormahnstufe OK ist
* Note 401786 >>>>
*>>> note 870252
*    IF xnbgm = 'X' AND <fkkmavs>-mahns = '00'.
    IF xnbgm = 'X' AND ( ( <fkkmavs>-mahns = '00'
                   AND     <fkkmavs>-dl_manual IS INITIAL
                   AND     <fkkmavs>-betrw > 0 )    "Debits >> Note 1790380
                   OR    ( <fkkmavs>-betrw <= 0     "Only dunned credits
                   AND     <fkkmavs>-mahnd IS INITIAL ) ).   "<< Note 1790380
*<<< note 870252
* Note 401786 <<<<
      IF xpost = space.
        DELETE i_fkkmavs INDEX l_tabix.
        CONTINUE.
      ELSE.
        <fkkmavs>-xinfo = 'X'.
        <fkkmavs>-mahnn = <fkkmavs>-mahns.
*        MODIFY i_fkkmavs. " not needed becaus of ASSIGN is used
        CONTINUE.
      ENDIF.
    ENDIF.
* Sollen nur fällige Posten gemahnt werden, werden Posten, die
* Verzugstage nicht erreicht haben, weggeworfen
    IF <fkkmavs>-xinfo = 'X'
      AND xpost = space.
      DELETE i_fkkmavs INDEX l_tabix.
      CONTINUE.
    ENDIF.
* Posten, die bereits die höchste Mahnstufe erreicht haben,
* werden nur dann berücksichtigt, wenn sie den Grenzbetrag
* für diese Mahnstufe nicht mehr erreichen.
    IF NOT <fkkmavs>-xlmst IS INITIAL.
      CHECK xlmst IS INITIAL.    " Go to next dunning proposal line
*                                " if item has last dunning level
*                                " and group is last dunning level
*     Item has reached last dunning level but should not be
*     regarded as such because we are dealing with a group
*     which has set the "last dunning level" indicator
      CLEAR <fkkmavs>-xlmst.
*      MODIFY i_fkkmavs. Not needed because of ASSIGN
    ENDIF.
    IF <fkkmavs>-xinfo = ' '.
*     Normale (nicht-Info-Posten)
      IF NOT <fkkmavs>-mansp IS INITIAL.
* Items with restricted blocks do not change their dunning level
* independent of what has been determined in 0304
* (Frueher: "bleiben auf Mahnstufe 0")
* See also Note 420563
        <fkkmavs>-mahnn = <fkkmavs>-mahns.
        <fkkmavs>-mstnn = <fkkmavs>-mstyp.
        IF <fkkmavs>-mahnn > akt_mahns.
          <fkkmavs>-higherdl = 'X'.
        ENDIF.
*        MODIFY i_fkkmavs. not needed because of ASSIGN
      ELSE.
*       Posten ohne Mahnsperre
        IF <fkkmavs>-mahnn > akt_mahns.
          IF l_not_lower_dl = ' '.
* Posten, die eine hoehere Mahnstufe haben, als es die Grenzbetraege
* zulassen, werden angepasst.
            <fkkmavs>-mahnn = akt_mahns.
            <fkkmavs>-mstnn = akt_mstyp.
*            MODIFY i_fkkmavs.
          ELSE.
* Mahnstufe des Postens ist hoeher als die der Mahnung, aber
* laut Customizing des Mahnverfahrens soll die Mahnstufe nicht
* verringert werden (auch nicht im Vergleich zur Mahnstufe im
* letzten Mahnlauf).
            IF <fkkmavs>-mahnn < <fkkmavs>-mahns.
              <fkkmavs>-mahnn = <fkkmavs>-mahns.
              <fkkmavs>-mstnn = <fkkmavs>-mstyp.
* Da die Mahnstufe immer noch hoeher als die Mahnstufe der
* Mahnung ist, setze Merker in Zeile:
              <fkkmavs>-higherdl = 'X'.
* The dunning level cann't be increased over the AKT_MAHNS
* because the check on amount limit has been done only for AKT_MAHNS
* Take maximum from <fkkmavs>-mahns and akt_mahns
            ELSEIF <fkkmavs>-mahns > akt_mahns.
              <fkkmavs>-mahnn = <fkkmavs>-mahns.
              <fkkmavs>-mstnn = <fkkmavs>-mstyp.
* Setze Merker in Zeile:
              <fkkmavs>-higherdl = 'X'.
            ELSE.
              <fkkmavs>-mahnn = akt_mahns.
              <fkkmavs>-mstnn = akt_mstyp.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
* Es wird die maximale Mahnstufe ermittelt von den Posten, die ihre
* Mahnstufe erhoeht haben und
* nicht nur Info sind und die nicht gesperrt sind.
    IF   <fkkmavs>-mahnn > <fkkmavs>-mahns AND
         <fkkmavs>-mahnn > max_mahns       AND
         <fkkmavs>-xinfo = ' '             AND
         <fkkmavs>-cdunn <> ' '            AND
         <fkkmavs>-mansp IS INITIAL.
      max_mahns = <fkkmavs>-mahnn.
*      max_mstyp = <fkkmavs>-mstnn.
    ENDIF.
  ENDLOOP.

ENDFORM.                               " MAHNSTUFEN_ANPASSEN

*&---------------------------------------------------------------------*
*&      Form  LAST_DUNNING_LEVEL
*&---------------------------------------------------------------------*
*       i_last_mahns   hoechste Mahnstufe
*       c_akt_mahns    wird reinregeben als die hoechste Mahnstufe
*                      der Posten, die nicht die letzte erreicht haben.
*                      und wird zurückgegeben als die endgültige
*                      Mahstufe der Mahnung, d. h. je nach Customizing
*                      TFK047A-VLMST bleibt C_AKT_MAHNS unveraendert
*                      oder wird auf i_last_mahns gesetzt
*&---------------------------------------------------------------------*
FORM last_dunning_level TABLES   c_fkkmavs STRUCTURE fkkmavs
                        USING    i_mahnv  TYPE mahnv_kk
                                 i_gpart  TYPE gpart_kk
                                 i_last_mahns LIKE fkkmavs-mahns
                        CHANGING c_xlmst LIKE fkkmagrp-xlmst
                                 c_akt_mahns LIKE fkkmavs-mahns.

  PERFORM read_tfk047a USING i_mahnv.
  CASE tfk047a-vlmst.
* no dunning, only entry in more specified log
    WHEN '0'.
      REFRESH c_fkkmavs.
      PERFORM message_append USING '>3' 'S' '230'
                                   i_mahnv i_gpart
                                   space space '4'.
      SET EXTENDED CHECK OFF.
      IF 1 = 2. MESSAGE s230. ENDIF.   "Verwendungsnachweis
      SET EXTENDED CHECK ON.
      EXIT.
* no dunning, entry in standard log
    WHEN '1'.
      REFRESH c_fkkmavs.
      PERFORM message_append USING '>3' 'S' '230'
                                   i_mahnv i_gpart
                                   space space '2'.
      SET EXTENDED CHECK OFF.
      IF 1 = 2. MESSAGE s230. ENDIF.   "Verwendungsnachweis
      SET EXTENDED CHECK ON.
* dunning with all items
    WHEN '2'.
      CLEAR c_xlmst.
*     i_last_mahns was filled after successful
*     check of minimum amount for this dunning level.
      IF NOT i_last_mahns IS INITIAL.
        c_akt_mahns = i_last_mahns.
      ENDIF.
* dunning only with items, that have not reached the last level before.
    WHEN '3' OR '4'.                                      "Note 1543727
      LOOP AT c_fkkmavs WHERE xlmst = 'X'.
*       Set all items which have reached the last dunning level to
*       the status "informative item in dunning notice":
        c_fkkmavs-xinfo = 'X'.
        MODIFY c_fkkmavs.
      ENDLOOP.
*     Are there any items left which are not only informative?
      READ TABLE c_fkkmavs WITH KEY xinfo = ' '.
      IF sy-subrc = 4.
*       No dunning notice at all when all items are only informative
*       (had reached last dunning level)
        REFRESH c_fkkmavs.
        PERFORM message_append USING '>3' 'S' '230'
                                     i_mahnv i_gpart
                                     space space '4'.
        SET EXTENDED CHECK OFF.
        IF 1 = 2. MESSAGE s230. ENDIF. "Verwendungsnachweis
        SET EXTENDED CHECK ON.
      ELSE.
        CLEAR c_xlmst.
      ENDIF.
  ENDCASE.

ENDFORM.                               " LAST_DUNNING_LEVEL

*&---------------------------------------------------------------------*
*&      Form  check_minimum_amount
*&---------------------------------------------------------------------*
*       Grenzbetragspruefung
*&---------------------------------------------------------------------*
FORM check_minimum_amount USING    p_waers LIKE tfk047c-waers
                                   p_local_waers LIKE tfk047c-waers
                                   p_mahnv LIKE tfk047c-mahnv
                                   p_mahns LIKE tfk047c-mahns
                                   p_sum_betrw LIKE tfk047c-minbt
                                   p_sum_betrh LIKE tfk047c-minbt
                          CHANGING p_rc LIKE sy-subrc.

  p_rc = '1'.
* Zunächst mit der Transaktionswährung lesen
  IF NOT p_waers IS INITIAL.
    PERFORM read_tfk047c USING p_mahnv p_mahns p_waers.
    IF sy-subrc = 0.
      IF tfk047c-minbt <= p_sum_betrw.
* Grenzbetrag erreicht
        p_rc = '0'.
        EXIT.
      ELSE.
* Grenzbetrag nicht erreicht
        p_rc = '1'.
        EXIT.
      ENDIF.
    ENDIF.                             " IF SY-SUBRC = 0.
  ENDIF.                               " IF NOT WAERS IS INITIAL.
* Nichts gefunden, dann mit der Hauswährung lesen, wenn sie von der
* Transaktionswährung abweicht.
  IF p_local_waers NE p_waers OR
     sy-subrc NE 0.
    PERFORM read_tfk047c USING p_mahnv p_mahns p_local_waers.
    IF sy-subrc NE 0.
* Grenzbetrag weder in Transaktions- noch in Hauswährung vorhanden
      p_rc = '2'.
      PERFORM message_append USING '>3' 'E' '259'
                             p_mahnv p_mahns p_waers
                             space '2'.
      IF 1 = 2.
        MESSAGE e259(>3) WITH p_mahnv p_mahns p_waers.
      ENDIF.
      EXIT.
    ELSEIF tfk047c-minbt <= p_sum_betrh.
      p_rc = '0'.
      EXIT.
    ENDIF.
  ELSE.
* Grenzbetrag in Transaktions- = Hauswährung vorhanden
    p_rc = '2'.
    PERFORM message_append USING '>3' 'S' '259'
                           p_mahnv p_mahns p_waers
                           space ' '.
    IF 1 = 2.
      MESSAGE s259(>3) WITH p_mahnv p_mahns p_waers.
    ENDIF.
    EXIT.
  ENDIF.
ENDFORM.                               " check_minimum_amount
