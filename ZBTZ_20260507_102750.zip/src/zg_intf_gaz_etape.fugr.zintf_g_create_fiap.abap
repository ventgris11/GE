FUNCTION zintf_g_create_fiap .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
*"* Modification:
*" Ticket : Jira GE-6908 [F.REXX] - message OPEN_FI du BTE ISUMRORD (Pose compteur)
*" Desc   : Récupération de la consommation période du numéro de cadran
*"           logique le plus récent et la date de fin la plus grande
*"----------------------------------------------------------------------
  DATA: lc_field_num_pce     TYPE fieldname VALUE 'NUM_PCE',
        lc_field_date_releve TYPE fieldname VALUE 'DATE_RELEVE',
        lc_field_nb_roue_cpt TYPE fieldname VALUE 'NB_ROUE_COMPTEUR',
        lc_field_num_serie   TYPE fieldname VALUE 'NUM_SERIE_COMPTEUR',
        lc_field_flux        TYPE fieldname VALUE 'FLUX',
        lc_field_index_fin   TYPE fieldname VALUE 'INDEX_BRUT_FIN_PERIODE',
        lv_field             TYPE string,
        lv_int_ui            TYPE int_ui,
        lv_anlage            TYPE anlage,
        ls_object            TYPE eedm_isu_objects,
        lt_etdz              TYPE TABLE OF etdz,
        ls_etdz              TYPE etdz,
        lv_stanzvor          TYPE stanzvor,
        ls_auto              TYPE isu42_devmod_auto,
        lv_device            TYPE geraet,
        lv_sernr             TYPE lsernr,
        lv_equnr             TYPE equnr,
        lv_db_update         TYPE e_update,
        ls_dev               TYPE reg42_dev,
        ls_dev_flag          TYPE reg42_dev_input_flag,
        ls_lsernr            TYPE lsernr,
        lv_ko                TYPE c,
     "Début:GE-6908: message OPEN_FI du BTE ISUMRORD (Pose compteur)
        lt_easts             TYPE TABLE OF easts,
        ls_easts             TYPE easts.
     "Fin  :GE-6908: message OPEN_FI du BTE ISUMRORD (Pose compteur)


  FIELD-SYMBOLS: <fs_num_pce>, <fs_date_releve>, <fs_nb_roue_compteur>, <fs_num_serie>, <fs_flux>, <fs_idx_fin_periode>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.
  IF <fs_num_pce> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_releve>.
  IF <fs_date_releve> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_nb_roue_cpt INTO lv_field.
  ASSIGN (lv_field) TO <fs_nb_roue_compteur>.
  IF <fs_nb_roue_compteur> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_serie INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_serie>.
  IF <fs_num_serie> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  "MFO    CONCATENATE 'FLUX-' lc_field_num_serie INTO lv_field.
  CONCATENATE 'FLUX-' lc_field_flux INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.
  IF <fs_flux> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_index_fin INTO lv_field.
  ASSIGN (lv_field) TO <fs_idx_fin_periode>.
  IF <fs_idx_fin_periode> IS NOT ASSIGNED.
  ENDIF.

* Pour récupération de INT_UI
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).
  IF lv_int_ui IS INITIAL.
  ENDIF.

* Pour récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.

  lv_anlage = ls_object-installation.

* A créer comme méthode dans ZCL_TOOL
  CLEAR ls_auto.
  CLEAR ls_dev.
  CLEAR ls_dev_flag.

* Créer constante ou se baser sur la table ETYP
*GLIC - GE-7263- 20191024 - Début - Ajout de RE1M
  IF <fs_flux> = 'RE6M' OR <fs_flux> = 'RE1M'.
*GLIC - GE-7263- 20191024 - Fin
    CASE <fs_nb_roue_compteur>.
      WHEN '4'.
        ls_dev-matnr      = 'ART_6M_4'.
        ls_dev-zwgruppe   = 'GAZ_6M_4'.
        ls_dev_flag-matnr = 'ART_6M_4'.
      WHEN '5'.
        ls_dev-matnr      = 'ART_6M_5'.
        ls_dev-zwgruppe   = 'GAZ_6M_5'.
        ls_dev_flag-matnr = 'ART_6M_5'.
*GLIC - GE-7263- 20191024 - Début - Ajout des artciles et groupes de cadrans 6 et 7 roues
      WHEN '6'.
        ls_dev-matnr      = 'ART_6M_6'.
        ls_dev-zwgruppe   = 'GAZ_6M_6'.
        ls_dev_flag-matnr = 'ART_6M_6'.
      WHEN '7'.
        ls_dev-matnr      = 'ART_6M_7'.
        ls_dev-zwgruppe   = 'GAZ_6M_7'.
        ls_dev_flag-matnr = 'ART_6M_7'.
*GLIC - GE-7263- 20191024 - Fin
    ENDCASE.
  ELSEIF <fs_flux> = 'REMM'.
    CASE <fs_nb_roue_compteur>.
      WHEN '4'.
        ls_dev-matnr      = 'ART_MM_4'.
        ls_dev-zwgruppe   = 'GAZ_MM_4'.
        ls_dev_flag-matnr = 'ART_MM_4'.
      WHEN '5'.
        ls_dev-matnr      = 'ART_MM_5'.
        ls_dev-zwgruppe   = 'GAZ_MM_5'.
        ls_dev_flag-matnr = 'ART_MM_5'.
      WHEN '6'.
        ls_dev-matnr      = 'ART_MM_6'.
        ls_dev-zwgruppe   = 'GAZ_MM_6'.
        ls_dev_flag-matnr = 'ART_MM_6'.
      WHEN '7'.
        ls_dev-matnr      = 'ART_MM_7'.
        ls_dev-zwgruppe   = 'GAZ_MM_7'.
        ls_dev_flag-matnr = 'ART_MM_7'.
      WHEN '8'.
        ls_dev-matnr      = 'ART_MM_8'.
        ls_dev-zwgruppe   = 'GAZ_MM_8'.
        ls_dev_flag-matnr = 'ART_MM_8'.
      WHEN '9'.
        ls_dev-matnr      = 'ART_MM_9'.
        ls_dev-zwgruppe   = 'GAZ_MM_9'.
        ls_dev_flag-matnr = 'ART_MM_9'.
    ENDCASE.
  ELSEIF <fs_flux> = 'REJM' OR <fs_flux> = 'REJJ'.
    ls_dev-matnr      = 'ART_JM/JJ'.
    ls_dev-zwgruppe   = 'G_JM_JJ'.
    ls_dev_flag-matnr = 'ART_JM/JJ'.
  ENDIF.

  ls_dev-ab         = <fs_date_releve> .
  ls_dev-bis        = '99991231'.

  ls_dev-sparte     = 'ZG'.
  ls_dev-egerr_info =  <fs_num_serie>.
  APPEND ls_dev TO ls_auto-dev.

  " MAJ DEV FLAG
  ls_dev_flag-ab         = <fs_date_releve>.
  ls_dev_flag-bis        = '99991231'.
  ls_dev_flag-zwgruppe   = 'X'.
  ls_dev_flag-egerr_info = 'X'.
  APPEND ls_dev_flag TO ls_auto-dev_flag.

  ls_auto-contr-okcode = 'SAVE'.

* Créer fiche info appareil
  CALL FUNCTION 'ISU_S_SMALL_DEVICE_CREATE'
    EXPORTING
*     X_DEVICE       = lv_device
      x_matnr        = ls_dev-matnr            " Type appareil
*     X_DEVISION     =
      x_keydate      = <fs_date_releve>
      x_upd_online   = 'X'
      x_no_dialog    = 'X'
      x_auto         = ls_auto
*     X_OBJ          =
      x_int_num      = 'X'
*     X_EXT_NUM      = ' '
    IMPORTING
      y_db_update    = lv_db_update
*     Y_EXIT_TYPE    =
      y_equnr        = lv_equnr
      y_device       = lv_sernr
    EXCEPTIONS
      not_found      = 1
      invalid        = 2
      foreign_lock   = 3
      input_error    = 4
      system_error   = 5
      internal_error = 6
      not_qualified  = 7
      not_customized = 8
      cancelled      = 9
      OTHERS         = 10.

  IF  sy-subrc EQ 0
  AND NOT lv_db_update IS INITIAL.
* 'OK'
  ELSE.
    ev_etape = 2.
    lv_ko = 'X'.
    EXIT.
* 'KO'
  ENDIF.
  IF lv_ko IS INITIAL.
    CONSTANTS: lc_365(3) VALUE 365.

    DATA: ld_date       TYPE datum,
          ld_perverbr   TYPE perverbr,
          ld_thgver     TYPE thgver,
          ld_tarifart   TYPE tarifart,
          ld_date_c(10) TYPE c,
          ld_db_update  TYPE xfeld,
          ls_zw         TYPE isu07_zw,
          lt_zw         TYPE isu07_zwt,
          ls_ger        TYPE isu07_auto_ger,
          ls_auto_pose  TYPE isu07_install_auto.

    " Pose de la fiche appareil créé
* Récupération :
* de la consommation périodique actuelle (CAR de facturation )
* de la catégorie de tarif
* de la conversion gaz
* Les données sont à récupérer à J-1 par rapport à la date de pose
    ld_date = <fs_date_releve> - 1.
* Si JJ/JM alors pas de consommation périodique donc on ne sélectionne pas
* dans cette table
    IF ls_dev-matnr EQ 'ART_JM/JJ'.
      SELECT easts~tarifart eadz~thgver
             INTO (ld_tarifart,ld_thgver)
             UP TO 1 ROWS
             FROM easts AS easts
             INNER JOIN eadz AS eadz
             ON eadz~logikzw EQ easts~logikzw
             AND eadz~bis GE easts~ab
             AND eadz~ab LE easts~bis
             WHERE easts~anlage EQ lv_anlage
             AND easts~ab LE ld_date
             AND easts~bis GE ld_date
             AND eadz~bis GE ld_date
             AND eadz~ab LE ld_date.
      ENDSELECT.
    ELSE.

*      SELECT easts~tarifart easte~perverbr eadz~thgver
*             INTO (ld_tarifart,ld_perverbr,ld_thgver)
*             UP TO 1 ROWS
*             FROM easts AS easts
*             INNER JOIN easte AS easte
*             ON easte~logikzw EQ easts~logikzw
*             AND easte~bis GE easts~ab
*             AND easte~ab LE easts~bis
*             INNER JOIN eadz AS eadz
*             ON eadz~logikzw EQ easts~logikzw
*             AND eadz~bis GE easts~ab
*             AND eadz~ab LE easts~bis
*             WHERE easts~anlage EQ lv_anlage
*             AND easts~ab LE ld_date
*             AND easts~bis GE ld_date
*             AND easte~ab LE ld_date
** AND easte~bis GE ld_date "ISU-708
*             AND eadz~bis GE ld_date
*             AND eadz~ab LE ld_date.
*      ENDSELECT.
*      "ed_perverbr = ld_perverbr. "+ISU-922

      "Début:GE-6908: message OPEN_FI du BTE ISUMRORD (Pose compteur)
      SELECT * INTO TABLE lt_easts
             FROM easts
             WHERE easts~anlage EQ lv_anlage
               AND ab  LE ld_date
               AND bis GE ld_date.

      SORT lt_easts BY bis DESCENDING.
      READ TABLE lt_easts INTO ls_easts INDEX 1.
      IF sy-subrc EQ 0.
        ld_tarifart = ls_easts-tarifart.

        SELECT perverbr thgver
            INTO (ld_perverbr,ld_thgver) UP TO 1 ROWS
             FROM easte
             INNER JOIN eadz
             ON eadz~logikzw EQ easte~logikzw
            AND eadz~bis GE easte~ab
            AND eadz~ab LE easte~bis
           WHERE easte~logikzw = ls_easts-logikzw
             AND easte~ab LE ld_date
             AND eadz~bis GE ld_date
             AND eadz~ab LE ld_date.
        ENDSELECT.
      ENDIF.
      "Fin  :GE-6908: message OPEN_FI du BTE ISUMRORD (Pose compteur)
    ENDIF.
    IF NOT sy-subrc IS INITIAL.
* Problème dans le modèle de données
      ev_etape = 2.
      lv_ko = 'X'.

    ELSE.

* Données cadran(s)
      ls_zw-zwnummere       = '001'.
      ls_zw-zwstandce       = <fs_idx_fin_periode>.
      ls_zw-spartype        = '02'.
      ls_zw-geraete         = lv_sernr.
      ls_zw-matnre          = ls_dev-matnr.
      ls_zw-anzerg          = 1.
      ls_zw-thgver          = ld_thgver.

      IF ls_dev-matnr NE 'ART_JM/JJ'.
        ls_zw-anzdaysofperiod = lc_365.
        ls_zw-perverbr        = ld_perverbr.
      ENDIF.
      ls_zw-tarifart        = ld_tarifart.
      IF ls_dev-matnr EQ 'ART_JM/JJ'.
        ls_zw-kondigre = 'GAZ_RTP'.
      ENDIF.
      APPEND ls_zw TO lt_zw.
* Données d'appareil
      ls_ger-matnr     = ls_dev-matnr.
      ls_ger-geraetneu = lv_sernr.
      ls_ger-ausbau    = space.
      ls_ger-sparteneu = 'ZG'.
      ls_ger-action    = '04'.
      APPEND ls_ger TO ls_auto_pose-auto_ger.
* Données de cadran(s)
      ls_auto_pose-auto_zw = lt_zw.
      ls_auto_pose-interface-anlage        = lv_anlage.
      ls_auto_pose-interface-eadat         = <fs_date_releve>.
      ls_auto_pose-interface-action        = '04'.
      ls_auto_pose-interface-upd_online    = 'X'.
      ls_auto_pose-interface-no_dialog     = 'X'.
      ls_auto_pose-interface-no_event      = 'X'.
      ls_auto_pose-interface-no_statistic  = 'X'.
      ls_auto_pose-interface-no_change_doc = 'X'.
      ls_auto_pose-okcode                  = 'SAVE'.
      ls_auto_pose-zwstand                 = 'X'.
      ls_auto_pose-consumption             = 'X'.

      CALL FUNCTION 'ISU_S_WORKLIST_INSTALL'
        EXPORTING
          x_anlage         = lv_anlage
          x_eadat          = <fs_date_releve>
          x_geraetneu      = lv_sernr
          x_matnr          = ls_dev-matnr
          x_action         = '04'       " Pose pour calcul de facturation
          x_spartee        = 'ZG' "02
          x_upd_online     = 'X'
          x_no_dialog      = 'X'
          x_no_event       = 'X'
          x_no_statistic   = 'X'
          x_no_change_doc  = 'X'
          x_called_by_idoc = space
        IMPORTING
          y_db_update      = ld_db_update
        CHANGING
          xy_auto          = ls_auto_pose
"         xy_ext_cont      = lt_cont[]
        EXCEPTIONS
          not_found        = 1
          foreign_lock     = 2
          invalid          = 3
          internal_error   = 4
          not_qualified    = 5
          input_error      = 6
          system_error     = 7
          not_customized   = 8
          OTHERS           = 9.
      IF NOT sy-subrc IS INITIAL.
        ev_etape = 2.
      ELSE.
        ev_etape = 1.
      ENDIF.
    ENDIF.

  ENDIF.

ENDFUNCTION.
