*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZBTZ_BTTOP.                       " Global Data
  INCLUDE LZBTZ_BTUXX.                       " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZBTZ_BTF...                       " Subroutines
* INCLUDE LZBTZ_BTO...                       " PBO-Modules
* INCLUDE LZBTZ_BTI...                       " PAI-Modules
* INCLUDE LZBTZ_BTE...                       " Events
* INCLUDE LZBTZ_BTP...                       " Local class implement.
* INCLUDE LZBTZ_BTT99.                       " ABAP Unit tests
