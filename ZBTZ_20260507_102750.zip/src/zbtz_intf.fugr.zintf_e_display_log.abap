FUNCTION ZINTF_E_DISPLAY_LOG .
*"--------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(OBJECT) TYPE  BALOBJ_D
*"     REFERENCE(SUBOBJECT) TYPE  BALSUBOBJ OPTIONAL
*"     REFERENCE(DATE_LOG) TYPE  DATS OPTIONAL
*"     REFERENCE(TIME_LOG) TYPE  TIMS OPTIONAL
*"     REFERENCE(USER_LOG) TYPE  UNAME OPTIONAL
*"     REFERENCE(TCODE_LOG) TYPE  TCODE OPTIONAL
*"     REFERENCE(TITLE_LOG) TYPE  BALTITLE OPTIONAL
*"  EXPORTING
*"     REFERENCE(T_LOG_HEADER) TYPE  BALHDR_T
*"  EXCEPTIONS
*"      NOT_AUTHORIZED
*"      NO_OBJECT_SPECIFIED
*"      LOG_NOT_FOUND
*"--------------------------------------------------------------------
  FIELD-SYMBOLS:
   <fs_mess_fcat>         TYPE bal_s_fcat.

  DATA:
    ls_display_profile     TYPE bal_s_prof.

***********************************************************************
* Pas d'autorisation d'affichage du journal d'applications en mode batch
***********************************************************************
  IF sy-batch NE space
  OR sy-uname CS 'BATCH'.
    MESSAGE i001(bl)
       WITH 'Traitement terminé'
            '-'
            'Consultez le journal des applications'
            '(SLG1)'
     RAISING not_authorized.
  ENDIF.

  IF object IS INITIAL.
* Absence d'indication de protocole pour le chargement
    MESSAGE i001(bl)
       WITH 'Traitement terminé'
            '-'
            'Consultez le journal des applications'
            '(SLG1)'
     RAISING no_object_specified.
  ENDIF.

  CLEAR: t_log_header[],
         t_log_header.

  SELECT *
    FROM balhdr
    INTO TABLE t_log_header
   WHERE object    EQ object
     AND aldate    EQ date_log
     AND altime    GE time_log
     AND aluser    EQ user_log.

  IF  NOT tcode_log      IS INITIAL
  AND NOT t_log_header[] IS INITIAL.
    DELETE t_log_header WHERE altcode NE tcode_log.
  ENDIF.

  IF t_log_header[] IS INITIAL.
* Absence d'indication d'objet de protocole pour le chargement
    MESSAGE i001(bl)
       WITH 'Traitement terminé'
            '-'
            'Consultez le journal des applications'
            '(SLG1)'
     RAISING no_object_specified.
  ENDIF.

  CALL FUNCTION 'BAL_DB_LOAD'
       EXPORTING
         i_t_log_header     = t_log_header
       EXCEPTIONS
         no_logs_specified  = 1
         log_not_found      = 2
         log_already_loaded = 3
         OTHERS             = 99.

  IF sy-subrc NE 0.
* Absence d'indication d'objet de protocole pour le chargement
    MESSAGE i001(bl)
       WITH 'Traitement terminé'
            '-'
            'Consultez le journal des applications'
            '(SLG1)'
     RAISING log_not_found.
  ENDIF.

* Affichage en mode ALV GRID
  CLEAR: ls_display_profile.

* Get standard profile for transaction SLG1
********************************************************************
  CALL FUNCTION 'BAL_DSP_PROFILE_STANDARD_GET'
       IMPORTING
            e_s_display_profile = ls_display_profile.

  ls_display_profile-title               = title_log.
  ls_display_profile-use_grid            = 'X'.
  ls_display_profile-show_all            = 'X'.
  ls_display_profile-mess_mark           = 'X'.
  ls_display_profile-tree_ontop          = 'X'.
  ls_display_profile-exp_level           = 1.
  ls_display_profile-disvariant-report   = sy-repid.
  ls_display_profile-clbk_ucbf-userexitp = sy-repid.
  ls_display_profile-clbk_ucbf-userexitf = 'BAL_CALLBACK_UCOMM'.

  READ TABLE ls_display_profile-mess_fcat ASSIGNING <fs_mess_fcat>
    WITH KEY ref_table = 'BAL_S_SHOW'
             ref_field = 'T_MSG'.
  <fs_mess_fcat>-outputlen = '000170'.

  CALL FUNCTION 'BAL_DSP_LOG_DISPLAY'
       EXPORTING
         i_s_display_profile  = ls_display_profile
       EXCEPTIONS
         profile_inconsistent = 1
         internal_error       = 2
         no_data_available    = 3
         no_authority         = 4
         OTHERS               = 99.

  IF sy-subrc NE 0.
* Absence d'indication d'objet de protocole pour le chargement
    MESSAGE i001(bl)
       WITH 'Traitement terminé'
            '-'
            'Consultez le journal des applications'
            '(SLG1)'
     RAISING log_not_found.
  ENDIF.

ENDFUNCTION.
