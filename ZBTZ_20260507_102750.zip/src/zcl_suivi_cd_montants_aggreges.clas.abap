class ZCL_SUIVI_CD_MONTANTS_AGGREGES definition
  public
  inheriting from ZCL_UTILS_BASE_ALV_GRID
  final
  create public .

public section.

  data PV_SELECT type ZSUIVI_CREANCES_DOUTEUSES_SEL .
  constants PC_SPARTE_GAZ type SPARTE value 'ZG' ##NO_TEXT.
  constants PC_SPARTE_ELEC type SPARTE value 'ZE' ##NO_TEXT.
  constants PC_BUKRS_GDP1 type BUKRS value 'GDP1' ##NO_TEXT.
  constants PC_BUKRS_GDP2 type BUKRS value 'GDP2' ##NO_TEXT.

  methods SET_CRITERIA
    importing
      !X_SELECT type ZSUIVI_CREANCES_DOUTEUSES_SEL .
protected section.

  data PT_DATA type ZSUIVI_TT_CD_MONTANTS_AGG .

  methods GET_LAYOUT
    redefinition .
  methods GRID_LOAD
    redefinition .
  PRIVATE SECTION.
ENDCLASS.



CLASS ZCL_SUIVI_CD_MONTANTS_AGGREGES IMPLEMENTATION.


  METHOD GET_LAYOUT.

    FIELD-SYMBOLS:
     <fcat> TYPE lvc_s_fcat.

    " Call superior method
    CALL METHOD super->get_layout( ).

    " Have the grid fit with the actual size of the columns
    pv_layo-cwidth_opt = abap_true.

    " Display with zebra
    pv_layo-zebra = abap_true.

    " Change the field catalog
    LOOP AT pt_fcat ASSIGNING <fcat>.

      CASE <fcat>-fieldname.
        WHEN 'ECHU_INF_T1'.
          <fcat>-coltext = `Mtt pièce échue < à ` && pv_select-t1 && ' j.'.

        WHEN 'ECHU_RES_INF_T1'.
          <fcat>-coltext = `Mtt pièce échue cont. rés. < à ` && pv_select-t1 && ' j.'.

        WHEN 'ECHU_T1_T2'.
          <fcat>-coltext = `Mtt pièce échue entre ` && pv_select-t1 && ` et ` && pv_select-t2 && ' j.'.

        WHEN 'ECHU_RES_T1_T2'.
          <fcat>-coltext = `Mtt pièce cont. rés. entre ` && pv_select-t1 && ` et ` && pv_select-t2 && ' j.'.

        WHEN 'ECHU_T2_T3'.
          <fcat>-coltext = `Mtt pièce échue entre ` && pv_select-t2 && ` et ` && pv_select-t3 && ' j.'.

        WHEN 'ECHU_RES_T2_T3'.
          <fcat>-coltext = `Mtt pièce cont. rés. entre ` && pv_select-t2 && ` et ` && pv_select-t3 && ' j.'.

        WHEN 'ECHU_T3_T4'.
          <fcat>-coltext = `Mtt pièce échue entre ` && pv_select-t3 && ` et ` && pv_select-t4 && ' j.'.

        WHEN 'ECHU_RES_T3_T4'.
          <fcat>-coltext = `Mtt pièce cont. rés. entre ` && pv_select-t3 && ` et ` && pv_select-t4 && ' j.'.

        WHEN 'ECHU_T4_T5'.
          <fcat>-coltext = `Mtt pièce échue entre` && pv_select-t4 && ` et ` && pv_select-t5 && ' j.'.

        WHEN 'ECHU_RES_T4_T5'.
          <fcat>-coltext = `Mtt pièce cont. rés. entre ` && pv_select-t4 && ` et ` && pv_select-t5 && ' j.'.

        WHEN 'ECHU_T5_T6'.
          <fcat>-coltext = 'Mtt pièce échue entre' && ` ` && pv_select-t5 && ` et ` && pv_select-t6 && ' j.'.

        WHEN 'ECHU_RES_T5_T6'.
          <fcat>-coltext = `Mtt pièce cont. rés. entre ` && pv_select-t5 && ` et ` && pv_select-t6 && ' j.'.

        WHEN 'ECHU_T6_T7'.
          <fcat>-coltext = `Mtt pièce échue entre ` && pv_select-t6 && ` et ` && pv_select-t7 && ' j.'.

        WHEN 'ECHU_RES_T6_T7'.
          <fcat>-coltext = `Mtt pièce cont. rés. entre ` && pv_select-t6 && ` et ` && pv_select-t7 && ' j.'.

        WHEN 'ECHU_SUP_T7'.
          <fcat>-coltext = `Mtt pièce échue > à ` && pv_select-t7 && ' j.'.

        WHEN 'ECHU_RES_T7'.
          <fcat>-coltext = `Mtt pièce échue cont. rés. > à ` && pv_select-t7 && ' j.'.

      ENDCASE.

    ENDLOOP.

  ENDMETHOD.


  METHOD grid_load.

    TYPES :
      BEGIN OF lty_vertrag,
        vtref   TYPE vtref_kk,
        vertrag TYPE vertrag,
      END OF lty_vertrag,

      BEGIN OF lty_opbel,
        xblnr TYPE xblnr_kk,
        opbel TYPE opbel_kk,
      END OF lty_opbel.

    DATA :
      lv_prec_xblnr TYPE xblnr_kk,
      lv_vtref      TYPE vtref_kk,
      lv_xblnr      TYPE xblnr_kk,
      lv_tabix      TYPE syst_tabix,
      lv_anlage     TYPE anlage,
      lv_cag        TYPE decfloat34,
      lv_cas        TYPE decfloat34,
      lv_cac        TYPE decfloat34,
      lv_cas_base   TYPE decfloat34,
      lv_cas_hphc   TYPE decfloat34,
      lv_cad_base   TYPE v_abrmenge,
      lv_cad_hp     TYPE v_abrmenge,
      lv_cad_hc     TYPE v_abrmenge,
      lv_ci_base    TYPE decfloat34,
      lv_ci_hc      TYPE decfloat34,
      lv_ci_hp      TYPE decfloat34,
      lv_type_tarif TYPE string1.

    DATA :
      ls_data    TYPE zsuivi_cd_montants_agg,
      ls_vertrag TYPE lty_vertrag,
      ls_opbel   TYPE lty_opbel.

    DATA :
      lt_vertrag TYPE STANDARD TABLE OF lty_vertrag,
      lt_opbel   TYPE STANDARD TABLE OF lty_opbel.

    " Call superior method
    CALL METHOD super->grid_load( ).

    " Reset the output table
    REFRESH pt_data.

    SELECT * INTO TABLE @DATA(lt_type_ligne_ach)
      FROM ztype_ligne_ach.

    SELECT * INTO TABLE @DATA(lt_pitd_report)
      FROM zpitd_report.

    SELECT * INTO TABLE @DATA(lt_coeff_zi)
      FROM zcoeff_zi.

    SELECT * INTO TABLE @DATA(lt_coeff_a)
      FROM zcoeff_a.

    IF pv_select-poste_stat IS INITIAL.

      SELECT opbel, bukrs, gpart, vkont, vtref, budat, spart, mwskz, xblnr, betrw, faedn INTO TABLE @DATA(lt_dfkkop)
        FROM dfkkop
       WHERE opbel  IN @pv_select-facture
         AND vkont  IN @pv_select-vkont
         AND gpart  IN @pv_select-partner
         AND bukrs  IN @pv_select-bukrs
         AND spart  IN @pv_select-sparte
         AND vtref  IN @pv_select-vertrag
         AND xblnr  IN @pv_select-piece
         AND budat  IN @pv_select-date_comptable
         AND faedn  IN @pv_select-echue
         AND augst  EQ @space.

    ELSE.

      SELECT opbel bukrs gpart vkont vtref budat spart mwskz xblnr betrw faedn INTO TABLE lt_dfkkop
      FROM dfkkop
       WHERE opbel  IN pv_select-facture
         AND vkont  IN pv_select-vkont
         AND gpart  IN pv_select-partner
         AND bukrs  IN pv_select-bukrs
         AND spart  IN pv_select-sparte
         AND vtref  IN pv_select-vertrag
         AND xblnr  IN pv_select-piece
         AND budat  IN pv_select-date_comptable
         AND faedn  IN pv_select-echue
         AND stakz  EQ space.

    ENDIF.

    " Table of contract ref
    DATA(lt_vtref) = lt_dfkkop.
    SORT lt_vtref BY vtref.
    DELETE ADJACENT DUPLICATES FROM lt_vtref COMPARING vtref.

    IF lt_vtref IS NOT INITIAL.

      " Conversion
      LOOP AT lt_vtref ASSIGNING FIELD-SYMBOL(<ls_vtref>).
        lv_vtref = ls_vertrag-vtref = <ls_vtref>-vtref.
        SHIFT lv_vtref LEFT DELETING LEADING '0'.
        ls_vertrag-vertrag = lv_vtref.
        APPEND ls_vertrag TO lt_vertrag.
      ENDLOOP.

      SELECT vertrag, auszdat, anlage INTO TABLE @DATA(lt_ever)
        FROM ever
        FOR ALL ENTRIES IN @lt_vertrag
        WHERE vertrag EQ @lt_vertrag-vertrag.

    ENDIF.

    " Table des installations
    DATA(lt_anlage) = lt_ever.
    SORT lt_anlage BY anlage.
    DELETE ADJACENT DUPLICATES FROM lt_anlage COMPARING anlage.

    IF lt_anlage IS NOT INITIAL.

      SELECT anlage, operand, tarifart, kondigr, ab, bis, string1 INTO TABLE @DATA(lt_ettifn)
        FROM ettifn
              FOR ALL ENTRIES IN @lt_anlage
              WHERE anlage EQ @lt_anlage-anlage
                AND operand IN ('ERTP' , 'ERPP', 'GVFTCJNP01' ,'GVVUTACH01').

      SELECT * INTO TABLE @DATA(lt_flux_g)
        FROM euiinstln
        INNER JOIN euitrans ON euitrans~int_ui EQ euiinstln~int_ui
        INNER JOIN zintf_g_adif ON zintf_g_adif~num_pce EQ euitrans~ext_ui
        FOR ALL ENTRIES IN @lt_anlage
        WHERE anlage EQ @lt_anlage-anlage.

    ENDIF.

    " Table des pièces de référence
    DATA(lt_xblnr) = lt_dfkkop.
    SORT lt_xblnr BY xblnr.
    DELETE ADJACENT DUPLICATES FROM lt_xblnr COMPARING xblnr.

    IF lt_xblnr IS NOT INITIAL.

      " Conversion
      LOOP AT lt_xblnr ASSIGNING FIELD-SYMBOL(<ls_xblnr>).
        lv_xblnr = ls_opbel-xblnr = <ls_xblnr>-xblnr.
        SHIFT lv_xblnr LEFT DELETING LEADING '0'.
        ls_opbel-opbel = lv_xblnr.
        APPEND ls_opbel TO lt_opbel.
      ENDLOOP.

      SELECT opbel, begabrpe, endabrpe, buchrel, nettobtr, dberchz1~belzart, dberchz1~aus01, v_zwstdiff, v_abrmenge INTO TABLE @DATA(lt_erch)
        FROM erchc
        INNER JOIN erch     ON erch~belnr EQ erchc~belnr
        INNER JOIN dberchz1 ON dberchz1~belnr EQ erchc~belnr
        INNER JOIN dberchz2 ON dberchz2~belnr EQ dberchz1~belnr
               AND dberchz2~belzeile EQ dberchz1~belzeile
        INNER JOIN dberchz3 ON dberchz3~belnr EQ dberchz1~belnr
               AND dberchz3~belzeile EQ dberchz1~belzeile
        FOR ALL ENTRIES IN @lt_opbel
        WHERE opbel = @lt_opbel-opbel.

    ENDIF.

    " Table des pièces
    DATA(lt_pieces) = lt_dfkkop.
    SORT lt_pieces BY opbel.
    DELETE ADJACENT DUPLICATES FROM lt_pieces COMPARING opbel.

    IF lt_pieces IS NOT INITIAL.

      SELECT opbel, budat, xblnr INTO TABLE @DATA(lt_dfkkko)
        FROM dfkkko
        FOR ALL ENTRIES IN @lt_pieces
        WHERE opbel EQ @lt_pieces-opbel.

    ENDIF.

    " Récupération des taux de TVA
    "- Tableau de code TVA
    DATA(lt_code_tva) = lt_dfkkop.
    SORT lt_code_tva BY mwskz.
    DELETE ADJACENT DUPLICATES FROM lt_code_tva COMPARING mwskz.

    IF lt_code_tva IS NOT INITIAL.
      SELECT mwskz, kbetr INTO TABLE @DATA(lt_taux)
        FROM a003
        INNER JOIN konp ON konp~knumh EQ a003~knumh
        FOR ALL ENTRIES IN @lt_code_tva
        WHERE aland EQ 'FR'
          AND mwskz EQ @lt_code_tva-mwskz.
    ENDIF.

    SELECT preis, abdatum, bisdatum, preisbtr INTO TABLE @DATA(lt_price)
       FROM epreih
      WHERE preis IN ( 'ET5FGINA', 'ET5FCINA', 'ET5FSICUSB', 'ET5FSIMUB', 'ET5VSICUSB', 'ET5VSIMUP', 'ET5VSIMUC', 'GPDA40101', 'GPDA30101', 'GPDA20101',
                       'GPDA10101', 'GPTATCS01', 'GPTATCR01', 'GVPFTCLP01', 'GPTATCR01', 'GPDC40101', 'GPDC30101' , 'GPDA40102' ).

    SORT lt_ever            BY vertrag.
    SORT lt_dfkkko          BY opbel.
    SORT lt_erch            BY opbel.
    SORT lt_taux            BY mwskz.
    SORT lt_vertrag         BY vtref.
    SORT lt_opbel           BY xblnr.
    SORT lt_dfkkop          BY xblnr.
    SORT lt_ettifn          BY anlage.
    SORT lt_price           BY preis.

    LOOP AT lt_dfkkop ASSIGNING FIELD-SYMBOL(<ls_dfkkop>).

      IF ls_data-ref_doc NE <ls_dfkkop>-xblnr AND sy-tabix GT 1.

        APPEND ls_data TO pt_data.
        CLEAR : ls_data, lv_cad_base, lv_cad_hc, lv_cad_hp, lv_anlage.

      ENDIF.

      ls_data-societe         = <ls_dfkkop>-bukrs.
      ls_data-partner         = <ls_dfkkop>-gpart.
      ls_data-compte_contrat  = <ls_dfkkop>-vkont.
      ls_data-contrat         = <ls_dfkkop>-vtref.
      ls_data-secteur         = <ls_dfkkop>-spart.
      ls_data-num_piece       = <ls_dfkkop>-opbel.
      ls_data-ref_doc         = <ls_dfkkop>-xblnr.

      READ TABLE lt_vertrag ASSIGNING FIELD-SYMBOL(<ls_vertrag>) WITH KEY vtref = <ls_dfkkop>-vtref BINARY SEARCH.
      IF sy-subrc EQ 0.
        READ TABLE lt_ever ASSIGNING FIELD-SYMBOL(<ls_ever>) WITH KEY vertrag = CONV vertrag( <ls_dfkkop>-vtref ) BINARY SEARCH.
        IF sy-subrc EQ 0.
          ls_data-date_dem = <ls_ever>-auszdat.
          lv_anlage = <ls_ever>-anlage.
        ENDIF.
      ENDIF.

      IF ls_data-date_dem NE '99991231'.
        ls_data-resilie = abap_true.
      ENDIF.

      READ TABLE lt_dfkkko ASSIGNING FIELD-SYMBOL(<ls_dfkkko>) WITH KEY opbel = <ls_dfkkop>-opbel BINARY SEARCH.
      IF sy-subrc EQ 0.
        ls_data-date_cpt  = <ls_dfkkko>-budat.
      ENDIF.


      READ TABLE lt_opbel ASSIGNING FIELD-SYMBOL(<ls_opbel>) WITH KEY xblnr = <ls_dfkkop>-xblnr BINARY SEARCH.
      IF sy-subrc EQ 0.

        " Somme des cadrans
        LOOP AT lt_erch ASSIGNING FIELD-SYMBOL(<ls_erch>) WHERE opbel EQ <ls_opbel>-opbel
                                                            AND ( belzart EQ 'XBASE' OR belzart EQ 'XHP' OR belzart EQ 'XHC' ).

          CASE <ls_erch>-belzart.
            WHEN 'XBASE'.
              lv_cad_base = lv_cad_base + <ls_erch>-v_abrmenge.
            WHEN 'XHP'.
              lv_cad_hp = lv_cad_base + <ls_erch>-v_abrmenge.
            WHEN 'XHC'.
              lv_cad_hc = lv_cad_base + <ls_erch>-v_abrmenge.
            WHEN OTHERS.
              " Aucun autre cas n'est géré
          ENDCASE.

        ENDLOOP.

        LOOP AT lt_erch ASSIGNING <ls_erch> WHERE opbel = <ls_opbel>-opbel.

          ls_data-deb_periode = <ls_erch>-begabrpe.
          ls_data-fin_periode = <ls_erch>-endabrpe.

          DATA(lv_nb_jrs) = <ls_erch>-endabrpe - <ls_erch>-begabrpe.

          LOOP AT lt_ettifn ASSIGNING FIELD-SYMBOL(<ls_ettifn>) WHERE anlage = lv_anlage AND ( operand EQ 'ERTP' OR operand EQ 'ERPP' ) AND ab LE <ls_erch>-endabrpe AND bis GE <ls_erch>-endabrpe.
            ls_data-tarif_ach = <ls_ettifn>-tarifart.
            DATA(ls_ettifn_er) = <ls_ettifn>.
            EXIT.
          ENDLOOP.

          LOOP AT lt_ettifn ASSIGNING <ls_ettifn> WHERE anlage = lv_anlage AND operand EQ 'GVVUTACH01' AND ab LE <ls_erch>-endabrpe AND bis GE <ls_erch>-endabrpe.
            lv_type_tarif = <ls_ettifn>-string1.
            EXIT.
          ENDLOOP.

          LOOP AT lt_price ASSIGNING FIELD-SYMBOL(<ls_price>) WHERE abdatum LE <ls_erch>-endabrpe AND bisdatum GE <ls_erch>-endabrpe.
            " RG 14
            CASE <ls_price>-preis.
              WHEN 'ET5FGINA'.
                lv_cag =  ( lv_nb_jrs + 1 ) * <ls_price>-preisbtr / 365.

              WHEN 'ET5FCINA'.
                lv_cac =  ( lv_nb_jrs + 1 ) * <ls_price>-preisbtr / 365.

              WHEN 'ET5FSICUSB'.
                DATA(lv_p) = ls_ettifn_er-kondigr+1(2).
                lv_cas_base =  <ls_price>-preisbtr * lv_p.

              WHEN 'ET5FSIMUB'.
                lv_p = ls_ettifn_er-kondigr+1(2).
                lv_cas_hphc = <ls_price>-preisbtr * lv_p.

              WHEN 'ET5VSICUSB'.
                lv_ci_base = <ls_price>-preisbtr.

              WHEN 'ET5VSIMUP'.
                lv_ci_hp = <ls_price>-preisbtr.

              WHEN 'ET5VSIMUC'.
                lv_ci_hc = <ls_price>-preisbtr.

              WHEN OTHERS.
                " Aucun autre cas n'est géré

            ENDCASE.

          ENDLOOP.

*ls_data-fixe_atrd_recalcule = ls_data-fixe_atrd_recalcule."RG16
*ls_data-fixe_atrt_recalcule = ls_data-fixe_atrt_recalcule."RG17
*ls_data-variable_atrd_recalcule = ls_data-variable_atrd_recalcule."RG18
*ls_data-cta_recalculee = ls_data-cta_recalculee."RG19

          IF ls_data-secteur EQ 'ZE'.

            READ TABLE lt_type_ligne_ach ASSIGNING FIELD-SYMBOL(<ls_ztype_ligne>) WITH KEY acheminement = 'Fixe' type_ligne = <ls_erch>-belzart.
            IF sy-subrc EQ 0 AND <ls_erch>-buchrel IS NOT INITIAL.
              ls_data-fixe_ach_facture = ls_data-fixe_ach_facture + <ls_erch>-nettobtr.
            ENDIF.

            READ TABLE lt_type_ligne_ach ASSIGNING <ls_ztype_ligne> WITH KEY acheminement = 'Variable' type_ligne = <ls_erch>-belzart.
            IF sy-subrc EQ 0 AND <ls_erch>-buchrel IS NOT INITIAL.
              ls_data-variable_ach_facture = ls_data-variable_ach_facture + <ls_erch>-nettobtr.
            ENDIF.

            READ TABLE lt_type_ligne_ach ASSIGNING <ls_ztype_ligne> WITH KEY acheminement = 'Forfait' type_ligne = <ls_erch>-belzart.
            IF sy-subrc EQ 0 AND <ls_erch>-buchrel IS NOT INITIAL.
              ls_data-forfait_ach_facture = ls_data-forfait_ach_facture + <ls_erch>-nettobtr.
            ENDIF.

            CASE ls_data-societe.

              WHEN 'GDP1'.
                ls_data-fixe_ach_recalcule = ls_data-fixe_ach_facture.
                ls_data-variable_ach_recalcule = ls_data-variable_ach_facture.

              WHEN 'GDP2'.
                IF ls_data-tarif_ach EQ 'EIBASE' OR ls_data-tarif_ach EQ 'EIHPHC'.
                  ls_data-fixe_ach_recalcule = lv_cag + lv_cac.
                  IF ls_data-tarif_ach EQ 'EIBASE'.
                    ls_data-fixe_ach_recalcule = ls_data-fixe_ach_recalcule + lv_cas_base.
                    IF <ls_erch>-belzart EQ 'XBASE'.
                      ls_data-variable_ach_recalcule = ls_data-variable_ach_recalcule + ( lv_ci_base * <ls_erch>-v_abrmenge ).
                    ENDIF.
                  ELSEIF ls_data-tarif_ach EQ 'EIHPHC'.
                    ls_data-fixe_ach_recalcule = ls_data-fixe_ach_recalcule + lv_cas_hphc.
                    IF <ls_erch>-belzart EQ 'XHP'.
                      ls_data-variable_ach_recalcule = ls_data-variable_ach_recalcule + ( lv_ci_hp * <ls_erch>-v_abrmenge ).
                    ENDIF.
                    IF <ls_erch>-belzart EQ 'XHC'.
                      ls_data-variable_ach_recalcule = ls_data-variable_ach_recalcule + ( lv_ci_hc * <ls_erch>-v_abrmenge ).
                    ENDIF.
                  ENDIF.
                ENDIF.

              WHEN OTHERS.
                " Aucun autre cas

            ENDCASE.

          ELSE. " Gaz

            READ TABLE lt_type_ligne_ach ASSIGNING <ls_ztype_ligne> WITH KEY acheminement = 'Fixe' operande = <ls_erch>-aus01.
            IF sy-subrc EQ 0 AND <ls_erch>-buchrel IS NOT INITIAL.
              ls_data-fixe_ach_facture = ls_data-fixe_ach_facture + <ls_erch>-nettobtr.
            ENDIF.

            READ TABLE lt_type_ligne_ach ASSIGNING <ls_ztype_ligne> WITH KEY acheminement = 'Variable' operande = <ls_erch>-aus01.
            IF sy-subrc EQ 0 AND <ls_erch>-buchrel IS NOT INITIAL.
              ls_data-variable_ach_facture = ls_data-variable_ach_facture + <ls_erch>-nettobtr.
            ENDIF.

            READ TABLE lt_type_ligne_ach ASSIGNING <ls_ztype_ligne> WITH KEY acheminement = 'Forfait' operande = <ls_erch>-aus01.
            IF sy-subrc EQ 0 AND <ls_erch>-buchrel IS NOT INITIAL.
              ls_data-forfait_ach_facture = ls_data-forfait_ach_facture + <ls_erch>-nettobtr.
            ENDIF.

          ENDIF.

        ENDLOOP.

      ENDIF.

      READ TABLE lt_taux ASSIGNING FIELD-SYMBOL(<ls_tva>) WITH KEY mwskz = <ls_dfkkop>-mwskz BINARY SEARCH.
      IF sy-subrc EQ 0.

        ls_data-mtt_creance_ht = ls_data-mtt_creance_ht + ( <ls_dfkkop>-betrw / ( 1 + ( <ls_tva>-kbetr / 1000 ) ) ).

        ls_data-cta_facturee = ls_data-cta_facturee + ( <ls_dfkkop>-betrw / ( 1 + ( <ls_tva>-kbetr / 1000 ) ) ).

        IF <ls_tva>-kbetr EQ 200.
          ls_data-tva_20 = ls_data-tva_20 + <ls_dfkkop>-betrw.
        ELSE.
          ls_data-tva_5 = ls_data-tva_5 + <ls_dfkkop>-betrw.
        ENDIF.

      ENDIF.

      ls_data-ttc_facture = ls_data-ttc_facture + <ls_dfkkop>-betrw.

      IF <ls_dfkkop>-betrw LT 0.
        ls_data-mtt_cred = ls_data-mtt_cred + <ls_dfkkop>-betrw.
      ENDIF.

      ls_data-solde = ls_data-solde + <ls_dfkkop>-betrw.

      ls_data-prct_creance_facture = ls_data-solde / ls_data-ttc_facture * 100.
      ls_data-ach_creance = ( ls_data-fixe_ach_recalcule - ls_data-variable_ach_recalcule ) * ls_data-prct_creance_facture.
      ls_data-cta_creance = ls_data-cta_recalculee - ls_data-prct_creance_facture.
      ls_data-ht_hors_ach = ls_data-mtt_creance_ht - ls_data-ach_creance - ls_data-cta_creance.

*ls_data-prov_calculee = ls_data-prov_calculee + ."RG24


      IF <ls_dfkkop>-betrw GE 0.

        DATA(lv_diff) = sy-datum - <ls_dfkkop>-faedn.

        IF ls_data-resilie IS NOT INITIAL.

          IF lv_diff LT pv_select-t1.
            ls_data-echu_inf_t1 = ls_data-echu_inf_t1 + <ls_dfkkop>-betrw.

          ELSEIF lv_diff GE pv_select-t1 AND lv_diff LT pv_select-t2.
            ls_data-echu_t1_t2 = ls_data-echu_t1_t2 + <ls_dfkkop>-betrw.

          ELSEIF lv_diff GE pv_select-t2 AND lv_diff LT pv_select-t3.
            ls_data-echu_t2_t3 = ls_data-echu_t2_t3 + <ls_dfkkop>-betrw.

          ELSEIF lv_diff GE pv_select-t3 AND lv_diff LT pv_select-t4.
            ls_data-echu_t3_t4 = ls_data-echu_t3_t4 + <ls_dfkkop>-betrw.

          ELSEIF lv_diff GE pv_select-t4 AND lv_diff LT pv_select-t5.
            ls_data-echu_t4_t5 = ls_data-echu_t4_t5 + <ls_dfkkop>-betrw.

          ELSEIF lv_diff GE pv_select-t5 AND lv_diff LT pv_select-t6.
            ls_data-echu_t5_t6 = ls_data-echu_t5_t6 + <ls_dfkkop>-betrw.

          ELSEIF lv_diff GE pv_select-t6 AND lv_diff LT pv_select-t7.
            ls_data-echu_t6_t7 = ls_data-echu_t6_t7 + <ls_dfkkop>-betrw.

          ELSEIF lv_diff GE pv_select-t7 .
            ls_data-echu_sup_t7 = ls_data-echu_sup_t7 + <ls_dfkkop>-betrw.

          ENDIF.

        ELSE.

          IF lv_diff LT pv_select-t1.
            ls_data-echu_res_inf_t1 = ls_data-echu_res_inf_t1 + <ls_dfkkop>-betrw.

          ELSEIF lv_diff GE pv_select-t1 AND lv_diff LT pv_select-t2.
            ls_data-echu_res_t1_t2 = ls_data-echu_res_inf_t1 + <ls_dfkkop>-betrw.

          ELSEIF lv_diff GE pv_select-t2 AND lv_diff LT pv_select-t3.
            ls_data-echu_res_t2_t3 = ls_data-echu_res_inf_t1 + <ls_dfkkop>-betrw.

          ELSEIF lv_diff GE pv_select-t3 AND lv_diff LT pv_select-t4.
            ls_data-echu_res_t3_t4 = ls_data-echu_res_inf_t1 + <ls_dfkkop>-betrw.

          ELSEIF lv_diff GE pv_select-t4 AND lv_diff LT pv_select-t5.
            ls_data-echu_res_t4_t5 = ls_data-echu_res_inf_t1 + <ls_dfkkop>-betrw.

          ELSEIF lv_diff GE pv_select-t5 AND lv_diff LT pv_select-t6.
            ls_data-echu_res_t5_t6 = ls_data-echu_res_inf_t1 + <ls_dfkkop>-betrw.

          ELSEIF lv_diff GE pv_select-t6 AND lv_diff LT pv_select-t7.
            ls_data-echu_res_t6_t7 = ls_data-echu_res_inf_t1 + <ls_dfkkop>-betrw.

          ELSEIF lv_diff GE pv_select-t7 .
            ls_data-echu_res_t7 = ls_data-echu_res_inf_t1 + <ls_dfkkop>-betrw.

          ENDIF.

        ENDIF.

      ENDIF.

    ENDLOOP.

    " Gérer la dernière ligne
    IF ls_data IS NOT INITIAL.
      APPEND ls_data TO pt_data.
    ENDIF.

    " Reference the data
    GET REFERENCE OF pt_data INTO pr_data.

  ENDMETHOD.


  METHOD SET_CRITERIA.

    " Save the new criteria
    pv_select = x_select.

    " Refresh the display
    CALL METHOD me->display( ).

  ENDMETHOD.
ENDCLASS.
