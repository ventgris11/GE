*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDSO_RESIL_DEM
*   generation date: 22.04.2019 at 02:53:37
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDSO_RESIL_DEM      .

  PERFORM TABLEPROC.

ENDFUNCTION.
