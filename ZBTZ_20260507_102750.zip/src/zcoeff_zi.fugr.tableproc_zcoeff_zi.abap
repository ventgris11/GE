*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCOEFF_ZI
*   generation date: 25.03.2019 at 09:29:33
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCOEFF_ZI           .

  PERFORM TABLEPROC.

ENDFUNCTION.
