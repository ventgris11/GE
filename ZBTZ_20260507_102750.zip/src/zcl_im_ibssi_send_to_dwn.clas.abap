class ZCL_IM_IBSSI_SEND_TO_DWN definition
  public
  final
  create public .

public section.

  interfaces IF_EX_IBSSI_SEND_TO_DWN .
protected section.
private section.

  methods ADD_TABLE_DATA
    importing
      !IS_DATA type ANY
      !IV_SOURCE_TABLE type STRING
      !IV_OBJKEY type ANY
    changing
      !CT_BAPIMTCS type BAPIMTCST .
ENDCLASS.



CLASS ZCL_IM_IBSSI_SEND_TO_DWN IMPLEMENTATION.


METHOD add_table_data.
  DATA: lr_data     TYPE REF TO data,
        ls_bapimtcs TYPE        bapimtcs,
        lt_dd03l    TYPE TABLE OF dd03l,
        ls_dd03l    TYPE dd03l.

  SELECT * FROM dd03l INTO TABLE lt_dd03l WHERE tabname = iv_source_table AND fieldname = '.INCLUDE'.

  LOOP AT lt_dd03l INTO ls_dd03l.
    CHECK ls_dd03l-precfield(2) EQ 'ZZ'.
*
*  LOOP AT st_structs INTO DATA(ls_struct) WHERE sourcetab = iv_source_table.
    ls_bapimtcs-objkey = iv_objkey.
    ls_bapimtcs-tabname = ls_dd03l-precfield.
    ls_bapimtcs-segtype = 'DA'.

    " Avoid duplicates
    READ TABLE ct_bapimtcs TRANSPORTING NO FIELDS WITH KEY objkey = ls_bapimtcs-objkey tabname = ls_bapimtcs-tabname.
    CHECK sy-subrc <> 0.

    ls_bapimtcs-currdno = lines( ct_bapimtcs ) + 1.

    CREATE DATA lr_data TYPE (ls_dd03l-precfield).
    ASSIGN lr_data->* TO FIELD-SYMBOL(<data>).
    MOVE-CORRESPONDING is_data TO <data>.
    ls_bapimtcs-data = <data>.
    APPEND ls_bapimtcs TO ct_bapimtcs.
  ENDLOOP.
ENDMETHOD.


  METHOD if_ex_ibssi_send_to_dwn~fill_bapimtcs.
    DATA: ls_iflot   TYPE iflot,
          ls_evbs    TYPE evbs,
          ls_euihead TYPE euihead,
          ls_eanl    TYPE eanl.

*  " Send customer-specific fields for connection object.
*  IF ehau IS NOT INITIAL AND lines( bapi_ehau ) = 1.
*    me->add_table_data( EXPORTING is_data = ehau
*                                  iv_source_table = 'IFLOT'
*                                  iv_objkey = ehau-haus
*                        CHANGING ct_bapimtcs = bapimtcs ).
*  ELSE.
*    LOOP AT bapi_ehau INTO DATA(ls_bapi_ehau).
*      SELECT SINGLE *
*        FROM iflot
*        INTO ls_iflot
*        WHERE tplnr = ls_bapi_ehau-tplnr.
*
*      me->add_table_data( EXPORTING is_data = ls_iflot
*                                    iv_source_table = 'IFLOT'
*                                    iv_objkey = ls_bapi_ehau-tplnr
*                          CHANGING ct_bapimtcs = bapimtcs ).
*    ENDLOOP.
*  ENDIF.
*
*  " Send customer-specific fields for premise & POD
*  LOOP AT bapi_eui INTO DATA(ls_bapi_eui).
*    IF ls_bapi_eui-vstelle IS NOT INITIAL.
*      SELECT SINGLE *
*        FROM evbs
*        INTO ls_evbs
*        WHERE vstelle = ls_bapi_eui-vstelle.
*
**      me->add_table_data( EXPORTING is_data = ls_evbs
**                                    iv_source_table = 'EVBS'
**                                    iv_objkey = ls_bapi_eui-vstelle
**                          CHANGING ct_bapimtcs = bapimtcs ).
*    ENDIF.
*
*    SELECT SINGLE *
*      INTO ls_euihead
*      FROM euihead
*      WHERE int_ui = ls_bapi_eui-int_ui.
*
*    me->add_table_data( EXPORTING is_data = ls_euihead
*                                  iv_source_table = 'EUIHEAD'
*                                  iv_objkey = ls_bapi_eui-int_ui
*                        CHANGING ct_bapimtcs = bapimtcs ).
*
*  ENDLOOP.
    DATA: ls_bapi_euitrans TYPE bapi_euitrans,
          ls_bapi_eui      TYPE bapi_eui.
*  FIELD-SYMBOLS <fs_BAPI_EUITRANS> TYPE <fsBAPI_EUITRANS.

    READ TABLE bapimtcs ASSIGNING FIELD-SYMBOL(<fs_bapimtcs_euitrans>) WITH KEY tabname = 'BAPI_EUITRANS'.

    IF sy-subrc = 0.
      CALL METHOD cl_abap_container_utilities=>read_container_c
        EXPORTING
          im_container           = <fs_bapimtcs_euitrans>-data
        IMPORTING
          ex_value               = ls_bapi_euitrans
        EXCEPTIONS
          illegal_parameter_type = 1
          OTHERS                 = 2.
      IF sy-subrc = 0.
        ls_bapi_euitrans-begru = 'ZGDP'.

        CALL METHOD cl_abap_container_utilities=>fill_container_c
          EXPORTING
            im_value               = ls_bapi_euitrans
          IMPORTING
            ex_container           = <fs_bapimtcs_euitrans>-data
          EXCEPTIONS
            illegal_parameter_type = 1
            OTHERS                 = 2.
*    <fs_bapimtcs_EUITRANS>-data = ls_bapi_euitrans.
      ENDIF.
    ENDIF.

    READ TABLE bapimtcs ASSIGNING FIELD-SYMBOL(<fs_bapimtcs_eui>) WITH KEY tabname = 'BAPI_EUI'.
    IF sy-subrc = 0.
      CALL METHOD cl_abap_container_utilities=>read_container_c
        EXPORTING
          im_container           = <fs_bapimtcs_eui>-data
        IMPORTING
          ex_value               = ls_bapi_eui
        EXCEPTIONS
          illegal_parameter_type = 1
          OTHERS                 = 2.
      IF sy-subrc = 0.
        ls_bapi_eui-begru = 'ZGDP'.
        CALL METHOD cl_abap_container_utilities=>fill_container_c
          EXPORTING
            im_value               = ls_bapi_euitrans
          IMPORTING
            ex_container           = <fs_bapimtcs_eui>-data
          EXCEPTIONS
            illegal_parameter_type = 1
            OTHERS                 = 2.
      ENDIF.
    ENDIF.
  ENDMETHOD.


method IF_EX_IBSSI_SEND_TO_DWN~FILTER_DATA.
  endmethod.
ENDCLASS.
