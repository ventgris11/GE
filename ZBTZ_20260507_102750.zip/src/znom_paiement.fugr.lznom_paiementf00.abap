*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 22.07.2017 at 13:06:50
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
