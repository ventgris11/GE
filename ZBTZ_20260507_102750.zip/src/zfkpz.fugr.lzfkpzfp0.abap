*&---------------------------------------------------------------------*
*&  Include           LFKPZFP0                                         *
*&---------------------------------------------------------------------*

*---------------------------------------------------------------------*
*       FORM PYBUK_DETERMINE                                           *
*---------------------------------------------------------------------*
*       Determine paying company code                                 *
*---------------------------------------------------------------------*
FORM PYBUK_DETERMINE USING PAR_RC PAR_F4.

* init
  CLEAR: H_PYBUK, PAR_RC.

* determine paying company
  IF IMPORT-PYBUK IS INITIAL.
    IF IMPORT-OPBUK IS INITIAL.
      IF IMPORT-BUKRS IS INITIAL.
* only I_LAND1 is set
        IF  IMPORT-GPART NE SPACE
        AND IMPORT-VKONT NE SPACE.
          CALL FUNCTION 'FKK_PYBUK_DETERMINE'
            EXPORTING
              I_GPART  = IMPORT-GPART
              I_VKONT  = IMPORT-VKONT
            IMPORTING
              E_PYBUK  = H_PYBUK.
        ENDIF.
      ELSE.
        IF IMPORT-GPART IS INITIAL
        OR IMPORT-VKONT IS INITIAL.
* only BUKRS (no PYBUK, no OPBUK) without GPART/VKONT?
* => PYBUK can not be determined.
          IF PAR_F4 = SPACE.
            MESSAGE E308(>4) WITH 'LFKPZFP0' 'PYBUK_DETERMINE'
              'BUKRS WITHOUT GPART/VKONT' SPACE.
            CALL FUNCTION 'FKK_PYBUK_DETERMINE_FOR_BUKRS'
              EXPORTING
                I_BUKRS     = IMPORT-BUKRS
              TABLES
                T_FKKPYBUK  = PYBTAB.
            READ TABLE PYBTAB INDEX 1.
            IF SY-SUBRC = 0.
              H_PYBUK = PYBTAB-PYBUK.
            ENDIF.
          ENDIF.
        ELSE.
          CALL FUNCTION 'FKK_PYBUK_DETERMINE'
            EXPORTING
              I_GPART  = IMPORT-GPART
              I_VKONT  = IMPORT-VKONT
            IMPORTING
              E_PYBUK  = H_PYBUK.
        ENDIF.
      ENDIF.
    ELSE.
      CALL FUNCTION 'FKK_OPBUK_CHECK'
        EXPORTING
          I_OPBUK = IMPORT-OPBUK
        IMPORTING
          E_PYBUK = H_PYBUK.
    ENDIF.
  ELSE.
    H_PYBUK = IMPORT-PYBUK.
  ENDIF.

* read country of paying company code
  IF H_PYBUK IS INITIAL.
    IF IMPORT-LAND1 IS INITIAL.
      PAR_RC = 4.
    ELSE.
      CLEAR T001.
      T001-LAND1 = IMPORT-LAND1.
    ENDIF.
  ELSE.
    PERFORM READ_COMPANY_CODE USING H_PYBUK.
  ENDIF.
ENDFORM.
