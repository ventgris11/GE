*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZINTF_A_FICHIER
*   generation date: 03.04.2019 at 18:10:39
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZINTF_A_FICHIER    .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.
