FUNCTION zintf_g_motif_releve_09.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  FIELD-SYMBOLS:
    <fs_emetteur>,
    <fs_idenreg>,
    <fs_flux>,
    <fs_num_pce>,
    <fs_date_releve>,
    <fs_motif_releve>.

  DATA:
        lv_field TYPE string.

  CLEAR lv_field.
  MOVE 'FLUX-EMETTEUR'     TO lv_field.
  ASSIGN (lv_field)        TO <fs_emetteur>.

  CLEAR lv_field.
  MOVE 'FLUX-IDENREG'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_idenreg>.

  CLEAR lv_field.
  MOVE 'FLUX-FLUX'         TO lv_field.
  ASSIGN (lv_field)        TO <fs_flux>.

  CLEAR lv_field.
  MOVE 'FLUX-NUM_PCE'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_num_pce>.

  CLEAR lv_field.
  MOVE 'FLUX-DATE_RELEVE'  TO lv_field.
  ASSIGN (lv_field)        TO <fs_date_releve>.

  CLEAR lv_field.
  MOVE 'FLUX-MOTIF_RELEVE' TO lv_field.
  ASSIGN (lv_field)        TO <fs_motif_releve>.


  "relève intermédiaire donc motif relève 09
  <fs_motif_releve> = '09'.


ENDFUNCTION.
