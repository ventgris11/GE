* regenerated at 03.04.2019 15:42:03
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDSORES_STAT_DSOTOP.              " Global Data
  INCLUDE LZDSORES_STAT_DSOUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDSORES_STAT_DSOF...              " Subroutines
* INCLUDE LZDSORES_STAT_DSOO...              " PBO-Modules
* INCLUDE LZDSORES_STAT_DSOI...              " PAI-Modules
* INCLUDE LZDSORES_STAT_DSOE...              " Events
* INCLUDE LZDSORES_STAT_DSOP...              " Local class implement.
* INCLUDE LZDSORES_STAT_DSOT99.              " ABAP Unit tests
  INCLUDE LZDSORES_STAT_DSOF00                    . " subprograms
  INCLUDE LZDSORES_STAT_DSOI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
