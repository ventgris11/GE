*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 21.04.2019 at 18:40:33
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZDSO_RESIL_PT_H.................................*
DATA:  BEGIN OF STATUS_ZDSO_RESIL_PT_H               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDSO_RESIL_PT_H               .
CONTROLS: TCTRL_ZDSO_RESIL_PT_H
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDSO_RESIL_PT_H               .
TABLES: ZDSO_RESIL_PT_H                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
