* regenerated at 22.07.2017 13:06:49
FUNCTION-POOL ZNOM_PAIEMENT              MESSAGE-ID SV.

* INCLUDE LZNOM_PAIEMENTD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZNOM_PAIEMENTT00                       . "view rel. data dcl.
