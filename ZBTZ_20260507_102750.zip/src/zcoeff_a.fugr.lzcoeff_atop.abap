* regenerated at 25.03.2019 09:29:54
FUNCTION-POOL ZCOEFF_A                   MESSAGE-ID SV.

* INCLUDE LZCOEFF_AD...                      " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCOEFF_AT00                            . "view rel. data dcl.
