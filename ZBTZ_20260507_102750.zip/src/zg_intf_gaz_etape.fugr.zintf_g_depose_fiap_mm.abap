FUNCTION zintf_g_depose_fiap_mm.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
  TYPES : BEGIN OF ty_etrg,
            abrvorg  TYPE abrvorg,
            adatsoll TYPE adatsoll,
          END OF ty_etrg.
  TYPES : BEGIN OF ty_eabl,
            ablbelnr TYPE ablbelnr,
            adattats TYPE adattats,
            adatsoll TYPE adatsoll,
          END OF ty_eabl.

  DATA: lc_field_num_pce      TYPE fieldname VALUE 'NUM_PCE',
        lc_field_date_releve  TYPE fieldname VALUE 'DATE_RELEVE',
        lc_field_idenreg      TYPE fieldname VALUE 'IDENREG',
        lc_field_motif_releve TYPE fieldname VALUE 'MOTIF_RELEVE',
        lc_field_statut       TYPE fieldname VALUE 'STATUT',
        lc_field_flux         TYPE fieldname VALUE 'FLUX',
        lv_field              TYPE string,
        lv_int_ui             TYPE int_ui,
        lv_anlage             TYPE anlage,
        ls_object             TYPE eedm_isu_objects,
        ls_canc_param         TYPE isu21_canc_param,
        lt_anlage             TYPE isu_t_eanlkey_h,
        lv_instdata           TYPE isu2a_instdata,
        lt_idispdata          TYPE isu_bi_inst_dispdata_tab,
        lv_idispdata          TYPE isu_bi_inst_dispdata,
        lt_ianl_bdoc          TYPE isu_bi_inst_billdoc_disp_tab,
        lv_ianl_bdoc          TYPE isu_bi_inst_billdoc_disp,
        ls_iabl               TYPE isu_bi_inst_eabl_disp,
        lt_insttab            TYPE isu17_meterdocu_insttab,
        ls_insttab            TYPE isu17_meterdocu_inst,
        ls_obj                TYPE isu17_meterread,
        ls_etrg               TYPE ty_etrg,
        lt_etrg               TYPE TABLE OF ty_etrg,
        lt_eabl               TYPE TABLE OF ty_eabl,
        ls_eabl               TYPE ty_eabl,
        ls_eabl_integration   TYPE eabl,
        lt_iabl               TYPE isu_bi_inst_eabl_disp_tab,
        lt_auto               TYPE  isu17_meterread_auto,
        lv_energie_entier     TYPE v_zwstand,
        lv_energie_decimal    TYPE n_zwstand,
        lt_mr_data            TYPE TABLE OF bapieabl,
        ls_mr_data            TYPE bapieabl,
        lt_mr_reason          TYPE TABLE OF bapieablg,
        lv_message            TYPE char255,
        lv_subobj             TYPE balsubobj
        .

  CLEAR : ls_eabl_integration,
          lv_energie_entier,
          lv_energie_decimal.


  DATA:
    lc_field_nb_roue_cpt TYPE fieldname VALUE 'NB_ROUE_COMPTEUR',
    lc_field_num_serie   TYPE fieldname VALUE 'NUM_SERIE_COMPTEUR',
    lc_field_index_fin   TYPE fieldname VALUE 'INDEX_BRUT_FIN_PERIODE',
    lv_date              TYPE adats,
    lt_etdz              TYPE TABLE OF etdz,
    ls_etdz              TYPE etdz,
    lv_stanzvor          TYPE stanzvor,
    ls_auto              TYPE isu42_devmod_auto,
    lv_device            TYPE geraet,
    lv_equnr             TYPE equnr,
    lv_db_update         TYPE e_update,
    ls_dev               TYPE reg42_dev,
    ls_dev_flag          TYPE reg42_dev_input_flag,
    lv_success           TYPE crmt_boolean,
    ls_bpem              TYPE zbpem_flux_struct,
    lv_interface         TYPE zisu_flxid.

  FIELD-SYMBOLS: <fs_motif_releve>, <fs_motif_statut>.

  FIELD-SYMBOLS: <fs_num_pce>, <fs_date_releve>, <fs_nb_roue_compteur>, <fs_num_serie>, <fs_flux>, <fs_idx_fin_periode>,<fs_idenreg>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_idenreg INTO lv_field.
  ASSIGN (lv_field) TO <fs_idenreg>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.
  IF <fs_num_pce> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_releve>.
  IF <fs_date_releve> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_nb_roue_cpt INTO lv_field.
  ASSIGN (lv_field) TO <fs_nb_roue_compteur>.
  IF <fs_nb_roue_compteur> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_serie INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_serie>.
  IF <fs_num_serie> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_flux INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.
  IF <fs_flux> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_index_fin INTO lv_field.
  ASSIGN (lv_field) TO <fs_idx_fin_periode>.
  IF <fs_idx_fin_periode> IS NOT ASSIGNED.
  ENDIF.



* Pour récupération de INT_UI
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).
  IF lv_int_ui IS INITIAL.
  ENDIF.

  lv_date = <fs_date_releve> + 1.

* Pour récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = lv_date
    IMPORTING
      es_detail = ls_object.

  lv_anlage = ls_object-installation.

  CALL METHOD zcl_tool=>install_depose_fiap
    EXPORTING
      iv_install    = ls_object-installation
      iv_date_effet = lv_date
      iv_mode_test  = iv_mode_test
*     iv_matnr      =
*     iv_equnr      =
    RECEIVING
      ev_success    = lv_success.

  IF lv_success IS INITIAL.
    ev_etape = 2.
  ELSE.
    ev_etape = 1.
  ENDIF.

  MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 INTO DATA(lv_msg).
  IF sy-msgid = 'ZINTF_G_MESSAGES' AND sy-msgno = '060'.
    CLEAR ls_bpem.
    ls_bpem-num_pce = <fs_num_pce>.
    CASE <fs_flux>.
      WHEN 'ADIF'.
        ls_bpem-date_effet_cont = <fs_date_releve>.
      WHEN 'RE6M' OR 'REMM' OR 'REJJ' OR 'REJM'.
        ls_bpem-date_releve     = <fs_date_releve>.
      WHEN 'AFAC'.
        ls_bpem-date_fin_prest  = <fs_date_releve>.
    ENDCASE.

    lv_interface    = <fs_flux>.
    IF <fs_idenreg> IS ASSIGNED .
      ls_bpem-idenreg = <fs_idenreg>.
    ENDIF.

    CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
      EXPORTING
        iv_interface_name = lv_interface
        iv_sparte         = 'ZG'
        is_structure      = ls_bpem.
  ENDIF.

  FIELD-SYMBOLS: <fs_remm> TYPE zintf_g_remm.

  ASSIGN flux TO <fs_remm>.

  lv_energie_entier = trunc( <fs_remm>-index_brut_fin_periode ).
  lv_energie_decimal = frac( <fs_remm>-index_brut_fin_periode ).

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_flux INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.
  IF <fs_flux> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.
  IF <fs_num_pce> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_releve>.
  IF <fs_date_releve> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_motif_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_motif_releve>.
  IF <fs_motif_releve> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_statut INTO lv_field.
  ASSIGN (lv_field) TO <fs_motif_statut>.
  IF <fs_motif_statut> IS NOT ASSIGNED.
  ENDIF.

  IF <fs_flux> = 'REMM'.
    lv_subobj = zcl_tool=>gc_log_subobject_re6m.
  ELSE.
    lv_subobj = zcl_tool=>gc_log_subobject_remm.
  ENDIF.

* Pour récupération de INT_UI
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).
  IF lv_int_ui IS INITIAL.
  ENDIF.

* Pour récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.
  IF ls_object-installation IS INITIAL.
  ENDIF.

  lv_anlage = ls_object-installation.

  INSERT lv_anlage INTO TABLE lt_anlage.

** Ouverture de l'objet relève
  CALL FUNCTION 'ISU_O_METERREAD_OPEN'
    EXPORTING
      x_anlage              = lv_anlage
      x_adatsoll            = <fs_date_releve>
      x_action              = '01'
      x_ablesgr             = '02'
      x_wmode               = '3'
      x_no_dialog           = 'X'
      x_upd_online          = 'X'
      x_no_enqueue          = 'X'
      x_ebene               = 'I'
      x_auto                = lt_auto
    IMPORTING
      y_obj                 = ls_obj
    EXCEPTIONS
      not_found             = 1
      foreign_lock          = 2
      internal_error        = 3
      input_error           = 4
      existing              = 5
      number_error          = 6
      general_fault         = 7
      system_error          = 8
      manual_abort          = 9
      gasdat_not_found      = 10
      no_mrrel_registers    = 11
      internal_warning      = 12
      not_authorized        = 13
      not_qualified         = 14
      anpstorno_not_allowed = 15
      already_billed        = 16
      OTHERS                = 17.
  IF NOT sy-subrc IS INITIAL.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
    INTO lv_message
    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    zcl_tool=>log_add_msg( EXPORTING iv_log_object = zcl_tool=>gc_log_object_intf_gaz
                                     iv_log_subobject = lv_subobj
                                     iv_test_mode = iv_mode_test
                           CHANGING  cv_log_handle = cv_log_handle ).
    ev_etape = 2.
    RETURN.
  ENDIF.


  READ TABLE ls_obj-ieabl INTO ls_eabl_integration INDEX 1.
  "ls_eabl_integration-adatsoll         = <fs_remm>-date_releve.
  ls_eabl_integration-adattats         = <fs_remm>-date_releve.
  ls_eabl_integration-zwnummer         = 1.
  ls_eabl_integration-v_zwstand        = lv_energie_entier.
  ls_eabl_integration-n_zwstand        = lv_energie_decimal.
  ls_eabl_integration-v_zwstndab       = lv_energie_entier.
  ls_eabl_integration-n_zwstndab       = lv_energie_decimal.

  ls_eabl_integration-zztype_rel              = <fs_remm>-type_releve.
  ls_eabl_integration-zzraison_rel            = <fs_remm>-raison_releve.
  ls_eabl_integration-zzdate_debut            = <fs_remm>-debut_periode.
  ls_eabl_integration-zzindex_brut_debut      = <fs_remm>-index_brut_debut_periode.
  ls_eabl_integration-zzqual_index_brut_debut = <fs_remm>-qual_index_brut_debut_periode.
  ls_eabl_integration-zzindex_conv_debut      = <fs_remm>-index_conv_debut_periode.
  ls_eabl_integration-zzqual_index_conv_debut = <fs_remm>-qual_index_conv_debut_periode.
  ls_eabl_integration-zzdate_fin              = <fs_remm>-fin_periode.
  ls_eabl_integration-zzqual_index_brut_fin   = <fs_remm>-qual_index_brut_fin_periode.
  ls_eabl_integration-zzindex_conv_fin        = <fs_remm>-index_conv_fin_periode.
  ls_eabl_integration-zzqual_index_conv_fin   = <fs_remm>-qual_index_conv_fin_periode.
  ls_eabl_integration-zzvolume_brut           = <fs_remm>-vol_brut_conso.
  ls_eabl_integration-zzqual_volume_brut      = <fs_remm>-qualif_vol_brut_conso.
  ls_eabl_integration-zzvolume_brut_conv      = <fs_remm>-volume_conv.
  ls_eabl_integration-zzqual_volume_conv      = <fs_remm>-qualif_volume_conv.
  ls_eabl_integration-zzqual_coeff_pcs        = <fs_remm>-qualif_pcs.
  ls_eabl_integration-zzenergie               = <fs_remm>-energie_conso.
  ls_eabl_integration-zzqualif_energie        = <fs_remm>-qualif_energie_conso.
  ls_eabl_integration-zzidenreg               = <fs_remm>-idenreg.

  ls_eabl_integration-istablart               = '01'.
  ls_eabl_integration-ablestyp                = '01'.
  ls_eabl_integration-ablstat                 = '1'.

  MODIFY ls_obj-ieabl  FROM ls_eabl_integration  INDEX 1.



  CALL FUNCTION 'ISU_O_METERREAD_OPEN_SUBOBJ'
    EXPORTING
      x_action   = '01'
      x_auto     = lt_auto
      x_adatsoll = <fs_date_releve>
    CHANGING
      xy_obj     = ls_obj
*       EXCEPTIONS
*     NOT_FOUND  = 1
*     FOREIGN_LOCK               = 2
*     INTERNAL_ERROR             = 3
*     INPUT_ERROR = 4
*     EXISTING   = 5
*     NUMBER_ERROR               = 6
*     GENERAL_FAULT              = 7
*     SYSTEM_ERROR               = 8
*     MANUAL_ABORT               = 9
*     OTHERS     = 10
    .
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  CALL FUNCTION 'ISU_O_METERREAD_INPUT'
    CHANGING
      xy_obj = ls_obj
    EXCEPTIONS
      OTHERS = 99.
  IF NOT sy-subrc IS INITIAL.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
    INTO lv_message
    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    zcl_tool=>log_add_msg( EXPORTING iv_log_object = zcl_tool=>gc_log_object_intf_gaz
                                     iv_log_subobject = lv_subobj
                                     iv_test_mode = iv_mode_test
                           CHANGING  cv_log_handle = cv_log_handle ).
    ev_etape = 2.
    RETURN.
  ENDIF.

* Préparation de la sauvegarde
  CALL FUNCTION 'ISU_O_METERREAD_ACTION'
    EXPORTING
      x_okcode             = 'PSAV'
    CHANGING
      xy_obj               = ls_obj
    EXCEPTIONS
      cancelled            = 1
      failed               = 2
      action_not_supported = 3
      system_error         = 4
      input_error          = 5
      not_customized       = 6
      OTHERS               = 7.
  IF NOT sy-subrc IS INITIAL.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
    INTO lv_message
    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    zcl_tool=>log_add_msg( EXPORTING iv_log_object = zcl_tool=>gc_log_object_intf_gaz
                                     iv_log_subobject = lv_subobj
                                     iv_test_mode = iv_mode_test
                           CHANGING  cv_log_handle = cv_log_handle ).
    ev_etape = 2.
    RETURN.
  ENDIF.
* sauvegarde
  CALL FUNCTION 'ISU_O_METERREAD_ACTION'
    EXPORTING
      x_okcode             = 'SAVE'
    CHANGING
      xy_obj               = ls_obj
    EXCEPTIONS
      cancelled            = 1
      failed               = 2
      action_not_supported = 3
      system_error         = 4
      input_error          = 5
      not_customized       = 6
      OTHERS               = 7.
  IF NOT sy-subrc IS INITIAL.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
    INTO lv_message
    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    zcl_tool=>log_add_msg( EXPORTING iv_log_object = zcl_tool=>gc_log_object_intf_gaz
                                     iv_log_subobject = lv_subobj
                                     iv_test_mode = iv_mode_test
                           CHANGING  cv_log_handle = cv_log_handle ).
    ev_etape = 2.
    RETURN.
  ENDIF.

  CALL FUNCTION 'ISU_O_METERREAD_CLOSE'
    EXPORTING
      x_no_dialog = 'X'
*     X_DEQ_SYNC  = ' '
*     IMPORTING
*     Y_DB_UPDATE =
*     Y_EXIT_TYPE =
*     TABLES
*     YT_NEW_EABL =
*     YT_NEW_EABLG         =
*     YT_NEW_ETRG =
    CHANGING
      xy_obj      = ls_obj
*     EXCEPTIONS
*     NOT_CUSTOMIZED       = 1
*     FAILED      = 2
*     GENERAL_FAULT        = 3
*     OTHERS      = 4
    .
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
    INTO lv_message
    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    zcl_tool=>log_add_msg( EXPORTING iv_log_object = zcl_tool=>gc_log_object_intf_gaz
                                     iv_log_subobject = lv_subobj
                                     iv_test_mode = iv_mode_test
                           CHANGING  cv_log_handle = cv_log_handle ).
    ev_etape = 2.
    RETURN.
  ENDIF.


  "ENDIF.

  ev_etape = 1.
ENDFUNCTION.
