*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDSO_RESIL_PT
*   generation date: 05.04.2019 at 12:51:30
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDSO_RESIL_PT       .

  PERFORM TABLEPROC.

ENDFUNCTION.
