*&---------------------------------------------------------------------*
*&  Include           LE25SF00                                         *
*&---------------------------------------------------------------------*

INCLUDE ieconv_vertrag.

*&---------------------------------------------------------------------*
*&      Form  DETERMINE_ROUNDING_DECIMALS
*&---------------------------------------------------------------------*
FORM determine_rounding_decimals USING i_obj      TYPE isu25_budbilplan
                                       i_ever     TYPE ever
                                       i_eanl     TYPE v_eanl
                                       i_betrag   LIKE eabps-betrw
                                       i_waers    TYPE twaers
                              CHANGING x_decimals LIKE t006-expon.

*... Folgende Strukturen der L_OBJ müssen gefüllt sein:
*    L_OBJ-INTEVER, L_OBJ-EABP-VERTRAG, L_OBJ-EDATUM, L_OBJ-WAERS

  DATA: l_eanl       LIKE v_eanl,
        betrag_in    LIKE eabps-betrw,
        l_ever       LIKE ever,
        aklasse      LIKE l_eanl-aklasse,
        waeanl_cache TYPE isu25_eanl_cache,
        l_te211      LIKE te211.

  FIELD-SYMBOLS: <refeanl> TYPE isu25_eanl_cache.

  IF i_eanl IS INITIAL.
    IF i_ever IS INITIAL.
      READ TABLE i_obj-intever INTO l_ever
                               WITH KEY vertrag = i_obj-eabp-vertrag.
    ELSE.
      l_ever = i_ever.
    ENDIF.

*   für Anlage im Puffer nachlesen
    LOOP AT eanl_cache ASSIGNING <refeanl>
                       WHERE device  EQ l_ever-anlage
                       AND   ab      LE i_obj-edatum
                       AND   bis     GE i_obj-edatum.
      EXIT.
    ENDLOOP.
    IF sy-subrc <> 0.
*     Keinen Eintrag im Cache gefunden, deshalb nachlesen
      CALL FUNCTION 'ISU_DB_EANL_SELECT'
        EXPORTING
          x_anlage     = l_ever-anlage
          x_keydate    = i_obj-edatum
        IMPORTING
          y_v_eanl     = l_eanl
        EXCEPTIONS
          not_found    = 01
          system_error = 02
          invalid_date = 03.
      IF sy-subrc NE 0.
*       Bei Fehler Runden auf Einer
        x_decimals = 0.
        EXIT.
      ENDIF.

*     Anlage im Cache ablegen
      waeanl_cache-device  = l_ever-anlage.
      waeanl_cache-ab      = l_eanl-ab.
      waeanl_cache-bis     = l_eanl-bis.
      waeanl_cache-aklasse = l_eanl-aklasse.
      APPEND waeanl_cache TO eanl_cache.

      aklasse = l_eanl-aklasse.

*     Prüfen, ob Puffer zu gross wird
      ADD 1 TO cache_count.
      IF cache_count GE 500.
*       Die letzten 10 Anlagen zurückbehalten
        DELETE eanl_cache FROM 1 TO 490.
        cache_count = cache_count - 490.
      ENDIF.
    ELSE.
*     Abrechnungsklasse aus Cache verwenden
      aklasse = <refeanl>-aklasse.
    ENDIF.
  ELSE.
*   Abrechnungsklasse aus Übergabeparameter verwenden
    aklasse = i_eanl-aklasse.
  ENDIF.

* Da die Tabelle kein Vorzeichen zulässt, muss der Prüfbetrag
* positiv werden
  betrag_in = ABS( i_betrag ).

*... Rundungstabelle lesen
  SELECT  * FROM  te211 INTO l_te211
                        WHERE aklasse EQ aklasse
                        AND   waers   EQ i_waers
                        AND   von     LE betrag_in
                        AND   bis     GE betrag_in.
    EXIT.
  ENDSELECT.
  IF syst-subrc EQ 0.
*   Dezimalstelle aus Tabelle nehmen
    x_decimals = l_te211-rundwert01.
  ELSE.
*   Wurde kein Eintrag gefunden, so wird auf Einer fest gerundet
    x_decimals = 0.
  ENDIF.

ENDFORM.                               " FGB_DECIMALS_FINDEN
