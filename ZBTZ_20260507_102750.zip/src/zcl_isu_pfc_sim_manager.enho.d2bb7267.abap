"Name: \TY:CL_ISU_PFC_SIM_MANAGER\ME:INITIALIZE_SIMSCEN\SE:END\EI
ENHANCEMENT 0 ZCL_ISU_PFC_SIM_MANAGER.
** Il faut gérer le contrat de concession via cet enhancement. A supprimer dès que SAP aura corrigé
  DATa: lv_konzver TYPE konzver,
        lv_tarifart TYPE TARIFART.

  me->configuration->GET_ELEMENT_VALUE( EXPORTING im_element = 'ZE_B2C_CONTRAT_CONCESSION' IMPORTING ex_value = lv_konzver ).
  IF lv_konzver IS NOT INITIAL.
    " On positionne la valeur dans KONZVER
    LOOP AT me->md->CONTR_SIM->inst->ieanl ASSIGNING FIELD-SYMBOL(<lr_eanl>).
      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
        EXPORTING
          input         = lv_konzver
       IMPORTING
         OUTPUT        = lv_konzver.

      <lr_eanl>-konzver = lv_konzver.
    ENDLOOP.
  ENDIF.
  " Pour le gaz, la configuration de l'appareil impacte le calcul, il faut donc modifier si fourni
  me->configuration->GET_ELEMENT_VALUE( EXPORTING im_element = 'ZG_ALL_PROFIL_TYPE_TARIF' IMPORTING ex_value = lv_tarifart ).
  IF lv_tarifart IS NOT INITIAL.
    " S'il s'agit d'un tarifart d'un JJ, il faut le substituer en non JJ car l'appareil n'est pas JJ !!!
    IF strlen( lv_tarifart ) >= 6 AND lv_tarifart(6) = 'GCCONJ'.
      lv_tarifart(6) = 'GCCONS'.
    ENDIF.

    LOOP AT me->md->CONTR_SIM->inst->ieasts ASSIGNING FIELD-SYMBOL(<lr_easts>).
      <lr_easts>-TARIFART = lv_tarifart.
    ENDLOOP.

  ENDIF.

ENDENHANCEMENT.
