FUNCTION ZISU_INV_BBP_MWSKZ.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(X_SFKKOP) TYPE  SFKKOP
*"  EXPORTING
*"     REFERENCE(Y_FWERA) TYPE  FWERA_KK
*"----------------------------------------------------------------------

  STATICS: ls_t001  TYPE t001,
           ls_t005  TYPE t005,
           lt_t007a TYPE TABLE OF t007a,
           ld_bukrs TYPE bukrs,
           ld_land1 TYPE land1.
  DATA:    ls_t007a TYPE t007a.

  CLEAR y_fwera.

y_fwera = x_sfkkop-mwskz.

*  IF x_sfkkop-bukrs NE ls_t001-bukrs.
*    CLEAR ls_t001.
*    SELECT SINGLE * FROM t001 INTO ls_t001
*           WHERE bukrs = x_sfkkop-bukrs.
*    CHECK sy-subrc EQ 0.
*  ENDIF.
*
*  IF ls_t001-land1 NE ls_t005-land1.
*    CLEAR ls_t005.
*    SELECT SINGLE * FROM t005 INTO ls_t005
*           WHERE land1 = ls_t001-land1.
*    CHECK sy-subrc EQ 0.
*
*    REFRESH lt_t007a.
*    SELECT * FROM t007a INTO TABLE lt_t007a
*           WHERE kalsm = ls_t005-kalsm.
*  ENDIF.
*
*  READ TABLE lt_t007a INTO ls_t007a
*       WITH KEY kalsm = ls_t005-kalsm
*                mwskz = x_sfkkop-mwskz
*       TRANSPORTING mwart.
*  CHECK sy-subrc EQ 0.
*
*  IF ls_t007a-mwart EQ 'V'.
*    y_fwera = 'Input tax'.
*  ELSE.
*    y_fwera = 'Output tax'.
*  ENDIF.

ENDFUNCTION.
