*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 29.11.2021 at 15:56:23
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZANNUL_REL_FACT.................................*
DATA:  BEGIN OF STATUS_ZANNUL_REL_FACT               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZANNUL_REL_FACT               .
CONTROLS: TCTRL_ZANNUL_REL_FACT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZANNUL_REL_FACT               .
TABLES: ZANNUL_REL_FACT                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
