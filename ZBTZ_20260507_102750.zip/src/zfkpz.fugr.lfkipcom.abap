*&---------------------------------------------------------------------*
*&  Include           LFKIPCOM
*&---------------------------------------------------------------------*
*ATA: GC_PYGRP_IP(1)    TYPE C         VALUE '>'.

DATA: GC_PDTYP_RES      TYPE PDTYP_KK  VALUE '1',
      GC_PDTYP_FPY1     TYPE PDTYP_KK  VALUE '2',
      GC_PDTYP_FP05     TYPE PDTYP_KK  VALUE '3',
      GC_PDTYP_BD       TYPE PDTYP_KK  VALUE '4',
      GC_PDTYP_FCC      TYPE PDTYP_KK  VALUE '5'.
