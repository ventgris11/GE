*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 15.08.2017 at 21:09:58
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZB2C_CRM_SIMU...................................*
DATA:  BEGIN OF STATUS_ZB2C_CRM_SIMU                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZB2C_CRM_SIMU                 .
CONTROLS: TCTRL_ZB2C_CRM_SIMU
            TYPE TABLEVIEW USING SCREEN '0001'.
*...processing: ZCRM_SIMU_CLEPRI................................*
DATA:  BEGIN OF STATUS_ZCRM_SIMU_CLEPRI              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCRM_SIMU_CLEPRI              .
CONTROLS: TCTRL_ZCRM_SIMU_CLEPRI
            TYPE TABLEVIEW USING SCREEN '0003'.
*...processing: ZCRM_SWTDOC_MAPP................................*
DATA:  BEGIN OF STATUS_ZCRM_SWTDOC_MAPP              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCRM_SWTDOC_MAPP              .
CONTROLS: TCTRL_ZCRM_SWTDOC_MAPP
            TYPE TABLEVIEW USING SCREEN '0002'.
*.........table declarations:.................................*
TABLES: *ZB2C_CRM_SIMU                 .
TABLES: *ZCRM_SIMU_CLEPRI              .
TABLES: *ZCRM_SWTDOC_MAPP              .
TABLES: ZB2C_CRM_SIMU                  .
TABLES: ZCRM_SIMU_CLEPRI               .
TABLES: ZCRM_SWTDOC_MAPP               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
