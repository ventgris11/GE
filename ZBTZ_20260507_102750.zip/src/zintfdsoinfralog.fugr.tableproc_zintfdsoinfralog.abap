*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZINTFDSOINFRALOG
*   generation date: 13.06.2019 at 19:00:32
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZINTFDSOINFRALOG    .

  PERFORM TABLEPROC.

ENDFUNCTION.
