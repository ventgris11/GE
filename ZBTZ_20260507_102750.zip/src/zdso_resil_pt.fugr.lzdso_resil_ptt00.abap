*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 05.04.2019 at 12:51:30
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZDSO_RESIL_PT...................................*
DATA:  BEGIN OF STATUS_ZDSO_RESIL_PT                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDSO_RESIL_PT                 .
CONTROLS: TCTRL_ZDSO_RESIL_PT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDSO_RESIL_PT                 .
TABLES: ZDSO_RESIL_PT                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
