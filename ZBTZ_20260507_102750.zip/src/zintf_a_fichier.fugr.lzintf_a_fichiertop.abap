* regenerated at 03.04.2019 18:10:39
FUNCTION-POOL ZINTF_A_FICHIER            MESSAGE-ID SV.

* INCLUDE LZINTF_A_FICHIERD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZINTF_A_FICHIERT00                     . "view rel. data dcl.
