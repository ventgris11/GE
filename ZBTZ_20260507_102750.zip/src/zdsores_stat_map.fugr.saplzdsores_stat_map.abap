* regenerated at 03.04.2019 15:45:50
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDSORES_STAT_MAPTOP.              " Global Data
  INCLUDE LZDSORES_STAT_MAPUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDSORES_STAT_MAPF...              " Subroutines
* INCLUDE LZDSORES_STAT_MAPO...              " PBO-Modules
* INCLUDE LZDSORES_STAT_MAPI...              " PAI-Modules
* INCLUDE LZDSORES_STAT_MAPE...              " Events
* INCLUDE LZDSORES_STAT_MAPP...              " Local class implement.
* INCLUDE LZDSORES_STAT_MAPT99.              " ABAP Unit tests
  INCLUDE LZDSORES_STAT_MAPF00                    . " subprograms
  INCLUDE LZDSORES_STAT_MAPI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
