* regenerated at 21.04.2019 18:40:33
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDSO_RESIL_PT_HTOP.               " Global Data
  INCLUDE LZDSO_RESIL_PT_HUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDSO_RESIL_PT_HF...               " Subroutines
* INCLUDE LZDSO_RESIL_PT_HO...               " PBO-Modules
* INCLUDE LZDSO_RESIL_PT_HI...               " PAI-Modules
* INCLUDE LZDSO_RESIL_PT_HE...               " Events
* INCLUDE LZDSO_RESIL_PT_HP...               " Local class implement.
* INCLUDE LZDSO_RESIL_PT_HT99.               " ABAP Unit tests
  INCLUDE LZDSO_RESIL_PT_HF00                     . " subprograms
  INCLUDE LZDSO_RESIL_PT_HI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
