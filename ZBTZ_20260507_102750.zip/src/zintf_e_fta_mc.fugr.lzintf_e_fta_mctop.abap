* regenerated at 05.07.2024 10:17:08
FUNCTION-POOL ZINTF_E_FTA_MC             MESSAGE-ID SV.

* INCLUDE LZINTF_E_FTA_MCD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZINTF_E_FTA_MCT00                      . "view rel. data dcl.
