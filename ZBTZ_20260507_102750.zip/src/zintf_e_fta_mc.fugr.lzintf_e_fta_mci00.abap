*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 05.07.2024 at 10:17:08
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules
