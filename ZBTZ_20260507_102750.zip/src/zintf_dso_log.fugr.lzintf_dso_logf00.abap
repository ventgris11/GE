*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 11.06.2019 at 17:56:48
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
