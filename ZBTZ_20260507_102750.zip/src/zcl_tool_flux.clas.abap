class ZCL_TOOL_FLUX definition
  public
  final
  create public .

public section.

  class-data GT_TRANSCO_RLV type ZINTF_TRNSCO_RLV_T .
  class-data GC_SPARTE_GAZ type SPARTE value 'ZG' ##NO_TEXT.
  class-data GC_SPARTE_ELEC type SPARTE value 'ZE' ##NO_TEXT.

  class-methods GET_MR_NATURE_FROM_FLUX
    importing
      !IV_EXT_UI type EXT_UI
      !IV_DATE type DATS
    exporting
      !EV_MR_NATURE type STRING .
  class-methods RXX_FIND_MOTIF
    importing
      !IV_MOTIF type ZMOTIF_RELEVE_N
    exporting
      !ES_TRANSCO_RLV type ZINTF_TRNSCO_RLV
      !EV_FOUND type CRMT_BOOLEAN .
protected section.
private section.
ENDCLASS.



CLASS ZCL_TOOL_FLUX IMPLEMENTATION.


METHOD get_mr_nature_from_flux.
** Cette méthode permet de récupérer la nature d'une relève en fonction des informations dans les
** tables de flux distributeur
  DATA: lv_sparte TYPE sparte.

  CLEAR ev_mr_nature.

  " Récupération du secteur d'activité du POD
  CALL FUNCTION 'ISU_INT_UI_DETERMINE'
    EXPORTING
      x_ext_pod         = iv_ext_ui
    IMPORTING
      y_sparte          = lv_sparte
    EXCEPTIONS
      not_found         = 1
      programming_error = 2
      system_error      = 3
      OTHERS            = 4.

  CHECK sy-subrc = 0. " Si pas de sparte, pas besoin d'aller plus loin

  CASE lv_sparte.
    WHEN zcl_tool_flux=>gc_sparte_gaz.
      " A faire plus tard

    WHEN zcl_tool_flux=>gc_sparte_elec.
      " DISCO : On recherche dans les flux C01
      SELECT SINGLE idenreg, id_prm FROM zintf_e_c01
        INTO (@DATA(lv_record), @DATA(lv_prm))
        WHERE id_prm           = @iv_ext_ui
          AND even_declencheur = 'S'
          AND date_index       = @iv_date.

      IF sy-subrc IS INITIAL.
        SELECT SINGLE nature_index FROM zintf_e_c01_3
          INTO @DATA(lv_nature_index)
          WHERE idenreg = @lv_record.
        CASE lv_nature_index .
          WHEN 'A' OR 'R'. ev_mr_nature = 'REEL' .
          WHEN 'I' OR 'C' .ev_mr_nature = 'ESTIME' .
        ENDCASE.
        EXIT.
      ENDIF.

      " GINKO : Sinon, on recherche dans les flux C15
      SELECT SINGLE idenreg, id_prm FROM zintf_e_c15
        INTO (@lv_record, @lv_prm)
        WHERE id_prm          = @iv_ext_ui
          AND nature_evenement = 'MES'
          AND date_evenement  = @iv_date.
      IF sy-subrc IS INITIAL.
        SELECT SINGLE nature_index FROM zintf_e_c15_2
          INTO @DATA(lv_nat_index)
          WHERE idenreg = @lv_record .
        CASE lv_nat_index .
          WHEN 'REEL' OR 'AUTO-RELEVE'. ev_mr_nature = 'REEL' .
          WHEN 'ESTIME' .               ev_mr_nature = 'ESTIME' .
        ENDCASE.
        EXIT.
      ENDIF.

      " COSY : Sinon, on recherche dans les flux C12 / R17
      SELECT SINGLE idenreg, id_prm FROM zintf_e_c12
        INTO (@lv_record, @lv_prm)
        WHERE id_prm          = @iv_ext_ui
          AND ( nature_evenement LIKE 'CFN%' OR
                nature_evenement EQ 'PMES' OR
                nature_evenement EQ 'MES' OR
                nature_evenement EQ 'CCF' )
          AND date_evenement  = @iv_date.
      IF sy-subrc IS INITIAL.
        SELECT SINGLE nature_index FROM zintf_e_r17
          INTO @DATA(lv_nat_index_17)
          WHERE id_prm = @lv_prm
            AND date_deb_conso = @iv_date
            AND date_fin_conso = @iv_date.

        ev_mr_nature = lv_nat_index_17 .
        EXIT.
      ENDIF.
  ENDCASE.

ENDMETHOD.


METHOD rxx_find_motif.
  DATA: lv_regexp TYPE string.

  CLEAR: ES_TRANSCO_RLV, ev_found.

  " Chargement de l'intégralité de la table si besoin
  IF gt_transco_rlv IS INITIAL.
    SELECT *
      FROM zintf_trnsco_rlv
      INTO TABLE gt_transco_rlv.
  ENDIF.

  " Afin de rechercher par expression régulière, il faut parcourir toutes les valeurs
  LOOP AT gt_transco_rlv INTO DATA(ls_transco_rlv).
    " Il faut remplacer les * par .* pour que le regexp fonctionne
    lv_regexp = ls_transco_rlv-motif_releve_new.
    REPLACE ALL OCCURRENCES OF '*' IN lv_regexp WITH '.*'.

    IF cl_abap_matcher=>contains( text = iv_motif  pattern = lv_regexp ).
      " Found it !!!!!!
      es_transco_rlv = ls_transco_rlv.
      ev_found = abap_true.
      EXIT.
    ENDIF.
  ENDLOOP.
ENDMETHOD.
ENDCLASS.
