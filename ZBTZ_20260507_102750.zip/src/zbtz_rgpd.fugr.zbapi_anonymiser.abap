FUNCTION zbapi_anonymiser.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  TABLES
*"      ET_PARTNER TYPE  BUPA_PARTNER_TYPE_T
*"----------------------------------------------------------------------

  IF et_partner[] IS NOT INITIAL.

    SELECT *
      FROM zisu_rgpd_suivi
      INTO TABLE @DATA(lt_suivi)
      FOR ALL ENTRIES IN @et_partner
      WHERE partner = @et_partner-partner AND
            statut = '06'.

    LOOP AT lt_suivi ASSIGNING FIELD-SYMBOL(<fs_suivi>).
      <fs_suivi>-statut = '03'.
      <fs_suivi>-aedat  = sy-datum.
      <fs_suivi>-aename = sy-uname.
    ENDLOOP.

    MODIFY zisu_rgpd_suivi FROM TABLE lt_suivi.
    COMMIT WORK AND WAIT.

  ENDIF.

ENDFUNCTION.
