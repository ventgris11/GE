*----------------------------------------------------------------------*
*   INCLUDE LFKPZFE0                                                   *
*----------------------------------------------------------------------*
*---------------------------------------------------------------------*
*      Form  EXIT_0650                                                *
*---------------------------------------------------------------------*
FORM EXIT_0650.
  CLEAR: H_0650_ACTIVE.
  PERFORM EXIT_FUNC_MODULE USING '0650'.
  CHECK T_TFKFBC-FUNCC NE 'FKK_SAMPLE_0650'.     "performance: do
  H_0650_ACTIVE = 'X'.
  PERFORM EXIT_0650_PUT.                         "not call empty sample
  PERFORM EXIT_0650_CALL.
  PERFORM EXIT_0650_GET.
ENDFORM.

*---------------------------------------------------------------------*
*      Form  EXIT_0650_CALL                                           *
*---------------------------------------------------------------------*
FORM EXIT_0650_CALL.
  CALL FUNCTION T_TFKFBC-FUNCC
       EXPORTING
            I_RESULT        = *FKKPY_0650_RESULT
            I_PAYMENT_DATA  = FKKPY_0650_PAYMENT_DATA
     IMPORTING
            E_RESULT        = FKKPY_0650_RESULT
       TABLES
            T_HOUSE_BANKS   = T_HBANK_0650
            T_PARTNER_BANKS = T_PBANK_0650
            T_ITEMS         = T_ITEMS_0650.
* cross ref
  IF 1 = 2.
    SET EXTENDED CHECK OFF.
    CALL FUNCTION 'FKK_SAMPLE_0650'.
    SET EXTENDED CHECK ON.
  ENDIF.
ENDFORM.

*---------------------------------------------------------------------*
*      Form  EXIT_0650_GET                                            *
*---------------------------------------------------------------------*
FORM EXIT_0650_GET.
  CHECK *FKKPY_0650_RESULT-STANDARD  NE FKKPY_0650_RESULT-NEWCHOICE
    AND NOT FKKPY_0650_RESULT-NEWCHOICE IS INITIAL.
  READ TABLE T_HBANK INDEX FKKPY_0650_RESULT-NEWCHOICE.
  IF SY-SUBRC NE 0.
    READ TABLE T_HBANK INDEX *FKKPY_0650_RESULT-STANDARD.
  ENDIF.
ENDFORM.

*---------------------------------------------------------------------*
*      Form  EXIT_0650_PUT                                            *
*---------------------------------------------------------------------*
FORM EXIT_0650_PUT.
  DATA LS_PBANK_0650 TYPE FKKPY_0650_PARTNER_BANK.
  CLEAR: T_PBANK_0650[], T_PBANK_0650.
  CLEAR: *FKKPY_0650_RESULT, FKKPY_0650_PAYMENT_DATA.
  *FKKPY_0650_RESULT-STANDARD = H_NUM04.
  MOVE-CORRESPONDING BUS000_EXT TO FKKPY_0650_PAYMENT_DATA.
  FKKPY_0650_PAYMENT_DATA-OPBUK = IMPORT-OPBUK.
  FKKPY_0650_PAYMENT_DATA-WAERS = IMPORT-WAERS.
  FKKPY_0650_PAYMENT_DATA-RWBTR = IMPORT-RWBTR.
  FKKPY_0650_PAYMENT_DATA-RBETR = IMPORT-RBETR.
  FKKPY_0650_PAYMENT_DATA-ZLSCH = FKK042Z-ZLSCH.
  FKKPY_0650_PAYMENT_DATA-BUDAT = IMPORT-BUDAT.
  T_HBANK_0650[] = T_HBANK[].
*>>> Note 1901265
*  T_PBANK_0650[] = T_PBANK[].      "#EC ENHOK
  LOOP AT T_PBANK.
    MOVE-CORRESPONDING T_PBANK TO: LS_PBANK_0650, LS_PBANK_0650-BUS0BK.
    APPEND LS_PBANK_0650 TO T_PBANK_0650.
  ENDLOOP.
*<<< Note 1901265
  T_ITEMS_0650[] = T_0650IT[].
ENDFORM.

*---------------------------------------------------------------------*
*      Form  EXIT_0654                                                *
*---------------------------------------------------------------------*
FORM EXIT_0654 USING P_REJECT.
DATA:    L_BUT0BK       TYPE BUS0BK.
DATA:    LT_MESSAGES    LIKE MESSA_KK   OCCURS 0 WITH HEADER LINE.
DATA:    LT_0650IT      LIKE FKKPY_0650 OCCURS 0 WITH HEADER LINE.
STATICS: T_FUNCC_0654   LIKE TFKFBC     OCCURS 0 WITH HEADER LINE.
STATICS: H_0654_CHECKED TYPE CHAR1.

* determine function modules for event 0654 if not yet done
  IF H_0654_CHECKED IS INITIAL.
    PERFORM EXIT_FUNC_MODULE USING '0654'.
    T_FUNCC_0654[] = T_TFKFBC[].
    H_0654_CHECKED = 'X'.
  ENDIF.

* something to do?
  CHECK LINES( T_FUNCC_0654 ) > 0.

* every registered event may reject, call them all
  LOOP AT T_FUNCC_0654.
    MOVE-CORRESPONDING T_PBANK TO L_BUT0BK.
    LT_0650IT[] = T_0650IT[].
    CLEAR: LT_MESSAGES, LT_MESSAGES[], P_REJECT.
    CALL FUNCTION T_FUNCC_0654-FUNCC
      EXPORTING
        I_SRT1      = IMPORT-SRT1
        I_FKK042Z   = FKK042Z
        I_FKK042E   = TFK042E
        I_HB_T012   = T_HBANK-T012
        I_HB_T012K  = T_HBANK-T012K
        I_HB_BNKA   = T_HBANK-BNKA
        I_PB_BUT0BK = L_BUT0BK
        I_PB_BNKA   = T_PBANK-BNKA
      IMPORTING
        E_REJECT    = P_REJECT
      TABLES
        T_ITEMS     = LT_0650IT[]
        T_MESSAGES  = LT_MESSAGES.
    IF P_REJECT NE SPACE.
      LOOP AT LT_MESSAGES.
        MSGID = LT_MESSAGES-MSGID.
        MSGV1 = LT_MESSAGES-MSGV1.
        MSGV2 = LT_MESSAGES-MSGV2.
        MSGV3 = LT_MESSAGES-MSGV3.
        MSGV4 = LT_MESSAGES-MSGV4.
        PERFORM MESSAGE USING LT_MESSAGES-MSGNO.
      ENDLOOP.
      EXIT.
    ENDIF.
  ENDLOOP.

* cross ref
  SET EXTENDED CHECK OFF.
  IF 1 = 2.
    CALL FUNCTION 'FKK_SAMPLE_0654'.
  ENDIF.
  SET EXTENDED CHECK ON.
ENDFORM.

*---------------------------------------------------------------------*
*      Form  EXIT_FUNC_MODULE                                         *
*---------------------------------------------------------------------*
FORM EXIT_FUNC_MODULE USING P_FBEVE TYPE FBEVE_KK.

* determin function module to be called
  CALL FUNCTION 'FKK_FUNC_MODULE_DETERMINE'
       EXPORTING
            I_FBEVE  = P_FBEVE
            I_APPLK  = IMPORT-APPLK
       TABLES
            T_FBSTAB = T_TFKFBC.
  READ TABLE T_TFKFBC INDEX 1.
ENDFORM.
