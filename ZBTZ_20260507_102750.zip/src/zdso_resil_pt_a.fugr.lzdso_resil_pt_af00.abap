*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 14.04.2019 at 12:20:32
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
