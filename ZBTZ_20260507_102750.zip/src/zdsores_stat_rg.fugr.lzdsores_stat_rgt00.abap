*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 07.04.2019 at 13:04:36
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZDSORES_STAT_RG.................................*
DATA:  BEGIN OF STATUS_ZDSORES_STAT_RG               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDSORES_STAT_RG               .
CONTROLS: TCTRL_ZDSORES_STAT_RG
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDSORES_STAT_RG               .
TABLES: ZDSORES_STAT_RG                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
