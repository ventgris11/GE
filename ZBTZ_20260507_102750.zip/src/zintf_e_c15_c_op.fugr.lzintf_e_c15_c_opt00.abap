*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 12.09.2019 at 11:03:16
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZINTF_E_C15_C_OP................................*
DATA:  BEGIN OF STATUS_ZINTF_E_C15_C_OP              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_C15_C_OP              .
CONTROLS: TCTRL_ZINTF_E_C15_C_OP
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZINTF_E_C15_C_OP              .
TABLES: ZINTF_E_C15_C_OP               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
