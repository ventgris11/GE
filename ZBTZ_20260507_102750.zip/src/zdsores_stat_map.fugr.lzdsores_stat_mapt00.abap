*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 03.04.2019 at 15:45:50
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZDSORES_STAT_MAP................................*
DATA:  BEGIN OF STATUS_ZDSORES_STAT_MAP              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDSORES_STAT_MAP              .
CONTROLS: TCTRL_ZDSORES_STAT_MAP
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDSORES_STAT_MAP              .
TABLES: ZDSORES_STAT_MAP               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
