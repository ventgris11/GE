*----------------------------------------------------------------------*
***INCLUDE LFKMBF04 .
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  GET_FIRST_DL_FOR_ADDITIONAL_RE
*&---------------------------------------------------------------------*
*       Determine the first dunning level for an
*       item which has been booked by a dunning run as the
*       dunning level in which it has been booked
*       The dunning date is also taken from the respective
*       dunning header
*----------------------------------------------------------------------*
*      --> IT_FKKMAKO  Table of dunning headers for the business partner
*      <--P_MAHNS  resulting dunning level
*      <--P_MSTYP  resulting dunning level type
*      <--P_MAHND  resulting dunning date
*----------------------------------------------------------------------*
FORM get_first_dl_for_additional_re TABLES
                                       it_fkkmako STRUCTURE fkkmako
                                    USING    p_opbel TYPE fkkmavs-opbel
                                             p_mahnv TYPE mahnv_kk
                                    CHANGING p_mahns TYPE mahns_kk
                                             p_mstyp TYPE mstyp_kk
                                             p_mahnd TYPE ausdt_kk.

  CHECK NOT p_opbel IS INITIAL.
* Initialize the output varialbes
  CLEAR: p_mahns, p_mstyp, p_mahnd.

  PERFORM read_tfk047a USING p_mahnv.

* First look if we have the right dunning header at hand:
* Document as the first charge document?
  IF tfk047a-xdlod = 'X'.
    READ TABLE it_fkkmako WITH KEY mg1bl = p_opbel
                                   mahnv = p_mahnv.
  ELSE.
    READ TABLE it_fkkmako WITH KEY mg1bl = p_opbel.
  ENDIF.
  IF sy-subrc = 0.
    p_mahns = it_fkkmako-mahns.
    p_mstyp = it_fkkmako-mstyp.
    p_mahnd = it_fkkmako-ausdt.
  ELSE.
*   Document as the interest document?
    IF tfk047a-xdlod = 'X'.
      READ TABLE it_fkkmako WITH KEY mibel = p_opbel
                                     mahnv = p_mahnv.
    ELSE.
      READ TABLE it_fkkmako WITH KEY mibel = p_opbel.
    ENDIF.
    IF sy-subrc = 0.
      p_mahns = it_fkkmako-mahns.
      p_mstyp = it_fkkmako-mstyp.
      p_mahnd = it_fkkmako-ausdt.
    ELSE.
*     Document as the second charge document?
      IF tfk047a-xdlod = 'X'.
        READ TABLE it_fkkmako WITH KEY mg2bl = p_opbel
                                       mahnv = p_mahnv.
      ELSE.
        READ TABLE it_fkkmako WITH KEY mg2bl = p_opbel.
      ENDIF.
      IF sy-subrc = 0.
        p_mahns = it_fkkmako-mahns.
        p_mstyp = it_fkkmako-mstyp.
        p_mahnd = it_fkkmako-ausdt.
      ELSE.
*       Document as the third charge document?
        IF tfk047a-xdlod = 'X'.
          READ TABLE it_fkkmako WITH KEY mg3bl = p_opbel
                                         mahnv = p_mahnv.
        ELSE.
          READ TABLE it_fkkmako WITH KEY mg3bl = p_opbel.
        ENDIF.
        IF sy-subrc = 0.
          p_mahns = it_fkkmako-mahns.
          p_mstyp = it_fkkmako-mstyp.
          p_mahnd = it_fkkmako-ausdt.
        ELSE.
* Second try: look into the data base
          IF 0 = 1.   " SHOULD NOT BE NECESSARY!!!
*                     " because full history was given
            SET EXTENDED CHECK OFF.
            CALL FUNCTION 'FKK_DUNNING_LEVEL_FROM_MAKO'.
            SET EXTENDED CHECK ON.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.

ENDFORM.                    " GET_FIRST_DL_FOR_ADDITIONAL_RE

*&---------------------------------------------------------------------*
*&      Form  set_add_receivable_fields
*&---------------------------------------------------------------------*
*       There are some indicatiors which are special for
*       additional receivalbes. These indicators are contained
*       in structure FKKMAVS
*----------------------------------------------------------------------*
*      -->I_OPBUK  Company code group
*      -->I_HVORG  Main transaction
*      -->I_TVORG  Subtransaction
*      <--e_CDUNN  text
*      <--e_PDUNN  text
*      <--e_SETDL  text
*----------------------------------------------------------------------*
FORM set_add_receivable_fields USING    i_opbuk TYPE opbuk_kk
                                        i_hvorg TYPE hvorg_kk
                                        i_tvorg TYPE tvorg_kk
                               CHANGING e_cdunn like tfk058a-cdunn
                                        e_pdunn like tfk058a-pdunn
                                        e_setdl like tfk058a-setdl.

  CALL FUNCTION 'FKK_GET_ADD_REC_PROPERTIES'
       EXPORTING
            i_applk                  = gl_para_0300-applk
            i_opbuk                  = i_opbuk
            i_hvorg                  = i_hvorg
            i_tvorg                  = i_tvorg
       IMPORTING
            e_cdunn                  = e_cdunn
            e_pdunn                  = e_pdunn
            e_setdl                  = e_setdl
       EXCEPTIONS
            transaction_not_found    = 1
            add_rec_rule_not_defined = 2
            OTHERS                   = 3.
  IF sy-subrc <> 0.
    PERFORM message_append USING sy-msgid sy-msgty sy-msgno
            sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 '2'.
*   In case of error set default values for normal items
*   (non-additional receivables)
    e_cdunn = 'X'.
    e_pdunn = 'X'.
    e_setdl = ' '.
  ENDIF.

ENDFORM.                    " set_add_receivable_fields

*&---------------------------------------------------------------------*
*&      Form  SEARCH_MAIN_RECEIVABLE
*&---------------------------------------------------------------------*
*       Schaue nach, ob in der Mahngruppe i_fkkmavs
*       mindestens eine mahnauslösende Forderung ist.
*----------------------------------------------------------------------*
*  -->  i_fkkmavs     Mahngruppe
*  <--  p_found       Rueckgabewert
*----------------------------------------------------------------------*
FORM search_main_receivable TABLES i_fkkmavs STRUCTURE fkkmavs
                            CHANGING p_found TYPE xfeld. " p_subrc.
***  DATA: local_rladdr LIKE tfktvo-rladdr.
***  DATA: local_cdunn LIKE tfk058a-cdunn.
***  DATA: local_opbuk LIKE fkkmavs-opbuk.

  CLEAR p_found.

* Look at all non-informative items:
  LOOP AT i_fkkmavs WHERE xinfo IS initial.
*   Only payable items are relevant:
    CHECK i_fkkmavs-betrw > 0.
*   Ignore locked items:
    CHECK i_fkkmavs-mansp IS INITIAL.
*   Only due items are relevant. Due items have got a dunning level
*   greater than zero in event 0304.
    CHECK i_fkkmavs-mahnn <> '00'.

*   We have the incicator needed in the
    IF i_fkkmavs-cdunn = 'X'.
      p_found = 'X'.
      EXIT.               " Exit from LOOP AT i_fkkmavs
    ENDIF.

  ENDLOOP.

ENDFORM.                               " SEARCH_MAIN_RECEIVABLE
*&---------------------------------------------------------------------*
*&      Form  GET_STEP_AND_GROUP_FOR_ADD_REC
*&---------------------------------------------------------------------*
*       Determine the last collection step for an
*       item which has been booked by a dunning run as the
*       dunning charge or dunning interest
*       The dunning date is also taken from the respective
*       dunning header - Note 2042997
*----------------------------------------------------------------------*
FORM GET_STEP_AND_GROUP_FOR_ADD_REC  TABLES   it_fkkmako STRUCTURE fkkmako
                                     USING    u_opbel TYPE fkkmavs-opbel
                                     CHANGING c_grpfield_last TYPE fkkmavs-grpfield_last
                                              c_itemgrp_last TYPE fkkmavs-itemgrp_last
                                              c_strat_last TYPE fkkmavs-strat_last
                                              c_step_last TYPE fkkmavs-step_last
                                              c_mahnd TYPE ausdt_kk.
  CHECK NOT u_opbel IS INITIAL.                                         ">>Note 2042997
* Initialize the output varialbes
  CLEAR: c_grpfield_last, c_itemgrp_last, c_step_last, c_mahnd.

* First look if we have the right dunning header at hand:
* Document as the first charge document?
  READ TABLE it_fkkmako WITH KEY mg1bl = u_opbel.
  IF sy-subrc = 0.
    c_grpfield_last = it_fkkmako-grpfield.
    c_itemgrp_last  = it_fkkmako-itemgrp.
    c_strat_last    = it_fkkmako-strat.
    c_step_last     = it_fkkmako-step.
    c_mahnd         = it_fkkmako-ausdt.
  ELSE.
*   Document as the interest document?
    READ TABLE it_fkkmako WITH KEY mibel = u_opbel.
    IF sy-subrc = 0.
      c_grpfield_last = it_fkkmako-grpfield.
      c_itemgrp_last  = it_fkkmako-itemgrp.
      c_strat_last    = it_fkkmako-strat.
      c_step_last     = it_fkkmako-step.
      c_mahnd         = it_fkkmako-ausdt.
    ELSE.
*     Document as the second charge document?
      READ TABLE it_fkkmako WITH KEY mg2bl = u_opbel.
      IF sy-subrc = 0.
        c_grpfield_last = it_fkkmako-grpfield.
        c_itemgrp_last  = it_fkkmako-itemgrp.
        c_strat_last    = it_fkkmako-strat.
        c_step_last     = it_fkkmako-step.
        c_mahnd         = it_fkkmako-ausdt.
      ELSE.
*       Document as the third charge document?
        READ TABLE it_fkkmako WITH KEY mg3bl = u_opbel.
        IF sy-subrc = 0.
          c_grpfield_last = it_fkkmako-grpfield.
          c_itemgrp_last  = it_fkkmako-itemgrp.
          c_strat_last    = it_fkkmako-strat.
          c_step_last     = it_fkkmako-step.
          c_mahnd         = it_fkkmako-ausdt.
        ELSE.
* Second try: look into the data base
          IF 0 = 1.   " SHOULD NOT BE NECESSARY!!!
*                     " because full history was given
            SET EXTENDED CHECK OFF.
            CALL FUNCTION 'FKK_DUNNING_LEVEL_FROM_MAKO'.
            SET EXTENDED CHECK ON.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.                                                        "<<Note 2042997

ENDFORM.                    " GET_STEP_AND_GROUP_FOR_ADD_REC
