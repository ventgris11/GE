FUNCTION Z_FKK_SAMPLE_TFK126.
*"--------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(X_GRUVAR) LIKE  TFK125-GRUVAR
*"     VALUE(X_VERART) LIKE  TFK110-VERART OPTIONAL
*"     VALUE(X_IFNAM) LIKE  TFK126-IFNAM
*"  TABLES
*"      T_FKKCL_E126 STRUCTURE  FKKCL_E126
*"--------------------------------------------------------------------
  DATA: Y_VALUE   LIKE FKKCL_E126-FWERT_E126.
  DATA: REFE   LIKE FKKOP-BETRW.

*  LOOP AT T_FKKCL_e126.
*
*    CLEAR: Y_VALUE.
*
*    CASE X_IFNAM.
*
*
*  WHEN 'S_XBLNR'.
**  On exclut les postes qui n'ont pas en référence un numéro présent dans la table des sélections
*      LOOP AT t_e516_fkkcl.
*        IF t_e516_fkkcl-i_xnpos_te516 NE 'X'.
*          READ TABLE t_seltab WITH KEY selfn = 'XBLNR' selcu = t_e516_fkkcl-xblnr.
*          IF sy-subrc <> 0.
*            t_e516_fkkcl-e_zreg_te516 = '2'.
*            MODIFY t_e516_fkkcl.
*          ENDIF.
*        ENDIF.
*      ENDLOOP.
**----------------------------------------------------------------------
*
**      WHEN 'E_VORG'.
**        Y_VALUE = T_FKKCL_e126-HVORG.
**        Y_VALUE+4(4) = T_FKKCL_e126-TVORG.
*
*    ENDCASE.
*
**    t_fkkcl_e126-fwert_e126 = Y_VALUE.
**    MODIFY T_FKKCL_e126.
*
*  ENDLOOP.



ENDFUNCTION.
