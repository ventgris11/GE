FUNCTION-POOL ZBTZ_BT.                      "MESSAGE-ID ..

* INCLUDE LZBTZ_BTD...                       " Local class definition
