FUNCTION zintf_g_exe_demngt.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA :
    lv_field            TYPE string,
    ls_object           TYPE eedm_isu_objects,
    lv_success          TYPE crmt_boolean,
    lv_doc_demenagement TYPE auszbeleg,
    lv_int_ui           TYPE int_ui.

  FIELD-SYMBOLS : <fs_num_pce>, <fs_date_releve>.

  CLEAR: lv_field.
  MOVE 'FLUX-NUM_PCE'                     TO lv_field.
  ASSIGN (lv_field)                       TO <fs_num_pce>.

  CLEAR: lv_field.
  MOVE 'FLUX-DATE_RELEVE'                 TO lv_field.
  ASSIGN (lv_field)                       TO <fs_date_releve>.

  "récupération de l'int_ui
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).
  IF lv_int_ui IS INITIAL.
    RETURN.
  ENDIF.

  "récupération des données liées au POD (particulièrement contrat)
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.

  IF ls_object-contract IS INITIAL.
    RETURN.
  ENDIF.

  "réaliser le déménagement
  CALL METHOD zcl_tool=>moveout_doc_creation
    EXPORTING
      iv_contrat    = ls_object-contract
      iv_date_effet = <fs_date_releve>
      iv_test_mode  = iv_mode_test
    IMPORTING
      ev_auszbeleg  = lv_doc_demenagement
    RECEIVING
      rv_success    = lv_success.
  IF lv_success IS INITIAL.
    "erreur déménagement
    RETURN.
  ELSE.
    ev_etape = 1.
  ENDIF.

ENDFUNCTION.
