FUNCTION zintf_g_ctrl_date_fin .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------
  CONSTANTS :
    lc_device              TYPE swo_objtyp VALUE 'DEVICE',
    lc_upd_update          TYPE c LENGTH 1 VALUE 'U'.

  DATA:
    lv_field               TYPE string,
    ls_findpar             TYPE efindpar,
    lt_result              TYPE STANDARD TABLE OF efindres,
    ls_result              TYPE efindres,
    lv_equnr               TYPE egerr-equnr,
    lt_eabl                TYPE TABLE OF eabl,
    ls_eabl                TYPE eabl,
    lv_message             TYPE char255.

  FIELD-SYMBOLS:
    <fs_emetteur>,
    <fs_flux>,
    <fs_idenreg>,
    <fs_num_pce>,
    <fs_date_releve>.

  DEFINE macro_add_message_to_log.
    MESSAGE &1(zintf_g_messages)
       WITH <fs_emetteur>
            <fs_flux>
            <fs_idenreg>
            &2
       INTO lv_message.
    RETURN.
  END-OF-DEFINITION.

  ev_etape = 2.

  CLEAR: lv_field.
  MOVE 'FLUX-EMETTEUR'           TO lv_field.
  ASSIGN (lv_field)              TO <fs_emetteur>.

  CLEAR: lv_field.
  MOVE 'FLUX-FLUX'               TO lv_field.
  ASSIGN (lv_field)              TO <fs_flux>.

  CLEAR: lv_field.
  MOVE 'FLUX-IDENREG'            TO lv_field.
  ASSIGN (lv_field)              TO <fs_idenreg>.

  CLEAR: lv_field.
  MOVE 'FLUX-NUM_PCE'            TO lv_field.
  ASSIGN (lv_field)              TO <fs_num_pce>.

  CLEAR: lv_field.
  MOVE 'FLUX-DATE_RELEVE'        TO lv_field.
  ASSIGN (lv_field)              TO <fs_date_releve>.

* Déterminer le N° d'équipement
  CLEAR:
    ls_findpar,
    lt_result,
    ls_result.

  ls_findpar-i_pod  = <fs_num_pce>.
  ls_findpar-d_date = <fs_date_releve>.

  CALL FUNCTION 'ISU_FINDER'
    EXPORTING
      x_objtype                   = lc_device
      x_findpar                   = ls_findpar
    TABLES
      yt_result                   = lt_result
    EXCEPTIONS
      insufficient_selection      = 1
      objtype_not_supported       = 2
      additional_selection_needed = 3
      OTHERS                      = 4.

  IF sy-subrc NE 0.
*   message e231(zintf_g_messages)
*   &1 - &2 - &3 : Aucun PCE à la date de relève du &4
    macro_add_message_to_log e231 <fs_date_releve>.
  ENDIF.

* Récupérer le N° d'équipement (objet DEVICE)
  READ TABLE lt_result WITH KEY objtype = lc_device
                       INTO ls_result.

  IF ls_result IS INITIAL.
*   message e232(zintf_g_messages)
*   &1 - &2 - &3 : Aucun équipement à la date de relève du &4
    macro_add_message_to_log e232 <fs_date_releve>.
  ENDIF.

  lv_equnr = ls_result-objkey.

  CALL FUNCTION 'ISU_DB_EABL_GET'
    EXPORTING
      x_zwnummer = '001'
*         X_ACTUAL   =
*         X_ADATAB   =
*         X_ADATBIS  =
      x_equnr    = lv_equnr
*       IMPORTING
*         Y_COUNT    =
*         Y_EABL     =
    TABLES
      t_eabl     = lt_eabl
    EXCEPTIONS
      OTHERS     = 1.

  IF sy-subrc NE 0.
*   message e233(zintf_g_messages)
*   &1 - &2 - &3 : Aucune relève pour l'équipement &4
    macro_add_message_to_log e233 lv_equnr.
  ENDIF.

* Suppression des lignes vides (sans date de relève)
  DELETE lt_eabl WHERE adat EQ '00000000'.

  IF lt_eabl[] IS INITIAL.
*   message e234(zintf_g_messages)
*   &1 - &2 - &3 : Aucune relève pertinente pour l'équipement &4
    macro_add_message_to_log e234 lv_equnr.
  ENDIF.

  SORT lt_eabl BY adat DESCENDING.
  READ TABLE lt_eabl INTO ls_eabl INDEX 1.

  IF ls_eabl-adatsoll NE <fs_date_releve>.
*   message e235(zintf_g_messages)
*   &1 - &2 - &3 : Date relève corrigée différente de date dernière relève &4
    macro_add_message_to_log e235 ls_eabl-adatsoll.
  ENDIF.

  ev_etape = 1.

ENDFUNCTION.
