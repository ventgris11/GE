* regenerated at 21.04.2019 16:50:39
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDSO_RESIL_BPTOP.                 " Global Data
  INCLUDE LZDSO_RESIL_BPUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDSO_RESIL_BPF...                 " Subroutines
* INCLUDE LZDSO_RESIL_BPO...                 " PBO-Modules
* INCLUDE LZDSO_RESIL_BPI...                 " PAI-Modules
* INCLUDE LZDSO_RESIL_BPE...                 " Events
* INCLUDE LZDSO_RESIL_BPP...                 " Local class implement.
* INCLUDE LZDSO_RESIL_BPT99.                 " ABAP Unit tests
  INCLUDE LZDSO_RESIL_BPF00                       . " subprograms
  INCLUDE LZDSO_RESIL_BPI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
