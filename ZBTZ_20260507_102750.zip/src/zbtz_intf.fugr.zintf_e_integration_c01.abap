FUNCTION zintf_e_integration_c01 .
*"--------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_IDENREG) TYPE  ZIDENREG
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN DEFAULT ABAP_FALSE
*"     REFERENCE(IV_ID_FLUX) TYPE  ZID_FLUX
*"  EXPORTING
*"     REFERENCE(EV_ERROR) TYPE  CRMT_BOOLEAN
*"--------------------------------------------------------------------

  DATA :  ls_activation TYPE zactivation,
          lv_rc         TYPE flag.

  lv_log_object    = lc_log_object_intf_elec.
  lv_log_subobject = lc_log_subobject_c01.
  lv_msgid         = lc_msgid_intf_elec.


* Appel en mode &1 pour le flux &2
  IF 1 = 2. MESSAGE i018(zintf_e_messages). ENDIF.
  IF iv_mode_test IS INITIAL.
    macro_add_msg_to_log 'I' '018'
                         'REEL' iv_id_flux '' ''.
  ELSE.
    macro_add_msg_to_log 'I' '018'
                         'TEST' iv_id_flux '' ''.
  ENDIF.

* Sélection des données à traiter
  SELECT *
    INTO TABLE lt_c01
    FROM zintf_e_c01
   WHERE idenreg EQ iv_idenreg
ORDER BY idenreg
         even_declencheur
         date_abonnement.

  SELECT *
    INTO TABLE lt_c01_2
    FROM zintf_e_c01_2
   WHERE idenreg EQ iv_idenreg
ORDER BY idenreg
         id_periode.

  SELECT *
    INTO TABLE lt_c01_3
    FROM zintf_e_c01_3
   WHERE idenreg EQ iv_idenreg
ORDER BY idenreg
         id_periode
         rang_cadran.

* Par défaut, le flag erreur est positionné à VRAI
* Seule la réussite de l'intégration positionnera le flag à FAUX
  ev_error = abap_true.
************************************************************************
*
*  1ère partie : Traiter les événements de type S
*
*                   Mise En Service
*
************************************************************************
  lt_c01_temp = lt_c01.
  DELETE lt_c01_temp WHERE even_declencheur NE 'S'.

  LOOP AT lt_c01_temp
     INTO ls_c01.
    lv_statut_flux = ls_c01-statut.

* Traitement de la ligne &1
    IF 1 = 2. MESSAGE i050(zintf_e_messages). ENDIF.
    macro_add_msg_to_log 'I' '050'
                         ls_c01-idenreg '' '' ''.

* Vérifier l’existence du PRM
    lv_int_ui
      = zcl_tool=>pod_check_exist( iv_pce_num = ls_c01-id_prm ).

    IF lv_int_ui IS INITIAL.
* PRM &1 non trouvé => passage au statut "Attention Action CRM"
      IF 1 = 2. MESSAGE e052(zintf_e_messages). ENDIF.
      macro_add_msg_to_log 'E' '052'
                           ls_c01-id_prm '' '' ''.
      lv_statut_flux = lc_statut_10_action_crm.
      PERFORM update_ligne_c01 USING lc_statut_10_action_crm.
      CONTINUE.
    ENDIF.

* Etape 4
* Rechercher le switch document
* On doit rechercher manuellement le switch
* car il faut également rechercher l'emménagement et la date
* (la classe standard ne le gérant pas)
    CALL METHOD zcl_tool=>swd_search
      EXPORTING
        iv_pod           = lv_int_ui
        iv_switch_type   = if_isu_ide_switch_constants=>co_swttype_enroll
        iv_status        = cl_isu_ide_switchdoc=>co_stat_active
        iv_date          = ls_c01-date_abonnement
      RECEIVING
        rr_switch_doc    = lr_switch_doc
      EXCEPTIONS
        multiple_swt_doc = 1
        error            = 2
        OTHERS           = 3.

    IF sy-subrc EQ 1.
* Plusieurs switch doc pour le PRM &1. Passage statut "Action CRM"
      IF 1 = 2. MESSAGE e089(zintf_e_messages). ENDIF.
      macro_add_msg_to_log 'E' '089'
                           ls_c01-id_prm '' '' ''.
      PERFORM update_ligne_c01 USING lc_statut_10_action_crm.
      CONTINUE.
*
    ELSEIF sy-subrc NE 0.
* Erreur lors de la récupération du switch doc
      IF 1 = 2. MESSAGE e091(zintf_e_messages). ENDIF.
      macro_add_msg_to_log 'E' '091'
                           '' '' '' ''.
      PERFORM update_ligne_c01 USING lc_statut_06_rejet.
      CONTINUE.
*
    ELSEIF lr_switch_doc IS NOT BOUND.
* Pas de switch doc associé au PRM &1 => passage au statut "Action CRM"
      IF 1 = 2. MESSAGE w054(zintf_e_messages). ENDIF.
      macro_add_msg_to_log 'W' '054'
                           ls_c01-id_prm '' '' ''.
      PERFORM update_ligne_c01 USING lc_statut_10_action_crm.
      CONTINUE.
    ENDIF.

    ls_switch_doc = lr_switch_doc->get_all_properties( ).

***** Etape 6 + 7 : Vérifier que le contrat est résilié
* Récupération des objets liés au POD
* => installation, contrat principalement
*
    CALL METHOD zcl_tool=>pod_get_related_object
      EXPORTING
        iv_int_ui = lv_int_ui
        iv_date   = ls_c01-date_abonnement
      IMPORTING
        es_detail = ls_object.

    IF ls_object-contract IS NOT INITIAL.
* Gestion du Forced Moved Out
* Il faut vérifier que nous n'avons pas de switch doc de déménagement
* Si c'est le cas,
* il faut que le flux d'emménagement attende celui de déménagement
      CALL METHOD zcl_tool=>swd_search
        EXPORTING
          iv_pod           = lv_int_ui
          iv_switch_type   = if_isu_ide_switch_constants=>co_swttype_drop
          iv_status        = cl_isu_ide_switchdoc=>co_stat_active
          iv_date          = ls_c01-date_abonnement
        RECEIVING
          rr_switch_doc    = lr_switch_doc_dem
        EXCEPTIONS
          multiple_swt_doc = 1
          error            = 2
          OTHERS           = 3.

      IF sy-subrc EQ 1.
* Plusieurs switch doc de déménagement => à corriger manuellement
        IF 1 = 2. MESSAGE e090(zintf_e_messages). ENDIF.
        macro_add_msg_to_log 'E' '090'
                             '' '' '' ''.
        PERFORM update_ligne_c01 USING lc_statut_14_action_manuelle.
*
      ELSEIF sy-subrc NE 0.
* Erreur lors de la récupération du switch doc
        IF 1 = 2. MESSAGE e091(zintf_e_messages). ENDIF.
        macro_add_msg_to_log 'E' '091'
                             '' '' '' ''.
        PERFORM update_ligne_c01 USING lc_statut_06_rejet.
*
      ELSEIF lr_switch_doc_dem IS BOUND.
* En attente traitement C01 de déménagement
        IF 1 = 2. MESSAGE w078(zintf_e_messages). ENDIF.
        MESSAGE w078(zintf_e_messages) INTO lv_message.
        macro_add_msg_to_log 'W' '078'
                             '' '' '' ''.
        ev_error = abap_false.
        PERFORM update_ligne_c01 USING lc_statut_03_mea_synchro.
*
      ELSE.
* PRM &1 est rattaché à un contrat actif (&2)
        IF 1 = 2. MESSAGE e055(zintf_e_messages). ENDIF.
        macro_add_msg_to_log 'E' '055'
                             ls_c01-id_prm
                             ls_object-contract '' ''.
        PERFORM update_ligne_c01 USING lc_statut_06_rejet.
      ENDIF.

      CONTINUE.
    ENDIF.

* Etapes 8 & 9
* Validation du switch document (pour réplication depuis CRM)
* Mise à jour des informations à répliquer dans CRM
* (CAR, Profil type et tarif acheminement)
*
*  lr_switch_doc->set_property( x_property = 'MOVEINDATE'
*                               x_value    = ls_c01-date_abonnement ).
*  lr_switch_doc->set_property( x_property = 'ZZE_MAT_COMPTEUR'
*                               x_value    = ls_c01-matr_compteur ).
*  lr_switch_doc->set_property( x_property = 'ZZE_NUM_TEL_URGENCE'
*                               x_value    = ls_c01-num_tel_urgence ).
*  lr_switch_doc->set_property( x_property = 'ZZE_NB_CADRAN'
*                               x_value    =  ls_c01-nb_cadrans ).
*  lr_switch_doc->set_property( x_property = 'ZZE_NB_ROUE'
*                               x_value    =  ls_c01-nb_roues ).
*  lr_switch_doc->set_property( x_property = 'ZZE_COEFF_LECTURE'
*                               x_value    = ls_c01-coef_lecture ).
*  lr_switch_doc->set_property( x_property = 'ZZE_LIB_HC'
*                               x_value    = ls_c01-libelle_hc ).
*  lr_switch_doc->set_property( x_property = 'ZZE_DTR'
*                               x_value    = ls_c01-date_theo_pro_re ).
    macro_set_switch_doc_property 'MOVEINDATE'
                                   ls_c01-date_abonnement.
    macro_set_switch_doc_property 'ZZE_MAT_COMPTEUR'
                                   ls_c01-matr_compteur.
    macro_set_switch_doc_property 'ZZE_NUM_TEL_URGENCE'
                                   ls_c01-num_tel_urgence.
    macro_set_switch_doc_property 'ZZE_NB_CADRAN'
                                   ls_c01-nb_cadrans.
    macro_set_switch_doc_property 'ZZE_NB_ROUE'
                                   ls_c01-nb_roues.
    macro_set_switch_doc_property 'ZZE_COEFF_LECTURE'
                                   ls_c01-coef_lecture.
    macro_set_switch_doc_property 'ZZE_LIB_HC'
                                   ls_c01-libelle_hc.
    macro_set_switch_doc_property 'ZZE_DTR'
                                   ls_c01-date_theo_pro_re.

    CLEAR ls_c01_2.
    READ TABLE lt_c01_2
          INTO ls_c01_2
      WITH KEY idenreg = ls_c01-idenreg.

*  lr_switch_doc->set_property( x_property = 'ZZE_PUISS_SOUS'
*                               x_value  = ls_c01_2-puissance_contrat ).

    macro_set_switch_doc_property 'ZZE_PUISS_SOUS'
                                   ls_c01_2-puissance_contrat.

    CLEAR ls_c01_3.
    READ TABLE lt_c01_3
          INTO ls_c01_3
      WITH KEY idenreg     = ls_c01-idenreg
               id_periode  = ls_c01_2-id_periode
               rang_cadran = '1'.

*   lr_switch_doc->set_property( x_property = 'ZZE_INDEX_CAD_1'
*                                x_value    =   ls_c01_3-index_cadran ).

    macro_set_switch_doc_property 'ZZE_INDEX_CAD_1'
                                   ls_c01_3-index_cadran.

    CLEAR ls_c01_3.
    READ TABLE lt_c01_3
          INTO ls_c01_3
      WITH KEY idenreg     = ls_c01-idenreg
               id_periode  = ls_c01_2-id_periode
               rang_cadran = '2'.

*   lr_switch_doc->set_property( x_property = 'ZZE_INDEX_CAD_2'
*                                x_value    =   ls_c01_3-index_cadran ).

    macro_set_switch_doc_property 'ZZE_INDEX_CAD_2'
                                   ls_c01_3-index_cadran.

    IF iv_mode_test IS INITIAL.

      CLEAR : ls_activation ,
              lv_rc .

      ls_activation-user_id = ls_switch_doc-partner.
      ls_activation-user_activation_date = ls_switch_doc-realmoveindate.

      CALL METHOD zcl_demat=>send_event_json
        EXPORTING
          iv_event                = 'ACTIVATION'
          is_struct_dataco        = ls_activation
        EXCEPTIONS
          interface_desactive     = 1
          error_send_http         = 2
          error_serialisation     = 3
          error_evenement_inconnu = 4
          OTHERS                  = 5.

      IF sy-subrc NE 0 .
        MESSAGE w248(zintf_g_messages)  INTO lv_message.
      ENDIF.

      lr_switch_doc->save( ).
* Génération de l'événement pour confirmer le switch document
      zcl_tool=>swd_event_generate(
        iv_event         = zcl_tool=>gc_swd_accept_enrollment
        iv_switchdoc_num = ls_switch_doc-switchnum ).
    ENDIF.

    lr_switch_doc->close( ).

* Etape 10 : Consommation du flux
    ev_error = abap_false.
    PERFORM update_ligne_c01 USING lc_statut_07_integre.

  ENDLOOP. "Fin LOOP sur toutes les entrées de type 'E'


************************************************************************
*
*          2ème partie : Traiter les événements de type R
*
*                        Mise Hors Service
*
************************************************************************
  lt_c01_temp = lt_c01.
  DELETE lt_c01_temp WHERE even_declencheur NE 'R'.

  LOOP AT lt_c01_temp
     INTO ls_c01.
    lv_statut_flux = ls_c01-statut.

* Traitement de la ligne &1
    IF 1 = 2. MESSAGE i050(zintf_e_messages). ENDIF.
    macro_add_msg_to_log 'I' '050'
                         ls_c01-idenreg '' '' ''.

***** Etape 2 : Vérification de l'existance du PRM
    lv_int_ui
      = zcl_tool=>pod_check_exist( iv_pce_num = ls_c01-id_prm ).

    IF lv_int_ui IS INITIAL.
* PRM &1 inconnu
      MESSAGE e240(zintf_e_messages) WITH ls_c01-id_prm
                                     INTO lv_msg_bpem.

      CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
        EXPORTING
          iv_interface_name = 'C01'
          iv_sparte         = 'ZE'
          is_structure      = ls_c01.
      macro_add_msg_to_log 'E' '240'
                       ls_c01-id_prm '' '' ''.
      PERFORM update_ligne_c01 USING lc_statut_06_rejet.
      CONTINUE. " Passage à l'enregistrement suivant
    ENDIF.

***** Etape 3 : Vérifier qu'il existe un contrat et que la fiche info
*appareil est posée
    " Récupération des objets liés au POD (contrat principalement)
    CALL METHOD zcl_tool=>pod_get_related_object
      EXPORTING
        iv_int_ui = lv_int_ui
        iv_date   = ls_c01-date_resiliation
      IMPORTING
        es_detail = ls_object
        ev_equnr  = lv_equnr
        ev_sernr  = lv_sernr.

* Vérification de l'existence d'un contrat
    IF ls_object-contract IS INITIAL.
* PRM &1 non rattaché à un contrat actif (ID &2)
      MESSAGE e056(zintf_e_messages) WITH ls_c01-id_prm
                                          ls_c01-idenreg
                                     INTO lv_msg_bpem.

      CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
        EXPORTING
          iv_interface_name = 'C01'
          iv_sparte         = 'ZE'
          is_structure      = ls_c01.

      macro_add_msg_to_log 'E' '056'
                           ls_c01-id_prm
                           ls_c01-idenreg '' ''.
      PERFORM update_ligne_c01 USING lc_statut_06_rejet.
      CONTINUE. " Passage à l'enregistrement suivant
    ENDIF.

* Vérification de l'existence d'une FIAP
    IF lv_sernr IS INITIAL.
* Pas de fiche info appareil posée sur le contrat &1 du PRM &2 (ID &3)
      MESSAGE e059(zintf_e_messages) WITH ls_object-contract
                                          ls_c01-id_prm
                                          ls_c01-idenreg
                                     INTO lv_msg_bpem.

      lv_interface = 'C01' .
      CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
        EXPORTING
          iv_interface_name = lv_interface
          iv_sparte         = 'ZE'
          is_structure      = ls_c01.

      macro_add_msg_to_log 'E' '059'
                           ls_object-contract
                           ls_c01-id_prm
                           ls_c01-idenreg ''.
      PERFORM update_ligne_c01 USING lc_statut_06_rejet.
      CONTINUE. " Passage à l'enregistrement suivant
    ENDIF.

* Etape 4 :
* Vérifier s'il existe une facture/relève postérieure à la date de MHS
* 4.1 : On vérifie qu'il n'y a pas de relève après la date de MES
    lv_date = ls_c01-date_resiliation - 1. " On prend la veille
    REFRESH: lt_mr_data, lt_mr_reason.
    CALL METHOD zcl_tool=>install_liste_releve
      EXPORTING
        iv_install        = ls_object-installation
        iv_date           = lv_date
      IMPORTING
        et_releves        = lt_mr_data
        et_releves_raison = lt_mr_reason.

    READ TABLE lt_mr_data INDEX 1 TRANSPORTING NO FIELDS.

    IF sy-subrc EQ 0. " Relève trouvée !!!
* Rejet du mouvement &1: relève présente après la &2 (ID &3)
      MESSAGE e058(zintf_e_messages) WITH ls_c01-even_declencheur
                                          'MHS'
                                          ls_c01-idenreg ''
                                     INTO lv_msg_bpem.

      CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
        EXPORTING
          iv_interface_name = 'C01'
          iv_sparte         = 'ZE'
          is_structure      = ls_c01.

      macro_add_msg_to_log 'E' '058'
                           ls_c01-even_declencheur
                           'MHS'
                           ls_c01-idenreg ''.

      PERFORM update_ligne_c01 USING lc_statut_06_rejet.
      CONTINUE. " Passage à l'enregistrement suivant
    ENDIF.

* 4.2 : Vérification des factures
* Vérifier l'existence d'un blocage de facture
    SELECT SINGLE abrsperr
             INTO lv_abrsperr
             FROM ever
            WHERE vertrag EQ ls_object-contract.

    IF lv_abrsperr IS NOT INITIAL.
* Motif de blocage &1 présent pour le contrat &2
      MESSAGE e060(zintf_e_messages) WITH lv_abrsperr
                                          ls_object-contract
                                     INTO lv_msg_bpem .

      CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
        EXPORTING
          iv_interface_name = 'C01'
          iv_sparte         = 'ZE'
          is_structure      = ls_c01.

      macro_add_msg_to_log 'E' '060'
                           lv_abrsperr
                           ls_object-contract '' ''.
      PERFORM update_ligne_c01 USING lc_statut_06_rejet.
      CONTINUE. " Passage à l'enregistrement suivant
    ENDIF.

* Etape 7.2 : Réaliser le déménagement
    CALL METHOD zcl_tool=>moveout_doc_creation
      EXPORTING
        iv_contrat    = ls_object-contract
        iv_date_effet = ls_c01-date_resiliation
        iv_test_mode  = iv_mode_test
      IMPORTING
        ev_auszbeleg  = lv_doc_demenagement
      RECEIVING
        rv_success    = lv_success.

    IF lv_success IS INITIAL.
      macro_add_msg_system_to_log.
      PERFORM update_ligne_c01 USING lc_statut_06_rejet.
      CONTINUE. " Passage à l'enregistrement suivant
    ENDIF.

*  Gestion d'un éventuel switch doc
    CALL METHOD zcl_tool=>swd_search
      EXPORTING
        iv_pod           = lv_int_ui
        iv_switch_type   = if_isu_ide_switch_constants=>co_swttype_drop
        iv_status        = cl_isu_ide_switchdoc=>co_stat_active
        iv_mode          = cl_isu_wmode=>co_change
        iv_date          = ls_c01-date_resiliation
      RECEIVING
        rr_switch_doc    = lr_switch_doc
      EXCEPTIONS
        multiple_swt_doc = 1
        error            = 2
        OTHERS           = 3.

    IF sy-subrc EQ 1.
* Plusieurs switch doc de déménagement => à corriger manuellement
      IF 1 = 2. MESSAGE e090(zintf_e_messages). ENDIF.
      macro_add_msg_to_log 'E' '090'
                           '' '' '' ''.
      PERFORM update_ligne_c01 USING lc_statut_14_action_manuelle.
*
    ELSEIF sy-subrc NE 0.
* Erreur lors de la récupération du switch doc
      IF 1 = 2. MESSAGE e091(zintf_e_messages). ENDIF.
      macro_add_msg_to_log 'E' '091'
                           '' '' '' ''.
      PERFORM update_ligne_c01 USING lc_statut_06_rejet.
*
    ENDIF.

    IF lr_switch_doc IS BOUND.
*      lr_switch_doc->set_property( x_property = 'MOVEOUTDATE'
*                                   x_value = ls_c01-date_resiliation ).
*      lr_switch_doc->set_property( x_property = 'ZZG_C01_OK'
*                                   x_value = abap_true ).
      macro_set_switch_doc_property 'MOVEOUTDATE'
                                     ls_c01-date_resiliation.
      macro_set_switch_doc_property 'ZZG_C01_OK'
                                     abap_true.

      IF iv_mode_test IS INITIAL.
        lr_switch_doc->save( ).
        lr_switch_doc->close( ).

        ls_switch_doc = lr_switch_doc->get_all_properties( ).

* On génère l'événement ici pour le déménagement
        zcl_tool=>swd_event_generate(
          iv_event =
                 if_isu_ide_switch_constants=>co_event_drop_confirmed
          iv_switchdoc_num = ls_switch_doc-switchnum ).
      ENDIF.
    ENDIF.

    lv_anlage = ls_object-installation.

* On vérifie si on ne dispose pas déjà d'un historique de releve
* sur le point
    REFRESH:
      lt_mr_data,
      lt_mr_reason.

    CALL FUNCTION 'BAPI_MTRREADDOC_GETLIST'
      EXPORTING
        installation      = ls_object-installation
        mrdocumenttype    = '1'  "Ordres de relevé
        mrreason          = '03' "Relevé de résiliation
      IMPORTING                  "Emménagement/Déménagement
        return            = ls_return
      TABLES
        mrdocumentdata    = lt_mr_data
        mrdocumentreasons = lt_mr_reason.

    IF lt_mr_data[] IS INITIAL.
      CALL FUNCTION 'BAPI_MTRREADDOC_GETLIST'
        EXPORTING
          installation      = ls_object-installation
          mrdocumenttype    = '2'  "Résultats relevé
          mrreason          = '03' "Relevé de résiliation
          "Emménagement/Déménagement
          targetmrdatefrom  = ls_c01-date_resiliation
        IMPORTING
          return            = ls_return
        TABLES
          mrdocumentdata    = lt_mr_data
          mrdocumentreasons = lt_mr_reason.

      IF lt_mr_data[] IS INITIAL.
* PRM &1 Installation &2 sans ordre de déménagement en date du &3
        IF 1 = 2. MESSAGE e094(zintf_e_messages). ENDIF.
        macro_add_msg_to_log 'E' '094'
                             ls_c01-id_prm
                             ls_object-installation
                             ls_c01-date_resiliation ''.
        PERFORM update_ligne_c01 USING lc_statut_14_action_manuelle.
        CONTINUE. " Passage à l'enregistrement suivant
        RETURN.
      ENDIF.
    ENDIF.

    CLEAR ls_c01_2.
    READ TABLE lt_c01_2
          INTO ls_c01_2
      WITH KEY idenreg = ls_c01-idenreg.

    CLEAR ls_c01_3.
    READ TABLE lt_c01_3
          INTO ls_c01_3
      WITH KEY idenreg     = ls_c01-idenreg
               id_periode  = ls_c01_2-id_periode
               rang_cadran = '1'.

    lv_index_cadran_1        = ls_c01_3-index_cadran.
    lv_nature_index_cadran_1 = ls_c01_3-nature_index.

    CLEAR ls_c01_3.
    READ TABLE lt_c01_3
          INTO ls_c01_3
      WITH KEY idenreg     = ls_c01-idenreg
               id_periode  = ls_c01_2-id_periode
               rang_cadran = '2'.

    lv_index_cadran_2        = ls_c01_3-index_cadran.
    lv_nature_index_cadran_2 = ls_c01_3-nature_index.

    lv_anlage = ls_object-installation.

    CLEAR ls_mr_data.
    READ TABLE lt_mr_data
          INTO ls_mr_data
      WITH KEY targetmrdate = ls_c01-date_resiliation
               register = '1'.

* Ouverture de l'objet relève
    CALL FUNCTION 'ISU_O_METERREAD_OPEN'
      EXPORTING
        x_adatsoll   = ls_c01-date_resiliation
        x_action     = '01'
        x_ablbelnr   = ls_mr_data-mridnumber
        x_wmode      = '2'
        x_select2    = '1'
        x_no_dialog  = 'X'
        x_upd_online = 'X'
        x_no_enqueue = 'X'
        x_auto       = lt_auto
      IMPORTING
        y_obj        = ls_obj
      EXCEPTIONS
        OTHERS       = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      PERFORM update_ligne_c01 USING lc_statut_06_rejet.
      CONTINUE. " Passage à l'enregistrement suivant
    ENDIF.

    CLEAR ls_ieabl.
    READ TABLE ls_obj-ieabl
          INTO ls_ieabl     INDEX 1.

    IF NOT sy-subrc IS INITIAL.
* Aucune relève pour l'installation &1 du PRM &2 en date du &3
      IF 1 = 2. MESSAGE e171(zintf_e_messages). ENDIF.
      macro_add_msg_to_log 'E' '171'
                           ls_object-installation
                           ls_c01-id_prm
                           ls_c01-date_resiliation ''.

      PERFORM update_ligne_c01 USING lc_statut_06_rejet.
      CONTINUE. " Passage à l'enregistrement suivant
    ENDIF.

    lv_index_entier    = trunc( lv_index_cadran_1 ).
    lv_index_decimales =  frac( lv_index_cadran_1 ).

    ls_ieabl-zwnummer          = 1.
    ls_ieabl-v_zwstand         = lv_index_entier.
    ls_ieabl-n_zwstand         = lv_index_decimales.
    ls_ieabl-v_zwstndab        = lv_index_entier.
    ls_ieabl-n_zwstndab        = lv_index_decimales.
    ls_ieabl-adattats          = ls_c01-date_resiliation.
    ls_ieabl-ablstat           = '1'.

    CASE lv_nature_index_cadran_1.
      WHEN 'A' .
        ls_ieabl-istablart     = 'Z5'.
      WHEN OTHERS.
        ls_ieabl-istablart     = '01'.
    ENDCASE.

    ls_ieabl-ablestyp          = '01'.
    ls_ieabl-zzidenreg         = ls_c01-idenreg.

    MODIFY ls_obj-ieabl
      FROM ls_ieabl     INDEX 1.

    CALL FUNCTION 'ISU_O_METERREAD_OPEN_SUBOBJ'
      EXPORTING
        x_action   = '01'
        x_auto     = lt_auto
        x_adatsoll = ls_c01-date_resiliation
      CHANGING
        xy_obj     = ls_obj
      EXCEPTIONS
        OTHERS     = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      PERFORM update_ligne_c01 USING lc_statut_06_rejet.
      CONTINUE. " Passage à l'enregistrement suivant
    ENDIF.

    CALL FUNCTION 'ISU_O_METERREAD_INPUT'
      CHANGING
        xy_obj = ls_obj
      EXCEPTIONS
        OTHERS = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      PERFORM update_ligne_c01 USING lc_statut_06_rejet.
      CONTINUE. " Passage à l'enregistrement suivant
    ENDIF.

* Préparation de la sauvegarde
    CALL FUNCTION 'ISU_O_METERREAD_ACTION'
      EXPORTING
        x_okcode = 'PSAV'
      CHANGING
        xy_obj   = ls_obj
      EXCEPTIONS
        OTHERS   = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      PERFORM update_ligne_c01 USING lc_statut_06_rejet.
      CONTINUE. " Passage à l'enregistrement suivant
    ENDIF.

* sauvegarde
    CALL FUNCTION 'ISU_O_METERREAD_ACTION'
      EXPORTING
        x_okcode = 'SAVE'
      CHANGING
        xy_obj   = ls_obj
      EXCEPTIONS
        OTHERS   = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      PERFORM update_ligne_c01 USING lc_statut_06_rejet.
      CONTINUE. " Passage à l'enregistrement suivant
    ENDIF.

    CALL FUNCTION 'ISU_O_METERREAD_CLOSE'
      EXPORTING
        x_no_dialog = 'X'
      CHANGING
        xy_obj      = ls_obj
      EXCEPTIONS
        OTHERS      = 99.

    IF NOT sy-subrc IS INITIAL.
      macro_add_msg_system_to_log.
      PERFORM update_ligne_c01 USING lc_statut_06_rejet.
      CONTINUE. " Passage à l'enregistrement suivant
    ENDIF.

    IF ls_c01-nb_cadrans = '2'.
      CLEAR ls_mr_data.
      READ TABLE lt_mr_data
            INTO ls_mr_data
        WITH KEY targetmrdate = ls_c01-date_resiliation
                 register = '2'.

* Ouverture de l'objet relève
      CALL FUNCTION 'ISU_O_METERREAD_OPEN'
        EXPORTING
          x_adatsoll   = ls_c01-date_resiliation
          x_action     = '01'
          x_ablbelnr   = ls_mr_data-mridnumber
          x_wmode      = '2'
          x_select2    = '1'
          x_no_dialog  = 'X'
          x_upd_online = 'X'
          x_no_enqueue = 'X'
          x_auto       = lt_auto
        IMPORTING
          y_obj        = ls_obj
        EXCEPTIONS
          OTHERS       = 99.

      IF NOT sy-subrc IS INITIAL.
        macro_add_msg_system_to_log.
        PERFORM update_ligne_c01 USING lc_statut_06_rejet.
        CONTINUE. " Passage à l'enregistrement suivant
      ENDIF.

      CLEAR ls_ieabl.
      READ TABLE ls_obj-ieabl INTO ls_ieabl INDEX 1.

      IF NOT sy-subrc IS INITIAL.
* Aucune relève pour l'installation &1 du PRM &2 en date du &3
        IF 1 = 2. MESSAGE e171(zintf_e_messages). ENDIF.
        macro_add_msg_to_log 'E' '171'
                             ls_object-installation
                             ls_c01-id_prm
                             ls_c01-date_resiliation ''.
        CONTINUE. " Passage à l'enregistrement suivant
      ENDIF.

      lv_index_entier    = trunc( lv_index_cadran_2 ).
      lv_index_decimales =  frac( lv_index_cadran_2 ).

      ls_ieabl-zwnummer        = 2.
      ls_ieabl-v_zwstand       = lv_index_entier.
      ls_ieabl-n_zwstand       = lv_index_decimales.
      ls_ieabl-v_zwstndab      = lv_index_entier.
      ls_ieabl-n_zwstndab      = lv_index_decimales.
      ls_ieabl-adattats        = ls_c01-date_resiliation.
      ls_ieabl-ablstat         = '1'.

      CASE lv_nature_index_cadran_2.
        WHEN 'A' .
          ls_ieabl-istablart   = 'Z5'.
        WHEN OTHERS.
          ls_ieabl-istablart   = '01'.
      ENDCASE.

      ls_ieabl-ablestyp        = '01'.
      ls_ieabl-zzidenreg       = ls_c01-idenreg.

      MODIFY ls_obj-ieabl
        FROM ls_ieabl     INDEX 1.

      CALL FUNCTION 'ISU_O_METERREAD_OPEN_SUBOBJ'
        EXPORTING
          x_action   = '01'
          x_auto     = lt_auto
          x_adatsoll = ls_c01-date_resiliation
        CHANGING
          xy_obj     = ls_obj
        EXCEPTIONS
          OTHERS     = 99.

      IF NOT sy-subrc IS INITIAL.
        macro_add_msg_system_to_log.
        PERFORM update_ligne_c01 USING lc_statut_06_rejet.
        CONTINUE. " Passage à l'enregistrement suivant
      ENDIF.

      CALL FUNCTION 'ISU_O_METERREAD_INPUT'
        CHANGING
          xy_obj = ls_obj
        EXCEPTIONS
          OTHERS = 99.

      IF NOT sy-subrc IS INITIAL.
        macro_add_msg_system_to_log.
        PERFORM update_ligne_c01 USING lc_statut_06_rejet.
        CONTINUE. " Passage à l'enregistrement suivant
      ENDIF.

* Préparation de la sauvegarde
      CALL FUNCTION 'ISU_O_METERREAD_ACTION'
        EXPORTING
          x_okcode = 'PSAV'
        CHANGING
          xy_obj   = ls_obj
        EXCEPTIONS
          OTHERS   = 99.

      IF NOT sy-subrc IS INITIAL.
        macro_add_msg_system_to_log.
        PERFORM update_ligne_c01 USING lc_statut_06_rejet.
        CONTINUE. " Passage à l'enregistrement suivant
      ENDIF.

* sauvegarde
      CALL FUNCTION 'ISU_O_METERREAD_ACTION'
        EXPORTING
          x_okcode = 'SAVE'
        CHANGING
          xy_obj   = ls_obj
        EXCEPTIONS
          OTHERS   = 99.

      IF NOT sy-subrc IS INITIAL.
        macro_add_msg_system_to_log.
        PERFORM update_ligne_c01 USING lc_statut_06_rejet.
        CONTINUE. " Passage à l'enregistrement suivant
      ENDIF.

      CALL FUNCTION 'ISU_O_METERREAD_CLOSE'
        EXPORTING
          x_no_dialog = 'X'
        CHANGING
          xy_obj      = ls_obj
        EXCEPTIONS
          OTHERS      = 99.

      IF NOT sy-subrc IS INITIAL.
        macro_add_msg_system_to_log.
        PERFORM update_ligne_c01 USING lc_statut_06_rejet.
        CONTINUE. " Passage à l'enregistrement suivant
      ENDIF.

    ENDIF.

* Consommation du FLUX
    ev_error = abap_false.
    PERFORM update_ligne_c01 USING lc_statut_07_integre.
  ENDLOOP. "Fin LOOP sur toutes les entrées de type 'S'


************************************************************************
*
*          3ème partie : Traiter les événements de type M
*
*                         Modification
*
************************************************************************
  lt_c01_temp = lt_c01.

  DELETE lt_c01_temp WHERE even_declencheur NE 'M'.

  LOOP AT lt_c01_temp
     INTO ls_c01.
    lv_statut_flux = ls_c01-statut.

* Traitement de la ligne &1
    IF 1 = 2. MESSAGE i050(zintf_e_messages). ENDIF.
    macro_add_msg_to_log 'I' '050'
                         ls_c01-idenreg '' '' ''.

***** Etape 1 : Vérification de l'existance du PRM
    lv_int_ui
      = zcl_tool=>pod_check_exist( iv_pce_num = ls_c01-id_prm ).

    IF lv_int_ui IS INITIAL.
* PRM &1 inconnu
      MESSAGE e240(zintf_e_messages) WITH ls_c01-id_prm
                                     INTO lv_msg_bpem.

      CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
        EXPORTING
          iv_interface_name = 'C01'
          iv_sparte         = 'ZE'
          is_structure      = ls_c01.
      macro_add_msg_to_log 'E' '240'
                           ls_c01-id_prm '' '' ''.
      PERFORM update_ligne_c01 USING lc_statut_06_rejet.
      CONTINUE. " Passage à l'enregistrement suivant
    ENDIF.

* Cas chgt DTR
    IF ls_c01-date_theo_pro_re IS NOT INITIAL.
      CALL METHOD zcl_tool=>pod_get_related_object
        EXPORTING
          iv_int_ui = lv_int_ui
          iv_date   = ls_c01-date_index
        IMPORTING
          es_detail = ls_object
          ev_sernr  = lv_sernr.

      SELECT *
        FROM eanlh
        INTO TABLE lt_eanlh
       WHERE anlage EQ ls_object-installation
         AND bis    GE ls_c01-date_index
         AND ab     LE ls_c01-date_index.

*      xy_obj-eanlh    = lt_eanlh.
*      xy_obj-db_eanlh = lt_eanlh.
*
*      CALL FUNCTION 'ISU_O_INSTLN_ACTION'
*        EXPORTING
*          x_okcode     = 'SAV'
*          x_no_message = 'X'
*        CHANGING
*          xy_obj       = xy_obj
*        EXCEPTIONS
*          OTHERS       = 1.

      IF sy-subrc IS NOT INITIAL.
* Données de base non créée en masse - &1 impossible
        IF 1 = 2. MESSAGE e032(zintf_e_messages). ENDIF.
        macro_add_msg_to_log 'E' '032'
                             'Changement UR' '' '' ''.
        PERFORM update_ligne_c01 USING lc_statut_06_rejet.
        CONTINUE. " Passage à l'enregistrement suivant
      ENDIF.
    ELSE.
* En fonction de l’origine index (ORI_INDEX dans la table C01_CADRAN)
*	V => Changement de compteur
*	W => Changement de puissance
*	Sinon, l’enregistrement est « filtré »
*        avec le message « Type de modification non géré »

* il faut aller chercher dans la table C01 Cadran
      SELECT SINGLE origine_index
               INTO lv_origine_index
               FROM zintf_e_c01_3
              WHERE idenreg     EQ ls_c01-idenreg
                AND rang_cadran EQ '1'.

****************************************
****************************************
**** Cas d'un changement de compteur ***
****************************************
****************************************

      IF lv_origine_index = 'V'.

***** Etape 2 : Vérifier qu'il existe un contrat
        " Récupération des objets liés au POD (contrat principalement)
        CALL METHOD zcl_tool=>pod_get_related_object
          EXPORTING
            iv_int_ui = lv_int_ui
            iv_date   = ls_c01-date_index
          IMPORTING
            es_detail = ls_object
            ev_sernr  = lv_sernr.

* 2.1 : Vérification de la non existence d'un contrat
        IF ls_object-contract IS INITIAL.
* PRM &1 non rattaché à un contrat actif (ID &2)
          MESSAGE e056(zintf_e_messages) WITH ls_c01-id_prm
                                              ls_c01-idenreg
                                         INTO lv_msg_bpem.

          CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
            EXPORTING
              iv_interface_name = 'C01'
              iv_sparte         = 'ZE'
              is_structure      = ls_c01.

          macro_add_msg_to_log 'E' '056'
                               ls_c01-id_prm
                               ls_c01-idenreg '' ''.
          PERFORM update_ligne_c01 USING lc_statut_06_rejet.
          CONTINUE. " Passage à l'enregistrement suivant
        ENDIF.

* 4.1 : On vérifie qu'il n'y a pas de relève après la date du mvt M
        lv_date = ls_c01-date_index + 1. " On prend le lendemain
        REFRESH: lt_mr_data, lt_mr_reason.
        CALL METHOD zcl_tool=>install_liste_releve
          EXPORTING
            iv_install        = ls_object-installation
            iv_date           = lv_date
          IMPORTING
            et_releves        = lt_mr_data
            et_releves_raison = lt_mr_reason.

        READ TABLE lt_mr_data INDEX 1 TRANSPORTING NO FIELDS.

        IF sy-subrc = 0. " Relève trouvée !!!
* Rejet du mouvement &1: relève présente après la &2 (ID &3)
          MESSAGE e058(zintf_e_messages) WITH ls_c01-even_declencheur
                                              'Date de changement de compteur'
                                              ls_c01-idenreg ''
                                         INTO lv_msg_bpem.

          CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
            EXPORTING
              iv_interface_name = 'C01'
              iv_sparte         = 'ZE'
              is_structure      = ls_c01.

          macro_add_msg_to_log 'E' '058'
                               ls_c01-even_declencheur
                               'Date de changement de compteur'
                               ls_c01-idenreg ''.

          PERFORM update_ligne_c01 USING lc_statut_06_rejet.
          CONTINUE. " Passage à l'enregistrement suivant
        ENDIF.

        SELECT *
          FROM zintf_e_c01
          INTO TABLE lt_c01_prec
         WHERE id_prm          EQ ls_c01-id_prm
           AND date_abonnement LE ls_c01-date_index
           AND idenreg         NE ls_c01-idenreg
           AND statut          EQ '07'.

        SORT lt_c01_prec BY date_index DESCENDING.

        READ TABLE lt_c01_prec
              INTO ls_c01_prec  INDEX 1.

*Vérifier si c’est une nouvelle situation (ID_SITUATION) par rapport
*aux enregistrements existants de ce PDL :*
*●  Si oui,  c’est un enregistrement de pose se rendre à l’étape n°8.
*●  Sinon, c’est un enregistrement de dépose, se rendre à l’étape n°5.

        IF ls_c01-id_situation NE ls_c01_prec-id_situation.
****************************************
**** Cas d'une pose ********************
****************************************

          REFRESH lt_fiap.
          CALL METHOD zcl_tool=>install_liste_fiap
            EXPORTING
              iv_install = ls_object-installation
              iv_date    = ls_c01-date_index
            IMPORTING
              et_fiap    = lt_fiap.

* Suppression des FIAP non pertinentes
          DELETE lt_fiap WHERE bis NE '99991231'.

          IF lt_fiap[] IS NOT INITIAL.
* Fiche info appareil déjà posée sur l'installation &1 du PRM &2 au &3
            IF 1 = 2. MESSAGE e095(zintf_e_messages). ENDIF.
            macro_add_msg_to_log 'E' '095'
                                 ls_object-installation
                                 ls_c01-id_prm
                                 ls_c01-date_index ''.
            PERFORM update_ligne_c01 USING lc_statut_06_rejet.
            CONTINUE. " Passage à l'enregistrement suivant
          ENDIF.

* On prend la veille pour rechercher le compteur précédent
          lv_date = ls_c01-date_index - 1.

          CALL METHOD zcl_tool=>install_liste_fiap
            EXPORTING
              iv_install = ls_object-installation
              iv_date    = lv_date
            IMPORTING
              et_fiap    = lt_fiap.

          lt_fiap_check_cadran = lt_fiap.

          SORT lt_fiap_check_cadran BY bis DESCENDING.

          READ TABLE lt_fiap_check_cadran
                INTO ls_fiap_check_cadran INDEX 1.

          IF ls_fiap_check_cadran-zwgruppe CS 'B'.
            nb_cadrans_prec = 1.
          ELSE.
            nb_cadrans_prec = 2.
          ENDIF.

          IF ls_c01-nb_cadrans NE nb_cadrans_prec.
* Si le nombre de cadrans est différent
*recherche du switch document avec le numéro d’affaire :
*Si trouvé, récupérer les valeurs de la consommation périodiques du
*switch doc et alimenter le switch doc avec la date d’effet de pose, se
*rendre à l’étape n°10

* Erreur lors de la récupération du switch doc
            IF 1 = 2. MESSAGE e091(zintf_e_messages). ENDIF.
            macro_add_msg_to_log 'E' '091'
                                 '' '' '' ''.
            PERFORM update_ligne_c01 USING lc_statut_06_rejet.
            CONTINUE. " Passage à l'enregistrement suivant
          ELSE.
* Création fiche info et pose
            IF ls_c01-nb_cadrans = '1'.
              lv_type_grpe_cadran = '1'. "Base
            ELSE.
              lv_type_grpe_cadran = '2'. "HP/HC
            ENDIF.

            CLEAR ls_c01_2.
            READ TABLE lt_c01_2
                  INTO ls_c01_2
              WITH KEY idenreg = ls_c01-idenreg.

            CLEAR ls_c01_3.
            READ TABLE lt_c01_3
                  INTO ls_c01_3
              WITH KEY idenreg     = ls_c01-idenreg
                       id_periode  = ls_c01_2-id_periode
                       rang_cadran = '1'.

            lv_index_cadran_1 = ls_c01_3-index_cadran.

            CLEAR ls_c01_3.
            READ TABLE lt_c01_3
                  INTO ls_c01_3
              WITH KEY idenreg     = ls_c01-idenreg
                       id_periode  = ls_c01_2-id_periode
                       rang_cadran = '2'.

            lv_index_cadran_2 = ls_c01_3-index_cadran.

            CALL FUNCTION 'ZINTF_E_POSE_FIAP'
              EXPORTING
                iv_nb_roues         = ls_c01-nb_roues
                iv_type_grpe_cadran = lv_type_grpe_cadran
                iv_id_flux          = ls_c01-id_flux
                iv_date_pose        = ls_c01-date_index
                iv_matricule        = ls_c01-matr_compteur
                iv_index_cad_1      = lv_index_cadran_1
                iv_index_cad_2      = lv_index_cadran_2
                iv_nb_cadrans       = ls_c01-nb_cadrans
                iv_anlage           = ls_object-installation
              IMPORTING
                ev_statut           = lv_statut.

            IF lv_statut NE 1. " Pose non faite
* Problème dans la pose pour l'installation &1
              MESSAGE e097(zintf_e_messages) WITH ls_object-installation
                                             INTO lv_msg_bpem.
              CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
                EXPORTING
                  iv_interface_name = 'C01'
                  iv_sparte         = 'ZE'
                  is_structure      = ls_c01.

              macro_add_msg_to_log 'E' '097'
                                   ls_object-installation '' '' ''.
              PERFORM update_ligne_c01 USING lc_statut_06_rejet.
              CONTINUE. " Passage à l'enregistrement suivant
            ENDIF.
          ENDIF.
        ELSE.
****************************************
**** Cas d'une dépose ******************
****************************************
          CALL METHOD zcl_tool=>install_liste_fiap
            EXPORTING
              iv_install = ls_object-installation
              iv_date    = ls_c01-date_index
            IMPORTING
              et_fiap    = lt_fiap.
* Suppression des FIAP non pertinentes
          DELETE lt_fiap WHERE bis NE '99991231'.

          IF lt_fiap[] IS INITIAL.
* Pas de fiche info appareil posée sur le contrat &1 du PRM &2 au &3
            MESSAGE e046(zintf_e_messages) WITH ls_object-contract
                                                ls_c01-id_prm
                                                ls_c01-date_index ''
                                           INTO lv_msg_bpem.

            lv_interface = ls_c01-id_flux .
            CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
              EXPORTING
                iv_interface_name = lv_interface
                iv_sparte         = 'ZE'
                is_structure      = ls_c01.

            macro_add_msg_to_log 'E' '046'
                                 ls_object-contract
                                 ls_c01-id_prm
                                 ls_c01-date_index ''.

            PERFORM update_ligne_c01 USING lc_statut_06_rejet.
            CONTINUE. " Passage à l'enregistrement suivant
          ELSE.

            CLEAR ls_c01_2.
            READ TABLE lt_c01_2
                  INTO ls_c01_2
              WITH KEY idenreg = ls_c01-idenreg.

            CLEAR ls_c01_3.
            READ TABLE lt_c01_3
                  INTO ls_c01_3
              WITH KEY idenreg     = ls_c01-idenreg
                       id_periode  = ls_c01_2-id_periode
                       rang_cadran = '1'.

            lv_index_cadran_1 = ls_c01_3-index_cadran.

            CLEAR ls_c01_3.
            READ TABLE lt_c01_3
                  INTO ls_c01_3
              WITH KEY idenreg     = ls_c01-idenreg
                       id_periode  = ls_c01_2-id_periode
                       rang_cadran = '2'.

            lv_index_cadran_2 = ls_c01_3-index_cadran.

            CALL FUNCTION 'ZINTF_E_DEPOSE_FIAP'
              EXPORTING
                iv_anlage      = ls_object-installation
                iv_date_depose = ls_c01-date_index
                iv_id_flux     = ls_c01-id_flux
                iv_index_cad_1 = lv_index_cadran_1
                iv_index_cad_2 = lv_index_cadran_2
                iv_nb_cadrans  = ls_c01-nb_cadrans
                iv_idenreg     = ls_c01-idenreg
                iv_id_prm      = ls_c01-id_prm
                iv_mode_test   = ''
              IMPORTING
                ev_statut      = lv_statut.

            IF lv_statut NE 1.  " Dépose non faite
* Problème dans la dépose pour l'installation &1
              MESSAGE e098(zintf_e_messages) WITH ls_object-installation
                                             INTO lv_msg_bpem.

              lv_interface = 'C01'.
              CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
                EXPORTING
                  iv_interface_name = lv_interface
                  iv_sparte         = 'ZE'
                  is_structure      = ls_c01.

              macro_add_msg_to_log 'E' '098'
                                   ls_object-installation '' '' ''.
              PERFORM update_ligne_c01 USING lc_statut_06_rejet.
              CONTINUE. " Passage à l'enregistrement suivant
            ENDIF.

          ENDIF.
        ENDIF. "Fin du cas dépose / pose
*****************************************

      ELSEIF lv_origine_index = 'W'.
****************************************
****************************************
**** Changement de puissance         ***
****************************************
****************************************

        "***** Etape 2 : Vérifier qu'il existe un contrat
        " Récupération des objets liés au POD (contrat principalement)
        CALL METHOD zcl_tool=>pod_get_related_object
          EXPORTING
            iv_int_ui = lv_int_ui
            iv_date   = ls_c01-date_abonnement
          IMPORTING
            es_detail = ls_object
            ev_sernr  = lv_sernr.

* 2.1 : Vérification de la non existence d'un contrat
        IF ls_object-contract IS INITIAL.
* PRM &1 non rattaché à un contrat actif (ID &2)
          MESSAGE e056(zintf_e_messages) WITH ls_c01-id_prm
                                              ls_c01-idenreg
                                         INTO lv_msg_bpem.

          CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
            EXPORTING
              iv_interface_name = 'C01'
              iv_sparte         = 'ZE'
              is_structure      = ls_c01.

          macro_add_msg_to_log 'E' '056'
                               ls_c01-id_prm
                               ls_c01-idenreg '' ''.
          PERFORM update_ligne_c01 USING lc_statut_06_rejet.
          CONTINUE. " Passage à l'enregistrement suivant
        ENDIF.

*4.1 : On vérifie qu'il n'y a pas de relève après la date du mvt M
        lv_date = ls_c01-date_abonnement + 1. " On prend le lendemain
        REFRESH: lt_mr_data, lt_mr_reason.
        CALL METHOD zcl_tool=>install_liste_releve
          EXPORTING
            iv_install        = ls_object-installation
            iv_date           = lv_date
          IMPORTING
            et_releves        = lt_mr_data
            et_releves_raison = lt_mr_reason.

        READ TABLE lt_mr_data INDEX 1 TRANSPORTING NO FIELDS.

        IF sy-subrc = 0. " Relève trouvée !!!
* Rejet du mouvement &1: relève présente après la &2 (ID &3)
          MESSAGE e058(zintf_e_messages) WITH ls_c01-even_declencheur
                                              'Date de changement de puissance'
                                              ls_c01-idenreg ''
                                         INTO lv_msg_bpem.

          CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
            EXPORTING
              iv_interface_name = 'C01'
              iv_sparte         = 'ZE'
              is_structure      = ls_c01.

          macro_add_msg_to_log 'E' '058'
                               ls_c01-even_declencheur
                               'Date de changement de puissance'
                               ls_c01-idenreg ''.

          PERFORM update_ligne_c01 USING lc_statut_06_rejet.
          CONTINUE. " Passage à l'enregistrement suivant
        ENDIF.

        IF ls_c01-date_resiliation IS NOT INITIAL.
* Si renseignée, c’est un enregistrement d’ancienne situation,
* pas d’information à intégrer, il peut directement passer au statut
* Type de modification &1 non gérée
          IF 1 = 2. MESSAGE e096(zintf_e_messages). ENDIF.
          macro_add_msg_to_log 'E' '096'
                               lv_origine_index '' '' ''.
          PERFORM update_ligne_c01 USING lc_statut_11_filtre.
          CONTINUE. " Passage à l'enregistrement suivant
        ENDIF.

        SELECT SINGLE kondigr
                 INTO lv_kondigr
                 FROM ettifn
                WHERE anlage  EQ ls_object-installation
                  AND operand EQ 'ERPP'
                  AND ab      LE ls_c01-date_abonnement
                  AND bis     GE ls_c01-date_abonnement.

        lv_changement_puissance = abap_false.

        LOOP AT lt_c01_2
           INTO ls_c01_2
          WHERE idenreg EQ ls_c01-idenreg.
          lv_puissance_grd     =  ls_c01_2-puissance_contrat / 10.
          lv_puissance_install =  lv_kondigr+1(2).
          IF lv_puissance_install NE lv_puissance_grd.
            lv_changement_puissance = abap_true.
          ENDIF.
        ENDLOOP.

        IF lv_changement_puissance EQ abap_true.
* Type de modification &1 non gérée
          IF 1 = 2. MESSAGE e096(zintf_e_messages). ENDIF.
          macro_add_msg_to_log 'E' '096'
                               lv_origine_index '' '' ''.
          PERFORM update_ligne_c01 USING lc_statut_11_filtre.
          CONTINUE. " Passage à l'enregistrement suivant
        ENDIF.
      ELSE.
* Type de modification &1 non gérée
        IF 1 = 2. MESSAGE e096(zintf_e_messages). ENDIF.
        macro_add_msg_to_log 'E' '096'
                             lv_origine_index '' '' ''.
        PERFORM update_ligne_c01 USING lc_statut_11_filtre.
        CONTINUE. " Passage à l'enregistrement suivant
      ENDIF.

    ENDIF. "Fin différents types événements M

***** Etape 7 : Consommation du FLUX
    ev_error = abap_false.
    PERFORM update_ligne_c01 USING lc_statut_07_integre.
  ENDLOOP. " Fin cas événement M

ENDFUNCTION.
