FUNCTION zintf_g_ctrl_or.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  FIELD-SYMBOLS:
    <fs_emetteur>,
    <fs_idenreg>,
    <fs_flux>,
    <fs_num_pce>,
    <fs_date_releve>,
    <fs_motif_releve>.

  TYPES:
    BEGIN OF ty_eabl_selected,
      equnr    TYPE equnr,
      zwnummer TYPE e_zwnummer,
      ablbelnr TYPE ablbelnr,
      adatsoll TYPE adatsoll,
      ablesgr  TYPE ablesgr,
    END   OF ty_eabl_selected.

  DATA:
    lv_field         TYPE string,
    lv_zwnummer      TYPE e_zwnummer,
    lv_message       TYPE char255,
    lv_int_ui        TYPE int_ui,
    ls_object        TYPE eedm_isu_objects,
    lt_mr_data       TYPE TABLE OF bapieabl,
    ls_mr_data       TYPE bapieabl,
    lt_mr_reason     TYPE TABLE OF bapieablg,
    ls_mr_reason     TYPE bapieablg,
    lv_return        TYPE bapireturn1,
    ls_bpem          TYPE zbpem_flux_struct,
    lv_interface     TYPE zisu_flxid,
    lt_eabl_selected TYPE TABLE OF ty_eabl_selected,
    ls_eabl_selected TYPE ty_eabl_selected,
    lt_eabl          TYPE TABLE OF eabl,
    ls_eabl          TYPE eabl,
    ls_obj           TYPE isu17_meterread,
    lt_insttab       TYPE isu17_meterdocu_insttab,
    ls_insttab       TYPE isu17_meterdocu_inst.


  CLEAR lv_field.
  MOVE 'FLUX-EMETTEUR'     TO lv_field.
  ASSIGN (lv_field)        TO <fs_emetteur>.

  CLEAR lv_field.
  MOVE 'FLUX-IDENREG'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_idenreg>.

  CLEAR lv_field.
  MOVE 'FLUX-FLUX'         TO lv_field.
  ASSIGN (lv_field)        TO <fs_flux>.

  CLEAR lv_field.
  MOVE 'FLUX-NUM_PCE'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_num_pce>.

  CLEAR lv_field.
  MOVE 'FLUX-DATE_RELEVE'  TO lv_field.
  ASSIGN (lv_field)        TO <fs_date_releve>.

  CLEAR lv_field.
  MOVE 'FLUX-MOTIF_RELEVE' TO lv_field.
  ASSIGN (lv_field)        TO <fs_motif_releve>.

  CLEAR ls_bpem.
  ls_bpem-num_pce = <fs_num_pce>.
  IF <fs_flux> = 'RE6M' OR <fs_flux> = 'RE1M'.
    ls_bpem-date_releve = <fs_date_releve>.
  ENDIF.

* Récupération du point de comptage
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).

  IF lv_int_ui IS INITIAL.
* &1 - &2 - &3 : PCE &4 inexistant
    MESSAGE e084(zintf_g_messages)
       WITH <fs_emetteur>
            <fs_flux>
            <fs_idenreg>
            <fs_num_pce>
       INTO lv_message.

    lv_interface    = <fs_flux> .
    ls_bpem-idenreg = <fs_idenreg>.
    CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
      EXPORTING
        iv_interface_name = lv_interface
        iv_sparte         = 'ZG'
        is_structure      = ls_bpem.

    RETURN.
  ENDIF.

* Récupération de l'installation à la date de relève
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object.

  IF ls_object-installation IS INITIAL.
* (ID &1) PCE &2 non rattaché à une installation active à la date du &3
    MESSAGE e044(zintf_g_messages)
       WITH <fs_idenreg>
            <fs_num_pce>
            <fs_date_releve>
       INTO lv_message.
    RETURN.
  ELSE.
*    SELECT *
**      APPENDING CORRESPONDING FIELDS OF TABLE lt_eabl
*      FROM eabl INNER JOIN eablg
*                        ON eablg~anlage EQ ls_object-installation
*                        AND eablg~adatsoll EQ <fs_date_releve>
*                        AND eabl~ablbelnr EQ eablg~ablbelnr
*      INTO CORRESPONDING FIELDS OF TABLE lt_eabl.
*
*    IF lt_eabl IS NOT INITIAL.
*      READ TABLE lt_eabl INTO ls_eabl INDEX 1.
*      lv_zwnummer = ls_eabl-zwnummer.
*    ENDIF.
  ENDIF.

* Vérification de l'existence d'un historique de relève sur le PCE
  REFRESH: lt_mr_data, lt_mr_reason.
  CALL FUNCTION 'BAPI_MTRREADDOC_GETLIST'
    EXPORTING
      installation      = ls_object-installation
      mrdocumenttype    = '1'  "Ordre de calcul de facturation
      mrreason          = '01' "Relevé périodique
      targetmrdatefrom  = <fs_date_releve>
    IMPORTING
      return            = lv_return
    TABLES
      mrdocumentdata    = lt_mr_data
      mrdocumentreasons = lt_mr_reason.

  IF lt_mr_data IS NOT INITIAL.
    CLEAR lt_eabl_selected[].
    LOOP AT lt_mr_data INTO ls_mr_data
*      WHERE register     EQ lv_zwnummer
      WHERE targetmrdate   GT <fs_date_releve>.

      READ TABLE lt_mr_reason
            INTO ls_mr_reason
        WITH KEY mridnumber = ls_mr_data-mridnumber.

      IF sy-subrc IS INITIAL.
        CLEAR ls_eabl_selected.
        ls_eabl_selected-equnr    = ls_mr_data-equipment.
        ls_eabl_selected-ablbelnr = ls_mr_data-mridnumber.
        ls_eabl_selected-adatsoll = ls_mr_data-targetmrdate.
        ls_eabl_selected-ablesgr  = ls_mr_reason-mrreason.
        APPEND ls_eabl_selected  TO lt_eabl_selected.
      ENDIF.
    ENDLOOP.

    CLEAR ls_eabl_selected.
    LOOP AT lt_eabl_selected INTO ls_eabl_selected.
      " Alimentation table interne pour appel module fonction
      CLEAR: lt_insttab[], ls_insttab.
      ls_insttab-anlage  = ls_object-installation.
      ls_insttab-ablesgr = ls_eabl_selected-ablesgr.
      APPEND ls_insttab TO lt_insttab.

* Ouverture de l'objet relève
      CALL FUNCTION 'ISU_O_METERREAD_OPEN'
        EXPORTING
          x_equnr               = ls_eabl_selected-equnr
*         x_zwnummer            = lv_zwnummer
          x_adatsoll            = ls_eabl_selected-adatsoll
          x_ablbelnr            = ls_eabl_selected-ablbelnr
          x_ablesgr             = ls_eabl_selected-ablesgr
          x_select2             = '1' "Ordres de relève
          x_wmode               = '6' "Annulation
          x_no_dialog           = 'X'
          x_upd_online          = 'X'
          x_no_enqueue          = 'X'
        IMPORTING
          y_obj                 = ls_obj
        TABLES
          xt_insttab            = lt_insttab
        EXCEPTIONS
          not_found             = 1
          foreign_lock          = 2
          internal_error        = 3
          input_error           = 4
          existing              = 5
          number_error          = 6
          general_fault         = 7
          system_error          = 8
          manual_abort          = 9
          gasdat_not_found      = 10
          no_mrrel_registers    = 11
          internal_warning      = 12
          not_authorized        = 13
          not_qualified         = 14
          anpstorno_not_allowed = 15
          already_billed        = 16
          OTHERS                = 99.
      IF NOT sy-subrc IS INITIAL.
        " Annulation OR impossible
        RETURN.
      ENDIF.

      " Préparation de l'annulation des ordres de relevés
      CALL FUNCTION 'ISU_O_METERREAD_ACTION'
        EXPORTING
          x_okcode             = 'PSAV'
        CHANGING
          xy_obj               = ls_obj
        EXCEPTIONS
          cancelled            = 1
          failed               = 2
          action_not_supported = 3
          system_error         = 4
          input_error          = 5
          not_customized       = 6
*         error_message        = 7
          OTHERS               = 99.
      IF NOT sy-subrc IS INITIAL.
        "Annulation OR impossible
        RETURN.
      ENDIF.

      "* Suppression des ordres de relevés
      CALL FUNCTION 'ISU_O_METERREAD_ACTION'
        EXPORTING
          x_okcode             = 'SAVE'
        CHANGING
          xy_obj               = ls_obj
        EXCEPTIONS
          cancelled            = 1
          failed               = 2
          action_not_supported = 3
          system_error         = 4
          input_error          = 5
          not_customized       = 6
          OTHERS               = 99.
      IF NOT sy-subrc IS INITIAL.
        "Annulation OR impossible
        RETURN.
      ENDIF.

      CALL FUNCTION 'ISU_O_METERREAD_CLOSE'
        EXPORTING
          x_no_dialog = 'X'
        CHANGING
          xy_obj      = ls_obj
        EXCEPTIONS
          OTHERS      = 99.
      IF NOT sy-subrc IS INITIAL.
        "Annulation OR impossible
        RETURN.
      ENDIF.
    ENDLOOP.
  ENDIF.

  ev_etape = 1.

ENDFUNCTION.
