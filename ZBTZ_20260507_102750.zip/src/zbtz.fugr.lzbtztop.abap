* regenerated at 17.04.2019 18:21:36
FUNCTION-POOL ZBTZ                       MESSAGE-ID SV.

* INCLUDE LZBTZD...                          " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZBTZT00                                . "view rel. data dcl.
