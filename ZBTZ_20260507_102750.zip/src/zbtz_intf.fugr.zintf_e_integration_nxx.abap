FUNCTION zintf_e_integration_nxx.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_IDENREG) TYPE  ZIDENREG
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN DEFAULT ABAP_FALSE
*"     REFERENCE(IV_ID_FLUX) TYPE  ZID_FLUX
*"  EXPORTING
*"     REFERENCE(EV_ERROR) TYPE  CRMT_BOOLEAN
*"----------------------------------------------------------------------

  CLEAR ev_error.
  lv_log_object    = lc_log_object_intf_elec.
  lv_msgid         = lc_msgid_intf_elec.

  IF  iv_id_flux = 'N15'.
    lv_log_subobject = lc_log_subobject_n15.
  ENDIF.

  CLEAR lv_log_handle.

* Appel en mode &1 pour le flux &2
  IF 1 = 2. MESSAGE i018(zintf_e_messages). ENDIF.
  IF iv_mode_test IS INITIAL.
    macro_add_msg_to_log 'I' '018'
                         'REEL' iv_id_flux '' ''.
  ELSE.
    macro_add_msg_to_log 'I' '018'
                         'TEST' iv_id_flux '' ''.
  ENDIF.

  IF  iv_id_flux = 'N15'.
    CLEAR ls_nxx.
    SELECT SINGLE *
      INTO CORRESPONDING FIELDS OF ls_nxx
      FROM zintf_e_n15
      WHERE idenreg EQ iv_idenreg.

    lv_statut_flux = ls_nxx-statut.

    REFRESH lt_nxx_3.
    SELECT *
      INTO CORRESPONDING FIELDS OF TABLE lt_nxx_3
      FROM zintf_e_n15_3
      WHERE idenreg EQ iv_idenreg
      ORDER BY idenreg
              rang_cad.

    REFRESH lt_nxx_3b.
    SELECT *
      INTO CORRESPONDING FIELDS OF TABLE lt_nxx_3b
      FROM zintf_e_n15_3b
      WHERE idenreg EQ iv_idenreg
      ORDER BY idenreg
               rang_cad.
  ENDIF.

*--STOU DEBUT GE-1255
*  "Contrôler si c'est un B2C
*  CLEAR lv_b2c .
*  ls_ext_ui-ext_ui = ls_nxx-id_prm  .
*  APPEND ls_ext_ui TO lt_ext_ui .
*  CALL METHOD zcl_tool=>get_ext_ui_type
*    CHANGING
*      ct_ext_ui = lt_ext_ui.
*
*  CLEAR ls_ext_ui .
*  READ TABLE lt_ext_ui INTO ls_ext_ui INDEX 1.
*  IF ls_ext_ui-type = 'B2C' OR ls_ext_ui-bukrs = 'GDP2'.
*    lv_b2c = 'X' .
*  ENDIF.
*
** Récupération du numéro de l'installation
*  lv_int_ui = zcl_tool=>pod_check_exist(
*                           iv_pce_num = ls_nxx-id_prm ).
*  CLEAR : ls_object, lv_anlage .
*  CALL METHOD zcl_tool=>pod_get_related_object
*    EXPORTING
*      iv_int_ui = lv_int_ui
*      iv_date   = ls_nxx-date_releve
*    IMPORTING
*      es_detail = ls_object
*      ev_equnr  = lv_equnr
*      ev_sernr  = lv_sernr.
*
*  lv_anlage = ls_object-installation.
*  INSERT lv_anlage INTO TABLE lt_anlage .
*--STOU FIN   GE-1255
  IF iv_id_flux = 'N15'.
    CASE ls_nxx-niv_service .
      WHEN 0 OR 1.
*++STOU DEBUT GE-1255
*        PERFORM processus_depose_appareil CHANGING ev_error .
        PERFORM processus_releve_a_filtrer CHANGING ev_error.
        PERFORM update_ligne_releve_n USING lc_statut_11_filtre.
        RETURN.
*++STOU DEBUT GE-1255
      WHEN 2.
        PERFORM processus_releve_a_filtrer CHANGING ev_error.
        PERFORM update_ligne_releve_n USING lc_statut_11_filtre.
        RETURN.
      WHEN OTHERS.
    ENDCASE.
  ENDIF.


  IF ev_error EQ abap_false.
    PERFORM update_ligne_releve_n USING lc_statut_07_integre.
  ENDIF.

  COMMIT WORK AND WAIT .

ENDFUNCTION.
