*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZNOM_PAIEMENT
*   generation date: 22.07.2017 at 13:06:49
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZNOM_PAIEMENT       .

  PERFORM TABLEPROC.

ENDFUNCTION.
