*----------------------------------------------------------------------*
***INCLUDE LFKCIF02 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  CALL_ZP_FB_6261
*&---------------------------------------------------------------------*
form call_zp_fb_6261
     using
       p_inkgp          type inkgp_kk
       p_gpart          type gpart_kk
     changing
       pt_collpaym      type fkkcollpaym_tab
       pt_collpaymlink  type fkkcollpaymlink_tab
       p_flg_error      type xfeld.

  data: i_fbstab      like tfkfbc occurs 0 with header line,
        h_applk       type applk_kk.

  data lt_collitemhier  type fkkcollitemhier_tab.
  data ls_collitemhier  type fkkcollitemhier.
  data ls_collpaym      type fkkcollpaym.
  data ls_collpaym_out  type fkkcollpaym_out.
  data lt_collpaym_out  type fkkcollpaym_out_tab.
  data ls_collpaymlink  type fkkcollpaymlink.
  data ls_collpaymlink_out  type fkkcollpaymlink_out.
  data lt_collpaymlink_out  type fkkcollpaymlink_out_tab.

  field-symbols <fs_collpaym>          type fkkcollpaym.
  field-symbols <fs_collpaym_out>      type fkkcollpaym_out.
  field-symbols <fs_collpaymlink>      type fkkcollpaymlink.
  field-symbols <fs_collpaymlink_out>  type fkkcollpaymlink_out.

  clear p_flg_error.

  call function 'FKK_GET_APPLICATION'
    exporting
      i_no_dialog      = 'X'
    importing
      e_applk          = h_applk
    exceptions
      no_appl_selected = 1
      others           = 2.
  if sy-subrc <> 0.
    call function 'FKK_AKTIV2_APPL_LOG_MSG'
      exporting
        i_msgty                  = 'E'
        i_msgid                  = sy-msgid
        i_msgno                  = sy-msgno
        i_msgv1                  = sy-msgv1
        i_msgv2                  = sy-msgv2
        i_msgv3                  = sy-msgv3
        i_msgv4                  = sy-msgv4
        i_probclass_this_message = '1'.
    p_flg_error = 'X'.
    return.
  endif.

  call function 'FKK_FUNC_MODULE_DETERMINE'
    exporting
      i_applk  = h_applk
      i_fbeve  = '6261'
    tables
      t_fbstab = i_fbstab.

* fill tables for event
  loop at pt_collpaym assigning <fs_collpaym>.
    clear ls_collpaym_out.
    move-corresponding <fs_collpaym> to ls_collpaym_out.
    append ls_collpaym_out to lt_collpaym_out.
  endloop.
  loop at pt_collpaymlink assigning <fs_collpaymlink>.
    clear ls_collpaymlink_out.
    move-corresponding <fs_collpaymlink> to ls_collpaymlink_out.
    append ls_collpaymlink_out to lt_collpaymlink_out.
  endloop.

* get hierarchy
  call function 'FKK_COLL_HIERARCHY_GET'
    exporting
      i_inkgp                    = p_inkgp
      i_gpart                    = p_gpart
    importing
      et_fkkcollitemhier         = lt_collitemhier
    exceptions
      ex_inconsistent_hierarchy  = 1
      ex_wrong_import_parameters = 2
      others                     = 3.
  if sy-subrc <> 0.
    call function 'FKK_AKTIV2_APPL_LOG_MSG'
      exporting
        i_msgty                  = 'E'
        i_msgid                  = sy-msgid
        i_msgno                  = sy-msgno
        i_msgv1                  = sy-msgv1
        i_msgv2                  = sy-msgv2
        i_msgv3                  = sy-msgv3
        i_msgv4                  = sy-msgv4
        i_probclass_this_message = '2'.
    p_flg_error = 'X'.
    return.
  endif.

  sort lt_collitemhier by collitem_id collitem_lv.

  loop at i_fbstab.
    call function i_fbstab-funcc
      exporting
        i_inkgp             = p_inkgp
        i_gpart             = p_gpart
        it_fkkcollitemhier  = lt_collitemhier
      changing
        ct_collpaym_out     = lt_collpaym_out
        ct_collpaymlink_out = lt_collpaymlink_out.
  endloop.
  set extended check off.
  if 1 = 2. call function 'FKK_SAMPLE_6261'. endif.
  set extended check on.


* check collection payment output and fill target structure
  sort pt_collpaym.

  loop at lt_collpaym_out assigning <fs_collpaym_out>.

* check INKGP
    if <fs_collpaym_out>-inkgp <> p_inkgp.
      call function 'FKK_AKTIV2_APPL_LOG_MSG'
        exporting
          i_msgty                  = 'E'
          i_msgid                  = 'FKKCOLL'
          i_msgno                  = '030'
          i_probclass_this_message = '2'.
      set extended check off.
      if 1 = 2. message e030(fkkcoll). endif.
      set extended check on.

      p_flg_error = 'X'.
      return.
    endif.

* check GPART
    if <fs_collpaym_out>-gpart <> p_gpart.
      call function 'FKK_AKTIV2_APPL_LOG_MSG'
        exporting
          i_msgty                  = 'E'
          i_msgid                  = 'FKKCOLL'
          i_msgno                  = '031'
          i_probclass_this_message = '2'.
      set extended check off.
      if 1 = 2. message e031(fkkcoll). endif.
      set extended check on.

      p_flg_error = 'X'.
      return.
    endif.

* check whether collection payment ID has been changed
    read table pt_collpaym assigning <fs_collpaym>
      with key collpaym_id = <fs_collpaym_out>-collpaym_id
               collpaym_tp = <fs_collpaym_out>-collpaym_tp
      binary search.

    if sy-subrc = 0.
      move-corresponding <fs_collpaym_out> to <fs_collpaym>.
    else.
      call function 'FKK_AKTIV2_APPL_LOG_MSG'
        exporting
          i_msgty                  = 'E'
          i_msgid                  = 'FKKCOLL'
          i_msgno                  = '033'
          i_probclass_this_message = '2'.
      set extended check off.
      if 1 = 2. message e033(fkkcoll). endif.
      set extended check on.

      p_flg_error = 'X'.
      return.
    endif.

  endloop.

* check collection payment assignment output and fill target structure
  refresh pt_collpaymlink.
  loop at lt_collpaymlink_out assigning <fs_collpaymlink_out>.

* check INKGP
    if <fs_collpaymlink_out>-inkgp <> p_inkgp.
      call function 'FKK_AKTIV2_APPL_LOG_MSG'
        exporting
          i_msgty                  = 'E'
          i_msgid                  = 'FKKCOLL'
          i_msgno                  = '030'
          i_probclass_this_message = '2'.
      set extended check off.
      if 1 = 2. message e030(fkkcoll). endif.
      set extended check on.

      p_flg_error = 'X'.
      return.
    endif.

* check GPART
    if <fs_collpaymlink_out>-gpart <> p_gpart.
      call function 'FKK_AKTIV2_APPL_LOG_MSG'
        exporting
          i_msgty                  = 'E'
          i_msgid                  = 'FKKCOLL'
          i_msgno                  = '031'
          i_probclass_this_message = '2'.
      set extended check off.
      if 1 = 2. message e031(fkkcoll). endif.
      set extended check on.

      p_flg_error = 'X'.
      return.
    endif.

* check if collection unit is defined
    read table lt_collitemhier into ls_collitemhier
       with key collitem_id = <fs_collpaymlink_out>-collitem_id
                collitem_lv = <fs_collpaymlink_out>-collitem_lv
                binary search.
    if sy-subrc <> 0.
      call function 'FKK_AKTIV2_APPL_LOG_MSG'
        exporting
          i_msgty                  = 'E'
          i_msgid                  = 'FKKCOLL'
          i_msgno                  = '032'
          i_probclass_this_message = '2'
          i_msgv1                  = <fs_collpaymlink_out>-collitem_id
          i_msgv2                  = <fs_collpaymlink_out>-collitem_lv.
      set extended check off.
      if 1 = 2. message e032(fkkcoll). endif.
      set extended check on.

      p_flg_error = 'X'.
      return.
    endif.

    clear ls_collpaymlink.
    move-corresponding <fs_collpaymlink_out> to ls_collpaymlink.

    append ls_collpaymlink to pt_collpaymlink.

  endloop.

endform.                    " CALL_ZP_FB_6261
*&---------------------------------------------------------------------*
*&      Form  CALL_ZP_FB_6262
*&---------------------------------------------------------------------*
form call_zp_fb_6262
     using
       p_inkgp           type inkgp_kk
       p_gpart           type gpart_kk
     changing
       p_collections_out type fkkcollections_out.

  data: i_fbstab      like tfkfbc occurs 0 with header line,
        h_applk       type applk_kk.

  call function 'FKK_GET_APPLICATION'
    exporting
      i_no_dialog      = 'X'
    importing
      e_applk          = h_applk
    exceptions
      no_appl_selected = 1
      others           = 2.
  if sy-subrc <> 0.
    call function 'FKK_AKTIV2_APPL_LOG_MSG'
      exporting
        i_msgty                  = 'E'
        i_msgid                  = sy-msgid
        i_msgno                  = sy-msgno
        i_msgv1                  = sy-msgv1
        i_msgv2                  = sy-msgv2
        i_msgv3                  = sy-msgv3
        i_msgv4                  = sy-msgv4
        i_probclass_this_message = '1'.
  endif.

  call function 'FKK_FUNC_MODULE_DETERMINE'
    exporting
      i_applk  = h_applk
      i_fbeve  = '6262'
    tables
      t_fbstab = i_fbstab.
* ------ for cross reference purpose only -----------------------------*
  set extended check off.
  if 1 = 2. call function 'FKK_SAMPLE_6262'. endif.
  set extended check on.
* ------ end of cross reference ---------------------------------------*
  loop at i_fbstab.
    call function i_fbstab-funcc
      exporting
        i_inkgp           = p_inkgp
        i_gpart           = p_gpart
      importing
        e_collbp_out_fpci = p_collections_out-collbp_out
      exceptions
        others            = 1.
  endloop.
* fill collection agency and business partner
  p_collections_out-collbp_out-inkgp = p_inkgp.
  p_collections_out-collbp_out-gpart = p_gpart.

endform.                    " CALL_ZP_FB_6262
*&---------------------------------------------------------------------*
*&      Form  CALL_ZP_FB_6269
*&---------------------------------------------------------------------*
form call_zp_fb_6269
     using
       p_inkgp          type inkgp_kk
       p_gpart          type gpart_kk
     changing
       pt_collitem  type fkkcollitem_tab
       p_flg_error      type xfeld.

  data: i_fbstab      like tfkfbc occurs 0 with header line,
        h_applk       type applk_kk.

  data ls_collitem_inf  type fkkcollitem_inf.
  data lt_collitem_inf  type fkkcollitem_inf_tab.
  data lt_collitemhier  type fkkcollitemhier_tab.
  data ls_collitemhier  type fkkcollitemhier.
  data ls_collitem  type fkkcollitem.

  field-symbols <fs_collitem>    type fkkcollitem.
  field-symbols <fs_collitem_inf>    type fkkcollitem_inf.

  clear p_flg_error.

  call function 'FKK_GET_APPLICATION'
    exporting
      i_no_dialog      = 'X'
    importing
      e_applk          = h_applk
    exceptions
      no_appl_selected = 1
      others           = 2.
  if sy-subrc <> 0.
    call function 'FKK_AKTIV2_APPL_LOG_MSG'
      exporting
        i_msgty                  = 'E'
        i_msgid                  = sy-msgid
        i_msgno                  = sy-msgno
        i_msgv1                  = sy-msgv1
        i_msgv2                  = sy-msgv2
        i_msgv3                  = sy-msgv3
        i_msgv4                  = sy-msgv4
        i_probclass_this_message = '1'.
    p_flg_error = 'X'.
    return.
  endif.

  call function 'FKK_FUNC_MODULE_DETERMINE'
    exporting
      i_applk  = h_applk
      i_fbeve  = '6269'
    tables
      t_fbstab = i_fbstab.

* fill table for event
  loop at pt_collitem assigning <fs_collitem>.
    clear ls_collitem_inf.
    move-corresponding <fs_collitem> to ls_collitem_inf.
    append ls_collitem_inf to lt_collitem_inf.
  endloop.

* get hierarchy
  call function 'FKK_COLL_HIERARCHY_GET'
    exporting
      i_inkgp                    = p_inkgp
      i_gpart                    = p_gpart
    importing
      et_fkkcollitemhier         = lt_collitemhier
    exceptions
      ex_inconsistent_hierarchy  = 1
      ex_wrong_import_parameters = 2
      others                     = 3.
  if sy-subrc <> 0.
    call function 'FKK_AKTIV2_APPL_LOG_MSG'
      exporting
        i_msgty                  = 'E'
        i_msgid                  = sy-msgid
        i_msgno                  = sy-msgno
        i_msgv1                  = sy-msgv1
        i_msgv2                  = sy-msgv2
        i_msgv3                  = sy-msgv3
        i_msgv4                  = sy-msgv4
        i_probclass_this_message = '2'.
    p_flg_error = 'X'.
    return.
  endif.

  sort lt_collitemhier by collitem_id collitem_lv.

  loop at i_fbstab.
    call function i_fbstab-funcc
      exporting
        i_inkgp            = p_inkgp
        i_gpart            = p_gpart
        it_fkkcollitemhier = lt_collitemhier
      changing
        ct_collitem_inf    = lt_collitem_inf.
  endloop.
  set extended check off.
  if 1 = 2. call function 'FKK_SAMPLE_6269'. endif.
  set extended check on.

* check output and fill target structure
  refresh pt_collitem.
  loop at lt_collitem_inf assigning <fs_collitem_inf>.

* check INKGP
    if <fs_collitem_inf>-inkgp <> p_inkgp.
      call function 'FKK_AKTIV2_APPL_LOG_MSG'
        exporting
          i_msgty                  = 'E'
          i_msgid                  = 'FKKCOLL'
          i_msgno                  = '030'
          i_probclass_this_message = '2'.
      set extended check off.
      if 1 = 2. message e030(fkkcoll). endif.
      set extended check on.

      p_flg_error = 'X'.
      return.
    endif.

* check GPART
    if <fs_collitem_inf>-gpart <> p_gpart.
      call function 'FKK_AKTIV2_APPL_LOG_MSG'
        exporting
          i_msgty                  = 'E'
          i_msgid                  = 'FKKCOLL'
          i_msgno                  = '031'
          i_probclass_this_message = '2'.
      set extended check off.
      if 1 = 2. message e031(fkkcoll). endif.
      set extended check on.

      p_flg_error = 'X'.
      return.
    endif.

* check if collection unit is defined
    read table lt_collitemhier into ls_collitemhier
       with key collitem_id = <fs_collitem_inf>-collitem_id
                collitem_lv = <fs_collitem_inf>-collitem_lv
       binary search.
    if sy-subrc <> 0.
      call function 'FKK_AKTIV2_APPL_LOG_MSG'
        exporting
          i_msgty                  = 'E'
          i_msgid                  = 'FKKCOLL'
          i_msgno                  = '032'
          i_probclass_this_message = '2'
          i_msgv1                  = <fs_collitem_inf>-collitem_id
          i_msgv2                  = <fs_collitem_inf>-collitem_lv.
      set extended check off.
      if 1 = 2. message e032(fkkcoll). endif.
      set extended check on.

      p_flg_error = 'X'.
      return.
    endif.

    clear ls_collitem.
    move-corresponding <fs_collitem_inf> to ls_collitem.

    append ls_collitem to pt_collitem.

  endloop.

endform.                    " CALL_ZP_FB_6269
*&---------------------------------------------------------------------*
*&      Form  COLLECTIONS_PACKAGE_PROCESS
*&---------------------------------------------------------------------*
form collections_package_process
     using
       p_xsimu              type xfeld
     changing
       pt_collections_out   type fkkcollections_out_tab
       pt_collitem          type fkkcollitem_tab
       pt_collpaym          type fkkcollpaym_tab
       pt_collpaymlink      type fkkcollpaymlink_tab
       pt_coli_log          type fkkcoli_log_tab
       pt_postyp_sum        type fkkcol_postyp_sum_tab
       pv_cnt_services      type i
       pv_cnt_services_error type i
       pv_success_num       type i.

  data ls_collitem       type fkkcollitem.
  data ls_collpaym       type fkkcollpaym.
  data ls_collpaymlink   type fkkcollpaymlink.

  data lv_xiguid             type guidxi_kk.
  data lv_flg_service_error  type xfeld.
  data lv_flg_db_error       type xfeld.

  data lx_lines       type i.

  field-symbols <fs_collections_out> type fkkcollections_out.

  if p_xsimu is initial.

* call outbound service
    call function 'FKK_COLL_SERVICE_REQUEST'
      exporting
        it_collections_out = pt_collections_out
      importing
        e_xiguid           = lv_xiguid
      exceptions
        service_failed     = 1
        others             = 2.

    if sy-subrc = 0.
      clear lv_flg_service_error.
    else.
      lv_flg_service_error = 'X'.
      call function 'FKK_AKTIV2_APPL_LOG_MSG'
        exporting
          i_msgty                  = 'E'
          i_msgid                  = sy-msgid
          i_msgno                  = sy-msgno
          i_msgv1                  = sy-msgv1
          i_msgv2                  = sy-msgv2
          i_msgv3                  = sy-msgv3
          i_msgv4                  = sy-msgv4
          i_probclass_this_message = '1'.
    endif.

* update DB
    if lv_flg_service_error is initial.

      clear lv_flg_db_error.

* set xi guid
      clear ls_collitem.
      ls_collitem-xiguid = lv_xiguid.
      modify pt_collitem from ls_collitem transporting xiguid where xiguid is initial.
      clear ls_collpaym.
      ls_collpaym-xiguid = lv_xiguid.
      modify pt_collpaym from ls_collpaym transporting xiguid where xiguid is initial.
      clear ls_collpaymlink.
      ls_collpaymlink-xiguid = lv_xiguid.
      modify pt_collpaymlink from ls_collpaymlink transporting xiguid where xiguid is initial.

* insert collection item information
      insert dfkkcollitem from table pt_collitem.           "#EC ENHOK

      if sy-subrc <> 0.
        lv_flg_db_error = 'X'.
        call function 'FKK_AKTIV2_APPL_LOG_MSG'
          exporting
            i_msgty                  = 'E'
            i_msgid                  = '>3'
            i_msgno                  = '844'
            i_msgv1                  = 'DFKKCOLLITEM'
            i_probclass_this_message = '1'.
        set extended check off.
        if 1 = 2. message e844(>3) with 'DFKKCOLLITEM'. endif.
        set extended check on.
      endif.

* insert collection payment information
      insert dfkkcollpaym from table pt_collpaym.           "#EC ENHOK

      if sy-subrc <> 0.
        lv_flg_db_error = 'X'.
        call function 'FKK_AKTIV2_APPL_LOG_MSG'
          exporting
            i_msgty                  = 'E'
            i_msgid                  = '>3'
            i_msgno                  = '844'
            i_msgv1                  = 'DFKKCOLLPAYM'
            i_probclass_this_message = '1'.
        set extended check off.
        if 1 = 2. message e844(>3) with 'DFKKCOLLPAYM'. endif.
        set extended check on.
      endif.

* insert collection payment information
      insert dfkkcollpaymlink from table pt_collpaymlink.   "#EC ENHOK

      if sy-subrc <> 0.
        lv_flg_db_error = 'X'.
        call function 'FKK_AKTIV2_APPL_LOG_MSG'
          exporting
            i_msgty                  = 'E'
            i_msgid                  = '>3'
            i_msgno                  = '844'
            i_msgv1                  = 'DFKKCOLLPAYMLINK'
            i_probclass_this_message = '1'.
        set extended check off.
        if 1 = 2. message e844(>3) with 'DFKKCOLLPAYMLINK'. endif.
        set extended check on.
      endif.

* update DFKKCOLI_LOG
      insert dfkkcoli_log from table pt_coli_log.

      if sy-subrc <> 0.
        lv_flg_db_error = 'X'.
        call function 'FKK_AKTIV2_APPL_LOG_MSG'
          exporting
            i_msgty                  = 'E'
            i_msgid                  = '>3'
            i_msgno                  = '844'
            i_msgv1                  = 'DFKKCOLI_LOG'
            i_probclass_this_message = '1'.
        set extended check off.
        if 1 = 2. message e844(>3) with 'DFKKCOLI_LOG'. endif.
        set extended check on.
      endif.

    endif.

    loop at pt_collections_out assigning <fs_collections_out>.
* DEQUEUE for GPART and INKGP
      call function 'DEQUEUE_E_COLLITEM'
        exporting
          mode_fkk_enq_collitem = 'E'
          mandt                 = sy-mandt
          inkgp                 = <fs_collections_out>-inkgp
          gpart                 = <fs_collections_out>-gpart.
    endloop.

* commit work/rollback work
    if lv_flg_db_error is initial and lv_flg_service_error is initial.

      lx_lines = lines( pt_collections_out ).
      add lx_lines to pv_success_num.

      add 1 to pv_cnt_services.

* messages
      perform msg_log_amounts_sum
                  using
                     p_xsimu
                     lv_xiguid
                     pt_postyp_sum.

      commit work.

    else.

      add 1 to pv_cnt_services_error.

      rollback work.

    endif.

  else.
* simulation run: just display messages

    perform msg_log_amounts_sum
                using
                   p_xsimu
                   lv_xiguid
                   pt_postyp_sum.

  endif.

* refresh
  refresh pt_collections_out.
  refresh pt_collitem.
  refresh pt_collpaym.
  refresh pt_collpaymlink.
  refresh pt_coli_log.
  refresh pt_postyp_sum.

endform.                    " COLLECTIONS_PACKAGE_PROCESS
*&---------------------------------------------------------------------*
*&      Form  collections_package_prepare
*&---------------------------------------------------------------------*
form collections_package_prepare
     using
       p_basics            type fkk_mad_basics
     changing
       ps_collections      type fkkcollections
       pt_collections_out  type fkkcollections_out_tab
       pt_collitem         type fkkcollitem_tab
       pt_collpaym         type fkkcollpaym_tab
       pt_collpaymlink     type fkkcollpaymlink_tab
       pt_coli_log         type fkkcoli_log_tab
       pt_postyp_sum       type fkkcol_postyp_sum_tab.

  data ls_collitem         type fkkcollitem.
  data ls_collpaym         type fkkcollpaym.
  data ls_collpaymlink     type fkkcollpaymlink.
  data ls_collections_out  type fkkcollections_out.
  data ls_collitem_out  type fkkcollitem_out.
  data ls_collpaym_out  type fkkcollpaym_out.
  data ls_collpaymlink_out  type fkkcollpaymlink_out.

  data lv_collitem_id_prev  type collitem_id_kk.
  data lv_collitem_lv_prev  type collitem_lv_kk.
  data lv_collpaym_id_prev  type collpaym_id_kk.
  data lv_collpaym_tp_prev  type collpaym_tp_kk.

  data lx_lfdnr type n length 2.

  data lv_collitem     TYPE fkkcollitem.
  data lv_collpaym     TYPE fkkcollpaym.
  data lv_collpaymlink TYPE fkkcollpaymlink.
  data lv_check_dup    type boole_d.

  field-symbols <fs_collitem>     type fkkcollitem.
  field-symbols <fs_collpaym>     type fkkcollpaym.
  field-symbols <fs_collpaymlink> type fkkcollpaymlink.
  field-symbols <fs_coli_log_ext> type gty_fkkcoli_log_ext.


* build table for collection unit DB update
  sort ps_collections-collitem_tab by collitem_id collitem_lv.

  loop at ps_collections-collitem_tab assigning <fs_collitem>.

    clear ls_collitem.
    move-corresponding <fs_collitem> to ls_collitem.

    ls_collitem-prcst = '02'. " outbound sent
    ls_collitem-sddat = sy-datum.
    ls_collitem-aenam = sy-uname.
    ls_collitem-acpdt = sy-datum.
    ls_collitem-acptm = sy-uzeit.
    ls_collitem-laufd = p_basics-runkey-laufd.
    ls_collitem-laufi = p_basics-runkey-laufi.

    if lv_collitem_id_prev = ls_collitem-collitem_id and
       lv_collitem_lv_prev = ls_collitem-collitem_lv.
      if lx_lfdnr = '99' and lv_check_dup is initial.
        lv_check_dup = c_marked.
      endif.
      lx_lfdnr = lx_lfdnr + 1.
    else.
      clear lv_check_dup.
      lx_lfdnr = '00'.
    endif.
    lv_collitem_id_prev = ls_collitem-collitem_id.
    lv_collitem_lv_prev = ls_collitem-collitem_lv.

    concatenate ls_collitem-acpdt ls_collitem-acptm lx_lfdnr into ls_collitem-tspnr.

*>>> Note 1722318
    IF lv_check_dup = c_marked.
      READ TABLE pt_collitem
                 WITH KEY inkgp          = ls_collitem-inkgp
                          collitem_id    = ls_collitem-collitem_id
                          collitem_lv    = ls_collitem-collitem_lv
                          tspnr          = ls_collitem-tspnr
                          INTO lv_collitem.
      IF sy-subrc = 0.
*     line already exists
*     try to insert a higher tspnr
        DO 98 TIMES.
          add '001' to ls_collitem-tspnr+11(3). "simply add 001 to the time
          READ TABLE pt_collitem
                     WITH KEY inkgp          = ls_collitem-inkgp
                              collitem_id    = ls_collitem-collitem_id
                              collitem_lv    = ls_collitem-collitem_lv
                              tspnr          = ls_collitem-tspnr
                              INTO lv_collitem.
          IF sy-subrc <> 0.
            EXIT.
          ENDIF.
        ENDDO.
      ENDIF.
    ENDIF.
*<<< Note 1722318

    append ls_collitem to pt_collitem.

  endloop.

  clear lv_check_dup.

* build table for collection payment DB update
  sort ps_collections-collpaym_tab by collpaym_id collpaym_tp.

  loop at ps_collections-collpaym_tab assigning <fs_collpaym>.

    clear ls_collpaym.
    move-corresponding <fs_collpaym> to ls_collpaym.

    ls_collpaym-prcst = '02'. " outbound sent
    ls_collpaym-sddat = sy-datum.
    ls_collpaym-aenam = sy-uname.
    ls_collpaym-acpdt = sy-datum.
    ls_collpaym-acptm = sy-uzeit.
    ls_collpaym-laufd = p_basics-runkey-laufd.
    ls_collpaym-laufi = p_basics-runkey-laufi.

    if lv_collpaym_id_prev = ls_collpaym-collpaym_id and
       lv_collpaym_tp_prev = ls_collpaym-collpaym_tp.
      if lx_lfdnr = '99' and lv_check_dup is initial.
        lv_check_dup = c_marked.
      endif.
      lx_lfdnr = lx_lfdnr + 1.
    else.
      clear lv_check_dup.
      lx_lfdnr = '00'.
    endif.
    lv_collpaym_id_prev = ls_collpaym-collpaym_id.
    lv_collpaym_tp_prev = ls_collpaym-collpaym_tp.

    concatenate ls_collpaym-acpdt ls_collpaym-acptm lx_lfdnr into ls_collpaym-tspnr.

*>>> Note 1722318
    IF lv_check_dup = c_marked.
      READ TABLE pt_collpaym
                 WITH KEY inkgp          = ls_collpaym-inkgp
                          collpaym_id    = ls_collpaym-collpaym_id
                          collpaym_tp    = ls_collpaym-collpaym_tp
                          tspnr          = ls_collpaym-tspnr
                          INTO lv_collpaym.
      IF sy-subrc = 0.
*     line already exists
*     try to insert a higher tspnr
        DO 98 TIMES.
          add '001' to ls_collpaym-tspnr+11(3). "simply add 001 to the time
          READ TABLE pt_collpaym
                     WITH KEY inkgp          = ls_collpaym-inkgp
                              collpaym_id    = ls_collpaym-collpaym_id
                              collpaym_tp    = ls_collpaym-collpaym_tp
                              tspnr          = ls_collpaym-tspnr
                              INTO lv_collpaym.

          IF sy-subrc <> 0.
            EXIT.
          ENDIF.
        ENDDO.
      ENDIF.
    ENDIF.
*<<< Note 1722318

    append ls_collpaym to pt_collpaym.

  endloop.

  clear lv_check_dup.

* build table for collection payment assignment DB update
  sort ps_collections-collpaymlink_tab by collpaym_id collpaym_tp.

  loop at ps_collections-collpaymlink_tab assigning <fs_collpaymlink>.

    clear ls_collpaymlink.
    move-corresponding <fs_collpaymlink> to ls_collpaymlink.

    ls_collpaymlink-prcst = '02'. " outbound sent
    ls_collpaymlink-sddat = sy-datum.
    ls_collpaymlink-aenam = sy-uname.
    ls_collpaymlink-acpdt = sy-datum.
    ls_collpaymlink-acptm = sy-uzeit.
    ls_collpaymlink-laufd = p_basics-runkey-laufd.
    ls_collpaymlink-laufi = p_basics-runkey-laufi.

    if lv_collpaym_id_prev = ls_collpaymlink-collpaym_id and
       lv_collpaym_tp_prev = ls_collpaymlink-collpaym_tp.
      if lx_lfdnr = '99' and lv_check_dup is initial.
        lv_check_dup = c_marked.
      endif.
      lx_lfdnr = lx_lfdnr + 1.
    else.
      clear lv_check_dup.
      lx_lfdnr = '00'.
    endif.
    lv_collpaym_id_prev = ls_collpaymlink-collpaym_id.
    lv_collpaym_tp_prev = ls_collpaymlink-collpaym_tp.

    concatenate ls_collpaymlink-acpdt ls_collpaymlink-acptm lx_lfdnr into ls_collpaymlink-tspnr.

*>>> Note 1722318
    IF lv_check_dup = c_marked.
      READ TABLE pt_collpaymlink
                 WITH KEY inkgp          = ls_collpaymlink-inkgp
                          collpaym_id    = ls_collpaymlink-collpaym_id
                          collpaym_tp    = ls_collpaymlink-collpaym_tp
                          tspnr          = ls_collpaymlink-tspnr
                          INTO lv_collpaymlink.
      IF sy-subrc = 0.
*     line already exists
*     try to insert a higher tspnr
        DO 98 TIMES.
          add '001' to ls_collpaymlink-tspnr+11(3). "simply add 001 to the time
          READ TABLE pt_collpaymlink
                     WITH KEY inkgp          = ls_collpaymlink-inkgp
                              collpaym_id    = ls_collpaymlink-collpaym_id
                              collpaym_tp    = ls_collpaymlink-collpaym_tp
                              tspnr          = ls_collpaymlink-tspnr
                              INTO lv_collpaymlink.

          IF sy-subrc <> 0.
            EXIT.
          ENDIF.
        ENDDO.
      ENDIF.
    ENDIF.
*<<< Note 1722318

    append ls_collpaymlink to pt_collpaymlink.

  endloop.

* build structure for outbound service

  clear ls_collections_out.
  ls_collections_out-inkgp = ps_collections-inkgp.
  ls_collections_out-gpart = ps_collections-gpart.
  loop at ps_collections-collitem_tab assigning <fs_collitem>.
    clear ls_collitem_out.
    move-corresponding <fs_collitem> to ls_collitem_out.
    append ls_collitem_out to ls_collections_out-collitem_out_tab.
  endloop.
  loop at ps_collections-collpaym_tab assigning <fs_collpaym>.
    clear ls_collpaym_out.
    move-corresponding <fs_collpaym> to ls_collpaym_out.
    append ls_collpaym_out to ls_collections_out-collpaym_out_tab.
  endloop.
  loop at ps_collections-collpaymlink_tab assigning <fs_collpaymlink>.
    clear ls_collpaymlink_out.
    move-corresponding <fs_collpaymlink> to ls_collpaymlink_out.
    append ls_collpaymlink_out to ls_collections_out-collpaymlink_out_tab.
  endloop.

  append ls_collections_out to pt_collections_out.

* build table for DFKKCOLI_LOG and table for sums

  read table gt_coli_log_ext_hash assigning <fs_coli_log_ext>
    with table key inkgp = ps_collections-inkgp
                   gpart = ps_collections-gpart.
  if sy-subrc = 0.
    append lines of <fs_coli_log_ext>-coli_log_tab to pt_coli_log.
    append lines of <fs_coli_log_ext>-postyp_sum_tab to pt_postyp_sum.
  endif.

endform.                    "collections_package_prepare
*&---------------------------------------------------------------------*
*&      Form  master_data_package_process
*&---------------------------------------------------------------------*
form master_data_package_process
     using
       p_xsimu               type xfeld
       pt_collections_out    type fkkcollections_out_tab
       p_cnt_master_data_ch  type i
       p_inkgp               type inkgp_kk
     changing
       pt_coli_log           type fkkcoli_log_tab
       pv_cnt_services       type i
       pv_cnt_services_error type i
       pv_success_num        type i.

  data lv_xiguid             type guidxi_kk.
  data lv_flg_service_error  type xfeld.
  data lv_flg_db_error       type xfeld.

  data lx_lines              type i.

  if p_xsimu is initial.

* call outbound service
    call function 'FKK_COLL_SERVICE_REQUEST'
      exporting
        it_collections_out = pt_collections_out
      importing
        e_xiguid           = lv_xiguid
      exceptions
        service_failed     = 1
        others             = 2.

    if sy-subrc = 0.
      clear lv_flg_service_error.
    else.
      lv_flg_service_error = 'X'.
      call function 'FKK_AKTIV2_APPL_LOG_MSG'
        exporting
          i_msgty                  = 'E'
          i_msgid                  = sy-msgid
          i_msgno                  = sy-msgno
          i_msgv1                  = sy-msgv1
          i_msgv2                  = sy-msgv2
          i_msgv3                  = sy-msgv3
          i_msgv4                  = sy-msgv4
          i_probclass_this_message = '1'.
    endif.

* update DB
    if lv_flg_service_error is initial.

* update DFKKCOLI_LOG
      insert dfkkcoli_log from table pt_coli_log.

      if sy-subrc <> 0.
        lv_flg_db_error = 'X'.
        call function 'FKK_AKTIV2_APPL_LOG_MSG'
          exporting
            i_msgty                  = 'E'
            i_msgid                  = '>3'
            i_msgno                  = '844'
            i_msgv1                  = 'DFKKCOLI_LOG'
            i_probclass_this_message = '1'.
        set extended check off.
        if 1 = 2. message e844(>3) with 'DFKKCOLI_LOG'. endif.
        set extended check on.
      endif.

    endif.
* commit work/rollback work
    if lv_flg_db_error is initial and lv_flg_service_error is initial.

      lx_lines = lines( pt_collections_out ).
      add lx_lines to pv_success_num.

      add 1 to pv_cnt_services.

* success - message for application log about successful master data changes
      call function 'FKK_AKTIV2_APPL_LOG_MSG'
        exporting
          i_msgty                  = 'I'
          i_msgid                  = 'FKKCOLL'
          i_msgno                  = '140'
          i_msgv1                  = p_cnt_master_data_ch
          i_msgv2                  = p_inkgp
          i_msgv3                  = lv_xiguid
          i_probclass_this_message = '4'.
      set extended check off.
      if 1 = 2. message i140(fkkcoll). endif.
      set extended check on.

      commit work.

    else.

      add 1 to pv_cnt_services_error.

      rollback work.

    endif.

  else.
* simulation - message for application log about simulated master data changes
    call function 'FKK_AKTIV2_APPL_LOG_MSG'
      exporting
        i_msgty                  = 'I'
        i_msgid                  = 'FKKCOLL'
        i_msgno                  = '139'
        i_msgv1                  = p_cnt_master_data_ch
        i_msgv2                  = p_inkgp
        i_probclass_this_message = '4'.
    set extended check off.
    if 1 = 2. message i139(fkkcoll). endif.
    set extended check on.
  endif.

endform.                    "master_data_package_process
*&---------------------------------------------------------------------*
*&      Form  MASTER_DATA_PACKAGE_PREPARE
*&---------------------------------------------------------------------*
form master_data_package_prepare
  tables
        pt_fkkcoll_ch        structure dfkkcoll_ch
        pt_fkkcoli_log       structure dfkkcoli_log
  using
        p_inkgp              type inkgp_kk
        p_gpart              type gpart_kk
        p_basics             type fkk_mad_basics
  changing
        pt_collections_out   type fkkcollections_out_tab.

  data ls_collections_out        type fkkcollections_out.

* call event for business partner master data for outbound enterprise service
  perform call_zp_fb_6262
              using
                 p_inkgp
                 p_gpart
              changing
                 ls_collections_out.

  ls_collections_out-inkgp = p_inkgp.
  ls_collections_out-gpart = p_gpart.

  append ls_collections_out to pt_collections_out.

* master data changes for later update on DFKKCOLI_LOG
  loop at pt_fkkcoll_ch.

    perform get_lfdnr_master_data_change
                using
                   pt_fkkcoll_ch-gpart
                changing
                   pt_fkkcoli_log-lfdnr
                   pt_fkkcoli_log-inkps.

    pt_fkkcoli_log-gpart      = pt_fkkcoll_ch-gpart.
    pt_fkkcoli_log-postyp     = c_master_data_changes.
    pt_fkkcoli_log-udate      = pt_fkkcoll_ch-udate.
    pt_fkkcoli_log-utime      = pt_fkkcoll_ch-utime.        "260402ins
    pt_fkkcoli_log-tabname    = pt_fkkcoll_ch-tabname.
    pt_fkkcoli_log-tabkey     = pt_fkkcoll_ch-tabkey.
    pt_fkkcoli_log-fname      = pt_fkkcoll_ch-fname.
    pt_fkkcoli_log-value_new  = pt_fkkcoll_ch-value_new.
    pt_fkkcoli_log-value_old  = pt_fkkcoll_ch-value_old.
    pt_fkkcoli_log-ernam      = sy-uname.
    pt_fkkcoli_log-erdat      = sy-datum.
    pt_fkkcoli_log-erzeit     = sy-uzeit.
    pt_fkkcoli_log-laufd      = p_basics-runkey-laufd.
    pt_fkkcoli_log-laufi      = p_basics-runkey-laufi.

    append pt_fkkcoli_log.

  endloop.

endform.                    " MASTER_DATA_PACKAGE_PREPARE
*&---------------------------------------------------------------------*
*&      Form  msg_log_amounts_sum
*&---------------------------------------------------------------------*
form msg_log_amounts_sum
     using
       p_xsimu        type xfeld
       pv_xiguid      type guidxi_kk
       pt_postyp_sum  type fkkcol_postyp_sum_tab.

  data ls_postyp_sum   type fkkcol_postyp_sum.

  data h_sum type c length 18.

  loop at pt_postyp_sum into ls_postyp_sum.

    at new inkgp.

      if p_xsimu is initial.
        call function 'FKK_AKTIV2_APPL_LOG_MSG'
          exporting
            i_msgty                  = 'I'
            i_msgid                  = 'FKKCOLL'
            i_msgno                  = '041'
            i_msgv1                  = ls_postyp_sum-inkgp
            i_probclass_this_message = '4'.
        set extended check off.
        if 1 = 2. message i041(fkkcoll). endif.
        set extended check on.
      else.
        call function 'FKK_AKTIV2_APPL_LOG_MSG'
          exporting
            i_msgty                  = 'I'
            i_msgid                  = 'FKKCOLL'
            i_msgno                  = '042'
            i_msgv1                  = ls_postyp_sum-inkgp
            i_probclass_this_message = '4'.
        set extended check off.
        if 1 = 2. message i042(fkkcoll). endif.
        set extended check on.
      endif.
    endat.

    clear h_sum.
    write ls_postyp_sum-betrw to h_sum currency ls_postyp_sum-waers.
    shift h_sum left deleting leading space.

    case ls_postyp_sum-postyp.

      when c_payment.

        if p_xsimu is initial.
          call function 'FKK_AKTIV2_APPL_LOG_MSG'
            exporting
              i_msgty                  = 'I'
              i_msgid                  = 'FKKCOLL'
              i_msgno                  = '034'
              i_msgv1                  = ls_postyp_sum-poscnt
              i_msgv2                  = ls_postyp_sum-betrw
              i_msgv3                  = ls_postyp_sum-waers
              i_msgv4                  = pv_xiguid
              i_probclass_this_message = '4'.
          set extended check off.
          if 1 = 2. message i034(fkkcoll). endif.
          set extended check on.
        else.
          call function 'FKK_AKTIV2_APPL_LOG_MSG'
            exporting
              i_msgty                  = 'I'
              i_msgid                  = 'FKKCOLL'
              i_msgno                  = '043'
              i_msgv1                  = ls_postyp_sum-poscnt
              i_msgv2                  = ls_postyp_sum-betrw
              i_msgv3                  = ls_postyp_sum-waers
              i_probclass_this_message = '4'.
          set extended check off.
          if 1 = 2. message i043(fkkcoll). endif.
          set extended check on.
        endif.

      when c_storno.

        if p_xsimu is initial.
          call function 'FKK_AKTIV2_APPL_LOG_MSG'
            exporting
              i_msgty                  = 'I'
              i_msgid                  = 'FKKCOLL'
              i_msgno                  = '035'
              i_msgv1                  = ls_postyp_sum-poscnt
              i_msgv2                  = ls_postyp_sum-betrw
              i_msgv3                  = ls_postyp_sum-waers
              i_msgv4                  = pv_xiguid
              i_probclass_this_message = '4'.
          set extended check off.
          if 1 = 2. message i035(fkkcoll). endif.
          set extended check on.
        else.
          call function 'FKK_AKTIV2_APPL_LOG_MSG'
            exporting
              i_msgty                  = 'I'
              i_msgid                  = 'FKKCOLL'
              i_msgno                  = '044'
              i_msgv1                  = ls_postyp_sum-poscnt
              i_msgv2                  = ls_postyp_sum-betrw
              i_msgv3                  = ls_postyp_sum-waers
              i_probclass_this_message = '4'.
          set extended check off.
          if 1 = 2. message i044(fkkcoll). endif.
          set extended check on.
        endif.

      when c_clearing.

        if p_xsimu is initial.
          call function 'FKK_AKTIV2_APPL_LOG_MSG'
            exporting
              i_msgty                  = 'I'
              i_msgid                  = 'FKKCOLL'
              i_msgno                  = '036'
              i_msgv1                  = ls_postyp_sum-poscnt
              i_msgv2                  = ls_postyp_sum-betrw
              i_msgv3                  = ls_postyp_sum-waers
              i_msgv4                  = pv_xiguid
              i_probclass_this_message = '4'.
          set extended check off.
          if 1 = 2. message i036(fkkcoll). endif.
          set extended check on.
        else.
          call function 'FKK_AKTIV2_APPL_LOG_MSG'
            exporting
              i_msgty                  = 'I'
              i_msgid                  = 'FKKCOLL'
              i_msgno                  = '045'
              i_msgv1                  = ls_postyp_sum-poscnt
              i_msgv2                  = ls_postyp_sum-betrw
              i_msgv3                  = ls_postyp_sum-waers
              i_probclass_this_message = '4'.
          set extended check off.
          if 1 = 2. message i045(fkkcoll). endif.
          set extended check on.
        endif.

      when c_recall.

        if p_xsimu is initial.
          call function 'FKK_AKTIV2_APPL_LOG_MSG'
            exporting
              i_msgty                  = 'I'
              i_msgid                  = 'FKKCOLL'
              i_msgno                  = '037'
              i_msgv1                  = ls_postyp_sum-poscnt
              i_msgv2                  = ls_postyp_sum-betrw
              i_msgv3                  = ls_postyp_sum-waers
              i_msgv4                  = pv_xiguid
              i_probclass_this_message = '4'.
          set extended check off.
          if 1 = 2. message i037(fkkcoll). endif.
          set extended check on.
        else.
          call function 'FKK_AKTIV2_APPL_LOG_MSG'
            exporting
              i_msgty                  = 'I'
              i_msgid                  = 'FKKCOLL'
              i_msgno                  = '046'
              i_msgv1                  = ls_postyp_sum-poscnt
              i_msgv2                  = ls_postyp_sum-betrw
              i_msgv3                  = ls_postyp_sum-waers
              i_probclass_this_message = '4'.
          set extended check off.
          if 1 = 2. message i046(fkkcoll). endif.
          set extended check on.
        endif.

      when c_cancelled_receivable.

        if p_xsimu is initial.
          call function 'FKK_AKTIV2_APPL_LOG_MSG'
            exporting
              i_msgty                  = 'I'
              i_msgid                  = 'FKKCOLL'
              i_msgno                  = '035'
              i_msgv1                  = ls_postyp_sum-poscnt
              i_msgv2                  = ls_postyp_sum-betrw
              i_msgv3                  = ls_postyp_sum-waers
              i_msgv4                  = pv_xiguid
              i_probclass_this_message = '4'.
          set extended check off.
          if 1 = 2. message i035(fkkcoll). endif.
          set extended check on.
        else.
          call function 'FKK_AKTIV2_APPL_LOG_MSG'
            exporting
              i_msgty                  = 'I'
              i_msgid                  = 'FKKCOLL'
              i_msgno                  = '044'
              i_msgv1                  = ls_postyp_sum-poscnt
              i_msgv2                  = ls_postyp_sum-betrw
              i_msgv3                  = ls_postyp_sum-waers
              i_probclass_this_message = '4'.
          set extended check off.
          if 1 = 2. message i044(fkkcoll). endif.
          set extended check on.
        endif.

      when c_write_off.

        if p_xsimu is initial.
          call function 'FKK_AKTIV2_APPL_LOG_MSG'
            exporting
              i_msgty                  = 'I'
              i_msgid                  = 'FKKCOLL'
              i_msgno                  = '038'
              i_msgv1                  = ls_postyp_sum-poscnt
              i_msgv2                  = ls_postyp_sum-betrw
              i_msgv3                  = ls_postyp_sum-waers
              i_msgv4                  = pv_xiguid
              i_probclass_this_message = '4'.
          set extended check off.
          if 1 = 2. message i038(fkkcoll). endif.
          set extended check on.
        else.
          call function 'FKK_AKTIV2_APPL_LOG_MSG'
            exporting
              i_msgty                  = 'I'
              i_msgid                  = 'FKKCOLL'
              i_msgno                  = '047'
              i_msgv1                  = ls_postyp_sum-poscnt
              i_msgv2                  = ls_postyp_sum-betrw
              i_msgv3                  = ls_postyp_sum-waers
              i_probclass_this_message = '4'.
          set extended check off.
          if 1 = 2. message i047(fkkcoll). endif.
          set extended check on.
        endif.

    endcase.

  endloop.

endform.                    "msg_log_amounts_sum
