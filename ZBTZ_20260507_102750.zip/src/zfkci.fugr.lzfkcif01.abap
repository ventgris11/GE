*----------------------------------------------------------------------*
***INCLUDE LFKCIF01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  addons_1000_import
*&---------------------------------------------------------------------*
form addons_1000_import.

  import addons to g_fkkcollinfo from memory id 'FKKMADADDONS'.

endform.                    " addons_1000_import
*&---------------------------------------------------------------------*
*&      Form  addons_1000_export
*&---------------------------------------------------------------------*
form addons_1000_export.

  export addons from g_fkkcollinfo to memory id 'FKKMADADDONS'.

endform.                    " addons_1000_export
*&---------------------------------------------------------------------*
*&      Form  check_interval_intersection
*&---------------------------------------------------------------------*
form check_interval_intersection
     tables
        r_gpart type fkk_rt_gpart
        r_vkont type fkk_rt_vkont
        r_vtref type fkk_rt_vtref
     using
        i_low type intlo_kk
        i_high type inthi_kk
        i_object type object_kk
     changing
        c_no_work_to_do type xfeld.

* declarations
  data: l_gpart like igpart occurs 0 with header line,
        l_vkont like ivkont occurs 0 with header line,
        l_vtref like ivtref occurs 0 with header line,
        wa_r_vkont type fkkr_vkont,
        wa_r_gpart type fkkr_gpart,
        wa_r_vtref type fkkr_vtref,
        h_low type intlo_kk,
        h_high type inthi_kk.

* Assume some work to do.
  clear c_no_work_to_do.

* Prepare VKONT for interval intersection
  loop at r_vkont into wa_r_vkont.
    move-corresponding wa_r_vkont to l_vkont.
    append l_vkont.
  endloop.

* Prepare GPART for interval intersection
  loop at r_gpart into wa_r_gpart.
    move-corresponding wa_r_gpart to l_gpart.
    append l_gpart.
  endloop.

* Prepare VTREF for interval intersection
  loop at r_vtref into wa_r_vtref.
    move-corresponding wa_r_vtref to l_vtref.
    append l_vtref.
  endloop.

*-Create intersection with interval
  h_low  = i_low.
  h_high = i_high.
  call function 'FKK_DI_INTERVAL_INTERSECTION'
    exporting
      i_intlo  = h_low
      i_inthi  = h_high
      i_object = i_object
    tables
      t_gpart  = l_gpart
      t_vkont  = l_vkont
      t_vtref  = l_vtref
    exceptions
      is_empty = 1
      others   = 2.

* If no work to do exit.
  if sy-subrc = 1.
    c_no_work_to_do = 'X'.
    exit.
  endif.

* if work to do, give results back, for GPART
  refresh r_gpart.
  loop at l_gpart.
    move-corresponding l_gpart to wa_r_gpart.
    wa_r_gpart-sign = 'I'.
    if l_gpart-high is initial or
       l_gpart-low eq l_gpart-high.
      wa_r_gpart-option = 'EQ'.
      clear wa_r_gpart-high.
    else.
      wa_r_gpart-option = 'BT'.
    endif.
    append wa_r_gpart to r_gpart.
  endloop.

* if work to do, give results back, for VKONT
  refresh r_vkont.
  loop at l_vkont.
    move-corresponding l_vkont to wa_r_vkont.
    wa_r_vkont-sign = 'I'.
    if l_vkont-high is initial or
       l_vkont-low eq l_vkont-high.
      wa_r_vkont-option = 'EQ'.
      clear wa_r_vkont-high.
    else.
      wa_r_vkont-option = 'BT'.
    endif.
    append wa_r_vkont to r_vkont.
  endloop.

* if work to do, give results back, for VTREF
  refresh r_vtref.
  loop at l_vtref.
    move-corresponding l_vtref to wa_r_vtref.
    wa_r_vtref-sign = 'I'.
    if l_vtref-high is initial or
       l_vtref-low eq l_vtref-high.
      wa_r_vtref-option = 'EQ'.
      clear wa_r_vtref-high.
    else.
      wa_r_vtref-option = 'BT'.
    endif.
    append wa_r_vtref to r_vtref.
  endloop.

endform.                    " check_interval_intersection
*&---------------------------------------------------------------------*
*&      Form  info_master_data_changes
*&---------------------------------------------------------------------*
form info_master_data_changes
            tables pt_gpart_datum   structure t_gpart_datum
                   pt_fkkcoll_ch    structure dfkkcoll_ch
                   pt_fkkcollp_im_w structure dfkkcollp_im_w
            using  p_gpart type gpart_kk
                   p_inkgp type inkgp_kk
                   p_i_basics type fkk_mad_basics
                   p_h_lfd_m type lfnum_kk
                   p_h_intnr_c type intnr_i_kk.

  data:
    h_dfies_tab like dfies occurs 0 with header line,
    h_tabname   type ddobjname,
    h_fname     type dfies-fieldname.

* Übernahme Partneränderungen
  loop at pt_fkkcoll_ch.
    pt_fkkcollp_im_w-laufd      = p_i_basics-runkey-laufd.
    pt_fkkcollp_im_w-laufi      = p_i_basics-runkey-laufi.
    pt_fkkcollp_im_w-w_inkgp    = p_inkgp.
    pt_fkkcollp_im_w-intnr      = p_h_intnr_c.
    add 1 to p_h_lfd_m.
    pt_fkkcollp_im_w-lfnum      = p_h_lfd_m.
    pt_fkkcollp_im_w-satztyp    = c_position.
    pt_fkkcollp_im_w-postyp     = c_master_data_changes.
    pt_fkkcollp_im_w-gpart      = pt_fkkcoll_ch-gpart.
    pt_fkkcollp_im_w-tabname    = pt_fkkcoll_ch-tabname.
    pt_fkkcollp_im_w-tabkey     = pt_fkkcoll_ch-tabkey.
    pt_fkkcollp_im_w-fname      = pt_fkkcoll_ch-fname.
    pt_fkkcollp_im_w-value_new  = pt_fkkcoll_ch-value_new.
    pt_fkkcollp_im_w-value_old  = pt_fkkcoll_ch-value_old.
    pt_fkkcollp_im_w-udate      = pt_fkkcoll_ch-udate.
    pt_fkkcollp_im_w-utime      = pt_fkkcoll_ch-utime.      "260402ins

* Aufbereiten Tabellen- bzw. Feldname
    clear: h_dfies_tab[], h_dfies_tab.
    clear: h_tabname, h_fname.
    h_tabname = pt_fkkcoll_ch-tabname.
    shift h_tabname left deleting leading space.
    h_fname = pt_fkkcoll_ch-fname.
    shift h_fname left deleting leading space.
    if not h_fname is initial.
      call function 'DDIF_FIELDINFO_GET'
        exporting
          tabname        = h_tabname
          fieldname      = h_fname
        tables
          dfies_tab      = h_dfies_tab
        exceptions
          not_found      = 1
          internal_error = 2
          others         = 3.
      if not sy-subrc is initial.
        concatenate pt_fkkcoll_ch-tabname '_' pt_fkkcoll_ch-fname
          into pt_fkkcollp_im_w-ddtext.
      else.
        read table h_dfies_tab index 1.
        pt_fkkcollp_im_w-ddtext = h_dfies_tab-scrtext_l.
      endif.
    else.
      select single ddtext into  pt_fkkcollp_im_w-ddtext
                           from  dd02t
                           where tabname    eq h_tabname
                           and   ddlanguage eq sy-langu
                           and   as4vers    eq 'A'.
      if not sy-subrc is initial.
        pt_fkkcollp_im_w-ddtext = h_tabname.
      endif.
    endif.

* INSERT Informationen zu Partner-Stammdatenänderungen
    insert into dfkkcollp_im_w values pt_fkkcollp_im_w.

* Registrieren Inkassobüro
    gt_inkgp = pt_fkkcollp_im_w-w_inkgp.
    collect gt_inkgp.

* Registrieren bearbeiteten Fall
    gt_fall = pt_fkkcollp_im_w-gpart.
    collect gt_fall.

  endloop.

endform.                    " info_master_data_changes
*&---------------------------------------------------------------------*
*&      Form  Last_partner_info_datum
*&---------------------------------------------------------------------*
*       Lesen Datum der letzten prot. Info zu Partner-Stammdatenänderung
*----------------------------------------------------------------------*
*      -->P_T_FKKCOLI_LOG  Struktur Log-Tabelle
*      -->P_T_GPART_DATUM  Struktur für Zuordnung Partner - Änd.Datum
*----------------------------------------------------------------------*
form last_partner_info_datum
                       tables   pt_fkkcoli_log structure dfkkcoli_log
                                pt_gpart_datum structure t_gpart_datum.

  sort pt_fkkcoli_log by gpart ascending udate descending utime descending.

* Selektion der Partner aus Protokoll
  loop at pt_fkkcoli_log where postyp eq c_master_data_changes.
    pt_gpart_datum = pt_fkkcoli_log-gpart.
    clear pt_gpart_datum-datum.
    clear pt_gpart_datum-uzeit.
    collect pt_gpart_datum.
  endloop.

* Zuordenen Datum der letzten Partneränderungs-Information zum Partner
  loop at pt_gpart_datum.

*    SELECT MAX( udate ) INTO  pt_gpart_datum-datum
*                        FROM  dfkkcoli_log
*                        WHERE nrzas EQ space
*                        AND   opbel EQ space
**                        AND   inkps EQ space
*                        AND   gpart EQ pt_gpart_datum-gpart.
**>> begin of insert                                        "260402ins
*    CHECK sy-subrc IS INITIAL.
** Zuordenen Uhrzeit der letzten Partneränderungs-Information zum Partner
*    SELECT MAX( utime ) INTO  pt_gpart_datum-uzeit
*                        FROM  dfkkcoli_log
*                        WHERE nrzas EQ space
*                        AND   opbel EQ space
**                        AND   inkps EQ space
*                        AND   gpart EQ pt_gpart_datum-gpart
*                        AND   udate EQ pt_gpart_datum-datum.
**>> end of insert

    read table pt_fkkcoli_log
            with key gpart = pt_gpart_datum-gpart.

    if sy-subrc eq 0.
      move pt_fkkcoli_log-udate to pt_gpart_datum-datum.
      move pt_fkkcoli_log-utime to pt_gpart_datum-uzeit.
      modify pt_gpart_datum.
    endif.
  endloop.

endform.                    " Last_partner_info_datum
*&---------------------------------------------------------------------*
*&      Form  select_master_data_changes
*&---------------------------------------------------------------------*
form select_master_data_changes
            tables   pt_gpart_datum structure t_gpart_datum
                     pt_fkkcoll_ch structure dfkkcoll_ch
            using    p_gpart type gpart_kk.

  data: i_datum like dfkkcoli_log-udate,
        i_uzeit like dfkkcoli_log-utime.                    "260402ins


* Lesen Zeitpunkt der letzten protokollierten Partneränderung
  clear: pt_gpart_datum.
  read table pt_gpart_datum with key gpart = p_gpart.
  if sy-subrc is initial.
    i_datum = pt_gpart_datum-datum.
    i_uzeit = pt_gpart_datum-uzeit.                         "260402ins
  else.
    clear i_datum.
    clear i_uzeit.                                          "260402ins
  endif.

* Selektion Geschäftspartner-Stammdatenänderungen
  clear: pt_fkkcoll_ch[], pt_fkkcoll_ch.
  select * into table pt_fkkcoll_ch[]
           from dfkkcoll_ch
          where gpart eq p_gpart
*           and udate gt i_datum                          "260402del
            and ( ( udate eq i_datum and utime > i_uzeit )  "260402ins
                 or udate gt i_datum )  .                   "260402ins

endform.                    " select_master_data_changes
*&---------------------------------------------------------------------*
*&      Form  info_header_data
*&---------------------------------------------------------------------*
form info_header_data tables   pt_fkkcollh_i_w structure dfkkcollh_i_w
                      using    p_inkgp type inkgp_kk
                               p_basics type fkk_mad_basics.

* Fortschreiben Kopfinformationen
  pt_fkkcollh_i_w-laufd   = p_basics-runkey-laufd.
  pt_fkkcollh_i_w-laufi   = p_basics-runkey-laufi.
  pt_fkkcollh_i_w-w_inkgp = p_inkgp.
  pt_fkkcollh_i_w-satztyp = c_header.
  pt_fkkcollh_i_w-inkgp   = p_inkgp.
  pt_fkkcollh_i_w-datum   = sy-datum.
  collect pt_fkkcollh_i_w.

endform.                    " info_header_data
*&---------------------------------------------------------------------*
*&      Form  read_events
*&---------------------------------------------------------------------*
*       read events
*----------------------------------------------------------------------*
form read_events tables   p_t_tfkfbc_5051 structure t_tfkfbc_5051
                          p_t_tfkfbc_5052 structure t_tfkfbc_5052
                          p_t_tfkfbc_5053 structure t_tfkfbc_5053
                 changing p_h_applk type applk_kk.

  call function 'FKK_GET_APPLICATION'
    exporting
      i_no_dialog      = 'X'
    importing
      e_applk          = p_h_applk
    exceptions
      no_appl_selected = 1
      others           = 2.

* Determine function modules for events 5051, 5052, 5053 --------------*
  refresh p_t_tfkfbc_5051.
  call function 'FKK_FUNC_MODULE_DETERMINE'
    exporting
      i_fbeve  = c_event_5051
      i_applk  = p_h_applk
    tables
      t_fbstab = p_t_tfkfbc_5051
    exceptions
      others   = 1.

  refresh p_t_tfkfbc_5052.
  call function 'FKK_FUNC_MODULE_DETERMINE'
    exporting
      i_fbeve  = c_event_5052
      i_applk  = p_h_applk
    tables
      t_fbstab = p_t_tfkfbc_5052
    exceptions
      others   = 1.

  refresh p_t_tfkfbc_5053.
  call function 'FKK_FUNC_MODULE_DETERMINE'
    exporting
      i_fbeve  = c_event_5053
      i_applk  = p_h_applk
    tables
      t_fbstab = p_t_tfkfbc_5053
    exceptions
      others   = 1.

endform.                    " read_events
*&---------------------------------------------------------------------*
*&      Form  create_range_agsta
*&---------------------------------------------------------------------*
*       Erzeugen Range für Abgabestatus
*----------------------------------------------------------------------*
form create_range_agsta
                  tables p_ht_agsta_range structure ht_agsta_range
                  using  p_fkkcollinfo type fkkcollinfo.
  if 1 = 1.
    clear: p_ht_agsta_range[], p_ht_agsta_range.
    p_ht_agsta_range-sign   = 'I'.
    p_ht_agsta_range-option = 'EQ'.
    clear: p_ht_agsta_range-high.

    p_ht_agsta_range-low = c_receivable_submitted.
    append p_ht_agsta_range.
    p_ht_agsta_range-low = c_receivable_paid.         "03
    append p_ht_agsta_range.
    p_ht_agsta_range-low = c_receivable_part_paid.    "04
    append p_ht_agsta_range.
    p_ht_agsta_range-low = c_receivable_recalled.
    append p_ht_agsta_range.
    p_ht_agsta_range-low = c_costumer_directly_paid.
    append p_ht_agsta_range.
    p_ht_agsta_range-low = c_costumer_partally_paid.
    append p_ht_agsta_range.
    p_ht_agsta_range-low = c_full_clearing.
    append p_ht_agsta_range.
    p_ht_agsta_range-low = c_partial_clearing.
    append p_ht_agsta_range.

  else.
    clear: p_ht_agsta_range[], p_ht_agsta_range.
    p_ht_agsta_range-sign   = 'I'.
    p_ht_agsta_range-option = 'EQ'.
    clear: p_ht_agsta_range-high.

    if  not p_fkkcollinfo-xcpart is initial
     or not p_fkkcollinfo-xausg  is initial.
      p_ht_agsta_range-low = c_receivable_submitted.     "02
      append p_ht_agsta_range.
    endif.

    if not p_fkkcollinfo-xback is initial.
      p_ht_agsta_range-low = c_receivable_recalled.      "09
      append p_ht_agsta_range.
    endif.

    if not p_fkkcollinfo-xausg is initial.
      p_ht_agsta_range-low = c_costumer_directly_paid.   "10
      append p_ht_agsta_range.
      p_ht_agsta_range-low = c_costumer_partally_paid.   "11
      append p_ht_agsta_range.
      p_ht_agsta_range-low = c_receivable_paid.          "03
      append p_ht_agsta_range.
      p_ht_agsta_range-low = c_receivable_part_paid.     "04
      append p_ht_agsta_range.
      p_ht_agsta_range-low = c_full_clearing.            "12
      append p_ht_agsta_range.
      p_ht_agsta_range-low = c_partial_clearing.         "13
      append p_ht_agsta_range.
    endif.
  endif.

  if not p_fkkcollinfo-xrever is initial.
    p_ht_agsta_range-low = c_receivable_cancelled.       "05
    append p_ht_agsta_range.
  endif.

  if not p_fkkcollinfo-xback is initial.
    p_ht_agsta_range-low = c_rec_recall_part_write_off.  "16
    append p_ht_agsta_range.
  endif.

*>> *<< Note 1320616
  if not p_fkkcollinfo-xwroff is initial or
     not p_fkkcollinfo-xausg  is initial.
    p_ht_agsta_range-low = c_agsta_cu_t-erfolglos.       "07
    append p_ht_agsta_range.
  endif.
*<< Note 1320616

  if not p_fkkcollinfo-xwroff is initial.
    p_ht_agsta_range-low = c_receivable_write_off.       "06
    append p_ht_agsta_range.
    p_ht_agsta_range-low = c_receivable_part_write_off.  "15
    append p_ht_agsta_range.
*    p_ht_agsta_range-low = c_agsta_cu_t-erfolglos.    "07 Note 1320616
*    APPEND p_ht_agsta_range.                              Note 1320616
    p_ht_agsta_range-low = c_agsta_t-erfolglos.          "08
    append p_ht_agsta_range.
  endif.

endform.                    " create_range_agsta
*&---------------------------------------------------------------------*
*&      Form  create_range_gpart
*&---------------------------------------------------------------------*
*       Erzeugen Range für aktuelles Geschäftspartner-Intervall
*----------------------------------------------------------------------*
form create_range_gpart
                  tables  p_ht_gpart_range structure ht_gpart_range
                  using   p_h_gpart_low type gpart_kk
                          p_h_gpart_high type gpart_kk.

  clear: p_ht_gpart_range[], p_ht_gpart_range.
  p_ht_gpart_range-sign   = 'I'.
  p_ht_gpart_range-option = 'BT'.
  p_ht_gpart_range-low    = p_h_gpart_low.
  p_ht_gpart_range-high   = p_h_gpart_high.
  append p_ht_gpart_range.

endform.                    " create_range_gpart
*&---------------------------------------------------------------------*
*&      Form  exit_5052
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
form exit_5052 using    p_postyp type postyp_kk
                        p_pt_fkkcollh_i_w
                        p_pt_fkkcollt_i_w
               changing p_pt_fkkcollp_ip_w
                        p_pt_fkkcollp_ir_w
                        p_pt_fkkcollp_im_w.

  data:
    lt_fkkcollh_i_w  like dfkkcollh_i_w,
    lt_fkkcollp_ip_w like dfkkcollp_ip_w,
    lt_fkkcollp_ir_w like dfkkcollp_ir_w,
    lt_fkkcollp_im_w like dfkkcollp_im_w,
    lt_fkkcollt_i_w  like dfkkcollt_i_w.


  lt_fkkcollh_i_w  = p_pt_fkkcollh_i_w.
  lt_fkkcollp_ip_w = p_pt_fkkcollp_ip_w.
  lt_fkkcollp_ir_w = p_pt_fkkcollp_ir_w.
  lt_fkkcollp_im_w = p_pt_fkkcollp_im_w.
  lt_fkkcollt_i_w  = p_pt_fkkcollt_i_w.

  loop at t_tfkfbc_5052.
    call function t_tfkfbc_5052-funcc
      exporting
        i_postyp        = p_postyp
        i_fkkcollh_i_w  = lt_fkkcollh_i_w
        i_fkkcollt_i_w  = lt_fkkcollt_i_w
      changing
        c_fkkcollp_ip_w = lt_fkkcollp_ip_w
        c_fkkcollp_ir_w = lt_fkkcollp_ir_w
        c_fkkcollp_im_w = lt_fkkcollt_i_w.
  endloop.

  p_pt_fkkcollp_ip_w = lt_fkkcollp_ip_w.
  p_pt_fkkcollp_ir_w = lt_fkkcollp_ir_w.
  p_pt_fkkcollp_im_w = lt_fkkcollp_im_w.

  set extended check off.
  if 1 = 2. call function 'FKK_SAMPLE_5052'. endif.
  set extended check on.

endform.                                                    " exit_5052
*&---------------------------------------------------------------------*
*&      Form  info_payment
*&---------------------------------------------------------------------*
form info_payment
     using
        p_postyp type postyp_kk
        p_i_basics type fkk_mad_basics
        p_h_intnr_c type intnr_i_kk
        p_t_fkkcollh like dfkkcollh
        p_h_lfd_p type lfnum_kk
        p_h_betrag type betrz_kk
        p_logkz type logkz_kk.

  data:
    l_fkkcollp_ip_w like dfkkcollp_ip_w,
    l_agsta_text type ddfixvalue,
    h_storb      type storb_kk,
    h_logkz      type logkz_kk,
    h_xragl      type xragl_kk,
    h_augbl      type augbl_kk.

  data lv_txtvw           type txtag_i_kk.
  data lv_betrw_content   type betrw_kk.

  data ls_collpaym        type fkkcollpaym.
  data ls_collpaymlink    type fkkcollpaymlink.
  data ls_collections     type fkkcollections.
  data ls_coli_log        type fkkcoli_log.
  data ls_coli_log_ext    type gty_fkkcoli_log_ext.
  data ls_postyp_sum      type fkkcol_postyp_sum.
  DATA lv_collitem_lv     TYPE collitem_lv_kk.

  field-symbols <fs_collections>  type fkkcollections.
  field-symbols <fs_coli_log_ext>  type gty_fkkcoli_log_ext.


  clear: l_fkkcollp_ip_w.
  clear: h_storb, h_logkz.

  if p_logkz is initial and
   ( p_t_fkkcollh-agsta = c_receivable_cancelled    or
     p_t_fkkcollh-agsta = c_costumer_directly_paid  or
     p_t_fkkcollh-agsta = c_costumer_partally_paid  or
     p_t_fkkcollh-agsta = c_full_clearing           or
     p_t_fkkcollh-agsta = c_partial_clearing ).
* check if the clearing document has been reversed
    select single augbl xragl into  (h_augbl, h_xragl)
                        from  dfkkop
                        where opbel eq p_t_fkkcollh-augbl.
    if not h_xragl is initial.
      h_logkz = 'X'.
      move h_augbl to t_stor.
      append t_stor.
    else.
      h_logkz = p_logkz.
    endif.
*    SELECT SINGLE storb INTO  h_storb
*                        FROM  dfkkko
*                        WHERE opbel EQ p_t_fkkcollh-augbl.
*    IF NOT h_storb IS INITIAL.
*      h_logkz = 'X'.
*      MOVE h_storb TO t_stor.
*      APPEND t_stor.
*    ELSE.
*      h_logkz = p_logkz.
*    ENDIF.
  else.
    h_logkz = p_logkz.
  endif.

  if  p_h_betrag ge 0.
    read table gt_dd07v
         with key domvalue_l = p_t_fkkcollh-agsta.
    lv_txtvw = gt_dd07v-ddtext.
  else.
    if p_t_fkkcollh-agsta eq c_full_clearing.
      lv_txtvw = 'Gutschrift ausgeglichen'(007).
    elseif p_t_fkkcollh-agsta eq c_partial_clearing.
      lv_txtvw = 'Gutschrift teilausgeglichen'(008).
    else.
      lv_txtvw = 'Gutschrift bezahlt'(002).
    endif.
  endif.

* ----------------------------------------------------------------------
* file based version (enterprise services not active)
* ----------------------------------------------------------------------
  if gv_flg_coll_esoa_active is initial.

    l_fkkcollp_ip_w-laufd   = p_i_basics-runkey-laufd.
    l_fkkcollp_ip_w-laufi   = p_i_basics-runkey-laufi.
    l_fkkcollp_ip_w-w_inkgp = p_t_fkkcollh-inkgp.
    l_fkkcollp_ip_w-intnr   = p_h_intnr_c.
    add 1 to p_h_lfd_p.
    l_fkkcollp_ip_w-lfnum   = p_h_lfd_p.
    l_fkkcollp_ip_w-lfdnr   = p_t_fkkcollh-lfdnr.
    l_fkkcollp_ip_w-logkz   = h_logkz.
    l_fkkcollp_ip_w-satztyp = c_position.
    l_fkkcollp_ip_w-postyp  = p_postyp.
    l_fkkcollp_ip_w-nrzas   = p_t_fkkcollh-nrzas.
    l_fkkcollp_ip_w-opbel   = p_t_fkkcollh-opbel.
    l_fkkcollp_ip_w-inkps   = p_t_fkkcollh-inkps.
    l_fkkcollp_ip_w-gpart   = p_t_fkkcollh-gpart.
    l_fkkcollp_ip_w-vkont   = p_t_fkkcollh-vkont.
    write p_t_fkkcollh-betrw to l_fkkcollp_ip_w-betrw
                                currency p_t_fkkcollh-waers.
    write p_h_betrag         to l_fkkcollp_ip_w-bwtrt
                                currency p_t_fkkcollh-waers. "#EC *
    l_fkkcollp_ip_w-waers   = p_t_fkkcollh-waers.
    l_fkkcollp_ip_w-augdt   = p_t_fkkcollh-rudat.

    l_fkkcollp_ip_w-txtvw = lv_txtvw.

* INSERT: Speichern Informationen zu Zahlungen
*>>>>> HANA
    DATA: lo_opt       TYPE REF TO if_fkk_optimization_settings,
          x_optimizing TYPE        xfeld.
    lo_opt = cl_fkk_optimization_settings=>get_instance( ).
    x_optimizing = lo_opt->is_active( cl_fkk_optimization_settings=>cc_fica_fpci_mass_insert ).
    IF x_optimizing = abap_true.
      APPEND l_fkkcollp_ip_w TO gt_fkkcollp_ip_w.
    ELSE.
      INSERT INTO dfkkcollp_ip_w VALUES l_fkkcollp_ip_w.  "OLD LOGIC
    ENDIF.
*<<<<< HANA

* Registrieren Inkassobüro
    gt_inkgp = l_fkkcollp_ip_w-w_inkgp.
    collect gt_inkgp.

* Registrieren bearbeiteten Fall
    gt_fall = l_fkkcollp_ip_w-gpart.
    collect gt_fall.

  endif.

* ----------------------------------------------------------------------
* enterprise service version (enterprise services active)
* ----------------------------------------------------------------------
  if gv_flg_coll_esoa_active = 'X'.

* payment information
    clear ls_collpaym.

    ls_collpaym-inkgp = p_t_fkkcollh-inkgp.
    ls_collpaym-gpart = p_t_fkkcollh-gpart.

    ls_collpaym-collpaym_id = p_t_fkkcollh-augbl.
    ls_collpaym-collpaym_tp = '1'.

    ls_collpaym-waers = p_t_fkkcollh-waers.
    ls_collpaym-betrw = p_h_betrag.
    ls_collpaym-valut = p_t_fkkcollh-rudat.

* payment assignment information
    clear ls_collpaymlink.

    ls_collpaymlink-inkgp = p_t_fkkcollh-inkgp.
    ls_collpaymlink-gpart = p_t_fkkcollh-gpart.

    ls_collpaymlink-collpaym_id = p_t_fkkcollh-augbl.
    ls_collpaymlink-collpaym_tp = '1'.

    concatenate p_t_fkkcollh-opbel p_t_fkkcollh-inkps into ls_collpaymlink-collitem_id.

    SELECT SINGLE collitem_lv FROM dfkkcollitem INTO lv_collitem_lv
            WHERE collitem_id = ls_collpaymlink-collitem_id.
    IF sy-subrc = 0 AND NOT lv_collitem_lv IS INITIAL.
      ls_collpaymlink-collitem_lv = lv_collitem_lv.
    ELSE.
      ls_collpaymlink-collitem_lv = '01'.
    ENDIF.

    ls_collpaymlink-waers = p_t_fkkcollh-waers.

    lv_betrw_content      = p_h_betrag.
    ls_collpaymlink-betrz = lv_betrw_content.
    ls_collpaymlink-paydt = p_t_fkkcollh-rudat.

    ls_collpaymlink-txtkm = lv_txtvw.

* insert into global collections table
    read table gt_collections_hash assigning <fs_collections>
      with table key inkgp = ls_collpaymlink-inkgp
                     gpart = ls_collpaymlink-gpart.
    if sy-subrc = 0.
      collect ls_collpaym into <fs_collections>-collpaym_tab.
      append ls_collpaymlink to <fs_collections>-collpaymlink_tab.
    else.
      clear ls_collections.
      ls_collections-inkgp = ls_collpaymlink-inkgp.
      ls_collections-gpart = ls_collpaymlink-gpart.
      append ls_collpaym to ls_collections-collpaym_tab.
      append ls_collpaymlink to ls_collections-collpaymlink_tab.
      insert ls_collections into table gt_collections_hash.
    endif.


* collect information for DFKKCOLI_LOG
    clear ls_coli_log.
    ls_coli_log-opbel  = p_t_fkkcollh-opbel.
    ls_coli_log-inkps  = p_t_fkkcollh-inkps.
    ls_coli_log-gpart  = p_t_fkkcollh-gpart.
    ls_coli_log-lfdnr  = p_t_fkkcollh-lfdnr.
    ls_coli_log-postyp = p_postyp.
    ls_coli_log-vkont  = p_t_fkkcollh-vkont.
    ls_coli_log-betrw  = p_t_fkkcollh-betrw.
*  ls_coli_log-bwtrt  = p_t_fkkcollh-bwtrt.
    ls_coli_log-waers  = p_t_fkkcollh-waers.
*  ls_coli_log-augdt  = p_t_fkkcollh-augdt.
*  ls_coli_log-txtvw  = p_t_fkkcollh-txtvw.
    ls_coli_log-ernam  = sy-uname.
    ls_coli_log-erdat  = sy-datum.
    ls_coli_log-erzeit = sy-uzeit.
    ls_coli_log-laufd  = p_i_basics-runkey-laufd.
    ls_coli_log-laufi  = p_i_basics-runkey-laufi.

* collect information for application log
    clear ls_postyp_sum.
    ls_postyp_sum-inkgp = p_t_fkkcollh-inkgp.
    ls_postyp_sum-postyp = p_postyp.
    ls_postyp_sum-waers  = p_t_fkkcollh-waers.
    ls_postyp_sum-betrw  = lv_betrw_content.
    ls_postyp_sum-poscnt = 1.

* insert into global coli_log table
    read table gt_coli_log_ext_hash assigning <fs_coli_log_ext>
      with table key inkgp = p_t_fkkcollh-inkgp
                     gpart = p_t_fkkcollh-gpart.
    if sy-subrc = 0.
      append ls_coli_log to <fs_coli_log_ext>-coli_log_tab.
      collect ls_postyp_sum into <fs_coli_log_ext>-postyp_sum_tab.
    else.
      clear ls_coli_log_ext.
      ls_coli_log_ext-inkgp = p_t_fkkcollh-inkgp.
      ls_coli_log_ext-gpart = p_t_fkkcollh-gpart.
      append ls_coli_log to ls_coli_log_ext-coli_log_tab.
      collect ls_postyp_sum into ls_coli_log_ext-postyp_sum_tab.
      insert ls_coli_log_ext into table gt_coli_log_ext_hash.
    endif.


  endif.

endform.                    " info_payment
*&---------------------------------------------------------------------*
*&      Form  info_recall
*&---------------------------------------------------------------------*
form info_recall
     using
        p_i_basics type fkk_mad_basics
        p_h_intnr_c type intnr_i_kk
        p_t_fkkcollh like dfkkcollh
        p_h_lfd_r type lfnum_kk
        p_w_collh_last like dfkkcollh
        p_t_fkkcoli_log structure dfkkcoli_log.
*       p_logkz type logkz_kk.

  data:
    l_fkkcollp_ir_w like dfkkcollp_ir_w,
    l_betrw type betrw_kk.

  data lv_txtvw           type txtag_i_kk.
  data lv_betrw_content   type betrw_kk.

  data ls_collitem        type fkkcollitem.
  data ls_collections     type fkkcollections.
  data ls_coli_log        type fkkcoli_log.
  data ls_coli_log_ext    type gty_fkkcoli_log_ext.
  data ls_postyp_sum      type fkkcol_postyp_sum.
  DATA lv_collitem_lv     TYPE collitem_lv_kk.

  field-symbols <fs_collections>  type fkkcollections.
  field-symbols <fs_coli_log_ext>  type gty_fkkcoli_log_ext.


  clear: l_fkkcollp_ir_w.
  clear: l_betrw.

  select single astxt into  lv_txtvw
                      from  tfk050at
                      where spras eq sy-langu
                      and   agsta eq p_t_fkkcollh-agsta.

* ----------------------------------------------------------------------
* file based version (enterprise services not active)
* ----------------------------------------------------------------------
  if gv_flg_coll_esoa_active is initial.

    l_fkkcollp_ir_w-laufd   = p_i_basics-runkey-laufd.
    l_fkkcollp_ir_w-laufi   = p_i_basics-runkey-laufi.
    l_fkkcollp_ir_w-w_inkgp = p_t_fkkcollh-inkgp.
    l_fkkcollp_ir_w-intnr   = p_h_intnr_c.
    add 1 to p_h_lfd_r.
    l_fkkcollp_ir_w-lfnum   = p_h_lfd_r.
    l_fkkcollp_ir_w-lfdnr   = p_t_fkkcollh-lfdnr.
    l_fkkcollp_ir_w-satztyp = c_position.
    l_fkkcollp_ir_w-postyp  = c_recall.
    l_fkkcollp_ir_w-nrzas   = p_t_fkkcollh-nrzas.
    l_fkkcollp_ir_w-opbel   = p_t_fkkcollh-opbel.
    l_fkkcollp_ir_w-inkps   = p_t_fkkcollh-inkps.
    l_fkkcollp_ir_w-gpart   = p_t_fkkcollh-gpart.
    l_fkkcollp_ir_w-vkont   = p_t_fkkcollh-vkont.
    if p_w_collh_last-agsta eq c_receivable_part_paid.
* If the debt collecting agency only partly paid a demand, the remainder is recalled.
      l_betrw = p_t_fkkcollh-betrw - p_t_fkkcollh-betrz.
      write l_betrw to l_fkkcollp_ir_w-betrw
                       currency p_t_fkkcollh-waers.
    elseif ( p_w_collh_last-agsta eq c_costumer_partally_paid or
             p_w_collh_last-agsta eq c_partial_clearing ) and
             p_w_collh_last-lfdnr eq p_t_fkkcoli_log-lfdnr.
      l_betrw = p_t_fkkcollh-betrw - p_t_fkkcollh-betrz.
      write l_betrw to l_fkkcollp_ir_w-betrw
                       currency p_t_fkkcollh-waers.
    else.
      write p_t_fkkcollh-betrw to l_fkkcollp_ir_w-betrw
                                  currency p_t_fkkcollh-waers.
    endif.
    l_fkkcollp_ir_w-waers   = p_t_fkkcollh-waers.
    l_fkkcollp_ir_w-rudat   = p_t_fkkcollh-rudat.

    l_fkkcollp_ir_w-txtvw = lv_txtvw.

* INSERT: Speichern Informationen zu Rückruf
    insert into dfkkcollp_ir_w values l_fkkcollp_ir_w.

* Registrieren Inkassobüro
    gt_inkgp = l_fkkcollp_ir_w-w_inkgp.
    collect gt_inkgp.

* Registrieren bearbeiteten Fall
    gt_fall = l_fkkcollp_ir_w-gpart.
    collect gt_fall.

  endif.

* ----------------------------------------------------------------------
* enterprise service version (enterprise services active)
* ----------------------------------------------------------------------
  if gv_flg_coll_esoa_active = 'X'.

* collection unit information
    clear ls_collitem.
    ls_collitem-inkgp = p_t_fkkcollh-inkgp.
    ls_collitem-gpart = p_t_fkkcollh-gpart.
    concatenate p_t_fkkcollh-opbel p_t_fkkcollh-inkps into ls_collitem-collitem_id.

    SELECT SINGLE collitem_lv FROM dfkkcollitem INTO lv_collitem_lv
            WHERE collitem_id = ls_collitem-collitem_id.
    IF sy-subrc = 0 AND NOT lv_collitem_lv IS INITIAL.
      ls_collitem-collitem_lv = lv_collitem_lv.
    ELSE.
      ls_collitem-collitem_lv = '01'.
    ENDIF.

    ls_collitem-waers = p_t_fkkcollh-waers.
    ls_collitem-rcdat = p_t_fkkcollh-rudat.
    ls_collitem-txtkm = lv_txtvw.

    if p_w_collh_last-agsta eq c_receivable_part_paid.
* If the debt collecting agency only partly paid a demand, the remainder is recalled.
      ls_collitem-rinkb = p_t_fkkcollh-betrw - p_t_fkkcollh-betrz.
    elseif ( p_w_collh_last-agsta eq c_costumer_partally_paid or
             p_w_collh_last-agsta eq c_partial_clearing ) and
             p_w_collh_last-lfdnr eq p_t_fkkcoli_log-lfdnr.
      ls_collitem-rinkb = p_t_fkkcollh-betrw - p_t_fkkcollh-betrz.
    else.
      ls_collitem-rinkb = p_t_fkkcollh-betrw.
    endif.
    lv_betrw_content = ls_collitem-rinkb.

* insert into global collections table
    read table gt_collections_hash assigning <fs_collections>
      with table key inkgp = ls_collitem-inkgp
                     gpart = ls_collitem-gpart.
    if sy-subrc = 0.
      append ls_collitem to <fs_collections>-collitem_tab.
    else.
      clear ls_collections.
      ls_collections-inkgp = ls_collitem-inkgp.
      ls_collections-gpart = ls_collitem-gpart.
      append ls_collitem to ls_collections-collitem_tab.
      insert ls_collections into table gt_collections_hash.
    endif.

* collect information for DFKKCOLI_LOG
    clear ls_coli_log.
    ls_coli_log-opbel  = p_t_fkkcollh-opbel.
    ls_coli_log-inkps  = p_t_fkkcollh-inkps.
    ls_coli_log-gpart  = p_t_fkkcollh-gpart.
    ls_coli_log-lfdnr  = p_t_fkkcollh-lfdnr.
    ls_coli_log-postyp = c_recall.
    ls_coli_log-vkont  = p_t_fkkcollh-vkont.
    ls_coli_log-betrw  = p_t_fkkcollh-betrw.
*  ls_coli_log-bwtrt  = p_t_fkkcollh-bwtrt.
    ls_coli_log-waers  = p_t_fkkcollh-waers.
*  ls_coli_log-augdt  = p_t_fkkcollh-augdt.
*  ls_coli_log-txtvw  = p_t_fkkcollh-txtvw.
    ls_coli_log-ernam  = sy-uname.
    ls_coli_log-erdat  = sy-datum.
    ls_coli_log-erzeit = sy-uzeit.
    ls_coli_log-laufd  = p_i_basics-runkey-laufd.
    ls_coli_log-laufi  = p_i_basics-runkey-laufi.

* collect information for application log
    clear ls_postyp_sum.
    ls_postyp_sum-inkgp  = p_t_fkkcollh-inkgp.
    ls_postyp_sum-postyp = c_recall.
    ls_postyp_sum-waers  = p_t_fkkcollh-waers.
    ls_postyp_sum-betrw  = lv_betrw_content.
    ls_postyp_sum-poscnt = 1.

* insert into global coli_log table
    read table gt_coli_log_ext_hash assigning <fs_coli_log_ext>
      with table key inkgp = p_t_fkkcollh-inkgp
                     gpart = p_t_fkkcollh-gpart.
    if sy-subrc = 0.
      append ls_coli_log to <fs_coli_log_ext>-coli_log_tab.
      collect ls_postyp_sum into <fs_coli_log_ext>-postyp_sum_tab.
    else.
      clear ls_coli_log_ext.
      ls_coli_log_ext-inkgp = p_t_fkkcollh-inkgp.
      ls_coli_log_ext-gpart = p_t_fkkcollh-gpart.
      append ls_coli_log to ls_coli_log_ext-coli_log_tab.
      collect ls_postyp_sum into ls_coli_log_ext-postyp_sum_tab.
      insert ls_coli_log_ext into table gt_coli_log_ext_hash.
    endif.

  endif.

endform.                    " info_recall
*&---------------------------------------------------------------------*
*&      Form  read_header_infos
*&---------------------------------------------------------------------*
form read_header_infos tables p_t_fkkcollh_i_w structure dfkkcollh_i_w
                       using  p_i_basics type fkk_mad_basics.

  clear: p_t_fkkcollh_i_w[], p_t_fkkcollh_i_w.

  select * into  table p_t_fkkcollh_i_w
           from  dfkkcollh_i_w
           where laufd eq p_i_basics-runkey-laufd
           and   laufi eq p_i_basics-runkey-laufi.

  sort p_t_fkkcollh_i_w by w_inkgp.

endform.                    " read_header_infos
*&---------------------------------------------------------------------*
*&      Form  create_file_header
*&---------------------------------------------------------------------*
form create_file_header using    p_fkkcollinfo    type fkkcollinfo
                                 p_t_fkkcollh_i_w like dfkkcollh_i_w
                                 p_i_basics       type fkk_mad_basics
                        changing p_h_file_name
                                 p_t_fkkcollh_i   like fkkcollh_i
                                 p_t_fkkcollt_i   like fkkcollt_i
                                 p_rc             like sy-subrc.
  data: w_open.

  clear: p_rc.
  clear: w_open.

  if not p_t_fkkcollh_i_w-inkgp is initial.

* Erzeugen Dateiname
    perform create_filename
       using
          p_i_basics
          p_fkkcollinfo-datei
          p_t_fkkcollh_i_w-inkgp
       changing
          p_h_file_name.

* Anlegen Informationsdatei
    if p_i_basics-status-xsimu is initial.
*     OPEN DATASET
      open dataset p_h_file_name for output in text mode
                                     encoding default.
      if sy-subrc is initial.
        w_open = 'X'.
      endif.
    else.
      w_open = 'X'.
    endif.

    if w_open is initial.
* Nachricht: File ... konnte nicht geöffnet werden
      mac_appl_log_msg 'E' '>3' '843'
         p_h_file_name space space space
         c_msgprio_high '1'.
      set extended check off.
      if 1 = 2. message e843(>3). endif.
      set extended check on.

      p_rc = 8 .
      exit.
    else.
      if p_i_basics-status-xsimu is initial.
* Nachricht: Datei ...  wurde auf Rechner ... gespeichert
        mac_appl_log_msg 'I' '>4' '803'
           p_h_file_name sy-host space space
           c_msgprio_high '1'.
        set extended check off.
        if 1 = 2. message i803(>4). endif.
        set extended check on.
      endif.

* ------- calls user exit 5051 ----------------------------------------*
      perform call_zp_fb_5051
         using
            p_t_fkkcollh_i_w
         changing
            p_t_fkkcollh_i.

* Schreiben Datei-Kopfsatz
      if p_i_basics-status-xsimu is initial.
        transfer t_fkkcollh_i to p_h_file_name.
      endif.

    endif.
  else.
* Nachricht: Schlüssel Inkassobüro is leer
    mac_appl_log_msg 'I' '>4' '804'
      space space space space
      c_msgprio_low '1'.
    set extended check off.
    if 1 = 2. message i804(>4). endif.
    set extended check on.

    p_rc = 8 .
    exit.
  endif.

* Vorbereiten Datei-Endesatz
  clear p_t_fkkcollt_i.
  p_t_fkkcollt_i-satztyp = c_trailer.

endform.                    " create_file_header
*&---------------------------------------------------------------------*
*&      Form  create_file_body
*&---------------------------------------------------------------------*
form create_file_body using    p_fkkcollinfo type fkkcollinfo
                               p_h_file_name
                               p_t_fkkcollh_i_w like dfkkcollh_i_w
                               p_t_fkkcollh_i like fkkcollh_i
                               p_i_basics type fkk_mad_basics
                      changing p_t_fkkcollt_i like fkkcollt_i.

* Erzeugen Positionen für direkte Zahlungen
***  if not p_fkkcollinfo-xausg is initial.
  perform create_info_payment
     using
        c_payment
        p_fkkcollinfo
        p_h_file_name
        p_t_fkkcollh_i_w
        p_t_fkkcollh_i
        p_i_basics
     changing
        p_t_fkkcollt_i.

* Erzeugen Positionen für Stornierungen von Zahlungen
  perform create_info_payment
     using
        c_storno
        p_fkkcollinfo
        p_h_file_name
        p_t_fkkcollh_i_w
        p_t_fkkcollh_i
        p_i_basics
     changing
        p_t_fkkcollt_i.

* Erzeugen Positionen für Stornierungen abgegebener Forderungen
  perform create_info_storno
     using
        c_cancelled_receivable
        p_fkkcollinfo
        p_h_file_name
        p_t_fkkcollh_i_w
        p_t_fkkcollh_i
        p_i_basics
     changing
        p_t_fkkcollt_i.


* Erzeugen Positionen für Ausbuchungen abgegebener Forderungen
  perform create_info_storno
     using
        c_write_off
        p_fkkcollinfo
        p_h_file_name
        p_t_fkkcollh_i_w
        p_t_fkkcollh_i
        p_i_basics
     changing
        p_t_fkkcollt_i.


* Erzeugen Positionen für Ausgleich
  perform create_info_payment
     using
        c_clearing
        p_fkkcollinfo
        p_h_file_name
        p_t_fkkcollh_i_w
        p_t_fkkcollh_i
        p_i_basics
     changing
        p_t_fkkcollt_i.

* Erzeugen Positionen für Zahlungen durch Inkassobüro
  perform create_info_payment
     using
        c_coll_ag_paid
        p_fkkcollinfo
        p_h_file_name
        p_t_fkkcollh_i_w
        p_t_fkkcollh_i
        p_i_basics
     changing
        p_t_fkkcollt_i.
***  endif.

* Erzeugen Positionen für Rückruf
  if not p_fkkcollinfo-xback is initial.
    perform create_info_recall
       using
          p_fkkcollinfo
          p_h_file_name
          p_t_fkkcollh_i_w
          p_t_fkkcollh_i
          p_i_basics
       changing
         p_t_fkkcollt_i.
  endif.

* Erzeugen Positionen für Geschäftspartner-Stammdatenänderungen
  if not p_fkkcollinfo-xcpart is initial.
    perform create_info_master_data_change
       using
          p_fkkcollinfo
          p_h_file_name
          p_t_fkkcollh_i_w
          p_t_fkkcollh_i
          p_i_basics
       changing
          p_t_fkkcollt_i.
  endif.

endform.                    " create_file_body
*&---------------------------------------------------------------------*
*&      Form  create_trailer
*&---------------------------------------------------------------------*
form create_trailer using    p_fkkcollinfo type fkkcollinfo
                             p_h_file_name
                             p_t_fkkcollh_i like fkkcollh_i
                             p_t_fkkcollt_i like fkkcollt_i
                             p_i_basics type fkk_mad_basics.

* ------- calls user exit 5053 ----------------------------------------*
  perform call_zp_fb_5053
     using
        p_t_fkkcollh_i
     changing
        p_t_fkkcollt_i.

* Scheiben Datei-Endesatz
  if p_i_basics-status-xsimu is initial.
    transfer p_t_fkkcollt_i to h_file_name.
  endif.

endform.                    " create_trailer
*&---------------------------------------------------------------------*
*&      Form  create_filename
*&---------------------------------------------------------------------*
form create_filename using    p_i_basics type fkk_mad_basics
                              p_p_fkkcollinfo_datei
                              p_p_t_fkkcollh_i_w_inkgp
                     changing p_h_file_name.

  data: w_knz       type c,
        w_lfdnr(8)  type n,
        w_lfdch(8)  type c,
        w_file_name like h_file_name, " authb-filename
        w_subname   like authb-filename.

  clear: w_knz, w_lfdnr, w_lfdch, w_file_name.

* Erzeugen Dateiname
  concatenate p_p_t_fkkcollh_i_w_inkgp ' '
         into w_subname.

  if p_p_fkkcollinfo_datei is initial.
* Falls logischer Dateiname ausgelassen, werden Abgabefiles in das
* HOME-Verzeichnis des aktuellen Servers abgelegt.
    p_h_file_name = w_subname.
  else.
* Wurde ein logischer Dateiname angegeben, erfolgt nach Bereitstellung
* des phys. Dateinemens dessen Verknüpfung  mit zusätzlichen
* Informationen wie <Schlüssel des Inkassobüros> und laufende-Nummer.
    call function 'FILE_GET_NAME'
      exporting
        logical_filename = p_p_fkkcollinfo_datei
      importing
        file_name        = p_h_file_name
      exceptions
        file_not_found   = 01.
    if sy-subrc eq 0.
      concatenate p_h_file_name w_subname into p_h_file_name.
    else.
      concatenate p_p_fkkcollinfo_datei w_subname into p_h_file_name.
    endif.
  endif.

  clear w_file_name.
  w_file_name = p_h_file_name.

* >>> note 1584972
* security enhancement (start)
  call function 'FILE_VALIDATE_NAME'
    exporting
      logical_filename           = 'FI-CA-COL-INFO'
    changing
      physical_filename          = w_file_name
    exceptions
      logical_filename_not_found = 1
      validation_failed          = 2
      others                     = 3.
  if sy-subrc ne 0.
    mac_appl_log_msg sy-msgty sy-msgid sy-msgno
     sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
     c_msgprio_high '1' .
  endif.
* security enhancement (end)
* <<< note 1584972

* Test Dateiname
  do 99999998 times.
    open dataset w_file_name for input in text mode
                                       encoding default.
    if not sy-subrc is initial.
      exit.
    endif.

    if w_knz is initial.
* Nachricht: Datei ... ist bereits vorhanden
      mac_appl_log_msg 'I' '>3' '805'
         p_h_file_name space space space
         c_msgprio_low '1'.
      set extended check off.
      if 1 = 2. message i805(>3). endif.
      set extended check on.

      w_knz = 'X'.
    endif.

* close dataset
    close dataset w_file_name.

* Erzeugen neuen Dateinamen, falls Datei schon existiert.
    clear w_file_name.
    add 1 to w_lfdnr.
    write w_lfdnr to w_lfdch no-zero.
    shift w_lfdch left deleting leading space.
    concatenate p_h_file_name w_lfdch
           into w_file_name separated by '_'.
  enddo.

  p_h_file_name =  w_file_name.

endform.                    " create_filename
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
*&      Form  create_info_payment
*&---------------------------------------------------------------------*
form create_info_payment using
                            p_postyp type postyp_kk
                            p_p_fkkcollinfo type fkkcollinfo
                            p_p_h_file_name
                            p_p_t_fkkcollh_i_w like dfkkcollh_i_w
                            p_p_t_fkkcollh_i like fkkcollh_i
                            p_p_i_basics type fkk_mad_basics
                         changing
                            p_p_t_fkkcollt_i like fkkcollt_i.

  data:
     t_fkkcollp_ip like fkkcollp_ip,
     t_fkkcollp_ip_w like dfkkcollp_ip_w,
     h_lfnum like dfkkcoli_log-lfdnr,
     h_anzza like sy-tabix,
     h_sumza type sumza_kk,
     h_summe type sumza_kk,
     h_knz,
     sum_fkkcollp_ip LIKE fkkcollp_ip,
     t_fkkcollp_ip_w_old LIKE dfkkcollp_ip_w.

  data:
    begin of h_key_nrzas,
     nrzas  type nrzas_kk,
     gpart  type gpart_kk,
    end of h_key_nrzas,
    h_key_nrzas_old like h_key_nrzas.

  data:
    begin of h_key_gpart,
     gpart  type gpart_kk,
     nrzas  type nrzas_kk,
    end of h_key_gpart,
    h_key_gpart_old like h_key_gpart.

  data:
    begin of h_key_vkont,
     vkont  type vkont_kk,
     nrzas  type nrzas_kk,
    end of h_key_vkont,
    h_key_vkont_old like h_key_vkont.

  clear:
    t_fkkcollp_ip,
    t_fkkcollp_ip_w,
    t_fkkcollp_ip_w_old,
    sum_fkkcollp_ip,
    h_anzza,
    h_summe,
    h_knz.

  clear:
    h_key_nrzas,
    h_key_nrzas_old,
    h_key_gpart,
    h_key_gpart_old,
    h_key_vkont,
    h_key_vkont_old.

  case p_p_fkkcollinfo-sumknz.

    when c_sum_no.
* ------- Keine Summierung --------------------------------------------*

* Lesen Ausgleichs-Informationen aus Zwischenspeicher
      select * into corresponding fields of t_fkkcollp_ip_w
               from  dfkkcollp_ip_w
               where laufd   eq p_p_i_basics-runkey-laufd
               and   laufi   eq p_p_i_basics-runkey-laufi
               and   w_inkgp eq p_p_t_fkkcollh_i_w-w_inkgp
               and   satztyp eq c_position
               and   postyp  eq p_postyp
               order by nrzas opbel inkps gpart.

        move-corresponding t_fkkcollp_ip_w to t_fkkcollp_ip.

* ------- calls user exit 5052 / payment ------------------------------*
        perform call_zp_fb_5052_payment
           using
              p_postyp
              p_p_t_fkkcollh_i
              t_fkkcollp_ip_w-lfdnr
           changing
              t_fkkcollp_ip.

* Ausgabe Inkassoposition auf Informationsdatei
        if t_fkkcollp_ip_w-logkz is initial.
          add 1 to h_anzza.
        endif.
        if p_p_i_basics-status-xsimu is initial.
          if t_fkkcollp_ip_w-logkz is initial.
            transfer t_fkkcollp_ip to p_p_h_file_name.
          endif.

* Meldung registrieren
          perform write_log_record_payment
             using
                t_fkkcollp_ip_w-lfdnr
                t_fkkcollp_ip
                p_p_i_basics.
        endif.

* Aktualisieren Datei-Endesatz
        if t_fkkcollp_ip_w-logkz is initial.
          add 1 to p_p_t_fkkcollt_i-recnum.
          perform addition
            using
              t_fkkcollp_ip-bwtrt
            changing
              p_p_t_fkkcollt_i-sumza.

* Aktualisieren Summensatz je Positionstyp
          perform addition
            using
              t_fkkcollp_ip-bwtrt
            changing
              h_summe.
        endif.

      endselect.


    when c_sum_gpart..

* ------- Summierung auf Geschäftspartnerebene ---------------------*
* Lesen Zahlungs- bzw. Ausgleichs-Informationen aus Zwischenspeicher
      select * into  corresponding fields of t_fkkcollp_ip_w
               from  dfkkcollp_ip_w
               where laufd   eq p_p_i_basics-runkey-laufd
               and   laufi   eq p_p_i_basics-runkey-laufi
               and   w_inkgp eq p_p_t_fkkcollh_i_w-w_inkgp
               and   satztyp eq c_position
               and   postyp  eq p_postyp
            ORDER BY gpart nrzas opbel inkps lfdnr.

        move-corresponding t_fkkcollp_ip_w to t_fkkcollp_ip.
        move-corresponding t_fkkcollp_ip   to h_key_gpart.

        if h_key_gpart_old ne h_key_gpart.
* Gruppenwechsel
          if not h_knz is initial.

* ------- calls user exit 5052 / payment (sum) ------------------------*
            perform call_zp_fb_5052_payment
               using
                  p_postyp
                  p_p_t_fkkcollh_i
                  0
               changing
                  sum_fkkcollp_ip.

* Ausgabe Inkassoposition auf Informationsdatei
            if t_fkkcollp_ip_w-logkz is initial.
              add 1 to h_anzza.

              if p_p_i_basics-status-xsimu is initial.
                transfer sum_fkkcollp_ip to p_p_h_file_name.
              endif.

* Aktualisieren Datei-Endesatz
              add 1 to p_p_t_fkkcollt_i-recnum.
              perform addition
                using
                  sum_fkkcollp_ip-bwtrt
                changing
                  p_p_t_fkkcollt_i-sumza.

            endif.
          endif.
          clear sum_fkkcollp_ip.
        endif.
        h_knz = 'X'.

* Aufbau Summensatz
        sum_fkkcollp_ip-postyp  = t_fkkcollp_ip-postyp.
        sum_fkkcollp_ip-satztyp = t_fkkcollp_ip-satztyp.
        sum_fkkcollp_ip-nrzas   = t_fkkcollp_ip-nrzas.
        sum_fkkcollp_ip-gpart   = t_fkkcollp_ip-gpart.
        sum_fkkcollp_ip-waers   = t_fkkcollp_ip-waers.
        sum_fkkcollp_ip-txtvw   = t_fkkcollp_ip-txtvw.

        if t_fkkcollp_ip_w-logkz is initial.
          perform addition
          using
            t_fkkcollp_ip-bwtrt
          changing
            sum_fkkcollp_ip-bwtrt.

          ">>>Note 2072897
          IF t_fkkcollp_ip_w_old IS INITIAL OR
            ( t_fkkcollp_ip_w_old-vkont NE t_fkkcollp_ip_w-vkont
              OR t_fkkcollp_ip_w_old-nrzas NE t_fkkcollp_ip_w-nrzas
              OR t_fkkcollp_ip_w_old-opbel NE t_fkkcollp_ip_w-opbel
              OR t_fkkcollp_ip_w_old-inkps NE t_fkkcollp_ip_w-inkps ).

                PERFORM addition
            using
              t_fkkcollp_ip-betrw
            changing
              sum_fkkcollp_ip-betrw.

          ENDIF.

* Aktualisieren Protokollsatz
          perform addition
            using
              t_fkkcollp_ip-bwtrt
            changing
              h_summe.
        endif.

* Meldung registrieren
        if p_p_i_basics-status-xsimu is initial.
          perform write_log_record_payment
             using
                t_fkkcollp_ip_w-lfdnr
                t_fkkcollp_ip
                p_p_i_basics.
        endif.

        move-corresponding h_key_gpart to h_key_gpart_old.

        CLEAR t_fkkcollp_ip_w_old.
        t_fkkcollp_ip_w_old = t_fkkcollp_ip_w.

      endselect.

* Ausagbe letzte Inkassoposition
      if not h_knz is initial.

* ------- calls user exit 5052 / payment -----------------------------*
        perform call_zp_fb_5052_payment
           using
              p_postyp
              p_p_t_fkkcollh_i
              0
           changing
              sum_fkkcollp_ip.

* Ausgabe Inkassoposition auf Informationsdatei
        if not h_summe is initial.
          add 1 to h_anzza.

          if p_p_i_basics-status-xsimu is initial.
            transfer sum_fkkcollp_ip to p_p_h_file_name.
          endif.
        endif.
        h_knz = 'X'.

* Aktualisieren Datei-Endesatz
        if t_fkkcollp_ip_w-logkz is initial.
          add 1 to p_p_t_fkkcollt_i-recnum.
          perform addition
             using
               sum_fkkcollp_ip-bwtrt
             changing
               p_p_t_fkkcollt_i-sumza.
        endif.
      endif.


    when c_sum_nrzas.
* ------- Summierung auf Basis Zahlschein-Nummer ----------------------*

* Lesen Ausgleichs-Informationen aus Zwischenspeicher
      select * into  corresponding fields of t_fkkcollp_ip_w
               from  dfkkcollp_ip_w
               where laufd   eq p_p_i_basics-runkey-laufd
               and   laufi   eq p_p_i_basics-runkey-laufi
               and   w_inkgp eq p_p_t_fkkcollh_i_w-w_inkgp
               and   satztyp eq c_position
               and   postyp  eq p_postyp
            ORDER BY nrzas gpart opbel inkps lfdnr.

        move-corresponding t_fkkcollp_ip_w to t_fkkcollp_ip.
        move-corresponding t_fkkcollp_ip   to h_key_nrzas.

        if h_key_nrzas_old ne h_key_nrzas.
* Gruppenwechsel
          if not h_knz is initial.
* ------- calls user exit 5052 / payment (sum) ------------------------*
            perform call_zp_fb_5052_payment
               using
                  p_postyp
                  p_p_t_fkkcollh_i
                  0
               changing
                  sum_fkkcollp_ip.

* Ausgabe Inkassoposition auf Informationsdatei
            if t_fkkcollp_ip_w-logkz is initial.
              add 1 to h_anzza.

              if p_p_i_basics-status-xsimu is initial.
                transfer sum_fkkcollp_ip to p_p_h_file_name.
              endif.

* Aktualisieren Datei-Endesatz
              add 1 to p_p_t_fkkcollt_i-recnum.
              perform addition
                 using
                   sum_fkkcollp_ip-bwtrt
                 changing
                   p_p_t_fkkcollt_i-sumza.
            endif.
          endif.
          clear sum_fkkcollp_ip.
        endif.
        h_knz = 'X'.

* Aufbau Summensatz
        sum_fkkcollp_ip-postyp  = t_fkkcollp_ip-postyp.
        sum_fkkcollp_ip-satztyp = t_fkkcollp_ip-satztyp.
        sum_fkkcollp_ip-nrzas   = t_fkkcollp_ip-nrzas.
        sum_fkkcollp_ip-gpart   = t_fkkcollp_ip-gpart.
        sum_fkkcollp_ip-waers   = t_fkkcollp_ip-waers.
        sum_fkkcollp_ip-txtvw   = t_fkkcollp_ip-txtvw.

        if t_fkkcollp_ip_w-logkz is initial.
          perform addition
          using
            t_fkkcollp_ip-bwtrt
          changing
            sum_fkkcollp_ip-bwtrt.

          ">>>Note 2072897
          IF t_fkkcollp_ip_w_old IS INITIAL OR
            ( t_fkkcollp_ip_w_old-vkont NE t_fkkcollp_ip_w-vkont
              OR t_fkkcollp_ip_w_old-nrzas NE t_fkkcollp_ip_w-nrzas
              OR t_fkkcollp_ip_w_old-opbel NE t_fkkcollp_ip_w-opbel
              OR t_fkkcollp_ip_w_old-inkps NE t_fkkcollp_ip_w-inkps ).

                PERFORM addition
            using
              t_fkkcollp_ip-betrw
            changing
              sum_fkkcollp_ip-betrw.
          ENDIF.

* Aktualisieren Protokollsatz
          perform addition
            using
              t_fkkcollp_ip-bwtrt
            changing
              h_summe.
        endif.

* Meldung registrieren
        if p_p_i_basics-status-xsimu is initial.
          perform write_log_record_payment
             using
                t_fkkcollp_ip_w-lfdnr
                t_fkkcollp_ip
                p_p_i_basics.
        endif.

* Merken letzte Schlüssel
        move-corresponding h_key_nrzas to h_key_nrzas_old.
        CLEAR t_fkkcollp_ip_w_old.
        t_fkkcollp_ip_w_old = t_fkkcollp_ip_w.

      endselect.

      if not h_knz is initial.
* ------- calls user exit 5052 / payment (sum) ------------------------*
        perform call_zp_fb_5052_payment
           using
              p_postyp
              p_p_t_fkkcollh_i
              0
           changing
              sum_fkkcollp_ip.

* Ausgabe Inkassoposition auf Informationsdatei
        if not h_summe is initial.
          add 1 to h_anzza.
          if p_p_i_basics-status-xsimu is initial.
            transfer sum_fkkcollp_ip to p_p_h_file_name.
          endif.
        endif.
        h_knz = 'X'.

* Aktualisieren Datei-Endesatz
        if t_fkkcollp_ip_w-logkz is initial.
          add 1 to p_p_t_fkkcollt_i-recnum.
          perform addition
            using
              sum_fkkcollp_ip-bwtrt
            changing
             p_p_t_fkkcollt_i-sumza.
        endif.
      endif.

    when c_sum_vkont.

* ------- Summierung auf Vertragskontoebene ---------------------*
* Lesen Zahlungs- bzw. Ausgleichs-Informationen aus Zwischenspeicher
      select * into  corresponding fields of t_fkkcollp_ip_w
               from  dfkkcollp_ip_w
               where laufd   eq p_p_i_basics-runkey-laufd
               and   laufi   eq p_p_i_basics-runkey-laufi
               and   w_inkgp eq p_p_t_fkkcollh_i_w-w_inkgp
               and   satztyp eq c_position
               and   postyp  eq p_postyp
            ORDER BY vkont nrzas opbel inkps lfdnr.

        move-corresponding t_fkkcollp_ip_w to t_fkkcollp_ip.
        move-corresponding t_fkkcollp_ip   to h_key_vkont.

        if h_key_vkont_old ne h_key_vkont.
* Gruppenwechsel
          if not h_knz is initial.

* ------- calls user exit 5052 / payment (sum) ------------------------*
            perform call_zp_fb_5052_payment
               using
                  p_postyp
                  p_p_t_fkkcollh_i
                  0
               changing
                  sum_fkkcollp_ip.

* Ausgabe Inkassoposition auf Informationsdatei
            if t_fkkcollp_ip_w-logkz is initial.
              add 1 to h_anzza.

              if p_p_i_basics-status-xsimu is initial.
                transfer sum_fkkcollp_ip to p_p_h_file_name.
              endif.

* Aktualisieren Datei-Endesatz
              add 1 to p_p_t_fkkcollt_i-recnum.
              perform addition
                using
                  sum_fkkcollp_ip-bwtrt
                changing
                  p_p_t_fkkcollt_i-sumza.

            endif.
          endif.
          clear sum_fkkcollp_ip.
        endif.
        h_knz = 'X'.

* Aufbau Summensatz
        sum_fkkcollp_ip-postyp  = t_fkkcollp_ip-postyp.
        sum_fkkcollp_ip-satztyp = t_fkkcollp_ip-satztyp.
        sum_fkkcollp_ip-nrzas   = t_fkkcollp_ip-nrzas.
        sum_fkkcollp_ip-gpart   = t_fkkcollp_ip-gpart.
        sum_fkkcollp_ip-vkont   = t_fkkcollp_ip-vkont.
        sum_fkkcollp_ip-waers   = t_fkkcollp_ip-waers.
        sum_fkkcollp_ip-txtvw   = t_fkkcollp_ip-txtvw.

        if t_fkkcollp_ip_w-logkz is initial.
          perform addition
          using
            t_fkkcollp_ip-bwtrt
          changing
            sum_fkkcollp_ip-bwtrt.

          ">>>Note 2072897
          IF t_fkkcollp_ip_w_old IS INITIAL OR
            ( t_fkkcollp_ip_w_old-vkont NE t_fkkcollp_ip_w-vkont
              OR t_fkkcollp_ip_w_old-nrzas NE t_fkkcollp_ip_w-nrzas
              OR t_fkkcollp_ip_w_old-opbel NE t_fkkcollp_ip_w-opbel
              OR t_fkkcollp_ip_w_old-inkps NE t_fkkcollp_ip_w-inkps ).

                PERFORM addition
            using
              t_fkkcollp_ip-betrw
            changing
              sum_fkkcollp_ip-betrw.
          ENDIF.

* Aktualisieren Protokollsatz
          perform addition
            using
              t_fkkcollp_ip-bwtrt
            changing
              h_summe.
        endif.

* Meldung registrieren
        if p_p_i_basics-status-xsimu is initial.
          perform write_log_record_payment
             using
                t_fkkcollp_ip_w-lfdnr
                t_fkkcollp_ip
                p_p_i_basics.
        endif.

        move-corresponding h_key_vkont to h_key_vkont_old.
        CLEAR t_fkkcollp_ip_w_old.
        t_fkkcollp_ip_w_old = t_fkkcollp_ip_w.

      endselect.

* Ausgabe letzte Inkassoposition
      if not h_knz is initial.

* ------- calls user exit 5052 / payment -----------------------------*
        perform call_zp_fb_5052_payment
           using
              p_postyp
              p_p_t_fkkcollh_i
              0
           changing
              sum_fkkcollp_ip.

* Ausgabe Inkassoposition auf Informationsdatei
        if not h_summe is initial.
          add 1 to h_anzza.

          if p_p_i_basics-status-xsimu is initial.
            transfer sum_fkkcollp_ip to p_p_h_file_name.
          endif.
        endif.
        h_knz = 'X'.

* Aktualisieren Datei-Endesatz
        if t_fkkcollp_ip_w-logkz is initial.
          add 1 to p_p_t_fkkcollt_i-recnum.
          perform addition
             using
               sum_fkkcollp_ip-bwtrt
             changing
               p_p_t_fkkcollt_i-sumza.
        endif.
      endif.

  endcase.

*>>>>> HANA
  IF NOT gt_fkkcoli_log[] IS INITIAL.
    INSERT dfkkcoli_log FROM TABLE gt_fkkcoli_log.
    CLEAR: gt_fkkcoli_log[],gt_fkkcoli_log.
  ENDIF.
*<<<<< HANA

* Protokoll
  WRITE h_summe TO h_sumza.
  shift h_sumza left deleting leading space.
  if p_postyp eq c_payment.
* Nachricht: Datei enthält & Zahlungs-Positionen im Gesamtwert von & &
    if h_anzza > 0.
      mac_appl_log_msg 'I' '>4' '810'
         h_anzza
         h_sumza t_fkkcollp_ip-waers space
         c_msgprio_info p_p_i_basics-appllog-probclass.
      set extended check off.
      if 1 = 2. message i810(>4). endif.
      set extended check on.
    endif.

  elseif p_postyp eq c_storno.
* Nachricht: Datei enthält & Storno-Positionen im Gesamtwert von & &
    if h_anzza > 0.
      mac_appl_log_msg 'I' '>4' '809'
         h_anzza
         h_sumza t_fkkcollp_ip-waers space
         c_msgprio_info p_p_i_basics-appllog-probclass.
      set extended check off.
      if 1 = 2. message i809(>4). endif.
      set extended check on.
    endif.

  elseif p_postyp eq c_clearing.
* Nachricht: Datei enthält & Ausgleichspositionen im Gesamtwert von & &
    if h_anzza > 0.
      mac_appl_log_msg 'I' '>4' '802'
         h_anzza
         h_sumza t_fkkcollp_ip-waers space
         c_msgprio_info p_p_i_basics-appllog-probclass.
      set extended check off.
      if 1 = 2. message i802(>4). endif.
      set extended check on.
    endif.

  endif.

endform.                    " create_info_payment
*&---------------------------------------------------------------------*
*&      Form  create_info_recall
*&---------------------------------------------------------------------*
form create_info_recall using    p_p_fkkcollinfo type fkkcollinfo
                                 p_p_h_file_name
                                 p_p_t_fkkcollh_i_w like dfkkcollh_i_w
                                 p_p_t_fkkcollh_i like fkkcollh_i
                                 p_p_i_basics type fkk_mad_basics
                        changing p_p_t_fkkcollt_i like fkkcollt_i.

  data:
    t_fkkcollp_ir like fkkcollp_ir,
    t_fkkcollp_ir_w like dfkkcollp_ir_w,
    h_lfdnr like dfkkcoli_log-lfdnr,
    h_sumrc type sumza_kk,
    h_summe type sumza_kk,
    h_knz,
    h_anzrc like sy-tabix,
    sum_fkkcollp_ir like fkkcollp_ir.

  data:
     begin of h_key_nrzas,
      nrzas  type nrzas_kk,
      gpart  type gpart_kk,
     end of h_key_nrzas,
     h_key_nrzas_old like h_key_nrzas.

  data:
    begin of h_key_gpart,
     gpart  type gpart_kk,
     nrzas  type nrzas_kk,
    end of h_key_gpart,
    h_key_gpart_old like h_key_gpart.

  data:
    begin of h_key_vkont,
     vkont  type vkont_kk,
     nrzas  type nrzas_kk,
    end of h_key_vkont,
    h_key_vkont_old like h_key_vkont.

  clear:
    t_fkkcollp_ir,
    t_fkkcollp_ir_w,
    sum_fkkcollp_ir,
    h_anzrc,
    h_knz.

  clear:
    h_key_nrzas,
    h_key_nrzas_old,
    h_key_gpart,
    h_key_gpart_old,
    h_key_vkont,
    h_key_vkont_old.

  case p_p_fkkcollinfo-sumknz.

    when c_sum_no.
* ------- Keine Summierung --------------------------------------------*

* Lesen Rückruf-Informationen aus Zwischenspeicher
      select * into  corresponding fields of t_fkkcollp_ir_w
               from  dfkkcollp_ir_w
               where laufd   eq p_p_i_basics-runkey-laufd
               and   laufi   eq p_p_i_basics-runkey-laufi
               and   w_inkgp eq p_p_t_fkkcollh_i_w-w_inkgp
               and   satztyp eq c_position
               and   postyp  eq c_recall
               order by nrzas opbel inkps gpart.

        move-corresponding t_fkkcollp_ir_w to t_fkkcollp_ir.

* ------- calls user exit 5052 / recall -------------------------------*
        perform call_zp_fb_5052_recall
           using
              p_p_t_fkkcollh_i
              t_fkkcollp_ir_w-lfdnr
           changing
              t_fkkcollp_ir.

* Ausgabe Rückrufinformation auf Informationsdatei
        add 1 to h_anzrc.
        if p_p_i_basics-status-xsimu is initial.
          transfer t_fkkcollp_ir to p_p_h_file_name.

* Registrieren Meldung in Log-Tabelle
          perform write_log_record_recall
             using
                t_fkkcollp_ir_w-lfdnr
                t_fkkcollp_ir
                p_p_i_basics.
        endif.

* Aktualisieren Datei-Endesatz
        add 1 to p_p_t_fkkcollt_i-recnum.
        perform addition
          using
            t_fkkcollp_ir-betrw
          changing
            p_p_t_fkkcollt_i-sumrc.
        perform addition
          using
            t_fkkcollp_ir-betrw
          changing
            h_summe.
      endselect.

    when c_sum_gpart.
* ------- Summierung über Geschäftspartner-Nummer ---------------------*

* Lesen Rückruf-Informationen aus Zwischenspeicher
      select * into  corresponding fields of t_fkkcollp_ir_w
               from  dfkkcollp_ir_w
               where laufd   eq p_p_i_basics-runkey-laufd
               and   laufi   eq p_p_i_basics-runkey-laufi
               and   w_inkgp eq p_p_t_fkkcollh_i_w-w_inkgp
               and   satztyp eq c_position
               and   postyp  eq c_recall
               order by gpart nrzas opbel inkps.

        move-corresponding t_fkkcollp_ir_w to t_fkkcollp_ir.
        move-corresponding t_fkkcollp_ir to h_key_gpart.

        if h_key_gpart_old ne h_key_gpart.
* Gruppenwechsel
          if not h_knz is initial.

* ------- calls user exit 5052 / recall (sum) -------------------------*
            perform call_zp_fb_5052_recall
               using
                  p_p_t_fkkcollh_i
                  0
               changing
                  sum_fkkcollp_ir.

* Ausgabe Rückruf auf Informationsdatei
            add 1 to h_anzrc.
            if p_p_i_basics-status-xsimu is initial.
              transfer sum_fkkcollp_ir to p_p_h_file_name.
            endif.

* Aktualisieren Datei-Endesatz
            add 1 to p_p_t_fkkcollt_i-recnum.
            perform addition
              using
                sum_fkkcollp_ir-betrw
              changing
                p_p_t_fkkcollt_i-sumrc.
          endif.
          clear sum_fkkcollp_ir.
        endif.
        h_knz = 'X'.

* Aufbau Summensatz
        sum_fkkcollp_ir-postyp  = t_fkkcollp_ir-postyp.
        sum_fkkcollp_ir-satztyp = t_fkkcollp_ir-satztyp.
        sum_fkkcollp_ir-nrzas   = t_fkkcollp_ir-nrzas.
        sum_fkkcollp_ir-gpart   = t_fkkcollp_ir-gpart.
        sum_fkkcollp_ir-waers   = t_fkkcollp_ir-waers.
        sum_fkkcollp_ir-txtvw   = t_fkkcollp_ir-txtvw.
        perform addition
          using
            t_fkkcollp_ir-betrw
          changing
            sum_fkkcollp_ir-betrw.
        perform addition
          using
            t_fkkcollp_ir-betrw
          changing
            h_summe.

* Registrieren Rüchrufmeldung
        if p_p_i_basics-status-xsimu is initial.
          perform write_log_record_recall
             using
                t_fkkcollp_ir_w-lfdnr
                t_fkkcollp_ir
                p_p_i_basics.
        endif.

        move-corresponding h_key_gpart to h_key_gpart_old.

      endselect.

* Ausagbe letzte Info
      if not h_knz is initial.

* ------- calls user exit 5052 / recall (sum) -------------------------*
        perform call_zp_fb_5052_recall
           using
              p_p_t_fkkcollh_i
              0
           changing
              sum_fkkcollp_ir.

* Ausgabe Rückrufinformation auf Informationsdatei
        add 1 to h_anzrc.
        if p_p_i_basics-status-xsimu is initial.
          transfer sum_fkkcollp_ir to p_p_h_file_name.
        endif.
        h_knz = 'X'.

* Aktualisieren Datei-Endesatz
        add 1 to p_p_t_fkkcollt_i-recnum.
        perform addition
          using
            sum_fkkcollp_ir-betrw
          changing
            p_p_t_fkkcollt_i-sumrc.
      endif.

    when c_sum_nrzas.
* ------- Summierung auf Basis Zahlschein-Nummer ---------------------*

* Lesen Rückruf-Informationen aus Zwischenspeicher
      select * into  corresponding fields of t_fkkcollp_ir_w
               from  dfkkcollp_ir_w
               where laufd   eq p_p_i_basics-runkey-laufd
               and   laufi   eq p_p_i_basics-runkey-laufi
               and   w_inkgp eq p_p_t_fkkcollh_i_w-w_inkgp
               and   satztyp eq c_position
               and   postyp  eq c_recall
               order by nrzas gpart opbel inkps.

        move-corresponding t_fkkcollp_ir_w to t_fkkcollp_ir.
        move-corresponding t_fkkcollp_ir to h_key_nrzas.

        if h_key_nrzas_old ne h_key_nrzas.
* Gruppenwechsel
          if not h_knz is initial.

* ------- calls user exit 5052 / recall (sum) -------------------------*
            perform call_zp_fb_5052_recall
               using
                  p_p_t_fkkcollh_i
                  0
               changing
                  sum_fkkcollp_ir.

* Ausgabe Rückrufinformation auf Informationsdatei
            add 1 to h_anzrc.
            if p_p_i_basics-status-xsimu is initial.
              transfer sum_fkkcollp_ir to p_p_h_file_name.
            endif.

* Aktualisieren Datei-Endesatz
            add 1 to p_p_t_fkkcollt_i-recnum..
            perform addition
              using
                sum_fkkcollp_ir-betrw
              changing
                p_p_t_fkkcollt_i-sumrc.
          endif.
          clear sum_fkkcollp_ir.
        endif.
        h_knz = 'X'.

* Aufbau Summensatz
        sum_fkkcollp_ir-postyp  = t_fkkcollp_ir-postyp.
        sum_fkkcollp_ir-satztyp = t_fkkcollp_ir-satztyp.
        sum_fkkcollp_ir-nrzas   = t_fkkcollp_ir-nrzas.
        sum_fkkcollp_ir-gpart   = t_fkkcollp_ir-gpart.
        sum_fkkcollp_ir-waers   = t_fkkcollp_ir-waers.
        sum_fkkcollp_ir-txtvw   = t_fkkcollp_ir-txtvw.
        perform addition
          using
            t_fkkcollp_ir-betrw
          changing
            sum_fkkcollp_ir-betrw.
        perform addition
          using
            t_fkkcollp_ir-betrw
          changing
            h_summe.

* Registrieren Rüchrufmeldung
        if p_p_i_basics-status-xsimu is initial.
          perform write_log_record_recall
             using
                t_fkkcollp_ir_w-lfdnr
                t_fkkcollp_ir
                p_p_i_basics.
        endif.

        move-corresponding h_key_nrzas to h_key_nrzas_old.

      endselect.

      if not h_knz is initial.
* ------- calls user exit 5052 / recall (sum) -------------------------*
        perform call_zp_fb_5052_recall
           using
              p_p_t_fkkcollh_i
              0
           changing
              sum_fkkcollp_ir.

* Ausgabe Rückrufinformation auf Informationsdatei
        add 1 to h_anzrc.
        if p_p_i_basics-status-xsimu is initial.
          transfer sum_fkkcollp_ir to p_p_h_file_name.
        endif.
        h_knz = 'X'.

* Aktualisieren Datei-Endesatz
        add 1 to p_p_t_fkkcollt_i-recnum.
        perform addition
          using
            sum_fkkcollp_ir-betrw
          changing
            p_p_t_fkkcollt_i-sumrc.
      endif.

    when c_sum_vkont.
* ------- Summierung über Vertragskonto-Nummer ---------------------*

* Lesen Rückruf-Informationen aus Zwischenspeicher
      select * into  corresponding fields of t_fkkcollp_ir_w
               from  dfkkcollp_ir_w
               where laufd   eq p_p_i_basics-runkey-laufd
               and   laufi   eq p_p_i_basics-runkey-laufi
               and   w_inkgp eq p_p_t_fkkcollh_i_w-w_inkgp
               and   satztyp eq c_position
               and   postyp  eq c_recall
               order by vkont nrzas opbel inkps.

        move-corresponding t_fkkcollp_ir_w to t_fkkcollp_ir.
        move-corresponding t_fkkcollp_ir to h_key_vkont.

        if h_key_vkont_old ne h_key_vkont.
* Gruppenwechsel
          if not h_knz is initial.

* ------- calls user exit 5052 / recall (sum) -------------------------*
            perform call_zp_fb_5052_recall
               using
                  p_p_t_fkkcollh_i
                  0
               changing
                  sum_fkkcollp_ir.

* Ausgabe Rückruf auf Informationsdatei
            add 1 to h_anzrc.
            if p_p_i_basics-status-xsimu is initial.
              transfer sum_fkkcollp_ir to p_p_h_file_name.
            endif.

* Aktualisieren Datei-Endesatz
            add 1 to p_p_t_fkkcollt_i-recnum.
            perform addition
              using
                sum_fkkcollp_ir-betrw
              changing
                p_p_t_fkkcollt_i-sumrc.
          endif.
          clear sum_fkkcollp_ir.
        endif.
        h_knz = 'X'.

* Aufbau Summensatz
        sum_fkkcollp_ir-postyp  = t_fkkcollp_ir-postyp.
        sum_fkkcollp_ir-satztyp = t_fkkcollp_ir-satztyp.
        sum_fkkcollp_ir-nrzas   = t_fkkcollp_ir-nrzas.
        sum_fkkcollp_ir-gpart   = t_fkkcollp_ir-gpart.
        sum_fkkcollp_ir-vkont   = t_fkkcollp_ir-vkont.
        sum_fkkcollp_ir-waers   = t_fkkcollp_ir-waers.
        sum_fkkcollp_ir-txtvw   = t_fkkcollp_ir-txtvw.
        perform addition
          using
            t_fkkcollp_ir-betrw
          changing
            sum_fkkcollp_ir-betrw.
        perform addition
          using
            t_fkkcollp_ir-betrw
          changing
            h_summe.

* Registrieren Rüchrufmeldung
        if p_p_i_basics-status-xsimu is initial.
          perform write_log_record_recall
             using
                t_fkkcollp_ir_w-lfdnr
                t_fkkcollp_ir
                p_p_i_basics.
        endif.

        move-corresponding h_key_vkont to h_key_vkont_old.

      endselect.

* Ausagbe letzte Info
      if not h_knz is initial.

* ------- calls user exit 5052 / recall (sum) -------------------------*
        perform call_zp_fb_5052_recall
           using
              p_p_t_fkkcollh_i
              0
           changing
              sum_fkkcollp_ir.

* Ausgabe Rückrufinformation auf Informationsdatei
        add 1 to h_anzrc.
        if p_p_i_basics-status-xsimu is initial.
          transfer sum_fkkcollp_ir to p_p_h_file_name.
        endif.
        h_knz = 'X'.

* Aktualisieren Datei-Endesatz
        add 1 to p_p_t_fkkcollt_i-recnum.
        perform addition
          using
            sum_fkkcollp_ir-betrw
          changing
            p_p_t_fkkcollt_i-sumrc.
      endif.

  endcase.

* Protokoll
* Nachricht: Datei enthält Rückrufpositionen im Gesamtwert von & &
  if h_anzrc > 0.
    write h_summe to h_sumrc left-justified.
    shift h_sumrc left deleting leading space.
    mac_appl_log_msg 'I' '>4' '801'
       h_anzrc
       h_sumrc t_fkkcollp_ir-waers space
       c_msgprio_info p_p_i_basics-appllog-probclass.
    set extended check off.
    if 1 = 2. message i801(>4). endif.
    set extended check on.
  endif.

endform.                    " create_info_recall
*&---------------------------------------------------------------------*
*&      Form  CREATE_INFO_MASTER_DATA_CHANGE
*&---------------------------------------------------------------------*
form create_info_master_data_change
                             using
                                p_p_fkkcollinfo type fkkcollinfo
                                p_p_h_file_name
                                p_p_t_fkkcollh_i_w like dfkkcollh_i_w
                                p_p_t_fkkcollh_i like fkkcollh_i
                                p_p_i_basics type fkk_mad_basics
                             changing
                                p_p_t_fkkcollt_i like fkkcollt_i.

  data:
    t_fkkcollp_im like fkkcollp_im,
    t_fkkcollp_im_w like dfkkcollp_im_w,
    h_anzgp like sy-tabix,
    h_gpanz(16),
    h_lfdnr like dfkkcoli_log-lfdnr,
    h_inkps like dfkkcoli_log-inkps.

  clear:
    t_fkkcollp_im,
    t_fkkcollp_im_w,
    h_anzgp.

  select * into  t_fkkcollp_im_w
           from  dfkkcollp_im_w
           where laufd   eq p_p_i_basics-runkey-laufd
           and   laufi   eq p_p_i_basics-runkey-laufi
           and   w_inkgp eq p_p_t_fkkcollh_i_w-w_inkgp
           and   satztyp eq c_position
           and   postyp  eq c_master_data_changes
           order by gpart.

    move-corresponding  t_fkkcollp_im_w to t_fkkcollp_im.

* Berechnen lfd. Nummer
    perform get_lfdnr_master_data_change
                using
                   t_fkkcollp_im-gpart
                changing
                   h_lfdnr
                   h_inkps.

* ------- calls user exit 5052 / BP-Master data changes ---------------*
    perform call_zp_fb_5052_gpart
       using
          p_p_t_fkkcollh_i
       changing
          t_fkkcollp_im.

* Scheiben Datei-Position
    if p_p_i_basics-status-xsimu is initial.
      transfer t_fkkcollp_im to p_p_h_file_name.

* Meldung registrieren
      perform write_log_record_gpart
         using
            h_lfdnr
            h_inkps
            t_fkkcollp_im
            t_fkkcollp_im_w
            p_p_i_basics.
    endif.

* Aktualisieren Zatzähler
    add 1 to p_p_t_fkkcollt_i-recnum.
    add 1 to h_anzgp.

  endselect.

* Protokoll
* Nachricht: Datei enthält Informationen zu & Stammdatenänderungen
  write h_anzgp to h_gpanz left-justified.
  if not h_anzgp is initial.
    mac_appl_log_msg 'I' '>4' '807'
       h_gpanz space space space
       c_msgprio_info p_p_i_basics-appllog-probclass.
    set extended check off.
    if 1 = 2. message i807(>4). endif.
    set extended check on.
  endif.

endform.                    " CREATE_INFO_MASTER_DATA_CHANGE
*&---------------------------------------------------------------------*
*&      Form  get_lfdnr_master_data_change
*&---------------------------------------------------------------------*
form get_lfdnr_master_data_change
  using
        p_gpart   type gpart_kk
  changing
        p_lfdnr   type lfdnr_kk
        p_inkps   type inkps_kk.

  statics h_lfdnr        type lfdnr_kk.
  statics h_gpart_old    type gpart_kk.

* Berechnen lfd. Nummer
  if p_gpart ne h_gpart_old or
     h_lfdnr eq '999'.

    select max( inkps ) into p_inkps
           from  dfkkcoli_log
           where nrzas  eq space
           and   opbel  eq space
           and   gpart  eq p_gpart.
    if not sy-subrc is initial.
      clear p_inkps.
    endif.

    select max( lfdnr ) into h_lfdnr
           from  dfkkcoli_log
           where nrzas  eq space
           and   opbel  eq space
           and   inkps  eq p_inkps
           and   gpart  eq p_gpart.
    if not sy-subrc is initial.
      clear h_lfdnr.
    else.
      if h_lfdnr eq '999'.
        add 1 to h_lfdnr.
        add 1 to p_inkps.
      endif.
    endif.
  endif.

  add 1 to h_lfdnr.
  p_lfdnr = h_lfdnr.

  h_gpart_old = p_gpart.

endform.                    "get_lfdnr_master_data_change
*&---------------------------------------------------------------------*
*&      Form  call_zp_fb_5051
*&---------------------------------------------------------------------*
*       Exit 5051 Ergänzen Dateikopf
*----------------------------------------------------------------------*
form call_zp_fb_5051 using    p_p_t_fkkcollh_i_w like dfkkcollh_i_w
                     changing p_p_t_fkkcollh_i like fkkcollh_i.

  data:  lt_fkkcollh_i  like fkkcollh_i.

  clear: lt_fkkcollh_i.

  move-corresponding p_p_t_fkkcollh_i_w  to lt_fkkcollh_i.
  loop at t_tfkfbc_5051.
    call function t_tfkfbc_5051-funcc
      exporting
        i_fkkcollh_i = lt_fkkcollh_i
      changing
        c_fkkcollh_i = lt_fkkcollh_i.
  endloop.
  move-corresponding lt_fkkcollh_i to p_p_t_fkkcollh_i.

  set extended check off.
  if 1 = 2. call function 'FKK_SAMPLE_5051'. endif.
  set extended check on.

endform.                    " call_zp_fb_5051
*&---------------------------------------------------------------------*
*&      Form  call_zp_fb_5052_payment
*&---------------------------------------------------------------------*
*       Exit 5052 Ergänzen Positionsdaten - Zahlungen, Storno, Ausgleich
*----------------------------------------------------------------------*
*      -->P_P_POSTYP          Positionstyp { 1 / 4 / 5 }
*      -->P_P_P_T_FKKCOLLH_I  Kopfsatz
*      <--P_T_FKKCOLLP_IP     Positionsatz Ausgleich
*----------------------------------------------------------------------*
form call_zp_fb_5052_payment using p_p_postyp type postyp_kk
                                   p_p_t_fkkcollh_i like fkkcollh_i
                                   p_lfdnr type lfdnr_kk
                          changing p_t_fkkcollp_ip like fkkcollp_ip.

  data:  lt_fkkcollp_ip  like fkkcollp_ip.

  clear: lt_fkkcollp_ip.

  move-corresponding p_t_fkkcollp_ip to lt_fkkcollp_ip.

  loop at t_tfkfbc_5052.
    call function t_tfkfbc_5052-funcc
      exporting
        i_postyp      = p_p_postyp
        i_fkkcollh_i  = p_p_t_fkkcollh_i
        i_lfdnr       = p_lfdnr
      changing
        c_fkkcollp_ip = lt_fkkcollp_ip.
  endloop.

  move-corresponding lt_fkkcollp_ip to p_t_fkkcollp_ip.

  set extended check off.
  if 1 = 2. call function 'FKK_SAMPLE_5052'. endif.
  set extended check on.

endform.                    " call_zp_fb_5052_payment
*&---------------------------------------------------------------------*
*&      Form  write_log_record_payment
*&---------------------------------------------------------------------*
form write_log_record_payment using  p_h_lfdnr type lfdnr_kk
                                     p_t_fkkcollp_ip like fkkcollp_ip
                                     p_p_p_i_basics type fkk_mad_basics.

  data:
    t_fkkcoli_log like dfkkcoli_log,
    h_lfdnr like dfkkcoli_log-lfdnr.

  clear:
    t_fkkcoli_log,
    h_lfdnr.

  t_fkkcoli_log-nrzas  = p_t_fkkcollp_ip-nrzas.
  t_fkkcoli_log-opbel  = p_t_fkkcollp_ip-opbel.
  t_fkkcoli_log-inkps  = p_t_fkkcollp_ip-inkps.
  t_fkkcoli_log-gpart  = p_t_fkkcollp_ip-gpart.
  t_fkkcoli_log-lfdnr  = p_h_lfdnr.
  t_fkkcoli_log-postyp = p_t_fkkcollp_ip-postyp.
  t_fkkcoli_log-vkont  = p_t_fkkcollp_ip-vkont.
  t_fkkcoli_log-betrw  = p_t_fkkcollp_ip-betrw.
  t_fkkcoli_log-bwtrt  = p_t_fkkcollp_ip-bwtrt.
  t_fkkcoli_log-waers  = p_t_fkkcollp_ip-waers.
  t_fkkcoli_log-augdt  = p_t_fkkcollp_ip-augdt.
  t_fkkcoli_log-txtvw  = p_t_fkkcollp_ip-txtvw.
  t_fkkcoli_log-ernam  = sy-uname.
  t_fkkcoli_log-erdat  = sy-datum.
  t_fkkcoli_log-erzeit = sy-uzeit.
  t_fkkcoli_log-laufd  = p_p_p_i_basics-runkey-laufd.
  t_fkkcoli_log-laufi  = p_p_p_i_basics-runkey-laufi.

* INSERT: Scheiben Protokollsatz
*>>>>> HANA
  DATA: lo_opt       TYPE REF TO if_fkk_optimization_settings,
        x_optimizing TYPE        xfeld.
  lo_opt = cl_fkk_optimization_settings=>get_instance( ).
  x_optimizing = lo_opt->is_active( cl_fkk_optimization_settings=>cc_fica_fpci_mass_insert ).
  IF x_optimizing = abap_true.
    APPEND t_fkkcoli_log TO gt_fkkcoli_log.
  ELSE.
    INSERT INTO dfkkcoli_log VALUES t_fkkcoli_log.  "OLD LOGIC
  ENDIF.
*<<<<< HANA

endform.                    " write_log_record_payment
*&---------------------------------------------------------------------*
*&      Form  call_zp_fb_5052_recall
*&---------------------------------------------------------------------*
*       Exit 5052 Ergänzen Positionsdaten - Rückruf
*----------------------------------------------------------------------*
form call_zp_fb_5052_recall  using p_p_t_fkkcollh_i like fkkcollh_i
                                   p_lfdnr type lfdnr_kk
                          changing p_t_fkkcollp_ir like fkkcollp_ir.

  data:  lt_fkkcollp_ir like fkkcollp_ir.

  clear: lt_fkkcollp_ir.

  move-corresponding p_t_fkkcollp_ir  to lt_fkkcollp_ir.

  loop at t_tfkfbc_5052.
    call function t_tfkfbc_5052-funcc
      exporting
        i_postyp      = c_recall
        i_fkkcollh_i  = p_p_t_fkkcollh_i
        i_lfdnr       = p_lfdnr
      changing
        c_fkkcollp_ir = lt_fkkcollp_ir.
  endloop.

  move-corresponding lt_fkkcollp_ir to p_t_fkkcollp_ir.

  set extended check off.
  if 1 = 2. call function 'FKK_SAMPLE_5052'. endif.
  set extended check on.

endform.                    " call_zp_fb_5052_recall
*&---------------------------------------------------------------------*
*&      Form  write_log_record_recall
*&---------------------------------------------------------------------*
form write_log_record_recall using   p_h_lfdnr
                                     p_t_fkkcollp_ir like fkkcollp_ir
                                     p_p_p_i_basics type fkk_mad_basics.

  data:
    t_fkkcoli_log like dfkkcoli_log.

  clear:
    t_fkkcoli_log.

  t_fkkcoli_log-nrzas  = p_t_fkkcollp_ir-nrzas.
  t_fkkcoli_log-opbel  = p_t_fkkcollp_ir-opbel.
  t_fkkcoli_log-inkps  = p_t_fkkcollp_ir-inkps.
  t_fkkcoli_log-gpart  = p_t_fkkcollp_ir-gpart.
  t_fkkcoli_log-lfdnr  = p_h_lfdnr.
  t_fkkcoli_log-postyp = p_t_fkkcollp_ir-postyp.
  t_fkkcoli_log-vkont  = p_t_fkkcollp_ir-vkont.
  t_fkkcoli_log-betrw  = p_t_fkkcollp_ir-betrw.
  t_fkkcoli_log-waers  = p_t_fkkcollp_ir-waers.
  t_fkkcoli_log-txtvw  = p_t_fkkcollp_ir-txtvw.
  t_fkkcoli_log-rudat  = p_t_fkkcollp_ir-rudat.
  t_fkkcoli_log-ernam  = sy-uname.
  t_fkkcoli_log-erdat  = sy-datum.
  t_fkkcoli_log-erzeit = sy-uzeit.
  t_fkkcoli_log-laufd  = p_p_p_i_basics-runkey-laufd.
  t_fkkcoli_log-laufi  = p_p_p_i_basics-runkey-laufi.

* INSERT: Scheiben Protokollsatz
  insert into dfkkcoli_log values t_fkkcoli_log.

endform.                    " write_log_record_recall
*&---------------------------------------------------------------------*
*&      Form  call_zp_fb_5052_gpart
*&---------------------------------------------------------------------*
*       Exit 5052 Ergänzen Positionsdaten - Partneränderungen
*----------------------------------------------------------------------*
form call_zp_fb_5052_gpart using  p_p_t_fkkcollh_i like fkkcollh_i
                        changing  p_t_fkkcollp_im like fkkcollp_im.

  data:  lt_fkkcollp_im  like fkkcollp_im.

  clear: lt_fkkcollp_im.

  move-corresponding p_t_fkkcollp_im  to lt_fkkcollp_im.

  loop at t_tfkfbc_5052.
    call function t_tfkfbc_5052-funcc
      exporting
        i_postyp      = c_master_data_changes
        i_fkkcollh_i  = p_p_t_fkkcollh_i
      changing
        c_fkkcollp_im = lt_fkkcollp_im.
  endloop.

  move-corresponding lt_fkkcollp_im to p_t_fkkcollp_im.

  set extended check off.
  if 1 = 2. call function 'FKK_SAMPLE_5052'. endif.
  set extended check on.

endform.                    " call_zp_fb_5052_gpart
*&---------------------------------------------------------------------*
*&      Form  write_log_record_gpart
*&---------------------------------------------------------------------*
form write_log_record_gpart using p_h_lfdnr type lfdnr_kk
                                  p_h_inkps type inkps_kk
                                  p_t_fkkcollp_im like fkkcollp_im
                                  p_t_fkkcollp_im_w like dfkkcollp_im_w
                                  p_p_p_i_basics type fkk_mad_basics.

  data:  t_fkkcoli_log like dfkkcoli_log.

  clear: t_fkkcoli_log.

  t_fkkcoli_log-gpart      = p_t_fkkcollp_im-gpart.
  t_fkkcoli_log-lfdnr      = p_h_lfdnr.
  t_fkkcoli_log-inkps      = p_h_inkps.
  t_fkkcoli_log-postyp     = p_t_fkkcollp_im-postyp.
  t_fkkcoli_log-vkont      = p_t_fkkcollp_im-vkont.
  t_fkkcoli_log-txtvw      = p_t_fkkcollp_im-ddtext.
  t_fkkcoli_log-udate      = p_t_fkkcollp_im-udate.
  t_fkkcoli_log-utime      = p_t_fkkcollp_im-utime.         "260402ins
  t_fkkcoli_log-tabname    = p_t_fkkcollp_im_w-tabname.
  t_fkkcoli_log-tabkey     = p_t_fkkcollp_im_w-tabkey.
  t_fkkcoli_log-fname      = p_t_fkkcollp_im_w-fname.
  t_fkkcoli_log-value_new  = p_t_fkkcollp_im-value_new.
  t_fkkcoli_log-value_old  = p_t_fkkcollp_im-value_old.
  t_fkkcoli_log-ernam      = sy-uname.
  t_fkkcoli_log-erdat      = sy-datum.
  t_fkkcoli_log-erzeit     = sy-uzeit.
  t_fkkcoli_log-laufd      = p_p_p_i_basics-runkey-laufd.
  t_fkkcoli_log-laufi      = p_p_p_i_basics-runkey-laufi.

* INSERT: Scheiben Protokollsatz
  insert into dfkkcoli_log values t_fkkcoli_log.

endform.                    " write_log_record_gpart
*&---------------------------------------------------------------------*
*&      Form  call_zp_fb_5053_gpart
*&---------------------------------------------------------------------*
*       Exit 5052 Ergänzen Datei-Endesatz
*----------------------------------------------------------------------*
form call_zp_fb_5053 using    p_p_t_fkkcollh_i like fkkcollh_i
                     changing p_p_t_fkkcollt_i like fkkcollt_i.

  data:  lt_fkkcollt_i like fkkcollt_i.

  clear: lt_fkkcollt_i.

  move-corresponding p_p_t_fkkcollt_i to lt_fkkcollt_i.

  loop at t_tfkfbc_5053.
    call function t_tfkfbc_5053-funcc
      exporting
        i_fkkcollh_i = p_p_t_fkkcollh_i
      changing
        c_fkkcollt_i = lt_fkkcollt_i.
  endloop.

  move-corresponding lt_fkkcollt_i to p_p_t_fkkcollt_i.

  set extended check off.
  if 1 = 2. call function 'FKK_SAMPLE_5053'. endif.
  set extended check on.

endform.                    " call_zp_fb_5053_gpart
*&---------------------------------------------------------------------*
*&      Form  addition
*&---------------------------------------------------------------------*
form addition using    p_wert
              changing p_summe.

  data:
    w_summe   like fkkcollt-sumza,
    w_summe_p type betrw_kk,
    w_wert    type abetrw_b_kk,
    w_wert_p  type betrw_kk.

  case g_dcpfm.

    when space or 'Y'.
* decimal_notation 'N.NNN,NN' or 'N NNN,NN'
      clear: w_wert, w_wert_p.
      w_wert  = p_wert.
      translate w_wert using '. '.
      condense  w_wert no-gaps.
      translate w_wert using ',.'.
      w_wert_p = w_wert.

      clear: w_summe, w_summe_p.
      w_summe = p_summe.
      translate w_summe using '. '.
      condense  w_summe no-gaps.
      translate w_summe using ',.'.
      w_summe_p = w_summe.

      add w_wert_p to w_summe_p.
      write w_summe_p to p_summe.                           "#EC *

    when 'X'.
* decimal_notation 'N,NNN.NN'
      clear: w_wert, w_wert_p.
      w_wert  = p_wert.
      translate w_wert using ', '.
      condense  w_wert no-gaps.
      w_wert_p = w_wert.

      clear: w_summe, w_summe_p.
      w_summe = p_summe.
      translate w_summe using ', '.
      condense  w_summe no-gaps.
      w_summe_p = w_summe.

      add w_wert_p to w_summe_p.
      write w_summe_p to p_summe.                           "#EC *

  endcase.

endform.                    " addition
*&---------------------------------------------------------------------*
*&      Form  close_dataset
*&---------------------------------------------------------------------*
form close_dataset using    p_h_file_name
                            p_t_fkkcollt_i like fkkcollt_i
                            p_i_basics type fkk_mad_basics.
  data:
    w_recnum like fkkcollt_i-recnum,
    w_anz(10).

  clear w_recnum.
  clear w_anz.

  if not p_t_fkkcollt_i-recnum is initial.
    w_recnum = p_t_fkkcollt_i-recnum.
  endif.

* Nachricht: Anzahl Datensätzen: &
  write w_recnum to w_anz no-zero.
  shift w_anz left deleting leading space.
  mac_appl_log_msg 'I' '>4' '805'
      w_anz space space space
      c_msgprio_low p_i_basics-appllog-probclass.
  set extended check off.
  if 1 = 2. message i805(>4). endif.
  set extended check on.

* Abschliessen Informationsdatei
  if p_i_basics-status-xsimu is initial.
    close dataset p_h_file_name.
  endif.

endform.                    " close_dataset
*&---------------------------------------------------------------------*
*&      Form  delete_old_data
*&---------------------------------------------------------------------*
*       Löschen Tabeleninhalt des Arbeitsspeichers
*----------------------------------------------------------------------*
form delete_old_data using p_i_basics type fkk_mad_basics.

* Löschen Kopfinformationen
  delete from dfkkcollh_i_w  where laufi eq p_i_basics-runkey-laufi
                             and   laufd eq p_i_basics-runkey-laufd.

* Löschen Zahlungsinformationen
  delete from dfkkcollp_ip_w where laufi eq p_i_basics-runkey-laufi
                             and   laufd eq p_i_basics-runkey-laufd.

* Löschen Rückrufinformationen
  delete from dfkkcollp_ir_w where laufi eq p_i_basics-runkey-laufi
                             and   laufd eq p_i_basics-runkey-laufd.

* Löschen Partnerstammdaten-Informationen
  delete from dfkkcollp_im_w where laufi eq p_i_basics-runkey-laufi
                             and   laufd eq p_i_basics-runkey-laufd.

endform.                    " delete_old_data
*&---------------------------------------------------------------------*
*&      Form  art_summierung
*&---------------------------------------------------------------------*
form art_summierung using    p_i_basics type fkk_mad_basics
                             p_fkkcollinfo type fkkcollinfo.

  data:
    t_dd07v_knz like dd07v occurs 0 with header line,
    w_anz       like sy-tfill.

  if  not p_fkkcollinfo-xausg is initial
   or not p_fkkcollinfo-xback is initial.

* Ausgabe Nachricht, falls Daten existieren
    clear w_anz.
    select count( * ) into  w_anz
                      from  dfkkcollh_i_w
                      where laufd eq p_i_basics-runkey-laufd
                      and   laufi eq p_i_basics-runkey-laufi.
    check not w_anz is initial.
* Lesen Bezeichnung der Art Summierung
    call function 'DDIF_DOMA_GET'
      exporting
        name          = 'SUMKNZ_KK'
        state         = 'A'
        langu         = sy-langu
      tables
        dd07v_tab     = t_dd07v_knz
      exceptions
        illegal_input = 1
        others        = 2.
    if sy-subrc is initial.
      read table t_dd07v_knz with key domvalue_l = p_fkkcollinfo-sumknz.
      if sy-subrc is initial.
* Nachricht: Art der Summierung: ........
        mac_appl_log_msg 'I' '>4' '808'
            t_dd07v_knz-ddtext space space space
            c_msgprio_low p_i_basics-appllog-probclass.
        set extended check off.
        if 1 = 2. message i808(>4). endif.
        set extended check on.
      endif.
    endif.
  endif.

endform.                    " art_summierung
*&---------------------------------------------------------------------*
*&      Form  info_storno
*&---------------------------------------------------------------------*
*       Information über stornierte Beträge
*----------------------------------------------------------------------*
form info_storno
     using
        p_postyp type postyp_kk
        p_i_basics type fkk_mad_basics
        p_h_intnr_c type intnr_i_kk
        p_t_fkkcollh like dfkkcollh
        p_h_lfd_p type lfnum_kk
        p_h_betrag type betrz_kk
        p_logkz type logkz_kk.

  data:
    l_fkkcollp_ip_w like dfkkcollp_ip_w,
    h_herkf         type herkf_kk,
    h_storb         type storb_kk,
    h_xragl         type xragl_kk,
    h_augbl         type augbl_kk,
    h_htext         type text20,
    h_logkz         type logkz_kk.

  data lv_txtvw           type txtag_i_kk.
  data lv_betrw_content   type betrw_kk.

  data ls_collitem        type fkkcollitem.
  data ls_collpaym        type fkkcollpaym.
  data ls_collpaymlink    type fkkcollpaymlink.
  data ls_collections     type fkkcollections.
  data ls_coli_log        type fkkcoli_log.
  data ls_coli_log_ext    type gty_fkkcoli_log_ext.
  data ls_postyp_sum      type fkkcol_postyp_sum.
  DATA ls_collitem1       TYPE fkkcollitem.
  DATA lv_collitem_lv     TYPE collitem_lv_kk.
  DATA ls_collitem_info   TYPE fkkcollitem.
  DATA lv_collitem_id     TYPE collitem_id_kk.

  data lv_betrz_st      type betrz_st_kk.
  data lx_flg_payment_info  type xfeld.

  field-symbols <fs_collections>  type fkkcollections.
  field-symbols <fs_coli_log_ext>  type gty_fkkcoli_log_ext.


  clear: l_fkkcollp_ip_w.
  clear: h_herkf.
  clear: h_htext.

  clear: h_storb, h_xragl, h_augbl.

*>>> Note 1539682
* check which DFKKCOLLH line has been reversed
  data: h_stbel type stbel_kk,
        h_agsta type agsta_kk.
  if not p_t_fkkcollh-storb is initial.
    select single stbel into  h_stbel
                        from  dfkkko
                        where opbel eq p_t_fkkcollh-storb.
    if not h_stbel is initial.
      select single agsta from dfkkcollh into h_agsta
                        where opbel = p_t_fkkcollh-opbel
                          and inkps = p_t_fkkcollh-inkps
                          and augbl = h_stbel.
      if sy-subrc eq 0 and
       ( h_agsta eq c_receivable_part_paid or
         h_agsta eq c_receivable_paid ).
        exit.
      endif.
    endif.
  endif.
*>>> Note 1539682

  if p_logkz is initial and
     p_t_fkkcollh-agsta = c_receivable_cancelled and
     not p_t_fkkcollh-storb is initial.
* check if the submitted document number is still reversed
    select single storb into  h_storb
                        from  dfkkko
                        where opbel eq p_t_fkkcollh-opbel.
    if h_storb is initial.
      h_logkz = 'X'.
    else.
      h_logkz = p_logkz.
    endif.

  elseif p_logkz is initial and
     not p_t_fkkcollh-augbl is initial and
     ( p_t_fkkcollh-agsta = c_receivable_write_off or
       p_t_fkkcollh-agsta = c_receivable_part_write_off ).
* check if the clearing document has been reversed or resetted
    select single augbl xragl into  (h_augbl, h_xragl)
                        from  dfkkop
                        where opbel eq p_t_fkkcollh-augbl.
    if not h_xragl is initial.
      h_logkz = 'X'.
      move h_augbl to t_stor.
      append t_stor.
    else.
      h_logkz = p_logkz.
    endif.

  else.
    read table t_stor with key storb = p_t_fkkcollh-storb
               transporting no fields.
    if sy-subrc eq 0.
      h_logkz = 'X'.
    else.
      h_logkz = p_logkz.
    endif.
  endif.

* Selektion Storno-Text
  if p_postyp eq c_cancelled_receivable.

    if not p_t_fkkcollh-storb is initial.
      lv_txtvw = 'Storno abgegebener Forderung'(009).
    else.
      lv_txtvw =
                   'Storno abgegebener Forderung bei Mahnen'(010).
    endif.

  elseif p_postyp eq c_write_off.

    if p_t_fkkcollh-agsta eq c_receivable_write_off.
      lv_txtvw = 'Abgegebene Forderung ausgebucht'(011).
    elseif p_t_fkkcollh-agsta eq c_receivable_part_write_off or
           p_t_fkkcollh-agsta eq c_agsta_t-erfolglos         or
           p_t_fkkcollh-agsta eq c_agsta_cu_t-erfolglos.
      lv_txtvw = 'Abgegebene Forderung teilausgebucht'(012).
    endif.

  else.

    select single herkf into  h_herkf
                        from  dfkkko
                        where opbel eq p_t_fkkcollh-storb.
    select single htext into  h_htext
                        from  tfk001t
                        where spras eq sy-langu
                        and   herkf eq h_herkf.

    case h_herkf.
      when '02'.
        if not h_htext is initial.
          lv_txtvw =  h_htext.
        else.
          lv_txtvw = 'Stornierung  von Kundenzahlung'(001).
        endif.

      when '08'.
        if not h_htext is initial.
          lv_txtvw =  h_htext.
        else.
          lv_txtvw =
                   'Bankrückläufer von Kundenzahlung'(005).
        endif.

      when '09'.
        if not h_htext is initial.
          lv_txtvw =  h_htext.
        else.
          lv_txtvw =
                   'Rücknahme Ausgleich von Kundenzahlung'(003).
        endif.

      when '39'.
        if not h_htext is initial.
          lv_txtvw =  h_htext.
        else.
          lv_txtvw =
                   'Teilrücknahme Ausgleich von Kundenzahlung'(006).
        endif.

      when others.
        lv_txtvw = 'Stornierung von Kundenzahlung'(004).
    endcase.

  endif.

* ----------------------------------------------------------------------
* file based version (enterprise services not active)
* ----------------------------------------------------------------------
  if gv_flg_coll_esoa_active is initial.

* Übergabe Werte zu Storno-Information
    l_fkkcollp_ip_w-laufd   = p_i_basics-runkey-laufd.
    l_fkkcollp_ip_w-laufi   = p_i_basics-runkey-laufi.
    l_fkkcollp_ip_w-w_inkgp = p_t_fkkcollh-inkgp.
    l_fkkcollp_ip_w-intnr   = p_h_intnr_c.
    add 1 to p_h_lfd_p.
    l_fkkcollp_ip_w-lfnum   = p_h_lfd_p.
    l_fkkcollp_ip_w-lfdnr   = p_t_fkkcollh-lfdnr.
    l_fkkcollp_ip_w-logkz   = h_logkz.
    l_fkkcollp_ip_w-satztyp = c_position.
    l_fkkcollp_ip_w-postyp  = p_postyp.
    l_fkkcollp_ip_w-nrzas   = p_t_fkkcollh-nrzas.
    l_fkkcollp_ip_w-opbel   = p_t_fkkcollh-opbel.
    l_fkkcollp_ip_w-inkps   = p_t_fkkcollh-inkps.
    l_fkkcollp_ip_w-gpart   = p_t_fkkcollh-gpart.
    l_fkkcollp_ip_w-vkont   = p_t_fkkcollh-vkont.
    write p_t_fkkcollh-betrw to l_fkkcollp_ip_w-betrw
                                currency p_t_fkkcollh-waers.
    if not p_h_betrag is initial.
      write p_h_betrag to l_fkkcollp_ip_w-bwtrt
                          currency p_t_fkkcollh-waers.
    endif.

    if  p_postyp eq c_write_off.
      write p_t_fkkcollh-ninkb to l_fkkcollp_ip_w-bwtrt
                                  currency p_t_fkkcollh-waers.
    endif.

    l_fkkcollp_ip_w-waers   = p_t_fkkcollh-waers.
    l_fkkcollp_ip_w-augdt   = p_t_fkkcollh-rudat.

    l_fkkcollp_ip_w-txtvw = lv_txtvw.

****    l_fkkcollp_ip_w-txtvw   = 'Kundenzahlung wurde storniert'(001).

* INSERT: Speichern Informationen zu Storno
*    INSERT INTO dfkkcollp_ip_w VALUES l_fkkcollp_ip_w.
*>>>>> HANA
    DATA: lo_opt        TYPE REF TO if_fkk_optimization_settings,
          x_optimizing  TYPE xfeld.
    lo_opt = cl_fkk_optimization_settings=>get_instance( ).
    x_optimizing = lo_opt->is_active( cl_fkk_optimization_settings=>cc_fica_fpci_mass_insert ).
    IF x_optimizing = abap_true.
      APPEND l_fkkcollp_ip_w TO gt_fkkcollp_ip_w.
    ELSE.
      INSERT INTO dfkkcollp_ip_w VALUES l_fkkcollp_ip_w.  "OLD LOGIC
    ENDIF.
*<<<<< HANA

* Registrieren Inkassobüro
    gt_inkgp = p_t_fkkcollh-inkgp.
    collect gt_inkgp.

* Registrieren bearbeiteten Fall
    gt_fall = p_t_fkkcollh-gpart.
    collect gt_fall.

  endif.

* ----------------------------------------------------------------------
* enterprise service version (enterprise services active)
* ----------------------------------------------------------------------
  if gv_flg_coll_esoa_active = 'X'.

* collection unit information
    clear ls_collitem.
    ls_collitem-inkgp = p_t_fkkcollh-inkgp.
    ls_collitem-gpart = p_t_fkkcollh-gpart.
    concatenate p_t_fkkcollh-opbel p_t_fkkcollh-inkps into ls_collitem-collitem_id.

    SELECT SINGLE collitem_lv FROM dfkkcollitem INTO lv_collitem_lv
            WHERE collitem_id = ls_collitem-collitem_id.
    IF sy-subrc = 0 AND NOT lv_collitem_lv IS INITIAL.
      ls_collitem-collitem_lv = lv_collitem_lv.
    ELSE.
      ls_collitem-collitem_lv = '01'.
    ENDIF.

    if  p_postyp eq c_write_off.
*>>> Note 1687283
* check if the write-off has been reported by the collection agency
      SELECT SINGLE * FROM dfkkcollitem INTO ls_collitem_info
            WHERE collitem_id = ls_collitem-collitem_id
              AND collitem_id_par NE SPACE.
      IF sy-subrc = 0.
         lv_collitem_id = ls_collitem_info-collitem_id_par.
      ELSE.
         lv_collitem_id = ls_collitem-collitem_id.
      ENDIF.
      SELECT SINGLE * FROM dfkkcollitem INTO ls_collitem1
        WHERE inkgp       = p_t_fkkcollh-inkgp
          AND gpart       = p_t_fkkcollh-gpart
          AND collitem_id = lv_collitem_id
          AND prcst BETWEEN '12' AND '13'.
      IF sy-subrc <> 0.
        SELECT SINGLE * FROM dfkkcollitem INTO ls_collitem1
          WHERE inkgp       = p_t_fkkcollh-inkgp
            AND gpart       = p_t_fkkcollh-gpart
            AND collitem_id = p_t_fkkcollh-opbel
            AND prcst BETWEEN '12' AND '13'.
      ENDIF.
      IF sy-subrc = 0.
        EXIT.
      ENDIF.
*<<< Note 1687283
      ls_collitem-rinkb = p_t_fkkcollh-ninkb.
      ls_collitem-rcdat = p_t_fkkcollh-rudat.
      lv_betrw_content = ls_collitem-rinkb.
    elseif p_h_betrag < 0.
* reversal of former payment clearing
      lx_flg_payment_info = 'X'.
      lv_betrz_st = abs( p_h_betrag ).
      lv_betrw_content = lv_betrz_st.
    elseif p_h_betrag > 0.
      ls_collitem-ainkb = p_h_betrag.
* if submitted credit, then inverse amount
      if p_t_fkkcollh-betrw < 0.
        ls_collitem-ainkb = -1 * ls_collitem-ainkb.
      endif.
      ls_collitem-agdat = p_t_fkkcollh-rudat.
      lv_betrw_content = ls_collitem-ainkb.
    elseif p_t_fkkcollh-storb is not initial.
      ls_collitem-rinkb = abs( p_t_fkkcollh-betrw ).
      ls_collitem-rcdat = p_t_fkkcollh-rudat.
      lv_betrw_content = ls_collitem-rinkb.
    endif.
    ls_collitem-waers = p_t_fkkcollh-waers.
    ls_collitem-txtkm = lv_txtvw.

* reversal payment information
    if lx_flg_payment_info = 'X'.

* payment information
      clear ls_collpaym.

      ls_collpaym-inkgp = p_t_fkkcollh-inkgp.
      ls_collpaym-gpart = p_t_fkkcollh-gpart.

      ls_collpaym-collpaym_id = p_t_fkkcollh-storb.
      ls_collpaym-collpaym_tp = '1'.

      ls_collpaym-waers = p_t_fkkcollh-waers.
      ls_collpaym-betrw = lv_betrz_st.
      ls_collpaym-revdt = p_t_fkkcollh-rudat.

* payment assignment information
      clear ls_collpaymlink.

      ls_collpaymlink-inkgp = p_t_fkkcollh-inkgp.
      ls_collpaymlink-gpart = p_t_fkkcollh-gpart.

      ls_collpaymlink-collpaym_id = p_t_fkkcollh-storb.
      ls_collpaymlink-collpaym_tp = '1'.

      concatenate p_t_fkkcollh-opbel p_t_fkkcollh-inkps into ls_collpaymlink-collitem_id.

      IF NOT lv_collitem_lv IS INITIAL.
        ls_collpaymlink-collitem_lv = lv_collitem_lv.
      ELSE.
        ls_collpaymlink-collitem_lv = '01'.
      ENDIF.

      ls_collpaymlink-waers = p_t_fkkcollh-waers.
      ls_collpaymlink-betrz_st = lv_betrz_st.
      ls_collpaymlink-rcpdt = p_t_fkkcollh-rudat.

      ls_collpaymlink-txtkm = lv_txtvw.

    endif.

* insert into global collections table
    read table gt_collections_hash assigning <fs_collections>
      with table key inkgp = ls_collitem-inkgp
                     gpart = ls_collitem-gpart.
    if sy-subrc = 0.
      if lx_flg_payment_info is initial.
        append ls_collitem to <fs_collections>-collitem_tab.
      else.
        collect ls_collpaym into <fs_collections>-collpaym_tab.
        append ls_collpaymlink to <fs_collections>-collpaymlink_tab.
      endif.
    else.
      clear ls_collections.
      ls_collections-inkgp = ls_collitem-inkgp.
      ls_collections-gpart = ls_collitem-gpart.
      if lx_flg_payment_info is initial.
        append ls_collitem to ls_collections-collitem_tab.
      else.
        append ls_collpaym to ls_collections-collpaym_tab.
        append ls_collpaymlink to ls_collections-collpaymlink_tab.
      endif.
      insert ls_collections into table gt_collections_hash.
    endif.

* collect information for DFKKCOLI_LOG
    clear ls_coli_log.
    ls_coli_log-opbel  = p_t_fkkcollh-opbel.
    ls_coli_log-inkps  = p_t_fkkcollh-inkps.
    ls_coli_log-gpart  = p_t_fkkcollh-gpart.
    ls_coli_log-lfdnr  = p_t_fkkcollh-lfdnr.
    ls_coli_log-postyp = p_postyp.
    ls_coli_log-vkont  = p_t_fkkcollh-vkont.
    ls_coli_log-betrw  = p_t_fkkcollh-betrw.
*  ls_coli_log-bwtrt  = p_t_fkkcollh-bwtrt.
    ls_coli_log-waers  = p_t_fkkcollh-waers.
*  ls_coli_log-augdt  = p_t_fkkcollh-augdt.
*  ls_coli_log-txtvw  = p_t_fkkcollh-txtvw.
    ls_coli_log-ernam  = sy-uname.
    ls_coli_log-erdat  = sy-datum.
    ls_coli_log-erzeit = sy-uzeit.
    ls_coli_log-laufd  = p_i_basics-runkey-laufd.
    ls_coli_log-laufi  = p_i_basics-runkey-laufi.

* collect information for application log
    clear ls_postyp_sum.
    ls_postyp_sum-inkgp  = p_t_fkkcollh-inkgp.
    ls_postyp_sum-postyp = p_postyp.
    ls_postyp_sum-waers  = p_t_fkkcollh-waers.
    ls_postyp_sum-betrw  = lv_betrw_content.
    ls_postyp_sum-poscnt = 1.

* insert into global coli_log table
    read table gt_coli_log_ext_hash assigning <fs_coli_log_ext>
      with table key inkgp = p_t_fkkcollh-inkgp
                     gpart = p_t_fkkcollh-gpart.
    if sy-subrc = 0.
      append ls_coli_log to <fs_coli_log_ext>-coli_log_tab.
      collect ls_postyp_sum into <fs_coli_log_ext>-postyp_sum_tab.
    else.
      clear ls_coli_log_ext.
      ls_coli_log_ext-inkgp = p_t_fkkcollh-inkgp.
      ls_coli_log_ext-gpart = p_t_fkkcollh-gpart.
      append ls_coli_log to ls_coli_log_ext-coli_log_tab.
      collect ls_postyp_sum into ls_coli_log_ext-postyp_sum_tab.
      insert ls_coli_log_ext into table gt_coli_log_ext_hash.
    endif.

  endif.

endform.                    " info_storno
*&---------------------------------------------------------------------*
*&      Form  select_agsta_fixed_values
*&---------------------------------------------------------------------*
form select_agsta_fixed_values.

  clear: gt_dd07v[],gt_dd07v.

* Lesen Abgabestatus-Festwerte
  call function 'DDUT_DOMVALUES_GET'
    exporting
      name          = 'AGSTA_KK'
      langu         = sy-langu
    tables
      dd07v_tab     = gt_dd07v
    exceptions
      illegal_input = 1
      others        = 2.
  if sy-subrc <> 0.
* Nachricht: Fehler bei Selektion von Abgabestatus-Festwerten
    mac_appl_log_msg sy-msgty sy-msgid sy-msgno
     sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
     c_msgprio_high '1' .
    set extended check off.
    if 1 = 2.
      message id sy-msgid type sy-msgty number sy-msgno
              with sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    endif.
    set extended check on.
  endif.

endform.                    " select_agsta_fixed_values
*&---------------------------------------------------------------------*
*&      Form  check_posting_area
*&---------------------------------------------------------------------*
form check_posting_area.

  data: h_tfk033d  like tfk033d.

  clear g_xcpart.
  clear g_xausg.
  clear g_xback.
  clear g_xrever.
  clear g_xreclr.
  clear g_xretrn.
  clear h_tfk033d.

  call function 'FKK_GET_APPLICATION'
    exporting
      i_no_dialog   = c_marked
    importing
      e_applk       = h_tfk033d-applk
    exceptions
      error_message = 1.

  h_tfk033d-buber = c_buber_1059.

* Lesen anwendungsspezifische Daten
  call function 'FKK_ACCOUNT_DETERMINE'
    exporting
      i_tfk033d           = h_tfk033d
    importing
      e_tfk033d           = h_tfk033d
    exceptions
      error_in_input_data = 1
      nothing_found       = 2
      others              = 3.
* Inkassobüro über Partneränderungen informieren
  if not h_tfk033d-fun01 is initial.
    g_xcpart = true.
  endif.
* Inkassobüro über Zahlungen informieren
  if not h_tfk033d-fun02 is initial.
    g_xausg = true.
  endif.
* Inkassobüro über Rückruf informieren
  if not h_tfk033d-fun03 is initial.
    g_xback = true.
  endif.
* Inkassobüro über Stornierung informieren
  if not h_tfk033d-fun04 is initial.
    g_xrever = true.
  endif.
* Inkassobüro über Ausgleichsrücknahme informieren
  if not h_tfk033d-fun05 is initial.
    g_xreclr = true.
  endif.
* Inkassobüro über Rückläufer informieren
  if not h_tfk033d-fun06 is initial.
    g_xretrn = true.
  endif.

* ------ for cross reference purpose only -----------------------------*
  set extended check off.
  if 1 = 2. call function 'FKK_ACCOUNT_DETERMINE_1059'. endif.
  set extended check on.
* ------ end of cross reference ---------------------------------------*

endform.                    " check_posting_area
*&---------------------------------------------------------------------*
*&      Form  esmon_log_bus_object_open
*&---------------------------------------------------------------------*
form esmon_log_bus_object_open using p_objtype type swo_objtyp
                                     p_objkey  type swo_typeid.

  call function 'EMMA_LOG_BUS_OBJECT_OPEN'
    exporting
      iv_tcode   = sy-tcode
      iv_objtype = p_objtype
      iv_objkey  = p_objkey.

endform.                    " esmon_log_bus_object_open
*&---------------------------------------------------------------------*
*&      Form  esmon_log_bus_object_close
*&---------------------------------------------------------------------*
form esmon_log_bus_object_close using p_objtype type swo_objtyp.

  call function 'EMMA_LOG_BUS_OBJECT_CLOSE'
    exporting
      iv_tcode   = sy-tcode
      iv_objtype = p_objtype.

endform.                    " esmon_log_bus_object_close
*&---------------------------------------------------------------------*
*&      Form  Lesen_herkunft
*&---------------------------------------------------------------------*
form lesen_herkunft  using    p_fkkcollh type dfkkcollh
                     changing p_herkf    type herkf_kk.

  clear p_herkf.
  select single herkf into  p_herkf
                      from  dfkkko
                      where opbel eq p_fkkcollh-storb.

endform.                    " Lesen_herkunft
*&---------------------------------------------------------------------*
*&      Form  check_Logtable
*&---------------------------------------------------------------------*
form check_logtable  using    p_fkkcollh_alt structure dfkkcollh
                     changing p_logtb type c
                              p_logkz type c.

  data:
    l_opbel type opbel_kk.

  clear: p_logtb, p_logkz.

* currently no index available for this select
  select single logkz into  p_logkz                     "#EC CI_NOFIRST
                    from  dfkkcollp_ip_w
                    where nrzas eq p_fkkcollh_alt-nrzas
                    and   opbel eq p_fkkcollh_alt-opbel
                    and   inkps eq p_fkkcollh_alt-inkps
                    and   gpart eq p_fkkcollh_alt-gpart
                    and   lfdnr eq p_fkkcollh_alt-lfdnr.

* collection agency was not informed, only log entry in DFKKCOLLP_IP_W ?
  if sy-subrc ne 0.
    clear p_logkz.
  endif.

*  SELECT SINGLE opbel INTO  l_opbel
*                      FROM  dfkkcoli_log
*                      WHERE nrzas EQ p_fkkcollh_alt-nrzas
*                      AND   opbel EQ p_fkkcollh_alt-opbel
*                      AND   inkps EQ p_fkkcollh_alt-inkps
*                      AND   gpart EQ p_fkkcollh_alt-gpart
*                      AND   lfdnr EQ p_fkkcollh_alt-lfdnr .

*  CHECK sy-subrc IS INITIAL.
* Inkassobüro wurde schon einmal über den Posten informiert
*  p_logtb = true.

endform.                    " check_Logtable
*&---------------------------------------------------------------------*
*&      Form  read_last_recall
*&---------------------------------------------------------------------*
form read_last_recall  tables   pt_fkkcollh structure dfkkcollh
                       changing ph_collh09 type dfkkcollh.

  clear ph_collh09.
  loop at pt_fkkcollh.
    check pt_fkkcollh-agsta eq c_receivable_recalled.
    ph_collh09 = pt_fkkcollh.
  endloop.

endform.                    " read_last_recall
*&---------------------------------------------------------------------*
*&      Form  infos_pro_inkgp
*&---------------------------------------------------------------------*
form infos_pro_inkgp  tables   t_fkkcollh structure dfkkcollh
                      using    i_basics type fkk_mad_basics
                               wt_fkkcoli_log structure dfkkcoli_log
                               h_intnr_c type intnr_i_kk
                               h_lfd_p like dfkkcollp_ip_w-lfnum
                               h_lfd_r like dfkkcollp_ir_w-lfnum.

  data:
    h_collh09      like dfkkcollh,
    w_fkkcollh_alt like dfkkcollh,
    h_betrag       type betrz_kk,
    h_ninkb        type ninkb_kk,
    x_delivered    type c,
    h_logtb        type c,
    h_herkf        type herkf_kk,
    h_logkz        type logkz_kk,
    w_collh_last   like dfkkcollh,
    h_collh_next   like dfkkcollh,
    h_tabix        like sy-tabix,
    h_xragl        type xragl_kk,
    h_augbl        type augbl_kk.

*>>> Note 1798474
  TYPES: rsds_selopt_t LIKE rsdsselopt OCCURS 0.
  TYPES: BEGIN OF rsds_frange,
           fieldname LIKE rsdstabs-prim_fname,
           selopt_t TYPE rsds_selopt_t,
         END OF rsds_frange.
  TYPES: rsds_frange_t TYPE rsds_frange OCCURS 0.
  DATA: it_ranges LIKE rsdsselopt OCCURS 0 WITH HEADER LINE,
        lt_fkkko  LIKE fkkko      OCCURS 0 WITH HEADER LINE,
        it_sel    TYPE rsds_frange_t       WITH HEADER LINE.
*<<< Note 1798474

* Lesen letzte Rückrufposition aus Historie
  perform read_last_recall tables   t_fkkcollh
                           changing h_collh09.

* Verarbeiten noch nicht behandelter Inkassopositionen
  clear: w_fkkcollh_alt.
  clear: h_betrag, h_ninkb.
  clear: x_delivered.
  clear: w_collh_last.
  refresh: t_stor.

  loop at t_fkkcollh.      " Historie

    case  t_fkkcollh-agsta.

      when space    .                                   " space
        clear x_delivered.
        w_collh_last   = t_fkkcollh.

      when c_released.                                      " '01'
        clear x_delivered.
        w_collh_last   = t_fkkcollh.

      when c_receivable_submitted.                          " '02'
        if w_fkkcollh_alt-agsta eq c_receivable_part_paid    or
           w_fkkcollh_alt-agsta eq c_receivable_paid         or
           w_fkkcollh_alt-agsta eq c_costumer_directly_paid  or
           w_fkkcollh_alt-agsta eq c_costumer_partally_paid  or
           w_fkkcollh_alt-agsta eq c_full_clearing           or
           w_fkkcollh_alt-agsta eq c_receivable_cancelled    or
           w_fkkcollh_alt-agsta eq c_receivable_write_off    or
           w_fkkcollh_alt-agsta eq c_receivable_part_write_off or
           w_fkkcollh_alt-agsta eq c_partial_clearing.

          if w_fkkcollh_alt-agsta eq c_receivable_cancelled or
             w_fkkcollh_alt-agsta eq c_receivable_write_off.
            h_betrag = t_fkkcollh-betrw.
          else.
            h_betrag = t_fkkcollh-betrz - w_fkkcollh_alt-betrz.
            if h_betrag eq 0.
              h_betrag = t_fkkcollh-ninkb - w_fkkcollh_alt-ninkb.
            endif.
          endif.

        else.
          x_delivered = true.
          w_collh_last = t_fkkcollh.
          continue.
        endif.

*-------- Storno     {'10'/'11'/'12'/'13'} --> '02'
        if t_fkkcollh-lfdnr > wt_fkkcoli_log-lfdnr.

*             Liegt ein Storno-Fall vor, d.h. war der Abgabestatus des
*             vorhergenhenden Postens '10', '11', '12', oder '13' ?
          if w_fkkcollh_alt-agsta eq c_costumer_directly_paid  or
             w_fkkcollh_alt-agsta eq c_costumer_partally_paid  or
             w_fkkcollh_alt-agsta eq c_full_clearing           or
             w_fkkcollh_alt-agsta eq c_receivable_cancelled    or
             w_fkkcollh_alt-agsta eq c_receivable_write_off    or
             w_fkkcollh_alt-agsta eq c_receivable_part_write_off or
             w_fkkcollh_alt-agsta eq c_partial_clearing.


            if t_fkkcollh-lfdnr >= h_collh09-lfdnr.

*              IF g_fkkcollinfo-xwroff IS INITIAL.
*                h_logkz = true.
*              ELSE.
*                CLEAR h_logkz.
*              ENDIF.

              if not t_fkkcollh-storb is initial.
                clear h_herkf.
                select single herkf
                       into   h_herkf
                       from   dfkkko
                       where  opbel eq t_fkkcollh-storb.

*>>> Note 1798474
                IF sy-subrc <> 0.
                  REFRESH: it_ranges, it_sel, lt_fkkko.
                  it_ranges-sign = 'I'.
                  it_ranges-option = 'EQ'.
                  it_ranges-low = t_fkkcollh-storb.
                  APPEND it_ranges.
                  it_sel-selopt_t[] = it_ranges[].
                  it_sel-fieldname = 'OPBEL'.
                  APPEND it_sel.

                  CALL FUNCTION 'FKK_GET_ARC_DOC'
                    TABLES
                      it_sel  = it_sel
                      t_fkkko = lt_fkkko
                    EXCEPTIONS
                      error_message = 0.
                  READ TABLE lt_fkkko INDEX 1.
                  IF sy-subrc = 0.
                    MOVE lt_fkkko-herkf TO h_herkf.
                  ENDIF.
                ENDIF.
*<<< Note 1798474

                if  ( ( h_herkf eq '08' )  and
                      ( not g_fkkcollinfo-xretrn is initial ) )

                 or ( ( h_herkf eq '09' or h_herkf eq '39'  ) and
                      ( not g_fkkcollinfo-xreclr is initial ) )

                 or ( ( not g_fkkcollinfo-xstorno is initial ) and
                    ( ( h_herkf eq '02' ) or
                      ( ( h_herkf ne '08' ) and
                        ( h_herkf ne '09' ) and
                        ( h_herkf ne '39' ) ) ) ) .

                  perform info_storno  using    c_storno
                                                i_basics
                                                h_intnr_c
                                                t_fkkcollh
                                                h_lfd_p
                                                h_betrag
                                                h_logkz.
                endif.
              endif.
            endif.
          endif.
        endif.
        x_delivered = true.
        w_fkkcollh_alt = t_fkkcollh.
        w_collh_last   = t_fkkcollh.


      when c_receivable_cancelled.                          " '05'

        h_tabix = sy-tabix + 1.
        read table t_fkkcollh index h_tabix
                              into h_collh_next transporting agsta.
        if sy-subrc eq 0 and h_collh_next-agsta eq space.
          continue.
        endif.
*------ Abgegebene Forderung storniert '05'
        if x_delivered eq true.
          if t_fkkcollh-lfdnr > wt_fkkcoli_log-lfdnr.
            if not g_fkkcollinfo-xrever is initial.
              if t_fkkcollh-lfdnr >= h_collh09-lfdnr.
*             Melden Stornierung abgegebener Forderungen an Inkassobüro
                perform info_storno using    c_cancelled_receivable
                                             i_basics
                                             h_intnr_c
                                             t_fkkcollh
                                             h_lfd_p
                                             h_betrag
                                             space.
              else.
                perform info_storno using    c_cancelled_receivable
                                             i_basics
                                             h_intnr_c
                                             t_fkkcollh
                                             h_lfd_p
                                             h_betrag
                                             c_only_log.
              endif.
            endif.
          endif.
        endif.
        clear x_delivered.
        w_fkkcollh_alt = t_fkkcollh.
        w_collh_last   = t_fkkcollh.
        continue.


      when c_receivable_write_off or c_receivable_part_write_off. "06/15
*           c_agsta_cu_t-erfolglos OR c_agsta_t-erfolglos.   "07/08
*------ Forderung ausgebucht / teilausgebucht '06' / '15'
        if x_delivered eq true.
          h_ninkb = t_fkkcollh-ninkb - w_fkkcollh_alt-ninkb. "Note 1410415
          if t_fkkcollh-lfdnr > wt_fkkcoli_log-lfdnr.
            if not g_fkkcollinfo-xwroff is initial.
              if not h_ninkb is initial.               " NOTE 1429275
                h_collh_next-ninkb = t_fkkcollh-ninkb. " NOTE 1429275
                t_fkkcollh-ninkb = h_ninkb.            " NOTE 1429275
              endif.                                   " NOTE 1429275
              if t_fkkcollh-lfdnr >= h_collh09-lfdnr.
*             Melden Stornierung abgegebener Forderungen an Inkassobüro
                perform info_storno using    c_write_off
                                             i_basics
                                             h_intnr_c
                                             t_fkkcollh
                                             h_lfd_p
                                             h_betrag
                                             space.
              else.
                perform info_storno using    c_write_off
                                             i_basics
                                             h_intnr_c
                                             t_fkkcollh
                                             h_lfd_p
                                             h_betrag
                                             c_only_log.
              endif.
              t_fkkcollh-ninkb = h_collh_next-ninkb. " NOTE 1429275
            else.

              if not t_fkkcollh-augbl is initial.
                clear: h_xragl, h_augbl.
* check if the clearing document has been reversed or resetted
                select single augbl xragl into  (h_augbl, h_xragl)
                                    from  dfkkop
                                    where opbel eq t_fkkcollh-augbl.
                if not h_xragl is initial.
                  move h_augbl to t_stor.
                  append t_stor.
                endif.

              endif.
            endif.
          endif.
        endif.
*        CLEAR x_delivered.
        w_fkkcollh_alt = t_fkkcollh.
        w_collh_last   = t_fkkcollh.
        continue.


      when c_receivable_recalled.                           " '09'

        h_tabix = sy-tabix + 1.
        read table t_fkkcollh index h_tabix
                              into h_collh_next transporting agsta.
        if sy-subrc eq 0 and h_collh_next-agsta eq space.
          continue.
        endif.

*-------- Rückruf '09'
        if x_delivered eq true.
          if t_fkkcollh-lfdnr > wt_fkkcoli_log-lfdnr.
            if not g_fkkcollinfo-xback is initial.
              if t_fkkcollh-lfdnr >= h_collh09-lfdnr.
*                   Rückruf an Inkassobüro melden und registrieren.
                perform info_recall  using    i_basics
                                              h_intnr_c
                                              t_fkkcollh
                                              h_lfd_r
                                              w_collh_last
                                              wt_fkkcoli_log.                                               .
              endif.
            endif.
          endif.
        endif.
        clear x_delivered.
        w_collh_last   = t_fkkcollh.
        continue.

*-------- Zahlung / Teilzahlung direkt vom Kunden        {'10'/'11'}
      when c_costumer_directly_paid or c_costumer_partally_paid.

        if x_delivered eq true.
          h_betrag = t_fkkcollh-betrz - w_fkkcollh_alt-betrz.
          if t_fkkcollh-lfdnr > wt_fkkcoli_log-lfdnr.
            if h_betrag < 0 and t_fkkcollh-betrw > 0 .
*           Storno

              if t_fkkcollh-lfdnr >= h_collh09-lfdnr.
*                   Wurde der vorherigr Posten bereits an Inkassobüro
*                   gemeldet(d.h. existiert Posten schon in der Log-Tab?
*                PERFORM check_logtable USING    w_fkkcollh_alt
*                                       CHANGING h_logtb
*                                                h_logkz.

*                   Möchte der Sachbearbeiter das Inkassobüro über die
*                   Stornierung informieren?
                if not g_fkkcollinfo-xstorno is initial.
*                     Ja: Stornierung an Inkassobüro melden und
*                     in Log-Tabelle registrieren.
                  if not t_fkkcollh-storb is initial.
                    perform info_storno  using    c_storno
                                                  i_basics
                                                  h_intnr_c
                                                  t_fkkcollh
                                                  h_lfd_p
                                                  h_betrag
                                                  space.
                  endif.
                else.
*                     Nein: Stornierung nur in Log-Tabelle registrieren
                  if not t_fkkcollh-storb is initial.
                    perform info_storno  using    c_storno
                                                  i_basics
                                                  h_intnr_c
                                                  t_fkkcollh
                                                  h_lfd_p
                                                  h_betrag
                                                  c_only_log.
                  endif.
                endif.
              endif.

            else.

*-------- Zahlung bzw. Teilzahlung direkt
              if not g_fkkcollinfo-xausg is initial.
                if t_fkkcollh-lfdnr >= h_collh09-lfdnr.
*                 Zahlung an Inkassobüro melden und registrieren
                  perform info_payment using    c_payment
                                                i_basics
                                                h_intnr_c
                                                t_fkkcollh
                                                h_lfd_p
                                                h_betrag
                                                space.
                else.
*                 Zahlung in Log-Tabelle registrieren
                  perform info_payment using    c_payment
                                                i_basics
                                                h_intnr_c
                                                t_fkkcollh
                                                h_lfd_p
                                                h_betrag
                                                c_only_log.
                endif.
              endif.
            endif.
          endif.
        endif.
        w_fkkcollh_alt = t_fkkcollh.
        w_collh_last   = t_fkkcollh.


      when c_receivable_paid or c_receivable_part_paid.     " '03'/'04'

        if x_delivered eq true.
          h_betrag = t_fkkcollh-betrz - w_fkkcollh_alt-betrz.
          if t_fkkcollh-lfdnr > wt_fkkcoli_log-lfdnr.
* Storno case
            if h_betrag < 0 and t_fkkcollh-betrw > 0 .

              if t_fkkcollh-lfdnr >= h_collh09-lfdnr.

*               Liegt ein Storno-Fall vor, d.h. war der Abgabestatus des
*               vorhergenhenden Postens '10', '11', '12', oder '13' ?
                if w_fkkcollh_alt-agsta eq c_costumer_directly_paid  or
                   w_fkkcollh_alt-agsta eq c_costumer_partally_paid  or
                   w_fkkcollh_alt-agsta eq c_full_clearing           or
                   w_fkkcollh_alt-agsta eq c_partial_clearing        or
                   w_fkkcollh_alt-agsta eq c_receivable_paid         or
                   w_fkkcollh_alt-agsta eq c_receivable_part_paid.

*               Abgabe der Information, falls Postition schon
*               protokolliert wurde.
                  if not g_fkkcollinfo-xstorno is initial.
*                 Ja: Stornierung an Inkassobüro melden und
*                 in Log-Tabelle registrieren.
                    if not t_fkkcollh-storb is initial.
                      perform info_storno  using    c_storno
                                                    i_basics
                                                    h_intnr_c
                                                    t_fkkcollh
                                                    h_lfd_p
                                                    h_betrag
                                                    space.
                    endif.
                  else.
*                 Nein: Stornierung nur in Log-Tabelle registrieren
                    if not t_fkkcollh-storb is initial.
                      perform info_storno  using    c_storno
                                                    i_basics
                                                    h_intnr_c
                                                    t_fkkcollh
                                                    h_lfd_p
                                                    h_betrag
                                                    c_only_log.
                    endif.
                  endif.
                endif.
              endif.
            endif.
          endif.
        endif.
        w_fkkcollh_alt = t_fkkcollh.
        w_collh_last   = t_fkkcollh.


*-------- Zahlung / Teilzahlung direkt vom Kunden        {'07'/'08'}
      when c_agsta_cu_t-erfolglos or c_agsta_t-erfolglos.   " 07, 08

        if x_delivered eq true.
          h_betrag = t_fkkcollh-betrz - w_fkkcollh_alt-betrz.
          h_ninkb  = t_fkkcollh-ninkb - w_fkkcollh_alt-ninkb.
          if t_fkkcollh-lfdnr > wt_fkkcoli_log-lfdnr.
            if h_betrag < 0 and t_fkkcollh-betrw > 0.    " REVERSE
              if t_fkkcollh-lfdnr >= h_collh09-lfdnr.
*               Storno registrieren ?
                if not g_fkkcollinfo-xstorno is initial.
                  if not t_fkkcollh-storb is initial.
                    perform info_storno  using    c_storno
                                                  i_basics
                                                  h_intnr_c
                                                  t_fkkcollh
                                                  h_lfd_p
                                                  h_betrag
                                                  space.
                  endif.
                else.
                  if not t_fkkcollh-storb is initial.
                    perform info_storno  using    c_storno
                                                  i_basics
                                                  h_intnr_c
                                                  t_fkkcollh
                                                  h_lfd_p
                                                  h_betrag
                                                  c_only_log.
                  endif.
                endif.
              endif.
            elseif h_ninkb > 0.                         " WRITEOFF
              if not g_fkkcollinfo-xwroff is initial.
                h_collh_next-ninkb = t_fkkcollh-ninkb. " NOTE 1429275
                t_fkkcollh-ninkb = h_ninkb.            " NOTE 1429275
                if t_fkkcollh-lfdnr >= h_collh09-lfdnr.
                  perform info_storno using    c_write_off
                                               i_basics
                                               h_intnr_c
                                               t_fkkcollh
                                               h_lfd_p
                                               h_betrag
                                               space.
                else.
                  perform info_storno using    c_write_off
                                               i_basics
                                               h_intnr_c
                                               t_fkkcollh
                                               h_lfd_p
                                               h_betrag
                                               c_only_log.
                endif.
                t_fkkcollh-ninkb = h_collh_next-ninkb.   " NOTE 1429275
              endif.
            else.                                       " PAYMENT
*-------- Zahlung bzw. Teilzahlung direkt
              if not g_fkkcollinfo-xausg is initial and
                 t_fkkcollh-agsta = c_agsta_cu_t-erfolglos.  " only for 07
                if t_fkkcollh-lfdnr >= h_collh09-lfdnr.
*                 Zahlung an Inkassobüro melden und registrieren
                  perform info_payment using    c_payment
                                                i_basics
                                                h_intnr_c
                                                t_fkkcollh
                                                h_lfd_p
                                                h_betrag
                                                space.
                else.
*                 Zahlung in Log-Tabelle registrieren
                  perform info_payment using    c_payment
                                                i_basics
                                                h_intnr_c
                                                t_fkkcollh
                                                h_lfd_p
                                                h_betrag
                                                c_only_log.
                endif.
              endif.
            endif.
          endif.
        endif.
        w_fkkcollh_alt = t_fkkcollh.
        w_collh_last   = t_fkkcollh.


      when c_full_clearing or c_partial_clearing.           " '12'/'13'

        if x_delivered eq true.
          h_betrag = t_fkkcollh-betrz - w_fkkcollh_alt-betrz.
          if h_betrag eq 0.
            h_betrag = t_fkkcollh-ninkb - w_fkkcollh_alt-ninkb.
          endif.
          if t_fkkcollh-lfdnr > wt_fkkcoli_log-lfdnr.
            if h_betrag < 0 and t_fkkcollh-betrw > 0 .
*         Storno

              if t_fkkcollh-lfdnr >= h_collh09-lfdnr.
*                 Abgabe der Information, falls Postition schon
*                 protokolliert wurde.
                if not g_fkkcollinfo-xstorno is initial.
*                     Ja: Stornierung an Inkassobüro melden und
*                     in Log-Tabelle registrieren.
                  if not t_fkkcollh-storb is initial.
                    perform info_storno  using    c_storno
                                                  i_basics
                                                  h_intnr_c
                                                  t_fkkcollh
                                                  h_lfd_p
                                                  h_betrag
                                                  space.
                  endif.
                else.
*                     Nein: Stornierung nur in Log-Tabelle registrieren
                  if not t_fkkcollh-storb is initial.
                    perform info_storno  using    c_storno
                                                  i_basics
                                                  h_intnr_c
                                                  t_fkkcollh
                                                  h_lfd_p
                                                  h_betrag
                                                  c_only_log.
                  endif.
                endif.
              endif.

            else.
*-------- Forderung ausgeglichen bzw. Forderung teilausgeglichen
              if not g_fkkcollinfo-xausg is initial.
                if t_fkkcollh-lfdnr >= h_collh09-lfdnr.
*                   Ausgleich an Inkassobüro melden und registrieren
                  perform info_payment using    c_clearing
                                                i_basics
                                                h_intnr_c
                                                t_fkkcollh
                                                h_lfd_p
                                                h_betrag
                                                space.
                else.
*                     Ausgleich in Log-Tabelle registrieren
                  perform info_payment using    c_clearing
                                                i_basics
                                                h_intnr_c
                                                t_fkkcollh
                                                h_lfd_p
                                                h_betrag
                                                c_only_log.
                endif.
              endif.
            endif.
          endif.
        endif.
        w_fkkcollh_alt = t_fkkcollh.
        w_collh_last   = t_fkkcollh.


      when others.

        w_collh_last   = t_fkkcollh.
        continue.

    endcase.

    w_collh_last   = t_fkkcollh.

  endloop.     " Historie

endform.                    " infos_pro_inkgp

*&---------------------------------------------------------------------*
*&      Form  get_ibvalues
*&---------------------------------------------------------------------*
*       Show text of collection agency
*----------------------------------------------------------------------*
form get_ibvalues  changing p_inkgp type inkgp_kk.

  data:
    tab_fields like dfies     occurs 0 with header line,
    tab_update like dynpread  occurs 0 with header line,
    returntab like ddshretval occurs 0 with header line,
    begin of ib_text occurs 0,
     name       type bu_descrip_long,
    end of ib_text,
    ht_tfk050b type tfk050b occurs 0 with header line,
    h_descrip type bu_descrip_long,
    h_selectfield like help_info-fieldname.

  select * from tfk050b into table ht_tfk050b.

  loop at ht_tfk050b.
    call function 'BUP_PARTNER_DESCRIPTION_GET'
      exporting
        i_partner          = ht_tfk050b-inkgp
        i_valdt            = sy-datlo
      importing
        e_description_long = h_descrip
      exceptions
        partner_not_found  = 1
        wrong_parameters   = 2
        others             = 3.
    if sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE 'S' NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 DISPLAY LIKE 'E'."Note 1830945
    ELSE.
    move ht_tfk050b-inkgp to ib_text-name.
    append ib_text.
    move h_descrip        to ib_text-name.
    append ib_text.
    ENDIF.
  endloop.

* ------ fill format table with data dictionary information -----------*
  refresh tab_fields.
  clear tab_fields.
  tab_fields-tabname     = 'TFK050B'.
  tab_fields-fieldname   = 'INKGP'.
  append tab_fields.
  clear tab_fields.
  tab_fields-tabname    = 'FKKEBPP_PARTNER'.
  tab_fields-fieldname  = 'DESCRIP_LONG'.
  append tab_fields.
  h_selectfield = 'INKGP'.
  call function 'F4IF_INT_TABLE_VALUE_REQUEST'
    exporting
      retfield   = h_selectfield
      value_org  = 'C'
      display    = ' '
    tables
      value_tab  = ib_text
      field_tab  = tab_fields
      return_tab = returntab
    exceptions
      others     = 0.

  read table returntab index 1.
  if sy-subrc = 0.
    p_inkgp = returntab-fieldval.
  endif.

endform.                    " get_ibvalues

*&---------------------------------------------------------------------*
*&      Form  get_decimal_notation
*&---------------------------------------------------------------------*
form get_decimal_notation .

  select single dcpfm into g_dcpfm from usr01 where bname eq sy-uname.

endform.                    " get_decimal_notation
*&                                                                     *
*&      Form  check_logical_file_name
*&                                                                     *
form check_logical_file_name using pi_basics  type fkk_mad_basics
                                   p_filename type fileintern.

  DATA: h_phys_filename TYPE pathextern.  " Note 1922813

  if not g_fkkcollinfo-datei is initial.
* Lesen phys. Dateiname
    call function 'FILE_GET_NAME'
      exporting
        logical_filename = p_filename
      importing
        file_name        = h_phys_filename
      exceptions
        file_not_found   = 1
        others           = 2.
    if sy-subrc <> 0.
* Nachricht: Log. Datei & wurde nicht gefunden!
      concatenate p_filename c_subname
                  into h_phys_filename.
    else.
      concatenate h_phys_filename c_subname
                  into h_phys_filename.
    endif.

* >>> note 1584972
* security enhancement (start)
    call function 'FILE_VALIDATE_NAME'
      exporting
        logical_filename           = 'FI-CA-COL-INFO'
      changing
        physical_filename          = h_phys_filename
      exceptions
        logical_filename_not_found = 1
        validation_failed          = 2
        others                     = 3.
    if sy-subrc ne 0.
      message id sy-msgid type sy-msgty number sy-msgno
        with sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    endif.
* security enhancement (end)
* <<< note 1584972

* check if file can be opened
    open dataset h_phys_filename for output in text mode encoding
                           non-unicode ignoring conversion errors.
    if not sy-subrc is initial.
* Nachricht: Testdatei & konnte nicht geöffnet werden!
      message a825(>4) with h_phys_filename.
    else.
      delete dataset h_phys_filename.
    endif.
  endif.
endform.                    " check_logical_file_name
*&---------------------------------------------------------------------*
*&      Form  create_info_storno
*&---------------------------------------------------------------------*
form create_info_storno  using
                            p_postyp type postyp_kk
                            p_p_fkkcollinfo type fkkcollinfo
                            p_p_h_file_name
                            p_p_t_fkkcollh_i_w like dfkkcollh_i_w
                            p_p_t_fkkcollh_i like fkkcollh_i
                            p_p_i_basics type fkk_mad_basics
                         changing
                            p_p_t_fkkcollt_i like fkkcollt_i.

  data:
     t_fkkcollp_ip like fkkcollp_ip,
     t_fkkcollp_ip_w like dfkkcollp_ip_w,
     h_lfnum like dfkkcoli_log-lfdnr,
     h_anzza like sy-tabix,
     h_sumza type sumza_kk,
     h_summe type sumza_kk,
     h_knz,
     sum_fkkcollp_ip like fkkcollp_ip.

  data:
     begin of h_key_nrzas,
      nrzas  type nrzas_kk,
      gpart  type gpart_kk,
     end of h_key_nrzas,
     h_key_nrzas_old like h_key_nrzas.

  data:
    begin of h_key_gpart,
     gpart  type gpart_kk,
     nrzas  type nrzas_kk,
    end of h_key_gpart,
    h_key_gpart_old like h_key_gpart.

  data:
    begin of h_key_vkont,
     vkont  type vkont_kk,
     nrzas  type nrzas_kk,
    end of h_key_vkont,
    h_key_vkont_old like h_key_vkont.

  clear:
    t_fkkcollp_ip,
    t_fkkcollp_ip_w,
    sum_fkkcollp_ip,
    h_anzza,
    h_summe,
    h_knz.

  clear:
    h_key_nrzas,
    h_key_nrzas_old,
    h_key_gpart,
    h_key_gpart_old,
    h_key_vkont,
    h_key_vkont_old.

  case p_p_fkkcollinfo-sumknz.

    when c_sum_no.
* ------- Keine Summierung --------------------------------------------*

* Lesen Ausgleichs-Informationen aus Zwischenspeicher
      select * into corresponding fields of t_fkkcollp_ip_w
               from  dfkkcollp_ip_w
               where laufd   eq p_p_i_basics-runkey-laufd
               and   laufi   eq p_p_i_basics-runkey-laufi
               and   w_inkgp eq p_p_t_fkkcollh_i_w-w_inkgp
               and   satztyp eq c_position
               and   postyp  eq p_postyp
               order by nrzas opbel inkps gpart.

        move-corresponding t_fkkcollp_ip_w to t_fkkcollp_ip.

* ------- calls user exit 5052 / payment ------------------------------*
        perform call_zp_fb_5052_payment
           using
              p_postyp
              p_p_t_fkkcollh_i
              t_fkkcollp_ip_w-lfdnr
           changing
              t_fkkcollp_ip.

* Ausgabe Inkassoposition auf Informationsdatei
        if t_fkkcollp_ip_w-logkz is initial.
          add 1 to h_anzza.
        endif.
        if p_p_i_basics-status-xsimu is initial.
          if t_fkkcollp_ip_w-logkz is initial.
            transfer t_fkkcollp_ip to p_p_h_file_name.
          endif.

* Meldung registrieren
          perform write_log_record_payment
             using
                t_fkkcollp_ip_w-lfdnr
                t_fkkcollp_ip
                p_p_i_basics.
        endif.

* Aktualisieren Datei-Endesatz
        if t_fkkcollp_ip_w-logkz is initial.
          add 1 to p_p_t_fkkcollt_i-recnum.

          if p_postyp eq c_cancelled_receivable.
            perform addition
              using
                t_fkkcollp_ip-betrw
              changing
                p_p_t_fkkcollt_i-sumrc.

* Aktualisieren Summensatz je Positionstyp
            perform addition
              using
                t_fkkcollp_ip-betrw
              changing
                h_summe.
          else.
            perform addition
              using
                t_fkkcollp_ip-bwtrt
              changing
                p_p_t_fkkcollt_i-sumza.

* Aktualisieren Summensatz je Positionstyp
            perform addition
              using
                t_fkkcollp_ip-bwtrt
              changing
                h_summe.
          endif.
        endif.

      endselect.


    when c_sum_gpart..

* ------- Summierung auf Geschäftspartnerebene ---------------------*
* Lesen Zahlungs- bzw. Ausgleichs-Informationen aus Zwischenspeicher
      select * into  corresponding fields of t_fkkcollp_ip_w
               from  dfkkcollp_ip_w
               where laufd   eq p_p_i_basics-runkey-laufd
               and   laufi   eq p_p_i_basics-runkey-laufi
               and   w_inkgp eq p_p_t_fkkcollh_i_w-w_inkgp
               and   satztyp eq c_position
               and   postyp  eq p_postyp
            order by gpart nrzas opbel inkps.

        move-corresponding t_fkkcollp_ip_w to t_fkkcollp_ip.
        move-corresponding t_fkkcollp_ip to h_key_gpart.

        if h_key_gpart_old ne h_key_gpart.
* Gruppenwechsel
          if not h_knz is initial.

* ------- calls user exit 5052 / payment (sum) ------------------------*
            perform call_zp_fb_5052_payment
               using
                  p_postyp
                  p_p_t_fkkcollh_i
                  0
               changing
                  sum_fkkcollp_ip.

* Ausgabe Inkassoposition auf Informationsdatei
            if t_fkkcollp_ip_w-logkz is initial.
              add 1 to h_anzza.

              if p_p_i_basics-status-xsimu is initial.
                transfer sum_fkkcollp_ip to p_p_h_file_name.
              endif.

* Aktualisieren Datei-Endesatz
              add 1 to p_p_t_fkkcollt_i-recnum.
              if p_postyp eq c_cancelled_receivable.
                perform addition
                  using
                    sum_fkkcollp_ip-betrw
                  changing
                    p_p_t_fkkcollt_i-sumrc.
              else.
                perform addition
                  using
                    sum_fkkcollp_ip-bwtrt
                  changing
                    p_p_t_fkkcollt_i-sumza.
              endif.
            endif.
          endif.
          clear sum_fkkcollp_ip.
        endif.
        h_knz = 'X'.

* Aufbau Summensatz
        sum_fkkcollp_ip-postyp  = t_fkkcollp_ip-postyp.
        sum_fkkcollp_ip-satztyp = t_fkkcollp_ip-satztyp.
        sum_fkkcollp_ip-nrzas   = t_fkkcollp_ip-nrzas.
        sum_fkkcollp_ip-gpart   = t_fkkcollp_ip-gpart.
        sum_fkkcollp_ip-waers   = t_fkkcollp_ip-waers.
        sum_fkkcollp_ip-txtvw   = t_fkkcollp_ip-txtvw.

        if t_fkkcollp_ip_w-logkz is initial.
          perform addition
          using
            t_fkkcollp_ip-bwtrt
          changing
            sum_fkkcollp_ip-bwtrt.
          perform addition
            using
              t_fkkcollp_ip-betrw
            changing
              sum_fkkcollp_ip-bwtrt.

* Aktualisieren Protokollsatz
          perform addition
            using
              t_fkkcollp_ip-bwtrt
            changing
              h_summe.
        endif.

* Meldung registrieren
        if p_p_i_basics-status-xsimu is initial.
          perform write_log_record_payment
             using
                t_fkkcollp_ip_w-lfdnr
                t_fkkcollp_ip
                p_p_i_basics.
        endif.

        move-corresponding h_key_gpart to h_key_gpart_old.

      endselect.

* Ausagbe letzte Inkassoposition
      if not h_knz is initial.

* ------- calls user exit 5052 / payment -----------------------------*
        perform call_zp_fb_5052_payment
           using
              p_postyp
              p_p_t_fkkcollh_i
              0
           changing
              sum_fkkcollp_ip.

* Ausgabe Inkassoposition auf Informationsdatei
        if not h_summe is initial.
          add 1 to h_anzza.

          if p_p_i_basics-status-xsimu is initial.
            transfer sum_fkkcollp_ip to p_p_h_file_name.
          endif.
        endif.
        h_knz = 'X'.

* Aktualisieren Datei-Endesatz
        if t_fkkcollp_ip_w-logkz is initial.
          add 1 to p_p_t_fkkcollt_i-recnum.
          if p_postyp eq c_cancelled_receivable.
            perform addition
               using
                sum_fkkcollp_ip-betrw
               changing
                 p_p_t_fkkcollt_i-sumrc.
          else.
            perform addition
               using
                sum_fkkcollp_ip-bwtrt
               changing
                 p_p_t_fkkcollt_i-sumza.
          endif.
        endif.
      endif.


    when c_sum_nrzas.
* ------- Summierung auf Basis Zahlschein-Nummer ----------------------*

* Lesen Ausgleichs-Informationen aus Zwischenspeicher
      select * into  corresponding fields of t_fkkcollp_ip_w
               from  dfkkcollp_ip_w
               where laufd   eq p_p_i_basics-runkey-laufd
               and   laufi   eq p_p_i_basics-runkey-laufi
               and   w_inkgp eq p_p_t_fkkcollh_i_w-w_inkgp
               and   satztyp eq c_position
               and   postyp  eq p_postyp
            order by nrzas gpart opbel inkps.

        move-corresponding t_fkkcollp_ip_w to t_fkkcollp_ip.
        move-corresponding t_fkkcollp_ip to h_key_nrzas.

        if h_key_nrzas_old ne h_key_nrzas.
* Gruppenwechsel
          if not h_knz is initial.
* ------- calls user exit 5052 / payment (sum) ------------------------*
            perform call_zp_fb_5052_payment
               using
                  p_postyp
                  p_p_t_fkkcollh_i
                  0
               changing
                  sum_fkkcollp_ip.

* Ausgabe Inkassoposition auf Informationsdatei
            if t_fkkcollp_ip_w-logkz is initial.
              add 1 to h_anzza.

              if p_p_i_basics-status-xsimu is initial.
                transfer sum_fkkcollp_ip to p_p_h_file_name.
              endif.

* Aktualisieren Datei-Endesatz
              add 1 to p_p_t_fkkcollt_i-recnum.
              if p_postyp eq c_cancelled_receivable.
                perform addition
                   using
                     sum_fkkcollp_ip-betrw
                   changing
                     p_p_t_fkkcollt_i-sumrc.
              else.
                perform addition
                   using
                     sum_fkkcollp_ip-bwtrt
                   changing
                     p_p_t_fkkcollt_i-sumza.
              endif.
            endif.
          endif.
          clear sum_fkkcollp_ip.
        endif.
        h_knz = 'X'.

* Aufbau Summensatz
        sum_fkkcollp_ip-postyp  = t_fkkcollp_ip-postyp.
        sum_fkkcollp_ip-satztyp = t_fkkcollp_ip-satztyp.
        sum_fkkcollp_ip-nrzas   = t_fkkcollp_ip-nrzas.
        sum_fkkcollp_ip-gpart   = t_fkkcollp_ip-gpart.
        sum_fkkcollp_ip-waers   = t_fkkcollp_ip-waers.
        sum_fkkcollp_ip-txtvw   = t_fkkcollp_ip-txtvw.

        if t_fkkcollp_ip_w-logkz is initial.
          perform addition
          using
           t_fkkcollp_ip-bwtrt
          changing
           sum_fkkcollp_ip-bwtrt.
          perform addition
            using
              t_fkkcollp_ip-betrw
            changing
              sum_fkkcollp_ip-betrw.

* Aktualisieren Protokollsatz
          perform addition
            using
              t_fkkcollp_ip-bwtrt
            changing
              h_summe.
        endif.

* Meldung registrieren
        if p_p_i_basics-status-xsimu is initial.
          perform write_log_record_payment
             using
                t_fkkcollp_ip_w-lfdnr
                t_fkkcollp_ip
                p_p_i_basics.
        endif.

* Merken letzte Schlüssel
        move-corresponding h_key_nrzas to h_key_nrzas_old.

      endselect.

      if not h_knz is initial.
* ------- calls user exit 5052 / payment (sum) ------------------------*
        perform call_zp_fb_5052_payment
           using
              p_postyp
              p_p_t_fkkcollh_i
              0
           changing
              sum_fkkcollp_ip.

* Ausgabe Inkassoposition auf Informationsdatei
*        IF t_fkkcollp_ip_w-logkz IS INITIAL.
        if not h_summe is initial.
          add 1 to h_anzza.
          if p_p_i_basics-status-xsimu is initial.
            transfer sum_fkkcollp_ip to p_p_h_file_name.
          endif.
        endif.
        h_knz = 'X'.

* Aktualisieren Datei-Endesatz
        if t_fkkcollp_ip_w-logkz is initial.
          add 1 to p_p_t_fkkcollt_i-recnum.
          if p_postyp eq c_cancelled_receivable.
            perform addition
               using
                sum_fkkcollp_ip-betrw
               changing
                 p_p_t_fkkcollt_i-sumrc.
          else.
            perform addition
               using
                sum_fkkcollp_ip-bwtrt
               changing
                 p_p_t_fkkcollt_i-sumza.
          endif.
        endif.
      endif.

    when c_sum_vkont.

* ------- Summierung auf Vertragskontoebene ---------------------*
* Lesen Zahlungs- bzw. Ausgleichs-Informationen aus Zwischenspeicher
      select * into  corresponding fields of t_fkkcollp_ip_w
               from  dfkkcollp_ip_w
               where laufd   eq p_p_i_basics-runkey-laufd
               and   laufi   eq p_p_i_basics-runkey-laufi
               and   w_inkgp eq p_p_t_fkkcollh_i_w-w_inkgp
               and   satztyp eq c_position
               and   postyp  eq p_postyp
            order by vkont nrzas opbel inkps.

        move-corresponding t_fkkcollp_ip_w to t_fkkcollp_ip.
        move-corresponding t_fkkcollp_ip to h_key_vkont.

        if h_key_vkont_old ne h_key_vkont.
* Gruppenwechsel
          if not h_knz is initial.

* ------- calls user exit 5052 / payment (sum) ------------------------*
            perform call_zp_fb_5052_payment
               using
                  p_postyp
                  p_p_t_fkkcollh_i
                  0
               changing
                  sum_fkkcollp_ip.

* Ausgabe Inkassoposition auf Informationsdatei
            if t_fkkcollp_ip_w-logkz is initial.
              add 1 to h_anzza.

              if p_p_i_basics-status-xsimu is initial.
                transfer sum_fkkcollp_ip to p_p_h_file_name.
              endif.

* Aktualisieren Datei-Endesatz
              add 1 to p_p_t_fkkcollt_i-recnum.
              if p_postyp eq c_cancelled_receivable.
                perform addition
                  using
                    sum_fkkcollp_ip-betrw
                  changing
                    p_p_t_fkkcollt_i-sumrc.
              else.
                perform addition
                  using
                    sum_fkkcollp_ip-bwtrt
                  changing
                    p_p_t_fkkcollt_i-sumza.
              endif.
            endif.
          endif.
          clear sum_fkkcollp_ip.
        endif.
        h_knz = 'X'.

* Aufbau Summensatz
        sum_fkkcollp_ip-postyp  = t_fkkcollp_ip-postyp.
        sum_fkkcollp_ip-satztyp = t_fkkcollp_ip-satztyp.
        sum_fkkcollp_ip-nrzas   = t_fkkcollp_ip-nrzas.
        sum_fkkcollp_ip-gpart   = t_fkkcollp_ip-gpart.
        sum_fkkcollp_ip-vkont   = t_fkkcollp_ip-vkont.
        sum_fkkcollp_ip-waers   = t_fkkcollp_ip-waers.
        sum_fkkcollp_ip-txtvw   = t_fkkcollp_ip-txtvw.

        if t_fkkcollp_ip_w-logkz is initial.
          perform addition
          using
            t_fkkcollp_ip-bwtrt
          changing
            sum_fkkcollp_ip-bwtrt.
          perform addition
            using
              t_fkkcollp_ip-betrw
            changing
              sum_fkkcollp_ip-betrw.

* Aktualisieren Protokollsatz
          perform addition
            using
              t_fkkcollp_ip-bwtrt
            changing
              h_summe.
        endif.

* Meldung registrieren
        if p_p_i_basics-status-xsimu is initial.
          perform write_log_record_payment
             using
                t_fkkcollp_ip_w-lfdnr
                t_fkkcollp_ip
                p_p_i_basics.
        endif.

        move-corresponding h_key_vkont to h_key_vkont_old.

      endselect.

* Ausagbe letzte Inkassoposition
      if not h_knz is initial.

* ------- calls user exit 5052 / payment -----------------------------*
        perform call_zp_fb_5052_payment
           using
              p_postyp
              p_p_t_fkkcollh_i
              0
           changing
              sum_fkkcollp_ip.

* Ausgabe Inkassoposition auf Informationsdatei
        if t_fkkcollp_ip_w-logkz is initial.
          add 1 to h_anzza.

          if p_p_i_basics-status-xsimu is initial.
            transfer sum_fkkcollp_ip to p_p_h_file_name.
          endif.
        endif.
        h_knz = 'X'.

* Aktualisieren Datei-Endesatz
        if not h_summe is initial.
          add 1 to p_p_t_fkkcollt_i-recnum.
          if p_postyp eq c_cancelled_receivable.
            perform addition
               using
                sum_fkkcollp_ip-betrw
               changing
                 p_p_t_fkkcollt_i-sumrc.
          else.
            perform addition
               using
                sum_fkkcollp_ip-bwtrt
               changing
                 p_p_t_fkkcollt_i-sumza.
          endif.
        endif.
      endif.

  endcase.

*>>>>> HANA
  IF NOT gt_fkkcoli_log[] IS INITIAL.
    INSERT dfkkcoli_log FROM TABLE gt_fkkcoli_log.
    CLEAR: gt_fkkcoli_log[],gt_fkkcoli_log.
  ENDIF.
*<<<<< HANA

* Protokoll
  WRITE h_summe TO h_sumza.
  shift h_sumza left deleting leading space.
  if p_postyp eq c_cancelled_receivable.
* Nachricht: Datei enthält & Storno-Positionen im Gesamtwert von & &
    if h_anzza > 0.
*      clear h_sumza.
*      write t_fkkcollp_ip_w-betrw to h_sumza.
*      shift h_sumza left deleting leading space.
      mac_appl_log_msg 'I' '>4' '828'
         h_anzza
         h_sumza t_fkkcollp_ip-waers space
         c_msgprio_info p_p_i_basics-appllog-probclass.
      set extended check off.
      if 1 = 2. message i809(>4). endif.
      set extended check on.
    endif.

  elseif p_postyp eq c_write_off.
* Nachricht: Datei enthält & Ausbuchungs-Positionen im Gesamtwert von &&
    if h_anzza > 0.
      mac_appl_log_msg 'I' '>4' '827'
         h_anzza
         h_sumza t_fkkcollp_ip-waers space
         c_msgprio_info p_p_i_basics-appllog-probclass.
      set extended check off.
      if 1 = 2. message i827(>4). endif.
      set extended check on.
    endif.
  endif.

endform.                    " create_info_storno
*&---------------------------------------------------------------------*
*&      Form  get_tfk050i
*&---------------------------------------------------------------------*
form get_tfk050i.

  data:
    t_tfk050i type tfk050i occurs 0 with header line.

  select * into table t_tfk050i
           from tfk050i.
  loop at t_tfk050i.
    case t_tfk050i-ictyp.
      when '01'.
        g_fkkcollinfo-xcpart  = t_tfk050i-xcinf.
      when '02'.
        g_fkkcollinfo-xausg   = t_tfk050i-xcinf.
      when '03'.
        g_fkkcollinfo-xback   = t_tfk050i-xcinf.
      when '04'.
        g_fkkcollinfo-xstorno = t_tfk050i-xcinf.
      when '05'.
        g_fkkcollinfo-xreclr  = t_tfk050i-xcinf.
      when '06'.
        g_fkkcollinfo-xretrn  = t_tfk050i-xcinf.
      when '07'.
        g_fkkcollinfo-xrever  = t_tfk050i-xcinf.
      when '08'.
        g_fkkcollinfo-xwroff  = t_tfk050i-xcinf.
    endcase.
  endloop.

endform.                    " get_tfk050i
