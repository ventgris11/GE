*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZINTF_E_C15_C_OP
*   generation date: 12.09.2019 at 11:03:16
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZINTF_E_C15_C_OP    .

  PERFORM TABLEPROC.

ENDFUNCTION.
