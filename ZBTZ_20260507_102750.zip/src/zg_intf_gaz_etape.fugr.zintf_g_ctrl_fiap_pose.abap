FUNCTION zintf_g_ctrl_fiap_pose .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA:
    lv_field     TYPE string,
    lv_int_ui    TYPE int_ui,
    lv_anlage    TYPE anlage,
    ls_object    TYPE eedm_isu_objects,
    lv_equnr     TYPE equnr,
    lv_sernr     TYPE gernr,
    lt_fiap      TYPE iegerr,
    ls_fiap      TYPE egerr,
    lv_message   TYPE char255,
    ls_bpem      TYPE zbpem_flux_struct,
    lv_interface TYPE zisu_flxid.

  FIELD-SYMBOLS:
    <fs_emetteur>,
    <fs_flux>,
    <fs_idenreg>,
    <fs_num_pce>,
    <fs_date_releve>.

  ev_etape = 2.

  CLEAR: lv_field.
  MOVE 'FLUX-EMETTEUR'     TO lv_field.
  ASSIGN (lv_field)        TO <fs_emetteur>.

  CLEAR: lv_field.
  MOVE 'FLUX-FLUX'         TO lv_field.
  ASSIGN (lv_field)        TO <fs_flux>.

  CLEAR: lv_field.
  MOVE 'FLUX-IDENREG'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_idenreg>.

  CLEAR: lv_field.
  MOVE 'FLUX-NUM_PCE'      TO lv_field.
  ASSIGN (lv_field)        TO <fs_num_pce>.

  CLEAR: lv_field.
  MOVE 'FLUX-DATE_RELEVE'  TO lv_field.
  ASSIGN (lv_field)        TO <fs_date_releve>.

  CLEAR ls_bpem.
  ls_bpem-num_pce = <fs_num_pce>.
  CASE <fs_flux>.
    WHEN 'ADIF'.
      ls_bpem-date_effet_cont = <fs_date_releve>.
    WHEN 'RE6M' OR 'RE1M' OR 'REMM' OR 'REJJ' OR 'REJM'.
      ls_bpem-date_releve     = <fs_date_releve>.
    WHEN 'AFAC'.
      ls_bpem-date_fin_prest  = <fs_date_releve>.
  ENDCASE.

* Récupération du PCE (Point de Comptage)
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).

  IF lv_int_ui IS INITIAL.
* &1 - &2 - &3 : PCE &4 inexistant
    MESSAGE e084(zintf_g_messages)
       WITH <fs_emetteur>
            <fs_flux>
            <fs_idenreg>
            <fs_num_pce>
       INTO lv_message.

    lv_interface    = <fs_flux> .
    ls_bpem-idenreg = <fs_idenreg>.
    CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
      EXPORTING
        iv_interface_name = lv_interface
        iv_sparte         = 'ZG'
        is_structure      = ls_bpem.

    RETURN.
  ENDIF.

* Récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = <fs_date_releve>
    IMPORTING
      es_detail = ls_object
      ev_equnr  = lv_equnr
      ev_sernr  = lv_sernr.

  IF ls_object-installation IS INITIAL.
* (ID &1) PCE &2 non rattaché à une installation active à la date du &3
    MESSAGE e044(zintf_g_messages)
       WITH <fs_idenreg>
            <fs_num_pce>
            <fs_date_releve>
       INTO lv_message.
    RETURN.
  ENDIF.

  REFRESH lt_fiap.
  CALL METHOD zcl_tool=>install_liste_fiap
    EXPORTING
      iv_install = ls_object-installation
      iv_date    = <fs_date_releve>
    IMPORTING
      et_fiap    = lt_fiap.

* Suppression des FIAP non pertinentes
  DELETE lt_fiap WHERE bis NE '99991231'.

  IF lt_fiap[] IS INITIAL.
* Contrôles ok, ETAPE SUIVANTE: Création FIAP puis Pose FIAP
    ev_etape = 1.
  ELSE.
* (ID &1) FIAP déjà posée sur l'installation &2 du PCE &3 en date du &4
    MESSAGE e095(zintf_g_messages)
       WITH <fs_idenreg>
            ls_object-installation
            <fs_num_pce>
            <fs_date_releve>
       INTO lv_message.
  ENDIF.

ENDFUNCTION.
