FUNCTION Z_ISU_SAMPLE_TFK116_EXCLFAECHU.
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     VALUE(X_VERVAR) LIKE  TFK115-VERVAR
*"     VALUE(X_VERART) LIKE  TFK110-VERART OPTIONAL
*"     VALUE(X_BLDAT) LIKE  FKKKO-BLDAT OPTIONAL
*"     VALUE(X_IFNAM) LIKE  TFK116-IFNAM
*"     VALUE(X_XSORT) LIKE  BOOLE-BOOLE DEFAULT SPACE
*"  TABLES
*"      T_E516_FKKCL STRUCTURE  E516_FKKCL
*"      T_SELTAB STRUCTURE  ISELTAB OPTIONAL
*"----------------------------------------------------------------------
* Ce MF a pour objectif de filtrer les pièces de type FA avec une date d'échéance dans le futur

  CASE x_ifnam.
    WHEN 'Z_EXCL_F_ECHU'. " Controle sur le nom de la zone

      LOOP AT t_e516_fkkcl ASSIGNING FIELD-SYMBOL(<lr_e516_fkkcl>).
        "On ne regarde que les postes liés à une facture
        IF
          (     <lr_e516_fkkcl>-blart = 'FA'
          OR    <lr_e516_fkkcl>-blart = 'AF'
          OR    <lr_e516_fkkcl>-blart = 'BB'
          OR    <lr_e516_fkkcl>-blart = 'PA'
          OR (  <lr_e516_fkkcl>-blart = 'RP' AND <lr_e516_fkkcl>-spart IS NOT INITIAL )
          OR (  <lr_e516_fkkcl>-blart = 'RC' AND <lr_e516_fkkcl>-spart IS NOT INITIAL )
          OR (  <lr_e516_fkkcl>-blart = 'GC' AND <lr_e516_fkkcl>-spart IS NOT INITIAL ) ).
          IF <lr_e516_fkkcl>-faedn GT sy-datum.
            <lr_e516_fkkcl>-e_zreg_te516 = '2'.
          ENDIF.
          IF <lr_e516_fkkcl>-BETRW < 0.
            <lr_e516_fkkcl>-e_zreg_te516 = '2'.
          ENDIF.
        ENDIF.

      ENDLOOP.
  ENDCASE.

ENDFUNCTION.
