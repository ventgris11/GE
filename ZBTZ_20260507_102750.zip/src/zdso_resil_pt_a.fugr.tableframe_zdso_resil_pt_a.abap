*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZDSO_RESIL_PT_A
*   generation date: 14.04.2019 at 12:20:31
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZDSO_RESIL_PT_A    .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.
