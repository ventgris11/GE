*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 28.09.2020 at 18:53:35
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZINTF_E_R15.....................................*
DATA:  BEGIN OF STATUS_ZINTF_E_R15                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZINTF_E_R15                   .
CONTROLS: TCTRL_ZINTF_E_R15
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZINTF_E_R15                   .
TABLES: ZINTF_E_R15                    .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
