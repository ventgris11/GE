FUNCTION zintf_g_depose_fiap .
*"----------------------------------------------------------------------
*"*"Interface locale :
*"  IMPORTING
*"     REFERENCE(IV_MODE_TEST) TYPE  CRMT_BOOLEAN
*"  EXPORTING
*"     REFERENCE(EV_ETAPE) TYPE  I
*"  CHANGING
*"     REFERENCE(FLUX) TYPE  ANY
*"     REFERENCE(CV_LOG_HANDLE) TYPE  BALLOGHNDL OPTIONAL
*"----------------------------------------------------------------------

  DATA: lc_field_idenreg     TYPE fieldname VALUE 'IDENREG',
        lc_field_num_pce     TYPE fieldname VALUE 'NUM_PCE',
        lc_field_date_releve TYPE fieldname VALUE 'DATE_RELEVE',
        lc_field_nb_roue_cpt TYPE fieldname VALUE 'NB_ROUE_COMPTEUR',
        lc_field_num_serie   TYPE fieldname VALUE 'NUM_SERIE_COMPTEUR',
        lc_field_flux        TYPE fieldname VALUE 'FLUX',
        lc_field_index_fin   TYPE fieldname VALUE 'INDEX_BRUT_FIN_PERIODE',
        lv_field             TYPE string,
        lv_int_ui            TYPE int_ui,
        lv_date              TYPE adats,
        lv_anlage            TYPE anlage,
        ls_object            TYPE eedm_isu_objects,
        lt_etdz              TYPE TABLE OF etdz,
        ls_etdz              TYPE etdz,
        lv_stanzvor          TYPE stanzvor,
        ls_auto              TYPE isu42_devmod_auto,
        lv_device            TYPE geraet,
        lv_equnr             TYPE equnr,
        lv_db_update         TYPE e_update,
        ls_dev               TYPE reg42_dev,
        ls_dev_flag          TYPE reg42_dev_input_flag,
        lv_success           TYPE crmt_boolean,
        ls_bpem              TYPE zbpem_flux_struct,
        lv_interface         TYPE zisu_flxid.

  FIELD-SYMBOLS: <fs_num_pce>, <fs_date_releve>, <fs_nb_roue_compteur>, <fs_num_serie>, <fs_flux>, <fs_idx_fin_periode>,<fs_idenreg>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_idenreg INTO lv_field.
  ASSIGN (lv_field) TO <fs_idenreg>.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_pce INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_pce>.
  IF <fs_num_pce> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_date_releve INTO lv_field.
  ASSIGN (lv_field) TO <fs_date_releve>.
  IF <fs_date_releve> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_nb_roue_cpt INTO lv_field.
  ASSIGN (lv_field) TO <fs_nb_roue_compteur>.
  IF <fs_nb_roue_compteur> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_num_serie INTO lv_field.
  ASSIGN (lv_field) TO <fs_num_serie>.
  IF <fs_num_serie> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_flux INTO lv_field.
  ASSIGN (lv_field) TO <fs_flux>.
  IF <fs_flux> IS NOT ASSIGNED.
  ENDIF.

  CLEAR: lv_field.
  CONCATENATE 'FLUX-' lc_field_index_fin INTO lv_field.
  ASSIGN (lv_field) TO <fs_idx_fin_periode>.
  IF <fs_idx_fin_periode> IS NOT ASSIGNED.
  ENDIF.



* Pour récupération de INT_UI
  lv_int_ui = zcl_tool=>pod_check_exist( iv_pce_num = <fs_num_pce> ).
  IF lv_int_ui IS INITIAL.
  ENDIF.

  lv_date = <fs_date_releve> + 1.

* Pour récupération du numéro de l'installation
  CLEAR ls_object.
  CALL METHOD zcl_tool=>pod_get_related_object
    EXPORTING
      iv_int_ui = lv_int_ui
      iv_date   = lv_date
    IMPORTING
      es_detail = ls_object.

  lv_anlage = ls_object-installation.

  CALL METHOD zcl_tool=>install_depose_fiap
    EXPORTING
      iv_install    = ls_object-installation
      iv_date_effet = lv_date
      iv_mode_test  = iv_mode_test
*     iv_matnr      =
*     iv_equnr      =
    RECEIVING
      ev_success    = lv_success.

  IF lv_success IS INITIAL.
    ev_etape = 2.
  ELSE.
    ev_etape = 1.
  ENDIF.

  MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 INTO data(lv_message).
  IF sy-msgid = 'ZINTF_G_MESSAGES' AND sy-msgno = '060'.
    CLEAR ls_bpem.
    ls_bpem-num_pce = <fs_num_pce>.
    CASE <fs_flux>.
      WHEN 'ADIF'.
        ls_bpem-date_effet_cont = <fs_date_releve>.
      WHEN 'RE6M' OR 'REMM' OR 'REJJ' OR 'REJM'.
        ls_bpem-date_releve     = <fs_date_releve>.
      WHEN 'AFAC'.
        ls_bpem-date_fin_prest  = <fs_date_releve>.
    ENDCASE.

    lv_interface    = <fs_flux>.
    IF <fs_idenreg> IS ASSIGNED .
      ls_bpem-idenreg = <fs_idenreg>.
    ENDIF.

    CALL FUNCTION 'ZBPEM_CREATE_CASE_GENERIC'
      EXPORTING
        iv_interface_name = lv_interface
        iv_sparte         = 'ZG'
        is_structure      = ls_bpem.
  ENDIF.


ENDFUNCTION.
