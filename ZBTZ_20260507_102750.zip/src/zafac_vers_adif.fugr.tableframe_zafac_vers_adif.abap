*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZAFAC_VERS_ADIF
*   generation date: 20.02.2019 at 16:37:17
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZAFAC_VERS_ADIF    .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.
