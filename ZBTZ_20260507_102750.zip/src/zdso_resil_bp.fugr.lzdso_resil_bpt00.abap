*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 21.04.2019 at 16:50:39
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZDSO_RESIL_BP...................................*
DATA:  BEGIN OF STATUS_ZDSO_RESIL_BP                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDSO_RESIL_BP                 .
CONTROLS: TCTRL_ZDSO_RESIL_BP
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDSO_RESIL_BP                 .
TABLES: ZDSO_RESIL_BP                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
