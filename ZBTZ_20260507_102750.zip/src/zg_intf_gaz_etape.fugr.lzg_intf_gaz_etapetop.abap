FUNCTION-POOL ZG_INTF_GAZ_ETAPE.            "MESSAGE-ID ..

* INCLUDE LZG_INTF_GAZ_ETAPED...             " Local class definition

Data: gv_pose_225 type flag.
