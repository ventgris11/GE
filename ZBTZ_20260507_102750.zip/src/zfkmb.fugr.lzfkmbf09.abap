*----------------------------------------------------------------------*
***INCLUDE LFKMBF09 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  fill_dunning_reductions
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM fill_dunning_reductions  TABLES   ct_fkkmared STRUCTURE fkkmared
                              USING    uf_disputes      TYPE fkk_dm_data
                                       u_fkkmared_betrh TYPE betrh_kk
                                       u_fkkmared_betrw TYPE betrw_kk
                                       u_hwaer          TYPE hwaer_kk
                                       u_mgrpx          TYPE mgrpx_kk.
  DATA: wa_fkkmared TYPE fkkmared.


* Assign other fields to FKKMARED
  MOVE: u_fkkmared_betrh             TO wa_fkkmared-betrh,
        u_fkkmared_betrw             TO wa_fkkmared-betrw,
        u_hwaer                      TO wa_fkkmared-hwaer,
        u_mgrpx                      TO wa_fkkmared-mgrpx,
        'DC'                         TO wa_fkkmared-obj1t,
        uf_disputes-case_guid        TO wa_fkkmared-obj1r,
        uf_disputes-ext_key          TO wa_fkkmared-int_ref,
        uf_disputes-ext_ref          TO wa_fkkmared-ext_ref,
        uf_disputes-fin_dispute_curr TO wa_fkkmared-waers,
        uf_disputes-fica_int_reason  TO wa_fkkmared-reason.
* Entry with this key already in reduction table?
  READ TABLE ct_fkkmared WITH KEY mgrpx = wa_fkkmared-mgrpx
                                  obj1t = wa_fkkmared-obj1t
                                  obj1r = wa_fkkmared-obj1r.
  IF sy-subrc IS INITIAL.
    ADD wa_fkkmared-betrh TO ct_fkkmared-betrh.
    ADD wa_fkkmared-betrw TO ct_fkkmared-betrw.
    MODIFY ct_fkkmared INDEX sy-tabix TRANSPORTING betrh betrw.
  ELSE.
    APPEND wa_fkkmared TO ct_fkkmared.
  ENDIF.

ENDFORM.                    " fill_dunning_reductions
