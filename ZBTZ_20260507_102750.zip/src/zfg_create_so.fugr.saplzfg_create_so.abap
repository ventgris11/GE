*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_CREATE_SOTOP.                 " Global Data
  INCLUDE LZFG_CREATE_SOUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_CREATE_SOF...                 " Subroutines
* INCLUDE LZFG_CREATE_SOO...                 " PBO-Modules
* INCLUDE LZFG_CREATE_SOI...                 " PAI-Modules
* INCLUDE LZFG_CREATE_SOE...                 " Events
* INCLUDE LZFG_CREATE_SOP...                 " Local class implement.
* INCLUDE LZFG_CREATE_SOT99.                 " ABAP Unit tests
