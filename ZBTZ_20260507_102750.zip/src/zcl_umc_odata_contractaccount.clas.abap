class ZCL_UMC_ODATA_CONTRACTACCOUNT definition
  public
  inheriting from CL_ISU_UMC_ODATA_CONTRACC
  final
  create public .

public section.

  methods IF_ISU_UMC_ODATA_IMPL~GET_ENTITY
    redefinition .
protected section.
private section.
ENDCLASS.



CLASS ZCL_UMC_ODATA_CONTRACTACCOUNT IMPLEMENTATION.


  METHOD if_isu_umc_odata_impl~get_entity.
    DATA:  lv_string              TYPE string,              "#EC NEEDED
           lv_contract_account_id TYPE vkont_kk,
           ls_contract_account    TYPE isus_umc_contractaccount,
           ls_key                 TYPE /iwbep/s_mgw_tech_pair,
           lt_keys                TYPE /iwbep/t_mgw_tech_pairs.
**************************************************************************
* Support of long navigation                                             *
**************************************************************************
    IF io_tech_request_context->get_navigation_path( ) IS INITIAL.
**************************************************************************
* Read Keys                                                              *
**************************************************************************
      lt_keys = io_tech_request_context->get_keys( ).
      READ TABLE lt_keys INTO ls_key WITH KEY name = gc_key_attribute.

      lv_contract_account_id = ls_key-value.
      lv_contract_account_id = convert_alpha( lv_contract_account_id ).
**************************************************************************
* Get contract account with the API Clss                     *
**************************************************************************
      cl_isu_umc_api_contracc=>read_contract_account(
        EXPORTING        iv_contract_account_id = lv_contract_account_id
        RECEIVING        rs_contract_account    = ls_contract_account ).

******** Ajout AliA Consulting (LWAT) 20170725 : Récupération des infos complémentaires:
******** - Conditions de paiements (ZHLKNOND)
******** - Facture dématérialisée (COPRC)
      DATA: ls_fkkvkp TYPE fkkvkp.
      CALL FUNCTION 'FKK_ACCOUNT_READ'
        EXPORTING
          i_vkont      = lv_contract_account_id
        IMPORTING
          e_fkkvkp     = ls_fkkvkp
        EXCEPTIONS
          not_found    = 1
          foreign_lock = 2
          not_valid    = 3
          OTHERS       = 4.

      IF sy-subrc = 0.
        ls_contract_account-zzzahlkond = ls_fkkvkp-zahlkond.
        IF ls_fkkvkp-zahlkond IS NOT INITIAL.
          SELECT SINGLE text FROM te052t INTO ls_contract_account-zzzahlkond_txt WHERE zahlkond = ls_fkkvkp-zahlkond AND spras = 'FR'.
        ENDIF.

        IF ls_fkkvkp-coprc EQ 'ZDEM'.
          ls_contract_account-zzfact_demat = abap_true.
        ELSE.
          ls_contract_account-zzfact_demat = abap_false.
        ENDIF.
      ENDIF.

** Ajout AliA Consulting (LWAT) 20170926 : Pour les CC B2C, il faut récupérer la PC dans CRM
      DATA: lt_object_id TYPE TABLE OF crmt_object_id_cm,
            lv_rfc_crm   TYPE rfcdest.
      IF ls_fkkvkp-stdbk EQ 'GDP2'. " Uniquement pour les CC de type B2C
        SELECT SINGLE rfcdest INTO lv_rfc_crm FROM crmrfcpar WHERE consumer = 'CRM'.
        IF sy-subrc = 0 AND lv_rfc_crm IS NOT INITIAL.
          " Récupération des PC au statut signées
          CALL FUNCTION 'ZMFU_ISU_GET_QUOTATION_FROM_CC'
            DESTINATION lv_rfc_crm
            EXPORTING
              iv_contractaccount    = lv_contract_account_id
            IMPORTING
              et_pc_id              = lt_object_id
            EXCEPTIONS
              system_failure        = 1
              communication_failure = 2.
          IF sy-subrc = 0.
** >> GE-2270 (LWAT) 02.09.2018 : On veut récupérer la PC la plus récente pour avoir le
**    dernier contrat PDF associé
            " On veut la plus récente
            SORT lt_object_id DESCENDING.
*            " On veut la plus ancienne pour l'instant " -- GE-2270
*            SORT lt_object_id ASCENDING. " -- GE-2270
** << GE-2270 (LWAT) 02.09.2018
            READ TABLE lt_object_id INTO ls_contract_account-zzcrm_id_pc_signed INDEX 1.
          ENDIF.
        ENDIF.
      ENDIF.
** Fin Ajout AliA Consulting (LWAT) 20170926
** Fin ajout AliA Consulting (LWAT) 20170725

**************************************************************************
* Check user authorisation                                               *
**************************************************************************
      check_user_authorisation(
        EXPORTING iv_account_id  = ls_contract_account-gpart
                  iv_entity_type = iv_entity_name ).

      er_entity = copy_data_to_ref( ls_contract_account ).
    ELSE.
**************************************************************************
* Support of long navigation                                             *
**************************************************************************
      TRY.
          super->if_isu_umc_odata_impl~get_entity(
            EXPORTING     iv_entity_name          = iv_entity_name
                          iv_entity_set_name      = iv_entity_set_name
                          iv_source_name          = iv_source_name
                          it_key_tab              = it_key_tab
                          it_navigation_path      = it_navigation_path
                          io_tech_request_context = io_tech_request_context
            IMPORTING     er_entity               = er_entity ).

        CATCH /iwbep/cx_mgw_tech_exception.

          MESSAGE e001(isu_umc_odata) WITH iv_entity_name  gc_key_attribute INTO lv_string.
          handle_technical_error( 'GET_ENTITY' ).
      ENDTRY.
    ENDIF.
  ENDMETHOD.
ENDCLASS.
