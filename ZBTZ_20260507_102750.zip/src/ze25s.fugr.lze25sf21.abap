*----------------------------------------------------------------------*
***INCLUDE LE25SF21 .
*----------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*&      Form  F25_CHECK_IMPORT_PARAMS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_XT_EVER  text
*----------------------------------------------------------------------*
FORM f21_check_import_params TABLES   it_ever STRUCTURE ever.

  READ TABLE it_ever INDEX 1.
  IF sy-subrc NE 0.
*   Interner Fehler: Eingabe von Parameter &1 oder &2 in FuBa &3
*                    erforderlich
    mac_msg_putx co_msg_error '888' 'E9' 'XT_EVER' space
                 'ISU_S_BBP_DEBCH_DEACTIV' space not_qualified.
    IF 1 = 2.
      MESSAGE e888(e9) WITH space space space.
    ENDIF.
  ENDIF.

ENDFORM.                               " F21_CHECK_IMPORT_PARAMS
*&---------------------------------------------------------------------*
*&      Form  F21_GET_EABP
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_XT_EVER  text
*      -->P_LT_EABP  text
*      -->P_LT_EABP_NO_DUPL  text
*      -->P_LT_EVER_F  text
*      -->P_ENDFUNCTION  text
*----------------------------------------------------------------------*
FORM f21_get_eabp TABLES it_ever            STRUCTURE ever
                         xt_eabp            STRUCTURE eabp
                         xt_eabp_no_dupl    STRUCTURE eabp
                         xt_ever_f          STRUCTURE ever.

  DATA: lt_eabp LIKE eabp OCCURS 0 WITH HEADER LINE,
        l_ever  LIKE ever,
        lin TYPE i.

  LOOP AT it_ever INTO l_ever.
    CLEAR   lt_eabp.
    REFRESH lt_eabp.
    CALL FUNCTION 'ISU_DB_EABP_SELECT_CONTRACT'
      EXPORTING
        x_vertrag     = l_ever-vertrag
      TABLES
        t_eabp        = lt_eabp
      EXCEPTIONS
        not_found     = 1
        not_qualified = 2
        OTHERS        = 3.
    CASE sy-subrc.
      WHEN 0.
        DELETE lt_eabp WHERE NOT deaktiv IS INITIAL.
        DELETE lt_eabp WHERE kzabsver = co_absver_ps
                         AND ( psstatus = co_psstat_deac OR
                               psstatus = co_psstat_depe ).
        DESCRIBE TABLE lt_eabp LINES lin.
        IF lin > 0.
          APPEND LINES OF lt_eabp TO xt_eabp.
        ELSE.
* keine aktiven Abschlagspläne zum Vertrag gefunden
          APPEND l_ever TO xt_ever_f.
        ENDIF.
      WHEN 1.
        APPEND l_ever TO xt_ever_f.
      WHEN OTHERS.
        APPEND l_ever TO xt_ever_f.
        mac_msg_repeat co_msg_error not_qualified.
    ENDCASE.
  ENDLOOP.
  SORT xt_eabp BY opbel.
  xt_eabp_no_dupl[] = xt_eabp[].
  DELETE ADJACENT DUPLICATES FROM xt_eabp_no_dupl COMPARING opbel.

ENDFORM.                               " F21_GET_EABP
*&---------------------------------------------------------------------*
*&      Form  F21_GET_EABPS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_EABP  text
*      -->P_LT_EABPS  text
*      -->P_L_EABP_OPBEL  text
*      -->P_L_EABP_KZABSVER  text
*----------------------------------------------------------------------*
FORM f21_get_eabps TABLES xt_eabp           STRUCTURE eabp
                          xt_eabps          STRUCTURE eabps
                    USING value(i_opbel)    LIKE eabp-opbel
                          value(i_kzabsver) LIKE eabp-kzabsver
                 CHANGING i_obj             TYPE  fkkwh_whgrp.

  DATA: l_eabp        LIKE eabp,
        l_sample_flag TYPE c,
        l_ever        LIKE ever.

  IF i_kzabsver NE co_absver_stat.
    l_sample_flag = co_flag_marked.
  ENDIF.

  CALL FUNCTION 'FKK_READ_DOC_INTO_LOGICAL'
    EXPORTING
      i_opbel         = i_opbel
      i_accumulate    = space
      ix_sample_flag  = l_sample_flag
      i_select_locks  = co_true
    IMPORTING
      e_obj           = i_obj
    TABLES
      t_logfkkop      = xt_eabps
    EXCEPTIONS
      opbel_not_found = 1
      OTHERS          = 2.
  IF sy-subrc NE 0.
    DELETE xt_eabp WHERE opbel EQ i_opbel.
    mac_msg_repeat co_msg_error space.
  ENDIF.

ENDFORM.                               " F21_GET_EABPS
*&---------------------------------------------------------------------*
*&      Form  f21_enrich_eabp_eabps
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_EABP  text
*      -->P_LT_EABPS  text
*      -->P_L_EABP_OPBEL  text
*----------------------------------------------------------------------*
FORM f21_enrich_eabps TABLES it_eabp           STRUCTURE eabp
                          it_eabps          STRUCTURE eabps
                    USING value(i_opbel)    LIKE eabp-opbel.

  DATA: l_eabp  LIKE eabp,
        l_eabps LIKE eabps,
        l_vtref LIKE eabps-vtref.

  LOOP AT it_eabp INTO l_eabp
    WHERE opbel = i_opbel.

    PERFORM convert_vertrag_vtref USING l_eabp-vertrag
                               CHANGING l_vtref.
* Positionen deaktivieren
    LOOP AT it_eabps INTO l_eabps WHERE opbel EQ i_opbel
                                    AND vtref EQ l_vtref
                                    AND augst IS INITIAL
                                    AND augbl IS INITIAL
                                    AND augrd IS INITIAL.
      l_eabps-augdt = sy-datum.
      l_eabps-augbl = l_eabps-opbel.
      l_eabps-augbd = l_eabps-budat.
      l_eabps-augrd = co_augrd_deb.
      l_eabps-augst = co_augst_9.
      MODIFY it_eabps FROM l_eabps INDEX sy-tabix.
    ENDLOOP.
  ENDLOOP.

ENDFORM.                               " f21_enrich_eabp_eabps
*&---------------------------------------------------------------------*
*&      Form  F21_EABP_FILL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_EABP  text
*      -->P_LT_EABP_SAME  text
*      -->P_L_OBJ_INTEABP_DB  text
*      -->P_L_EABP_OPBEL  text
*----------------------------------------------------------------------*
FORM f21_eabp_fill TABLES   it_eabp            STRUCTURE eabp
                            xt_s_eabp          STRUCTURE eabp
                            xt_inteabp_db      STRUCTURE eabp
                      USING value(i_opbel)     LIKE      eabp-opbel.

  DATA: l_eabp LIKE eabp.

  LOOP AT it_eabp INTO l_eabp WHERE opbel EQ i_opbel.
    APPEND l_eabp TO xt_inteabp_db.
* Kopf deaktivieren
    l_eabp-deaktiv = l_eabp-opbel.
    l_eabp-debid   = co_true.
    APPEND l_eabp TO xt_s_eabp.
  ENDLOOP.

ENDFORM.                               " F21_EABP_FILL
*&---------------------------------------------------------------------*
*&      Form  f21_update_eabp_eabps
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_EABPS  text
*      -->P_LT_EABP_SAME  text
*      -->P_L_OBJ_INTEABP_DB  text
*----------------------------------------------------------------------*
FORM f21_update_eabp_eabps TABLES   pt_eabps         STRUCTURE eabps
                                    pt_eabp_same     STRUCTURE eabp
                                    p_obj_inteabp_db STRUCTURE eabp
                           USING    i_obj            TYPE fkkwh_whgrp
                                    i_kzabsver       LIKE eabp-kzabsver.

  DATA: l_sample_flag TYPE c.

  IF i_kzabsver NE co_absver_stat.
    l_sample_flag = co_flag_marked.
  ENDIF.

* Update der EABP
  CALL FUNCTION 'ISU_DB_EABP_UPDATE'
    EXPORTING
      x_upd_mode        = 'U'
    TABLES
      t_eabp            = pt_eabp_same
      t_eabp_old        = p_obj_inteabp_db
    EXCEPTIONS
      update_incomplete = 1
      modus_incorrect   = 2
      system_error      = 3
      OTHERS            = 4.
  IF sy-subrc <> 0.
    mac_msg_repeat co_msg_error update_incomplete.
  ENDIF.

* Update der EABPS (log. Sicht)
  CALL FUNCTION 'FKK_CREATE_DOC_FROM_LOGICAL'
    EXPORTING
      i_mode         = 'V'
      i_accumulate   = space
      ix_sample_flag = l_sample_flag
      i_calc_tax     = space
    TABLES
      i_logfkkop     = pt_eabps
      i_fkkko        = i_obj-merkifkkko
    EXCEPTIONS
      update_failed  = 1
      general_fault  = 2
      OTHERS         = 3.
  IF sy-subrc <> 0.
    mac_msg_putx co_msg_error sy-msgno sy-msgid
                 sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
                 update_incomplete.
  ENDIF.

ENDFORM.                    " f21_update_eabp_eabps
