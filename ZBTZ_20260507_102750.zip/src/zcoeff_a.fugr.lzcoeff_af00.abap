*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 25.03.2019 at 09:29:54
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .
