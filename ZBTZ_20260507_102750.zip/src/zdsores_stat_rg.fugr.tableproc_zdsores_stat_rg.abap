*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDSORES_STAT_RG
*   generation date: 07.04.2019 at 13:04:36
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDSORES_STAT_RG     .

  PERFORM TABLEPROC.

ENDFUNCTION.
